package com.realplugs;

import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.patryk3211.powergrid.electricity.base.ITerminalPlacement;
import org.patryk3211.powergrid.electricity.wire.powercord.AutoCordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.IAcceptCord;
import org.patryk3211.powergrid.electricity.wire.powercord.ICordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.ICordPlacementHandler;

/**
 * Registered in front of Power Grid's own handler. For a plug cord clicked on one of our outlets it picks the slot,
 * checks that the slot's connector standard matches the cord's plug and that the slot is free, then makes a cord end
 * on that slot's tap terminal (2 + slot) and the neutral bus, so only that slot is powered by the cord. Anything else (other blocks, other cords) is passed on untouched.
 */
public class PlugCordHandler implements ICordPlacementHandler {
    private final IAcceptCord.Handler stock = new IAcceptCord.Handler();

    @Override
    public InteractionResultHolder<ICordEndpoint> place(BlockState state, UseOnContext ctx) {
        if (!(ctx.getItemInHand().getItem() instanceof PlugCordItem) || !(state.getBlock() instanceof PlugSocketBlock block)) {
            return InteractionResultHolder.pass(null);
        }
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        BlockPos pos = ctx.getClickedPos();
        int slot = block.slotAtHit(state, pos, ctx.getClickLocation());
        PlugTypes.Standard want = PlugCordItem.standardOf(ctx.getItemInHand());
        PlugTypes.Standard have = block.def.slots()[slot];

        if (want != have) {
            tell(level, player, Component.translatable("message.realplugs.cord_wrong_slot",
                    Component.translatable(want.langKey()), Component.translatable(have.langKey())));
            return InteractionResultHolder.fail(null);
        }
        if (level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be
                && (!be.plugs().get(slot).isEmpty() || be.hasCord(slot))) {
            tell(level, player, Component.translatable("message.realplugs.cord_slot_taken"));
            return InteractionResultHolder.fail(null);
        }
        return InteractionResultHolder.success(
                new AutoCordEndpoint(pos, 2 + slot, 1, ctx.getClickLocation(), ctx.getClickedFace()));
    }

    @Override
    public ITerminalPlacement terminal(BlockState state, Level level, BlockHitResult hit) {
        return stock.terminal(state, level, hit);
    }

    private static void tell(Level level, Player player, Component msg) {
        if (!level.isClientSide && player != null) player.displayClientMessage(msg, true);
    }
}
