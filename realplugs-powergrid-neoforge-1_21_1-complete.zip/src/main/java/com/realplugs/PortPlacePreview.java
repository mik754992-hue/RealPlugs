package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RenderLevelStageEvent;

/**
 * While you hold a port and look at a CC: Tweaked block, outline the exact spot it would be placed in, like the
 * connector box Power Grid shows for cords. Green when sneaking (that is what places it), white otherwise.
 */
@EventBusSubscriber(modid = RealPlugsMod.MODID, value = Dist.CLIENT)
public class PortPlacePreview {
    private static final double HALF = 0.1;     // half the port width in blocks
    private static final double DEPTH = 0.04;   // how far it sticks out

    @SubscribeEvent
    public static void onRender(RenderLevelStageEvent event) {
        if (event.getStage() != RenderLevelStageEvent.Stage.AFTER_TRIPWIRE_BLOCKS) return;
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        if (player == null || mc.level == null) return;
        if (!(player.getMainHandItem().getItem() instanceof PortItem) && !(player.getOffhandItem().getItem() instanceof PortItem)) return;
        if (!(mc.hitResult instanceof BlockHitResult hit) || hit.getType() != HitResult.Type.BLOCK) return;
        var key = BuiltInRegistries.BLOCK.getKey(mc.level.getBlockState(hit.getBlockPos()).getBlock());
        if (!PortPlaceHandler.isPortHost(key)) return;

        // same snapping as PortPlaceHandler
        Vec3 p = hit.getLocation();
        Vec3 at = new Vec3(Math.round(p.x * 16) / 16.0, Math.round(p.y * 16) / 16.0, Math.round(p.z * 16) / 16.0);
        Direction f = hit.getDirection();
        double hx = f.getAxis() == Direction.Axis.X ? 0 : HALF;
        double hy = f.getAxis() == Direction.Axis.Y ? 0 : HALF;
        double hz = f.getAxis() == Direction.Axis.Z ? 0 : HALF;
        AABB box = new AABB(at.x - hx, at.y - hy, at.z - hz, at.x + hx, at.y + hy, at.z + hz)
                .expandTowards(f.getStepX() * DEPTH, f.getStepY() * DEPTH, f.getStepZ() * DEPTH);

        Vec3 cam = event.getCamera().getPosition();
        PoseStack ps = event.getPoseStack();
        MultiBufferSource.BufferSource buffers = mc.renderBuffers().bufferSource();
        VertexConsumer lines = buffers.getBuffer(RenderType.lines());
        boolean ready = player.isShiftKeyDown();
        LevelRenderer.renderLineBox(ps, lines, box.move(-cam.x, -cam.y, -cam.z),
                ready ? 0.2f : 1f, ready ? 1f : 1f, ready ? 0.2f : 1f, 1f);
        buffers.endBatch(RenderType.lines());
    }
}
