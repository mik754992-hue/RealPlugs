package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

public class PlugEntityRenderer extends EntityRenderer<PlugEntity> {
    public PlugEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(PlugEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
        ItemStack stack = e.getStack();
        if (stack.isEmpty()) return;

        Direction f = e.getFace();
        ps.pushPose();
        if (f.getAxis().isHorizontal()) {
            ps.mulPose(Axis.YP.rotationDegrees(-f.toYRot()));
        } else {
            ps.mulPose(Axis.XP.rotationDegrees(f == Direction.UP ? -90f : 90f));
        }
        ps.scale(0.35f, 0.35f, 0.35f);

        var items = Minecraft.getInstance().getItemRenderer();
        items.renderStatic(stack, ItemDisplayContext.FIXED, light, 0, ps, buf, e.level(), e.getId());

        ItemStack inner = PlugItem.inner(stack);
        if (!inner.isEmpty()) {
            ps.translate(0, 0, 0.45);
            ps.scale(0.9f, 0.9f, 0.9f);
            items.renderStatic(inner, ItemDisplayContext.FIXED, light, 0, ps, buf, e.level(), e.getId() + 100);
        }
        ps.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(PlugEntity e) {
        return ResourceLocation.withDefaultNamespace("textures/misc/white.png");
    }
}
