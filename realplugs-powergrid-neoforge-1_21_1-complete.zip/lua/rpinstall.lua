-- rpinstall: fetch all the Real Plugs programs from a file server in one go. Self-contained, so it is small enough to type in:
--   on the server computer (it has the lua folder):   rpfiles serve 1 <folder with the .lua files>
--   on a new computer:                                rpinstall <server> [slot] [folder]
-- It asks the server for its file list (rpfiles protocol, port 21) and saves every rp*.lua file next to itself.
local args = { ... }
if not args[1] then print("rpinstall <server> [slot] [remote folder]"); return end
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)
local slot = tonumber(args[2]) or 1
local folder = args[3] or ""

local function ask(request)
  local id, why = nic.connect(slot, args[1], 21)
  if not id then error(why or "cannot connect to " .. args[1], 0) end
  local buf, sent = "", false
  local timer = os.startTimer(20)
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then return nil, "timed out" end
    if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot and ev[5] == id then
      if ev[4] == "connected" and not sent then nic.tcpSend(slot, id, request .. "\n"); sent = true
      elseif ev[4] == "data" then
        buf = buf .. tostring(ev[6])
        local len, rest = buf:match("^OK (%d+)\n(.*)$")
        if len and #rest >= tonumber(len) then pcall(nic.tcpClose, slot, id); return rest:sub(1, tonumber(len)) end
        local bad = buf:match("^ERR ([^\n]*)")
        if bad then pcall(nic.tcpClose, slot, id); return nil, bad end
      elseif ev[4] == "closed" or ev[4] == "refused" then return nil, "connection closed" end
    end
  end
end

local list, why = ask("LS " .. folder)
if not list then error("cannot list files: " .. tostring(why), 0) end
local n = 0
for line in list:gmatch("[^\r\n]+") do
  local name, kind = line:match("^(.-)\t(.*)$")
  if name and kind ~= "dir" and name:match("^rp[%w_]*%.lua$") then
    local data, err = ask("GET " .. (folder ~= "" and folder .. "/" or "") .. name)
    if data then
      local f = fs.open(name, "w"); f.write(data); f.close()
      n = n + 1; print("installed " .. name .. " (" .. #data .. " bytes)")
    else print("failed " .. name .. ": " .. tostring(err)) end
  end
end
print(n .. " programs installed")
