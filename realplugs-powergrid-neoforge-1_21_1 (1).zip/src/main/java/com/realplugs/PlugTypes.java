package com.realplugs;

/**
 * GENERATED from the model generator - connector standards, plug types and adapter types.
 * The array index of a plug/adapter is its custom_model_data value.
 * A plug fits a socket only when plug.plugs() == the socket's standard; an adapter fits a plug when
 * plug.plugs() == adapter.accepts(), and then itself plugs into whatever adapter.plugs() says.
 */
public final class PlugTypes {
    public enum Standard {
        US_POWER("us_power", false),
        EU_POWER("eu_power", false),
        UK_POWER("uk_power", false),
        USB_A("usb_a", true),
        USB_C("usb_c", true),
        HDMI("hdmi", true),
        RJ45("rj45", true),
        BARREL("barrel", true),
        AU_POWER("au_power", false),
        MICRO_USB("micro_usb", true),
        DISPLAYPORT("displayport", true);

        public final String key;
        /** Device-side connectors can be attached to computers; mains plugs cannot. */
        public final boolean deviceSide;

        Standard(String key, boolean deviceSide) {
            this.key = key;
            this.deviceSide = deviceSide;
        }

        public String langKey() { return "standard.realplugs." + key; }
    }

    public record PlugDef(String name, Standard plugs) {}

    /** accepts = what the front sockets take, plugs = what the back plugs into, sockets = front socket positions in model units. */
    public record AdapterDef(String name, Standard accepts, Standard plugs, float[][] sockets) {}

    public static final PlugDef[] PLUGS = {
        new PlugDef("placeholder", Standard.US_POWER),
        new PlugDef("usb_a", Standard.USB_A),
        new PlugDef("usb_c", Standard.USB_C),
        new PlugDef("us_plug", Standard.US_POWER),
        new PlugDef("eu_plug", Standard.EU_POWER),
        new PlugDef("hdmi", Standard.HDMI),
        new PlugDef("ethernet", Standard.RJ45),
        new PlugDef("barrel", Standard.BARREL),
        new PlugDef("uk_plug", Standard.UK_POWER),
        new PlugDef("au_plug", Standard.AU_POWER),
        new PlugDef("micro_usb", Standard.MICRO_USB),
        new PlugDef("displayport", Standard.DISPLAYPORT)
    };

    public static final AdapterDef[] ADAPTERS = {
        new AdapterDef("placeholder", Standard.US_POWER, Standard.US_POWER, new float[][]{{8f, 8f}}),
        new AdapterDef("us_to_eu", Standard.US_POWER, Standard.EU_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("usb_wall", Standard.USB_A, Standard.US_POWER, new float[][]{{8f, 8f}}),
        new AdapterDef("hdmi_to_usb_c", Standard.HDMI, Standard.USB_C, new float[][]{{8f, 8f}}),
        new AdapterDef("multi_tap", Standard.US_POWER, Standard.US_POWER, new float[][]{{3.2f, 7.8f}, {8f, 7.8f}, {12.8f, 7.8f}}),
        new AdapterDef("eu_to_us", Standard.EU_POWER, Standard.US_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("us_to_uk", Standard.US_POWER, Standard.UK_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("uk_to_us", Standard.UK_POWER, Standard.US_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("usbc_wall", Standard.USB_C, Standard.US_POWER, new float[][]{{8f, 8f}}),
        new AdapterDef("usb_a_to_c", Standard.USB_A, Standard.USB_C, new float[][]{{8f, 8f}}),
        new AdapterDef("multi_tap_eu", Standard.EU_POWER, Standard.EU_POWER, new float[][]{{3.2f, 7.8f}, {8f, 7.8f}, {12.8f, 7.8f}}),
        new AdapterDef("us_to_au", Standard.US_POWER, Standard.AU_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("au_to_us", Standard.AU_POWER, Standard.US_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("eu_to_uk", Standard.EU_POWER, Standard.UK_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("uk_to_eu", Standard.UK_POWER, Standard.EU_POWER, new float[][]{{8f, 8.5f}}),
        new AdapterDef("microusb_wall", Standard.MICRO_USB, Standard.US_POWER, new float[][]{{8f, 8f}}),
        new AdapterDef("dp_to_hdmi", Standard.DISPLAYPORT, Standard.HDMI, new float[][]{{8f, 8f}})
    };

    public static PlugDef plug(int type) { return PLUGS[type >= 0 && type < PLUGS.length ? type : 0]; }
    public static AdapterDef adapter(int type) { return ADAPTERS[type >= 0 && type < ADAPTERS.length ? type : 0]; }

    private PlugTypes() {}
}
