package com.realplugs.net;

import net.minecraft.nbt.CompoundTag;

import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Network settings of one socket: one set per slot (each RJ45 slot is its own interface), plus the router and bridge
 * switches that apply to the whole socket. Saved with the block entity.
 */
public final class NetConfig {
    public static final int MAX = 8;

    public final String[] ip = new String[MAX];
    public final int[] prefix = new int[MAX];
    public final String[] gateway = new String[MAX];
    public final boolean[] uplink = new boolean[MAX];
    public final boolean[] dhcp = new boolean[MAX];
    public final String[] hostname = new String[MAX];
    /** Forward packets between this socket's interfaces (a router). */
    public boolean routing;
    /** All RJ45 slots of this socket form one segment (a switch). */
    public boolean bridge;
    /** The Network Router block has had its factory settings applied. */
    public boolean configured;
    /** Port forwarding of a router: public port -> "ip:port" of a private host. */
    public final Map<Integer, String> forwards = new HashMap<>();

    // ---- DHCP server and local DNS (socket-wide, used by any port that has dhcp on) ----
    /** First and last address a DHCP server hands out, as an offset inside the port's network (0 = the default). */
    public final int[] dhcpFirst = new int[MAX];
    public final int[] dhcpLast = new int[MAX];
    /** MAC address -> address the server gave it last time (the same port gets the same address again). Oldest first. */
    public final Map<String, String> leases = new LinkedHashMap<>();
    /** MAC address -> address that is always given to that port. */
    public final Map<String, String> reservations = new LinkedHashMap<>();
    /** Local DNS records: name -> address. Every port in the segment can resolve them. */
    public final Map<String, String> dnsRecords = new LinkedHashMap<>();

    // ---- firewall (rules are checked in order, the first that matches decides) ----
    public record FwRule(String action, String dir, String proto, String src, String dst, int port) {}

    public final List<FwRule> rules = new ArrayList<>();
    /** What happens to a packet no rule matches: allow, reject (the sender is told) or drop (silence). */
    public String fwPolicy = "allow";
    /** Packets the firewall stopped since the world was loaded. Not saved. */
    public int fwBlocked;

    // ---- Wi-Fi ----
    /** Client side, per port: the network this port joined by radio (instead of, or next to, a cable). */
    public final String[] wifiSsid = new String[MAX];
    public final String[] wifiKey = new String[MAX];
    /** Access point block: its network name, password (empty = open) and range in blocks. */
    public String apSsid = "";
    public String apKey = "";
    public int apRange;

    /** NAT table of a router, not saved: private "ip:port" -> public port, and back. */
    public final Map<String, Integer> natOut = new HashMap<>();
    public final Map<Integer, String> natIn = new HashMap<>();
    public int nextNatPort = 49152;

    public String ip(int slot) {
        return ip[slot] == null ? "" : ip[slot];
    }

    public String hostname(int slot) {
        return hostname[slot] == null ? "" : hostname[slot];
    }

    public String gateway(int slot) {
        return gateway[slot] == null ? "" : gateway[slot];
    }

    public String wifiSsid(int slot) {
        return wifiSsid[slot] == null ? "" : wifiSsid[slot];
    }

    public String wifiKey(int slot) {
        return wifiKey[slot] == null ? "" : wifiKey[slot];
    }

    private boolean slotIsDefault(int i) {
        return ip(i).isEmpty() && gateway(i).isEmpty() && !uplink[i] && !dhcp[i] && hostname(i).isEmpty()
                && dhcpFirst[i] == 0 && dhcpLast[i] == 0 && wifiSsid(i).isEmpty();
    }

    public boolean isEmpty() {
        if (routing || bridge || configured || !forwards.isEmpty()) return false;
        if (!leases.isEmpty() || !reservations.isEmpty() || !dnsRecords.isEmpty() || !rules.isEmpty()) return false;
        if (!"allow".equals(fwPolicy) || !apSsid.isEmpty() || !apKey.isEmpty() || apRange != 0) return false;
        for (int i = 0; i < MAX; i++) {
            if (!slotIsDefault(i)) return false;
        }
        return true;
    }

    private static CompoundTag mapTag(Map<String, String> m) {
        CompoundTag t = new CompoundTag();
        for (Map.Entry<String, String> e : m.entrySet()) t.putString(e.getKey(), e.getValue());
        return t;
    }

    private static void loadMap(CompoundTag t, Map<String, String> into) {
        into.clear();
        for (String k : t.getAllKeys()) into.put(k, t.getString(k));
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("Routing", routing);
        t.putBoolean("Bridge", bridge);
        t.putBoolean("Configured", configured);
        CompoundTag fwd = new CompoundTag();
        for (Map.Entry<Integer, String> e : forwards.entrySet()) fwd.putString(Integer.toString(e.getKey()), e.getValue());
        t.put("Fwd", fwd);
        if (!leases.isEmpty()) t.put("Leases", mapTag(leases));
        if (!reservations.isEmpty()) t.put("Resv", mapTag(reservations));
        if (!dnsRecords.isEmpty()) t.put("Dns", mapTag(dnsRecords));
        if (!rules.isEmpty()) {
            ListTag list = new ListTag();
            for (FwRule r : rules) {
                CompoundTag e = new CompoundTag();
                e.putString("Action", r.action());
                e.putString("Dir", r.dir());
                e.putString("Proto", r.proto());
                e.putString("Src", r.src());
                e.putString("Dst", r.dst());
                e.putInt("Port", r.port());
                list.add(e);
            }
            t.put("Rules", list);
        }
        t.putString("FwPolicy", fwPolicy);
        if (!apSsid.isEmpty()) t.putString("ApSsid", apSsid);
        if (!apKey.isEmpty()) t.putString("ApKey", apKey);
        t.putInt("ApRange", apRange);
        for (int i = 0; i < MAX; i++) {
            if (slotIsDefault(i)) continue;
            CompoundTag s = new CompoundTag();
            s.putString("Ip", ip(i));
            s.putInt("Prefix", prefix[i]);
            s.putString("Gw", gateway(i));
            s.putBoolean("Uplink", uplink[i]);
            s.putBoolean("Dhcp", dhcp[i]);
            s.putString("Host", hostname(i));
            s.putInt("DhcpFirst", dhcpFirst[i]);
            s.putInt("DhcpLast", dhcpLast[i]);
            s.putString("Wifi", wifiSsid(i));
            s.putString("WifiKey", wifiKey(i));
            t.put("S" + i, s);
        }
        return t;
    }

    public void load(CompoundTag t) {
        routing = t.getBoolean("Routing");
        bridge = t.getBoolean("Bridge");
        configured = t.getBoolean("Configured");
        forwards.clear();
        CompoundTag fwd = t.getCompound("Fwd");
        for (String k : fwd.getAllKeys()) {
            try {
                forwards.put(Integer.parseInt(k), fwd.getString(k));
            } catch (NumberFormatException ignored) {
                // a damaged entry is dropped
            }
        }
        loadMap(t.getCompound("Leases"), leases);
        loadMap(t.getCompound("Resv"), reservations);
        loadMap(t.getCompound("Dns"), dnsRecords);
        rules.clear();
        for (Tag e : t.getList("Rules", Tag.TAG_COMPOUND)) {
            CompoundTag r = (CompoundTag) e;
            rules.add(new FwRule(r.getString("Action"), r.getString("Dir"), r.getString("Proto"), r.getString("Src"),
                    r.getString("Dst"), r.getInt("Port")));
        }
        fwPolicy = t.contains("FwPolicy") ? t.getString("FwPolicy") : "allow";
        apSsid = t.getString("ApSsid");
        apKey = t.getString("ApKey");
        apRange = t.getInt("ApRange");
        for (int i = 0; i < MAX; i++) {
            if (!t.contains("S" + i)) {   // nothing saved = factory state (matters when a synced update replaces old values)
                ip[i] = null;
                prefix[i] = 0;
                gateway[i] = null;
                uplink[i] = false;
                dhcp[i] = false;
                hostname[i] = null;
                dhcpFirst[i] = 0;
                dhcpLast[i] = 0;
                wifiSsid[i] = null;
                wifiKey[i] = null;
                continue;
            }
            CompoundTag s = t.getCompound("S" + i);
            ip[i] = s.getString("Ip");
            prefix[i] = s.getInt("Prefix");
            gateway[i] = s.getString("Gw");
            uplink[i] = s.getBoolean("Uplink");
            dhcp[i] = s.getBoolean("Dhcp");
            hostname[i] = s.getString("Host");
            dhcpFirst[i] = s.getInt("DhcpFirst");
            dhcpLast[i] = s.getInt("DhcpLast");
            wifiSsid[i] = s.getString("Wifi");
            wifiKey[i] = s.getString("WifiKey");
        }
    }

    // ---- IPv4 helpers ----

    /** "a.b.c.d" to a number, or -1. */
    public static long parse(String s) {
        if (s == null || s.isEmpty()) return -1;
        String[] p = s.trim().split("\\.");
        if (p.length != 4) return -1;
        long v = 0;
        for (String x : p) {
            int n;
            try {
                n = Integer.parseInt(x);
            } catch (NumberFormatException e) {
                return -1;
            }
            if (n < 0 || n > 255) return -1;
            v = (v << 8) | n;
        }
        return v;
    }

    public static String format(long v) {
        return ((v >> 24) & 255) + "." + ((v >> 16) & 255) + "." + ((v >> 8) & 255) + "." + (v & 255);
    }

    /** Are both addresses in the same network of this prefix length (1..32)? */
    public static boolean sameSubnet(long a, long b, int prefix) {
        if (prefix < 1 || prefix > 32) return false;
        long mask = prefix == 32 ? 0xFFFFFFFFL : (0xFFFFFFFFL << (32 - prefix)) & 0xFFFFFFFFL;
        return (a & mask) == (b & mask);
    }

    // ---- firewall helpers ----

    /** "any", one address, or "a.b.c.d/n". */
    public static boolean validSpec(String spec) {
        if (spec == null) return false;
        String s = spec.trim();
        if (s.equals("any")) return true;
        int slash = s.indexOf('/');
        if (slash < 0) return parse(s) >= 0;
        if (parse(s.substring(0, slash)) < 0) return false;
        try {
            int n = Integer.parseInt(s.substring(slash + 1));
            return n >= 0 && n <= 32;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /** Does this address fall under the spec? */
    public static boolean inSpec(String spec, long ip) {
        if (spec.equals("any")) return true;
        int slash = spec.indexOf('/');
        if (slash < 0) return parse(spec) == ip;
        long base = parse(spec.substring(0, slash));
        int n = Integer.parseInt(spec.substring(slash + 1));
        if (n == 0) return true;
        return sameSubnet(base, ip, n);
    }
}
