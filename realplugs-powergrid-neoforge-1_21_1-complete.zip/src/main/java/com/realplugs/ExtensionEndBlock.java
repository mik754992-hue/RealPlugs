package com.realplugs;

/**
 * The strip end of an extension cable, placed on a surface. It is an ordinary multi-slot outlet whose hot and neutral
 * buses are fed by the cable; it removes itself when the cable is gone (see PlugSocketBlockEntity.tick).
 */
public class ExtensionEndBlock extends PlugSocketBlock {
    public ExtensionEndBlock(Properties props, SocketDef def) {
        super(props, def);
    }
}
