package com.realplugs;

import com.mojang.math.Axis;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.UUID;

/**
 * A pay-to-charge EV charger: one slot of an EV connector, fed by the input connectors on its sides like any outlet.
 * The slot only passes power while there is credit, and the credit runs down per minute while something is plugged in
 * or a cord is attached. Pay by right-clicking the gold coin panel on the front with coins (sneak to insert the whole
 * stack). Coin values come from item tags, see EvCoins.
 *
 * Every charger has a built-in cord: its connector sits docked in the socket. Right-click the socket (or the cable
 * gland below the coin panel) with an empty hand to pull the cord out, and again to put it back. While it is out the
 * slot counts as occupied, exactly as if a cord were plugged in (the slot closes and the credit runs down); it docks
 * itself if you walk more than PocketTether.RANGE away. A plug placed in the socket works as before.
 *
 * A charger is two blocks high: this block (socket, coin plate, gland, all the logic) and an EvChargerTopBlock above it
 * (screen and buttons). The buttons: - / + change the price per minute (sneak = steps of 8), the padlock toggles private
 * mode, STOP ends the session. The player who placed the charger is its owner: only the owner can change the price and
 * the mode. In private mode only the owner can use it, for free; Power Grid cords do not power a private charger (use the
 * built-in cord or a plug).
 *
 * A charger is two blocks high: this block (socket, coin plate, gland, all the logic) and an EvChargerTopBlock above it
 * (screen and buttons). The buttons: - / + change the price per minute, the padlock toggles private mode, STOP ends the
 * session. The player who placed the charger is its owner: only the owner can change the price and the mode. In private
 * mode only the owner can use it, for free; Power Grid cords do not power a private charger (use the built-in cord or a plug).
 */
public class EvChargerBlock extends PlugSocketBlock {
    private final int pricePerMinute;

    public EvChargerBlock(Properties props, SocketDef def, int pricePerMinute) {
        super(props, def);
        this.pricePerMinute = pricePerMinute;
    }

    public int pricePerMinute() {
        return pricePerMinute;
    }

    /** Spurs per minute: wall boxes are cheap, fast chargers cost more. */
    public static int pricePerMinute(String id) {
        return switch (id) {
            case "ev_charger_type1", "ev_charger_type2" -> 2;
            case "ev_charger_ccs", "ev_charger_chademo" -> 6;
            default -> 8;
        };
    }

    /** Chargers stand upright (on a floor or ceiling they face the way the player looks) and need two free blocks. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Level level = ctx.getLevel();
        BlockPos up = ctx.getClickedPos().above();
        if (up.getY() >= level.getMaxBuildHeight() || !level.getBlockState(up).canBeReplaced(ctx)) return null;
        Direction d = ctx.getClickedFace().getAxis().isHorizontal() ? ctx.getClickedFace() : ctx.getHorizontalDirection().getOpposite();
        return defaultBlockState().setValue(FACING, d);
    }

    /** Places the upper half and remembers who placed the charger (the owner may set the fee and make it private). */
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.isClientSide) return;
        Direction d = state.getValue(FACING);
        if (!d.getAxis().isHorizontal()) d = Direction.NORTH;
        level.setBlock(pos.above(), ModBlocks.EV_TOPS.get(def.id()).get().defaultBlockState()
                .setValue(EvChargerTopBlock.FACING, d), 3);
        if (placer instanceof Player player && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
            be.setOwner(player);
        }
    }

    /** If the upper half goes, so does this one (and the other way round, see EvChargerTopBlock). */
    @Override
    protected BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                     BlockPos pos, BlockPos neighborPos) {
        if (dir == Direction.UP && !(neighbor.getBlock() instanceof EvChargerTopBlock)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    /** Position (viewer units: x from the viewer's left edge, y up, z depth) of a hit on a block facing horizontally. */
    public static Vector3f viewerPoint(Direction f, BlockPos pos, Vec3 hit) {
        Vector3f p = frontPointStatic(f, pos, hit);
        return new Vector3f(16f - p.x, p.y, p.z);
    }

    private static Vector3f frontPointStatic(Direction f, BlockPos pos, Vec3 hit) {
        if (!f.getAxis().isHorizontal()) return new Vector3f(-1, -1, -1);
        Quaternionf q = Axis.YP.rotationDegrees(-(f.toYRot() + 180f));
        Vector3f v = new Vector3f((float) (hit.x - pos.getX() - 0.5), (float) (hit.y - pos.getY() - 0.5), (float) (hit.z - pos.getZ() - 0.5));
        q.conjugate(new Quaternionf()).transform(v);
        return new Vector3f((v.x + 0.5f) * 16f, (v.y + 0.5f) * 16f, (v.z + 0.5f) * 16f);
    }

    private void tell(Player player, String key, Object... args) {
        player.displayClientMessage(Component.translatable("message.realplugs." + key, args), true);
    }

    /** What the screen says, as a chat-bar message. */
    public void sendStatus(Level level, BlockPos pos, Player player) {
        if (!(level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be)) return;
        if (be.isPersonal()) tell(player, "ev_status_private", be.ownerName());
        else if (be.isStopped()) tell(player, "ev_status_stopped", be.credit());
        else tell(player, "ev_status", be.credit(), be.feePerMinute(this));
    }

    /** STOP: the part of the credit that was paid by card goes back into the card's bank account (the deposit call). */
    private int refundToCard(PlugSocketBlockEntity be) {
        int amount = be.cardCredit();
        if (amount <= 0 || be.isPersonal() || be.cardAccount() == null
                || !net.neoforged.fml.ModList.get().isLoaded("numismatics")) return 0;
        if (!com.realplugs.numismatics.NumismaticsPay.refund(be.cardAccount(), amount)) return 0;
        be.takeCardCredit(amount);
        return amount;
    }

    /** STOP: whatever credit is left goes back to the player as coins (the biggest first). Returns the amount given. */
    private int giveChange(PlugSocketBlockEntity be, Player player) {
        if (be.isPersonal() || be.credit() <= 0) return 0;
        java.util.List<ItemStack> coins = new java.util.ArrayList<>();
        int paid = be.credit() - EvCoins.makeChange(be.credit(), coins);
        if (paid <= 0) return 0;
        be.takeCredit(paid);
        for (ItemStack coin : coins) {
            if (!player.getInventory().add(coin) && !coin.isEmpty()) player.drop(coin, false);
        }
        return paid;
    }

    /** A press on the screen or one of the buttons of the upper half (zone from EvChargerTopBlock). */
    public void pressPanel(Level level, BlockPos pos, Player player, int zone) {
        if (!(level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be)) return;
        if (zone == EvChargerTopBlock.SCREEN) {
            sendStatus(level, pos, player);
            return;
        }
        if (be.isPersonal() && !be.isOwnerOrUnowned(player)) {
            tell(player, "ev_private", be.ownerName());
            return;
        }
        if (zone == EvChargerTopBlock.BTN_STOP) {
            be.setStopped(!be.isStopped());
            if (!be.isStopped()) {
                tell(player, "ev_resumed");
            } else if (be.credit() > 0 && !be.isPersonal() && be.creditPayer() != null
                    && !be.creditPayer().equals(player.getUUID())) {
                tell(player, "ev_stopped_keep", be.credit());   // somebody else's money: no change for you
            } else {
                int toCard = refundToCard(be);
                int change = giveChange(be, player);
                if (toCard > 0) tell(player, "ev_stopped_refund", toCard, change);
                else if (change > 0) tell(player, "ev_stopped_change", change);
                else tell(player, "ev_stopped");
            }
            return;
        }
        if (!be.isOwnerOrUnowned(player)) {
            tell(player, "ev_not_owner", be.ownerName());
            return;
        }
        if (zone == EvChargerTopBlock.BTN_MODE) {
            be.setPersonal(!be.isPersonal());
            tell(player, be.isPersonal() ? "ev_mode_private" : "ev_mode_public");
            return;
        }
        int step = player.isShiftKeyDown() ? 8 : 1;
        int now = be.feePerMinute(this);
        be.setFee(zone == EvChargerTopBlock.BTN_PLUS ? now + step : now - step);
        tell(player, "ev_fee_set", be.feePerMinute(this));
    }

    /** Where on the front plate (north frame, 1/16 units: x to the viewer's left, y up) a world hit position is. */
    private Vector3f frontPoint(BlockState state, BlockPos pos, Vec3 hit) {
        return frontPointStatic(state.getValue(FACING), pos, hit);
    }

    /** The gold coin panel on the front. */
    private boolean onCoinPanel(BlockState state, BlockPos pos, BlockHitResult hit) {
        Vector3f p = frontPoint(state, pos, hit.getLocation());
        return p.x >= 5 && p.x <= 11 && p.y >= 2.5f && p.y <= 5.5f;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
            if (be.isPersonal() && !be.isOwnerOrUnowned(player)) {
                if (!level.isClientSide) tell(player, "ev_private", be.ownerName());
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (BuiltinCord.isMarked(held)) {
                if (!level.isClientSide && onCordDock(frontPoint(state, pos, hit.getLocation())) && tryDock(be, held, player)) {
                    return ItemInteractionResult.SUCCESS;
                }
                // anything else with the cord in hand (an EV port, another block) is Power Grid's cord handling
                return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
            }
            int coin = EvCoins.valueOf(held);
            if (coin > 0 && onCoinPanel(state, pos, hit)) {
                if (!level.isClientSide) {
                    int n = player.isShiftKeyDown() ? held.getCount() : 1;
                    be.addCredit(coin * n, player.getUUID());
                    if (!player.getAbilities().instabuild) held.shrink(n);
                    player.displayClientMessage(Component.translatable("message.realplugs.ev_credit", be.credit(), be.feePerMinute(this)), true);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (EvCoins.isNumismaticsCard(held) && onCoinPanel(state, pos, hit)) {
                if (!level.isClientSide) payByCard(be, held, player);
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return super.useItemOn(held, state, level, pos, player, hand, hit);
    }

    /** The dock (the connector socket) and the cable gland, where the built-in cord is pulled out and put back. */
    private boolean onCordDock(Vector3f p) {
        boolean socket = p.x >= 5 && p.x <= 11 && p.y >= 6 && p.y <= 12;
        boolean gland = p.x >= 10.8f && p.x <= 13 && p.y >= 1.4f && p.y <= 3.4f;
        return socket || gland;
    }

    /** Empty hand on the dock: pull the built-in cord out, or put it back if you are the one holding it. */
    private void toggleBuiltinCord(PlugSocketBlockEntity be, Level level, Player player) {
        if (be.hasPgCord(0)) {
            player.displayClientMessage(Component.translatable("message.realplugs.cord_slot_taken"), true);
        } else if (be.builtinCordHolder() != null) {
            if (be.builtinCordHolder().equals(player.getUUID())) {
                be.dockBuiltinCord();
                player.displayClientMessage(Component.translatable("message.realplugs.ev_cord_docked"), true);
            } else {
                player.displayClientMessage(Component.translatable("message.realplugs.ev_cord_in_use"), true);
            }
        } else if (be.tetherOwner(0) != null) {
            player.displayClientMessage(Component.translatable("message.realplugs.ev_cord_in_use"), true);
        } else {
            ItemStack cord = BuiltinCord.make(level, be.getBlockPos(), level.getBlockState(be.getBlockPos()), this);
            if (cord.isEmpty()) {
                tell(player, "ev_cord_unavailable");
                return;
            }
            player.setItemInHand(InteractionHand.MAIN_HAND, cord);
            be.pullBuiltinCord(player, level.getGameTime());
            player.displayClientMessage(Component.translatable(be.credit() > 0 || be.isPersonal()
                    ? "message.realplugs.ev_cord_out" : "message.realplugs.ev_cord_out_no_credit"), true);
        }
    }

    /** Each tap of a card pays for this many minutes at the charger's price (but never less than 16 spurs). */
    private static final int CARD_MINUTES = 10;

    /** A Create: Numismatics card on the coin plate: take money from its account and add it as credit. */
    private void payByCard(PlugSocketBlockEntity be, ItemStack card, Player player) {
        if (!net.neoforged.fml.ModList.get().isLoaded("numismatics")) {
            tell(player, "ev_card_unsupported");
            return;
        }
        int spurs = Math.max(16, be.feePerMinute(this) * CARD_MINUTES);
        Component error = com.realplugs.numismatics.NumismaticsPay.pay(card, player, spurs);
        if (error != null) {
            player.displayClientMessage(error.copy().withStyle(net.minecraft.ChatFormatting.DARK_RED), true);
            return;
        }
        UUID account = com.realplugs.numismatics.NumismaticsPay.accountOf(card);
        if (account != null) be.addCardCredit(spurs, player.getUUID(), account);
        else be.addCredit(spurs, player.getUUID());
        tell(player, "ev_card_paid", spurs, be.credit(), be.feePerMinute(this));
    }

    /** Holding this charger's cord and clicking its dock: the cord goes back in. */
    private boolean tryDock(PlugSocketBlockEntity be, ItemStack held, Player player) {
        if (!BuiltinCord.belongsTo(held, be.getBlockPos()) || !player.getUUID().equals(be.builtinCordHolder())) return false;
        held.shrink(1);
        be.dockBuiltinCord();
        player.displayClientMessage(Component.translatable("message.realplugs.ev_cord_docked"), true);
        return true;
    }

    /** Empty hand on the panel or the screen: show the credit and price. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        Vector3f p = frontPoint(state, pos, hit.getLocation());
        if (level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be0 && be0.isPersonal() && !be0.isOwnerOrUnowned(player)) {
            if (!level.isClientSide) tell(player, "ev_private", be0.ownerName());
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (p.y >= 2.5f && p.y <= 15.5f && p.x >= 4 && p.x <= 12 && (p.y >= 12 || onCoinPanel(state, pos, hit))) {
            if (!level.isClientSide) sendStatus(level, pos, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (player.getMainHandItem().isEmpty() && onCordDock(p)
                && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be && be.plugs().get(0).isEmpty()) {
            if (!level.isClientSide) toggleBuiltinCord(be, level, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return super.useWithoutItem(state, level, pos, player, hit);
    }
}
