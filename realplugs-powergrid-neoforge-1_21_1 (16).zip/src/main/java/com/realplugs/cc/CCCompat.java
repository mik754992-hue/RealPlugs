package com.realplugs.cc;

import com.realplugs.ModBlockEntities;
import dan200.computercraft.api.peripheral.PeripheralCapability;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/** Only ever touched when CC: Tweaked is loaded (see RealPlugsMod), so the CC classes it references always exist. */
public final class CCCompat {
    private CCCompat() {}

    /** Called once from the mod constructor, only when CC: Tweaked is loaded. */
    public static void init(IEventBus modBus) {
        modBus.addListener(CCCompat::registerCapabilities);
        ModPocketUpgrades.TYPES.register(modBus);
    }

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(PeripheralCapability.get(), ModBlockEntities.SOCKET.get(),
                (be, side) -> new SocketPeripheral(be));
    }
}
