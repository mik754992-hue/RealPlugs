# Real Plugs for Create: Power Grid (NeoForge 1.21.1)

Wall outlets and power strips that are **real Create: Power Grid electrical blocks**, plus plugs,
cables and adapters you plug into them, and plugs you can stick onto CC: Tweaked computers.

Needs: Minecraft 1.21.1, NeoForge 21.1.x, Create 6.0.9+, Create: Power Grid 0.6.x (+ Architectury). CC: Tweaked optional.

## Build on GitHub
1. Push the contents of this folder to the root of a repo (keep `libs/`, it holds the Power Grid jar the build compiles against).
2. `.github/workflows/build.yml` runs on push. Download `realplugs-jar` from the run's Artifacts.
3. Put the jar in `mods/` next to Create, Power Grid and Architectury.

## How the outlets work electrically
Each outlet / power strip has these Power Grid terminals (use Power Grid wires or copper cords on them):
- **Red bar on top = hot bus.** Wire your supply's hot side here.
- **Blue bar at the bottom = neutral bus.** Supply neutral AND every device's return go here.
- **One small copper stud per slot = that slot's hot tap.** Wire the device's hot side here.

A slot's tap is connected to the hot bus **only while a plug (or adapter) is plugged into that slot**.
Unplug it and the tap is cut off. Outlet: 2 slots. Power Strip: 4 slots.

## How to play
- **Plugging in**: right-click a slot with a plug or adapter. Empty hand removes it (an adapter's inner plug comes out first).
- **Adapter in a socket**: plug an adapter in, then right-click it with a plug to plug into the adapter.
- **On a computer**: hold a plug/adapter, **sneak + right-click** a CC computer where you want it. These are visual only.
- Everything is in the **Real Plugs** creative tab. Place the outlets against a wall (the back sits on the clicked face).

## Models
Everything is a real 3D cuboid model, not a flat sprite. All colours come from one shared palette,
`assets/realplugs/textures/block/palette.png` (4x4 cells, each element samples one cell), so you can
re-colour every model by editing that one PNG.

Plug and adapter models share one orientation: the **cable / body side faces NORTH (-z, toward the viewer)** and the
**prongs / plug side point SOUTH (+z, into the socket)**. Keep that and your own model will sit correctly in a socket,
on a computer and inside an adapter.

## Add your own plug / cable / adapter
1. Add a name to `PlugTypes.java` (`PLUGS` or `ADAPTERS`). The array position is its custom_model_data number.
2. Make the model: copy `models/item/plug_usb_c.json` (or `adapter_*.json`) and edit it, or build one in Blockbench
   (keep the orientation above, keep `"display"` as it is, and use `realplugs:block/palette` or your own texture).
   Save it as `models/item/plug_<name>.json` (or `adapter_<name>.json`).
3. Add one line to the `overrides` list in `models/item/plug.json` (or `adapter.json`) with the matching number.
4. Add `item.realplugs.plug.<name>` to `lang/en_us.json`.

Give one by command: `/give @s realplugs:plug[custom_model_data=3]`

## Known gaps
- Plugs and adapters are visual markers: a plugged item only closes the slot contact, it does not carry its own load.
- Plugs on computers do nothing electrically. No pocket-computer plug yet.
- Untested build: dependency versions in `build.gradle` (Create `6.0.11-319`, Ponder, Flywheel, Registrate) may need adjusting.
