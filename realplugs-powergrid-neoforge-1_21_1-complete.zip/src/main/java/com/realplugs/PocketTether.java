package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Shared bits of the pocket computer tether: a pocket computer with a Real Plugs port can be linked to an outlet slot.
 * It acts like a cord (the slot shows a plug and a rope is drawn to your hand) but is not a Power Grid cord.
 *
 * Clicking a slot with the pocket computer only leaves a short-lived request here (the block has no access to the
 * computer's data); the port upgrade picks it up in its next tick and does the linking.
 */
public final class PocketTether {
    /** How far you can be from the slot before the tether snaps, in blocks. */
    public static final double RANGE = 10.0;

    public record Request(ResourceKey<Level> dim, BlockPos pos, int slot, long tick) {}

    private static final Map<UUID, Request> REQUESTS = new HashMap<>();   // server thread only

    private PocketTether() {}

    public static void request(UUID player, Request r) {
        REQUESTS.put(player, r);
    }

    /** The player's pending request if it is still fresh (a few ticks old at most). */
    public static Request take(UUID player, long now) {
        Request r = REQUESTS.remove(player);
        return r != null && now - r.tick() <= 5 ? r : null;
    }

    public static boolean isPocketComputer(ItemStack s) {
        var key = BuiltInRegistries.ITEM.getKey(s.getItem());
        return key.getNamespace().equals("computercraft") && key.getPath().startsWith("pocket_computer");
    }

    /** Does this pocket computer have a Real Plugs port equipped? (Read from its upgrade component's text form, so no CC internals are needed.) */
    public static boolean hasPortUpgrade(ItemStack s) {
        for (TypedDataComponent<?> c : s.getComponents()) {
            if (String.valueOf(c.value()).contains("realplugs:port")) return true;
        }
        return false;
    }
}
