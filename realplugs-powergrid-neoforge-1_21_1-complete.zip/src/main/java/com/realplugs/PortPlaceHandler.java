package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Sneak + right-click any CC: Tweaked block (computer, monitor, disk drive, printer, speaker, modem...) with a port
 * to stick it on at the exact spot you clicked, snapped to the 1/16 pixel grid. Matches blocks by registry
 * namespace, so there is no compile-time dependency on CC: Tweaked.
 */
@EventBusSubscriber(modid = RealPlugsMod.MODID)
public class PortPlaceHandler {
    /** Which blocks a port can be stuck on: see RealPlugsApi (CC: Tweaked and LittleTiles built in, others can register). */
    public static boolean isPortHost(ResourceLocation blockKey) {
        return com.realplugs.api.RealPlugsApi.isPortHost(blockKey);
    }

    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        ItemStack held = event.getItemStack();
        if (!(held.getItem() instanceof PortItem) || !player.isShiftKeyDown()) return;

        Level level = event.getLevel();
        BlockState state = level.getBlockState(event.getPos());
        ResourceLocation key = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        if (!isPortHost(key)) return;

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
        if (level.isClientSide) return;

        Vec3 hit = event.getHitVec().getLocation();
        hit = new Vec3(Math.round(hit.x * 16) / 16.0, Math.round(hit.y * 16) / 16.0, Math.round(hit.z * 16) / 16.0);
        PortEntity port = PortEntity.create(level, event.getPos(), event.getFace(), hit, PlugItem.takeOne(held, player));
        level.addFreshEntity(port);
        if (!port.installAnchor()) {
            player.displayClientMessage(net.minecraft.network.chat.Component.translatable("message.realplugs.port_no_cord_room"), true);
        }
    }
}
