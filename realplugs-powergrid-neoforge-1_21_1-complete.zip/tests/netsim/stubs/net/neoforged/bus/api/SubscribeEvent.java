package net.neoforged.bus.api; public @interface SubscribeEvent {}
