package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.patryk3211.powergrid.electricity.wire.powercord.AutoCordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

/**
 * An invisible one-slot "outlet" placed in the empty block in front of a port (see PortEntity). A computer has no
 * electrical side, so a cord has nothing to attach to; this block is what the cord end really sits on. The cord
 * is drawn ending exactly at the port.
 *
 * It only has a selection box while you hold a cord, so it never gets in the way of anything else, and it can only be
 * removed by removing its port.
 */
public class PortAnchorBlock extends PlugSocketBlock {
    public PortAnchorBlock(Properties props, SocketDef def) {
        super(props, def);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    /** A plate against the computer face, but only while a cord is in hand, so ordinary clicks pass through to the computer. */
    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        if (ctx instanceof EntityCollisionContext ecc && ecc.getEntity() instanceof Player p
                && (p.getMainHandItem().getItem() instanceof CordItem || p.getOffhandItem().getItem() instanceof CordItem)) {
            return super.getShape(state, level, pos, ctx);
        }
        return Shapes.empty();
    }

    /** The cord end sits on this block's slot, drawn at the port's exact spot. */
    @Override
    public AutoCordEndpoint getEndpoint(UseOnContext ctx) {
        BlockPos pos = ctx.getClickedPos();
        Level level = ctx.getLevel();
        PortEntity port = PortEntity.at(level, pos);
        Vec3 where = port != null ? port.position() : Vec3.atCenterOf(pos);
        Direction face = port != null ? port.getFace() : level.getBlockState(pos).getValue(FACING);
        return new AutoCordEndpoint(pos, 2, 1, where, face);
    }

    // nothing to plug into or open here: the port entity handles plugs
    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return InteractionResult.PASS;
    }
}
