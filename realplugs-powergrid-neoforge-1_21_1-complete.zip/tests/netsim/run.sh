#!/bin/sh
# Runs the network model (NetworkManager, NetConfig) against small stand-ins for the Minecraft classes, with scenarios
# for DHCP, DNS, firewall, NAT, Wi-Fi, VLANs, VPN tunnels, repeaters and guest isolation.
# Needs a JDK 17+ (javac). Run from the repo root:  sh tests/netsim/run.sh
set -e
OUT=$(mktemp -d)
mkdir -p "$OUT/src/com/realplugs/net"
cp -r tests/netsim/stubs/* "$OUT/src/"
cp src/main/java/com/realplugs/net/*.java "$OUT/src/com/realplugs/net/"
cp tests/netsim/T.java "$OUT/src/com/realplugs/net/"
if command -v javac >/dev/null 2>&1; then JAVAC=javac; else JAVAC="java -m jdk.compiler/com.sun.tools.javac.Main"; fi
$JAVAC -d "$OUT/classes" $(find "$OUT/src" -name '*.java')
java -cp "$OUT/classes" com.realplugs.net.T | tail -${TAIL:-5}
rm -rf "$OUT"
