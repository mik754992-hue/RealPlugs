package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.patryk3211.powergrid.electricity.base.ElectricBehaviour;
import org.patryk3211.powergrid.electricity.base.ElectricBlockEntity;
import org.patryk3211.powergrid.electricity.base.IElectricEntity;
import org.patryk3211.powergrid.electricity.sim.SwitchedWire;
import org.patryk3211.powergrid.electricity.wire.BaseWireEntity;
import org.patryk3211.powergrid.electricity.wire.BlockWireEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.CordEntity;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import java.util.Map;
import java.util.UUID;
import java.util.Set;

/**
 * Electrical model of an outlet / power strip:
 *   terminal 0        = hot bus      (wire the supply here)
 *   terminal 1        = neutral bus  (supply neutral, and every device's return, goes here)
 *   terminal 2 + i    = tap of slot i, connected to the hot bus ONLY while a plug (or a plug cord) sits in slot i
 */
public class PlugSocketBlockEntity extends ElectricBlockEntity {
    /** Resistance of a closed slot contact in ohms. */
    private static final float CONTACT_RESISTANCE = 0.005f;

    private NonNullList<ItemStack> plugs;
    private SwitchedWire[] taps;
    /** Who is tethered to each slot (pocket computer port). Synced to the client so the rope can be drawn. */
    // NOT initialised inline: buildCircuit() runs inside the super constructor (before field initialisers),
    // and an initialiser here would also wipe anything set during that call. Created lazily via owners().
    private UUID[] tetherOwner;
    /** Game time until which the tether is valid; the pocket computer renews it every few ticks. Server only. */
    private long[] tetherUntil;
    /** Game time this extension end first ticked (server only), so a freshly placed one is given time to get its cable. */
    private long placedAt;
    /** Who has pulled this charger's built-in cord out of its dock (server only, not saved: after a reload it is docked). */
    private UUID cordHolder;
    /** EV charger credit in the smallest coin unit (only used when this block is an EvChargerBlock). */
    private int credit;
    /** Who paid the credit that is left (the last one to put money in): only they get change when STOP is pressed. */
    private UUID creditPayer;
    /** The part of the credit that was paid by card, and the bank account it came from (refunded to it by STOP). */
    private int cardCredit;
    private UUID cardAccount;
    /** Fractional billing: price * ticks, one unit of credit is spent per 1200 (a minute at price 1). */
    private int billing;
    /** Bit i set = a plug cord end sits in slot i. Synced to the client so the renderer can draw the plug. */
    private int cordMask;
    // EV charger settings. No inline initialisers on purpose: occupied() runs inside the super constructor.
    /** Who placed the charger (may change its fee and mode). Null = anybody may. */
    private UUID owner;
    private String ownerName;
    /** Private charger: only the owner can use it, and the owner charges for free. */
    private boolean personal;
    /** The STOP button was pressed: the slot stays dead until somebody starts a new session. */
    private boolean stopped;
    /** The owner's own built-in cord is plugged into something (a Power Grid cord now): it powers a private charger. */
    private boolean ownCord;
    /** Game time the built-in cord was last pulled out (grace period while Power Grid connects the cord). */
    private long pulledAt;
    /** The owner's own price per minute, used when customFee is set (otherwise the charger's default price). */
    private boolean customFee;
    private int fee;

    public PlugSocketBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    /** Created lazily because the circuit can be built before our own constructor body would have run. */
    public NonNullList<ItemStack> plugs() {
        if (plugs == null) {
            int n = getBlockState().getBlock() instanceof PlugSocketBlock b ? b.slots : 1;
            plugs = NonNullList.withSize(n, ItemStack.EMPTY);
        }
        return plugs;
    }

    @Override
    public void buildCircuit(IElectricEntity.CircuitBuilder builder) {
        int n = plugs().size();
        builder.setTerminalCount(2 + n);
        taps = new SwitchedWire[n];
        for (int i = 0; i < n; i++) {
            taps[i] = builder.connectSwitch(CONTACT_RESISTANCE,
                    builder.terminalNode(0), builder.terminalNode(2 + i), occupied(i));
        }
    }

    /** Close the contact of every slot that holds a plug, open the rest. */
    public void refreshTaps() {
        if (taps == null) return;
        for (int i = 0; i < taps.length; i++) {
            if (taps[i] != null) taps[i].setState(occupied(i));
        }
    }

    @Override
    public ElectricBehaviour specifyElectricBehaviour() {
        return new SocketBehaviour(this);
    }

    /** True when a Real Plugs plug cord is plugged into this slot (its end sits on the slot's tap terminal). */
    public boolean hasPgCord(int slot) {
        ElectricBehaviour eb = getElectricBehaviour();
        if (eb == null) return false;
        for (Map.Entry<BlockWireEndpoint, Set<BaseWireEntity>> e : eb.getConnections().entrySet()) {
            if (e.getKey().getTerminal() != 2 + slot) continue;
            for (BaseWireEntity w : e.getValue()) if (w instanceof CordEntity) return true;
        }
        return false;
    }

    /** A cord end or a pocket computer tether is in this slot. */
    public boolean hasCord(int slot) {
        return hasPgCord(slot) || tetherOwner(slot) != null;
    }

    private UUID[] owners() {
        if (tetherOwner == null) tetherOwner = new UUID[8];
        return tetherOwner;
    }

    private long[] untils() {
        if (tetherUntil == null) tetherUntil = new long[8];
        return tetherUntil;
    }

    public UUID tetherOwner(int slot) {
        UUID[] o = owners();
        return slot >= 0 && slot < o.length ? o[slot] : null;
    }

    /** Who is holding the built-in cord of this charger, or null while it is docked. */
    public UUID builtinCordHolder() {
        return cordHolder;
    }

    /** Pull the built-in cord out of its dock: the slot counts as occupied (and is billed) until it is docked again. */
    public void pullBuiltinCord(Player player, long now) {
        stopped = false;
        ownCord = false;
        pulledAt = now;
        cordHolder = player.getUUID();
        renewTether(0, cordHolder, now + 30);
    }

    /** Put the built-in cord back in its dock. */
    public void dockBuiltinCord() {
        UUID holder = cordHolder;
        cordHolder = null;
        if (holder != null) releaseTether(0, holder);
    }

    /** Starts or renews a tether; called by the pocket computer's port upgrade. */
    public void renewTether(int slot, UUID owner, long until) {
        UUID[] o = owners();
        if (slot < 0 || slot >= o.length) return;
        boolean changed = !owner.equals(o[slot]);
        o[slot] = owner;
        untils()[slot] = until;
        if (changed) {
            cordsChanged();
            notifyUpdate();
        }
    }

    public void releaseTether(int slot, UUID owner) {
        UUID[] o = owners();
        if (slot < 0 || slot >= o.length || !owner.equals(o[slot])) return;
        o[slot] = null;
        cordsChanged();
        notifyUpdate();
    }

    /** Is a Power Grid cord attached to the hot bus (terminal 0)? That is where an extension cable ends. */
    public boolean hasBusCord() {
        ElectricBehaviour eb = getElectricBehaviour();
        if (eb == null) return false;
        for (Map.Entry<BlockWireEndpoint, Set<BaseWireEntity>> e : eb.getConnections().entrySet()) {
            if (e.getKey().getTerminal() != 0) continue;
            for (BaseWireEntity w : e.getValue()) if (w instanceof CordEntity) return true;
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide || level.getGameTime() % 10 != 0) return;
        long now = level.getGameTime();
        if (getBlockState().getBlock() instanceof EvChargerBlock charger && credit > 0 && !stopped && !personal
                && (!plugs().get(0).isEmpty() || hasCord(0))) {
            billing += feePerMinute(charger) * 10;     // this runs every 10 ticks
            int before = credit;
            while (billing >= 1200 && credit > 0) {
                billing -= 1200;
                credit--;
                if (cardCredit > credit) cardCredit = credit;   // the coins are used up first
            }
            if (credit != before) {
                if (credit == 0) refreshTaps();            // out of credit: the slot goes dead
                notifyUpdate();
            }
        }
        if (getBlockState().getBlock() instanceof ExtensionEndBlock) {
            if (placedAt == 0) placedAt = now;
            if (now - placedAt > 100 && !hasBusCord()) {   // the cable was broken (or never connected)
                level.removeBlock(worldPosition, false);
                return;
            }
        }
        if (cordHolder != null) {   // the cord snaps back into its dock when its holder walks off, dies or logs out
            Player p = level.getPlayerByUUID(cordHolder);
            double r = PocketTether.RANGE;
            if (p == null || !p.isAlive() || p.distanceToSqr(Vec3.atCenterOf(worldPosition)) > r * r
                    || !cordHolder.equals(owners()[0])) {
                dockBuiltinCord();
            } else if (now - pulledAt > 2 && (hasPgCord(0) || (now - pulledAt > 5 && !BuiltinCord.holds(p, worldPosition)))) {
                // the cord item is gone from the player's hands: it was plugged in (a Power Grid cord now links this
                // slot to the port) or got lost. Either way the dock lets go of the rope.
                if (hasPgCord(0)) ownCord = true;
                dockBuiltinCord();
                refreshTaps();
                notifyUpdate();
            } else {
                untils()[0] = now + 30;
            }
        }
        if (ownCord && !hasPgCord(0)) {   // that cord was unplugged again
            ownCord = false;
            refreshTaps();
            notifyUpdate();
        }
        boolean changed = false;
        UUID[] o = owners();
        long[] u = untils();
        for (int i = 0; i < o.length; i++) {
            if (o[i] != null && u[i] < now) {   // the pocket computer stopped renewing it
                o[i] = null;
                changed = true;
            }
        }
        if (changed) {
            cordsChanged();
            notifyUpdate();
        }
    }

    /** The rope can reach as far as the tether does. */
    @Override
    protected AABB createRenderBoundingBox() {
        return new AABB(worldPosition).inflate(PocketTether.RANGE + 2);
    }

    private boolean occupied(int slot) {
        if (getBlockState().getBlock() instanceof EvChargerBlock) {
            if (stopped) return false;
            if (personal) {
                // private: only a plug the owner inserted or the built-in cord counts (Power Grid cords are ignored)
                return !plugs().get(slot).isEmpty() || tetherOwner(slot) != null || (ownCord && hasPgCord(slot));
            }
            // a public charger only passes power while it has credit
            return (!plugs().get(slot).isEmpty() || hasCord(slot)) && credit > 0;
        }
        return !plugs().get(slot).isEmpty() || hasCord(slot);
    }

    // ---- EV charger settings ----

    public UUID owner() {
        return owner;
    }

    public String ownerName() {
        return ownerName == null ? "" : ownerName;
    }

    public boolean isPersonal() {
        return personal;
    }

    public boolean isStopped() {
        return stopped;
    }

    /** Price per minute: the owner's custom fee, or the charger's default. */
    public int feePerMinute(EvChargerBlock charger) {
        return customFee ? fee : charger.pricePerMinute();
    }

    /** May this player change the fee/mode and use a private charger? */
    public boolean isOwnerOrUnowned(Player player) {
        return owner == null || owner.equals(player.getUUID());
    }

    public void setOwner(Player player) {
        owner = player.getUUID();
        ownerName = player.getGameProfile().getName();
        notifyUpdate();
    }

    public void setPersonal(boolean value) {
        personal = value;
        if (value) dockBuiltinCord();
        refreshTaps();
        notifyUpdate();
    }

    public void setFee(int value) {
        customFee = true;
        fee = Math.max(0, Math.min(4096, value));
        notifyUpdate();
    }

    /** STOP pressed: end the session (the built-in cord snaps back, the slot goes dead) or, pressed again, allow a new one. */
    public void setStopped(boolean value) {
        stopped = value;
        if (value) dockBuiltinCord();
        refreshTaps();
        notifyUpdate();
    }

    public int credit() {
        return credit;
    }

    public void addCredit(int amount) {
        credit = (int) Math.min(Integer.MAX_VALUE, (long) credit + amount);
        refreshTaps();
        notifyUpdate();
    }

    /** Credit paid by this player (coins or card). */
    public void addCredit(int amount, UUID payer) {
        creditPayer = payer;
        addCredit(amount);
    }

    /** Credit paid by card from this account. */
    public void addCardCredit(int amount, UUID payer, UUID account) {
        if (cardAccount != null && !cardAccount.equals(account)) cardCredit = 0;   // a second account: the first part comes back as coins
        cardAccount = account;
        cardCredit += amount;
        addCredit(amount, payer);
    }

    public UUID creditPayer() {
        return creditPayer;
    }

    /** How much of the credit can go back to the card, and to which account. */
    public int cardCredit() {
        return Math.min(cardCredit, credit);
    }

    public UUID cardAccount() {
        return cardAccount;
    }

    /** The card part of the credit was refunded. */
    public void takeCardCredit(int amount) {
        cardCredit = Math.max(0, cardCredit - amount);
        takeCredit(amount);
    }

    /** Takes credit back out (change given). */
    public void takeCredit(int amount) {
        credit = Math.max(0, credit - amount);
        if (cardCredit > credit) cardCredit = credit;
        if (credit == 0) {
            creditPayer = null;
            cardAccount = null;
        }
        refreshTaps();
        notifyUpdate();
    }

    /** Called by SocketBehaviour whenever a wire or cord is attached or removed. */
    public void cordsChanged() {
        if (level == null || isRemoved()) return;
        refreshTaps();
        if (level.isClientSide) return;
        int mask = 0;
        for (int i = 0; i < plugs().size(); i++) if (hasCord(i)) mask |= 1 << i;
        if (mask != cordMask) {
            cordMask = mask;
            notifyUpdate();
        }
    }

    /** For the renderer: is a cord end shown in this slot? */
    public boolean cordShown(int slot) {
        return (cordMask >> slot & 1) != 0;
    }

    public void setPlug(int slot, ItemStack stack) {
        if (!stack.isEmpty()) stopped = false;   // a new session
        plugs().set(slot, stack);
        plugsChanged();
    }

    public void plugsChanged() {
        refreshTaps();
        notifyUpdate();
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        NonNullList<ItemStack> list = plugs();
        for (int i = 0; i < list.size(); i++) list.set(i, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        cordMask = tag.getInt("CordMask");
        credit = tag.getInt("Credit");
        creditPayer = tag.hasUUID("CreditPayer") ? tag.getUUID("CreditPayer") : null;
        cardCredit = tag.getInt("CardCredit");
        cardAccount = tag.hasUUID("CardAccount") ? tag.getUUID("CardAccount") : null;
        billing = tag.getInt("Billing");
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        ownerName = tag.getString("OwnerName");
        personal = tag.getBoolean("Personal");
        stopped = tag.getBoolean("Stopped");
        ownCord = tag.getBoolean("OwnCord");
        customFee = tag.contains("Fee");
        fee = tag.getInt("Fee");
        UUID[] o = owners();
        for (int i = 0; i < o.length; i++) {
            o[i] = tag.contains("Tether" + i) ? UUID.fromString(tag.getString("Tether" + i)) : null;
        }
        refreshTaps();
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        ContainerHelper.saveAllItems(tag, plugs(), registries);
        tag.putInt("CordMask", cordMask);
        tag.putInt("Credit", credit);
        if (creditPayer != null) tag.putUUID("CreditPayer", creditPayer);
        tag.putInt("CardCredit", cardCredit);
        if (cardAccount != null) tag.putUUID("CardAccount", cardAccount);
        tag.putInt("Billing", billing);
        if (owner != null) tag.putUUID("Owner", owner);
        if (ownerName != null) tag.putString("OwnerName", ownerName);
        tag.putBoolean("Personal", personal);
        tag.putBoolean("Stopped", stopped);
        tag.putBoolean("OwnCord", ownCord);
        if (customFee) tag.putInt("Fee", fee);
        if (clientPacket) {   // leases are not saved: after a reload nothing is tethered until the computer renews it
            UUID[] o = owners();
            for (int i = 0; i < o.length; i++) {
                if (o[i] != null) tag.putString("Tether" + i, o[i].toString());
            }
        }
    }
}
