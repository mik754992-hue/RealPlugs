package net.minecraft.server;
import net.minecraft.server.level.*; import java.util.*;
public class MinecraftServer { public final Map<Dim,ServerLevel> levels=new HashMap<>(); public long tick;
 public ServerLevel getLevel(Dim dim){return levels.get(dim);} public long getTickCount(){return tick;} }
