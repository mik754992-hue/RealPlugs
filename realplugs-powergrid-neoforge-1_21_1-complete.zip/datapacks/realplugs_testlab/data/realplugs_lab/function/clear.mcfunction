# Removes the lab again (the platform and everything on it).
execute at @s run fill ~ ~ ~ ~16 ~4 ~6 minecraft:air
execute at @s run fill ~ ~-1 ~ ~16 ~-1 ~6 minecraft:grass_block
