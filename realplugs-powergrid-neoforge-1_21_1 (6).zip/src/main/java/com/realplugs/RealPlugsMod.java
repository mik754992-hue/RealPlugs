package com.realplugs;

import com.realplugs.cc.CCCompat;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;

@Mod(RealPlugsMod.MODID)
public class RealPlugsMod {
    public static final String MODID = "realplugs";

    public RealPlugsMod(IEventBus modBus) {
        ModComponents.COMPONENTS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        // CC: Tweaked is optional: only touch its classes when it is installed
        if (ModList.get().isLoaded("computercraft")) {
            modBus.addListener(CCCompat::registerCapabilities);
        }
    }
}
