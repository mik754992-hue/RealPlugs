package com.realplugs;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

import java.util.List;

/**
 * A real Power Grid cord with a plug on each end. Both ends can be the same connector standard or two different ones
 * (US plug on one end, USB-A on the other). The variant is custom_model_data, see CordTypes.
 *
 * Power Grid does the cord itself (the hanging cord entity, length limit, item cost, electrical connection) because
 * this extends its CordItem and has a wire_types entry; PlugCordHandler decides where an end may be plugged.
 */
public class PlugCordItem extends CordItem {
    public PlugCordItem(Properties props) {
        super(props);
    }

    public static CordTypes.CordDef defOf(ItemStack stack) {
        return CordTypes.get(PlugItem.typeOf(stack));
    }

    @Override
    public String getDescriptionId(ItemStack stack) {
        int i = PlugItem.typeOf(stack);
        String base = getDescriptionId();
        return i > 0 && i < CordTypes.ALL.length ? base + "." + CordTypes.ALL[i].name() : base;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tips, TooltipFlag flag) {
        CordTypes.CordDef d = defOf(stack);
        tips.add(Component.translatable("tooltip.realplugs.cord_ends", Component.translatable(d.a().langKey()),
                        Component.translatable(d.b().langKey()))
                .withStyle(ChatFormatting.GRAY));
    }
}
