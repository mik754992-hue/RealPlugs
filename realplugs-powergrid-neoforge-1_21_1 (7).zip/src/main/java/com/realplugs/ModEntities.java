package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(BuiltInRegistries.ENTITY_TYPE, RealPlugsMod.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<PlugEntity>> PLUG =
            ENTITIES.register("plug", () -> EntityType.Builder.<PlugEntity>of(PlugEntity::new, MobCategory.MISC)
                    .sized(0.25f, 0.25f)
                    .clientTrackingRange(8)
                    .updateInterval(Integer.MAX_VALUE)
                    .build("plug"));

    public static final DeferredHolder<EntityType<?>, EntityType<PortEntity>> PORT =
            ENTITIES.register("port", () -> EntityType.Builder.<PortEntity>of(PortEntity::new, MobCategory.MISC)
                    .sized(0.25f, 0.25f)
                    .clientTrackingRange(8)
                    .updateInterval(Integer.MAX_VALUE)
                    .build("port"));
}
