package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import java.util.List;

/**
 * What a coin is worth at an EV charger. Data-driven: the item tags realplugs:ev_coin_1, _8, _16, _64, _512 and _4096
 * list the coins of each value (the file lists Create: Numismatics' coins as optional entries). Add your own coins to
 * these tags with a datapack. The unit is the smallest coin (a spur).
 */
public final class EvCoins {
    private static final int[] VALUES = {4096, 512, 64, 16, 8, 1};
    private static final TagKey<Item>[] TAGS = tags();

    private EvCoins() {}

    @SuppressWarnings("unchecked")
    private static TagKey<Item>[] tags() {
        TagKey<Item>[] out = new TagKey[VALUES.length];
        for (int i = 0; i < VALUES.length; i++) {
            out[i] = TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(RealPlugsMod.MODID, "ev_coin_" + VALUES[i]));
        }
        return out;
    }

    /**
     * Change for an amount: the biggest coins first, the first item of each value's tag. Adds the stacks to out and
     * returns what could not be paid back (a value whose tag lists no installed coin is skipped).
     */
    public static int makeChange(int amount, List<ItemStack> out) {
        int rest = amount;
        for (int i = 0; i < VALUES.length; i++) {
            Item coin = BuiltInRegistries.ITEM.getTag(TAGS[i]).flatMap(set -> set.stream().findFirst())
                    .map(h -> h.value()).orElse(null);
            if (coin == null) continue;
            int n = rest / VALUES[i];
            rest -= n * VALUES[i];
            int max = new ItemStack(coin).getMaxStackSize();
            while (n > 0) {
                int c = Math.min(n, max);
                out.add(new ItemStack(coin, c));
                n -= c;
            }
        }
        return rest;
    }

    /** Value of ONE of these, or 0 if it is not a coin. */
    public static int valueOf(ItemStack stack) {
        for (int i = 0; i < VALUES.length; i++) if (stack.is(TAGS[i])) return VALUES[i];
        return 0;
    }

    /** Is this a Create: Numismatics card? (Paying with one goes through NumismaticsPay, only when that mod is loaded.) */
    public static boolean isNumismaticsCard(ItemStack stack) {
        var key = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem());
        return key.getNamespace().equals("numismatics") && key.getPath().contains("card");
    }
}
