package dan200.computercraft.api.peripheral;

import net.minecraft.core.Direction;
import net.neoforged.neoforge.capabilities.BlockCapability;

/** COMPILE-TIME STUB of CC: Tweaked's capability holder. Excluded from the released jar. */
public final class PeripheralCapability {
    private PeripheralCapability() {}

    public static BlockCapability<IPeripheral, Direction> get() {
        throw new UnsupportedOperationException("stub: the real class comes from CC: Tweaked");
    }
}
