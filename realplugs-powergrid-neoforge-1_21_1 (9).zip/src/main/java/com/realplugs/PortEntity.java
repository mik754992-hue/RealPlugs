package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/**
 * A socket stuck onto a face of a CC: Tweaked block at an exact position. One plug of the matching connector
 * standard can be plugged into it. (Purely visual and for the build: it does not connect to the computer's peripherals.)
 */
public class PortEntity extends Entity {
    private static final EntityDataAccessor<ItemStack> PORT =
            SynchedEntityData.defineId(PortEntity.class, EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<ItemStack> PLUGGED =
            SynchedEntityData.defineId(PortEntity.class, EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<Direction> FACE =
            SynchedEntityData.defineId(PortEntity.class, EntityDataSerializers.DIRECTION);

    public BlockPos anchor = BlockPos.ZERO;

    public PortEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static PortEntity create(Level level, BlockPos anchor, Direction face, Vec3 hit, ItemStack port) {
        PortEntity e = new PortEntity(ModEntities.PORT.get(), level);
        e.anchor = anchor;
        e.entityData.set(PORT, port);
        e.entityData.set(FACE, face);
        e.setPos(hit.x + face.getStepX() * 0.02, hit.y + face.getStepY() * 0.02, hit.z + face.getStepZ() * 0.02);
        return e;
    }

    public ItemStack getPort() { return entityData.get(PORT); }
    public ItemStack getPlugged() { return entityData.get(PLUGGED); }
    public Direction getFace() { return entityData.get(FACE); }
    public PlugTypes.Standard standard() { return PortItem.standardOf(getPort()); }

    /** The stack the renderer draws: the empty port, or (custom_model_data + 100) the port with its plug in. */
    public ItemStack getRenderStack() {
        ItemStack s = getPort().copy();
        if (!getPlugged().isEmpty()) {
            s.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(100 + PlugItem.typeOf(getPort())));
        }
        return s;
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(PORT, ItemStack.EMPTY);
        builder.define(PLUGGED, ItemStack.EMPTY);
        builder.define(FACE, Direction.NORTH);
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount % 20 == 0 && level().isEmptyBlock(anchor)) {
            dropContents();
            discard();
        }
    }

    private void dropContents() {
        spawnAtLocation(getPort());
        if (!getPlugged().isEmpty()) spawnAtLocation(getPlugged());
    }

    /**
     * An entity's position is the bottom of its box, so by default the box sits ABOVE the spot you clicked and aiming at
     * the plug/port misses it. Centre the box on the position instead.
     */
    @Override
    protected AABB makeBoundingBox() {
        return super.makeBoundingBox().move(0.0, -getBbHeight() / 2.0, 0.0);
    }

    @Override
    public boolean isPickable() { return true; }

    @Override
    public ItemStack getPickResult() { return getPort().copy(); }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        boolean client = level().isClientSide;

        // holding a plug: it has to be a plain plug of this port's standard
        if (held.getItem() instanceof PlugItem pi) {
            if (!getPlugged().isEmpty()) {
                if (!client) player.displayClientMessage(Component.translatable("message.realplugs.port_taken"), true);
            } else if (pi.adapter || PlugItem.plugStandard(held) != standard()) {
                if (!client) player.displayClientMessage(Component.translatable("message.realplugs.no_fit",
                        Component.translatable(standard().langKey())), true);
            } else if (!client) {
                entityData.set(PLUGGED, PlugItem.takeOne(held, player));
            }
            return InteractionResult.sidedSuccess(client);
        }

        if (held.isEmpty()) {
            if (!client) {
                if (!getPlugged().isEmpty()) {
                    PlugItem.give(player, getPlugged());
                    entityData.set(PLUGGED, ItemStack.EMPTY);
                } else if (player.isShiftKeyDown()) {
                    PlugItem.give(player, getPort());
                    discard();
                }
            }
            return InteractionResult.sidedSuccess(client);
        }
        return InteractionResult.PASS;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return true;
        if (source.getEntity() instanceof Player p) {
            if (!p.getAbilities().instabuild) dropContents();
            discard();
            return true;
        }
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(PORT, ItemStack.parseOptional(level().registryAccess(), tag.getCompound("Port")));
        entityData.set(PLUGGED, ItemStack.parseOptional(level().registryAccess(), tag.getCompound("Plugged")));
        entityData.set(FACE, Direction.from3DDataValue(tag.getInt("Face")));
        int[] a = tag.getIntArray("Anchor");
        if (a.length == 3) anchor = new BlockPos(a[0], a[1], a[2]);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("Port", getPort().saveOptional(level().registryAccess()));
        tag.put("Plugged", getPlugged().saveOptional(level().registryAccess()));
        tag.putInt("Face", getFace().get3DDataValue());
        tag.putIntArray("Anchor", new int[]{anchor.getX(), anchor.getY(), anchor.getZ()});
    }
}
