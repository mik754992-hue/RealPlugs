package net.minecraft.server.level;
import net.minecraft.core.BlockPos; import java.util.*;
public class ServerLevel { public final Dim dim; public final net.minecraft.server.MinecraftServer server; public final Map<BlockPos,Object> bes=new HashMap<>();
 public ServerLevel(Dim d, net.minecraft.server.MinecraftServer s){dim=d;server=s;}
 public Dim dimension(){return dim;} public net.minecraft.server.MinecraftServer getServer(){return server;}
 public boolean isLoaded(BlockPos p){return true;} public Object getBlockEntity(BlockPos p){return bes.get(p);} }
