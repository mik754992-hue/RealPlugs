package com.realplugs;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

import java.util.List;

/**
 * An extension cable: a real Power Grid cord with a plug on one end and a power-strip-like block on the other.
 * Right-click a free slot of the matching connector to plug the cord in, then right-click a surface to place the strip
 * end there (see ExtensionPlaceHandler). Power Grid does the cord itself because this extends its CordItem and has a
 * wire_types entry.
 */
public class ExtensionCableItem extends CordItem {
    public ExtensionCableItem(Properties props) {
        super(props);
    }

    public static ExtensionTypes.Def defOf(ItemStack stack) {
        return ExtensionTypes.get(PlugItem.typeOf(stack));
    }

    @Override
    public String getDescriptionId(ItemStack stack) {
        int i = PlugItem.typeOf(stack);
        String base = getDescriptionId();
        return i > 0 && i < ExtensionTypes.ALL.length ? base + "." + ExtensionTypes.ALL[i].name() : base;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("tooltip.realplugs.extension_plug",
                Component.translatable(defOf(stack).plug().langKey())).withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("tooltip.realplugs.extension_place").withStyle(ChatFormatting.DARK_GRAY));
    }
}
