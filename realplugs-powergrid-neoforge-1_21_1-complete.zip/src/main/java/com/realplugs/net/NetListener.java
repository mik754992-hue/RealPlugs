package com.realplugs.net;

/** Something that wants to hear what arrives at a socket (a CC computer attached to it). */
public interface NetListener {
    /** A datagram (UDP-like). */
    void packet(int slot, String srcIp, int srcPort, int dstPort, String payload);

    /** A raw Ethernet frame from the same segment. */
    void frame(int slot, String srcMac, String dstMac, int etherType, String payload);

    /** Something happened to a TCP-like connection: "accepted", "connected", "data" or "closed". */
    void tcp(int slot, String event, int id, Object... args);

    /** A packet crossed the segment of a port that is set to sniff (a copy of everything that is sent inside the segment). */
    default void sniff(int slot, String srcIp, String dstIp, String protocol, int srcPort, int dstPort, String payload) {}
}
