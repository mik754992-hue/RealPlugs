package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;
import org.patryk3211.powergrid.electricity.base.DirectionalElectricBlock;

public class PlugSocketRenderer implements BlockEntityRenderer<PlugSocketBlockEntity> {
    private final ItemRenderer items;

    private final Font font;

    public PlugSocketRenderer(BlockEntityRendererProvider.Context ctx) {
        this.font = ctx.getFont();
        this.items = ctx.getItemRenderer();
    }

    private static final java.util.Map<PlugTypes.Standard, ItemStack> CORD_PLUGS = new java.util.EnumMap<>(PlugTypes.Standard.class);

    private static ItemStack cordPlug(PlugTypes.Standard std) {
        return CORD_PLUGS.computeIfAbsent(std, k -> {
            ItemStack st = new ItemStack(ModItems.PLUG.get());
            st.set(net.minecraft.core.component.DataComponents.CUSTOM_MODEL_DATA,
                    new net.minecraft.world.item.component.CustomModelData(PlugTypes.plugIndexFor(k)));
            return st;
        });
    }

    @Override
    public void render(PlugSocketBlockEntity be, float partial, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        if (be.getLevel() == null || !(be.getBlockState().getBlock() instanceof PlugSocketBlock block)) return;
        Direction f = be.getBlockState().getValue(DirectionalElectricBlock.FACING);
        var plugs = be.plugs();
        float scale = block.plugScale();

        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        // same rotation the blockstate applies, so we can work in the north-facing frame
        if (f.getAxis().isHorizontal()) {
            ps.mulPose(Axis.YP.rotationDegrees(-(f.toYRot() + 180f)));
        } else {
            ps.mulPose(Axis.XP.rotationDegrees(f == Direction.UP ? 90f : -90f));
        }

        for (int i = 0; i < plugs.size(); i++) {
            ItemStack s = plugs.get(i);
            if (s.isEmpty() && !(block instanceof PortAnchorBlock)) {
                if (block instanceof EvChargerBlock) {
                    // a charger's own cord sits docked in the socket, and leaves it empty while somebody holds the cord
                    if (be.tetherOwner(i) == null) s = cordPlug(block.def.slots()[i]);
                } else if (be.cordShown(i)) {
                    // a cord is plugged in here: show a plug of this slot's connector standard
                    s = cordPlug(block.def.slots()[i]);
                }
            }
            if (s.isEmpty()) continue;

            ps.pushPose();
            ps.translate(block.slotCenterX(i), block.plugCenterY(), block.frontLocalZ() - 0.02);
            ps.mulPose(Axis.YP.rotationDegrees(180f));
            ps.scale(scale, scale, scale);
            PlugRender.draw(items, s, ps, buf, light, overlay, be.getLevel(), i * 8);
            ps.popPose();
        }
        if (be.hasLights()) drawLights(be, block, ps, buf);
        ps.popPose();

        if (block instanceof EvChargerBlock charger) {
            drawScreen(be, charger, f, ps, buf, light);
        }

        // the cable to anyone tethered to a slot (a pocket computer with a port)
        if (block instanceof EvChargerBlock) {
            drawBuiltinCord(be, block, f, ps, buf, light, partial);
        } else if (!(block instanceof PortAnchorBlock)) {
            Vec3 origin = Vec3.atLowerCornerOf(be.getBlockPos());
            for (int i = 0; i < plugs.size(); i++) {
                java.util.UUID owner = be.tetherOwner(i);
                if (owner == null) continue;
                Player p = be.getLevel().getPlayerByUUID(owner);
                if (p == null) continue;
                Vec3 out = new Vec3(f.getStepX(), f.getStepY(), f.getStepZ()).scale(0.17);   // the back end of the plug
                Vec3 from = block.slotWorldPos(be.getBlockState(), be.getBlockPos(), i).add(out).subtract(origin);
                TetherRope.draw(ps, buf, from, TetherRope.handPos(p, partial).subtract(origin), light);
            }
        }
    }

    // ---- status lights of the network blocks: little glowing squares over the unlit lenses of the model ----

    private static final ResourceLocation PALETTE =
            ResourceLocation.fromNamespaceAndPath(RealPlugsMod.MODID, "textures/block/palette.png");
    /** Top-left pixel of a colour cell of palette.png (cells are 4x4 pixels). */
    private static final int[] GREEN = {1, 9};
    private static final int[] AMBER = {9, 9};
    private static final int[] BLUE = {13, 5};

    /**
     * Per port: a link light (green = a cable with two ends, blue = a router's WAN that is online) on the left of the
     * jack, and an activity light (amber, blinks while packets pass) on the right. The access point also has a blue
     * radio light that is on while a port is connected to it. Drawn in the north frame, in model units.
     */
    private void drawLights(PlugSocketBlockEntity be, PlugSocketBlock block, PoseStack ps, MultiBufferSource buf) {
        VertexConsumer vc = buf.getBuffer(RenderType.eyes(PALETTE));
        boolean ap = block.def.id().equals("wifi_access_point");
        for (int i = 0; i < block.slots; i++) {
            double xc = ap ? 8.0 : 14.0 - 4.0 * i;
            if (be.lampLink(i)) lamp(ps, vc, xc - 1.5, xc - 0.5, be.lampUplink(i) ? BLUE : GREEN);
            if (be.lampActivity(i)) lamp(ps, vc, xc + 0.5, xc + 1.5, AMBER);
        }
        if (ap && be.lampWifi()) lamp(ps, vc, 12.0, 13.0, BLUE);
    }

    private static void lamp(PoseStack ps, VertexConsumer vc, double x0, double x1, int[] cell) {
        PoseStack.Pose pose = ps.last();
        float u0 = cell[0] / 16f;
        float u1 = (cell[0] + 2) / 16f;
        float v0 = cell[1] / 16f;
        float v1 = (cell[1] + 2) / 16f;
        float ax = (float) (x0 / 16.0 - 0.5);
        float bx = (float) (x1 / 16.0 - 0.5);
        float ay = (float) (11.2 / 16.0 - 0.5);
        float by = (float) (12.0 / 16.0 - 0.5);
        float z = (float) (11.6 / 16.0 - 0.5);   // just in front of the lens (its front face is at 11.7)
        lampVertex(vc, pose, bx, ay, z, u0, v1);
        lampVertex(vc, pose, ax, ay, z, u1, v1);
        lampVertex(vc, pose, ax, by, z, u1, v0);
        lampVertex(vc, pose, bx, by, z, u0, v0);
    }

    private static void lampVertex(VertexConsumer vc, PoseStack.Pose pose, float x, float y, float z, float u, float v) {
        vc.addVertex(pose, x, y, z).setColor(255, 255, 255, 255).setUv(u, v)
                .setOverlay(net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY)
                .setLight(net.minecraft.client.renderer.LightTexture.FULL_BRIGHT)
                .setNormal(pose, 0f, 0f, -1f);
    }

    /** A point on the charger's front, given in model units of the north frame, relative to the block's corner. */
    private static Vec3 frontPoint(Direction f, double x, double y, double z) {
        Vector3f v = new Vector3f((float) (x / 16.0 - 0.5), (float) (y / 16.0 - 0.5), (float) (z / 16.0 - 0.5));
        Axis.YP.rotationDegrees(-(f.toYRot() + 180f)).transform(v);
        return new Vec3(0.5 + v.x, 0.5 + v.y, 0.5 + v.z);
    }

    /**
     * The charger's built-in cord. Docked: a cable runs from the connector in the socket down to the cable gland.
     * Pulled out: the cable runs from the gland to the hand of whoever holds it.
     */
    private void drawBuiltinCord(PlugSocketBlockEntity be, PlugSocketBlock block, Direction f, PoseStack ps,
                                 MultiBufferSource buf, int light, float partial) {
        if (!f.getAxis().isHorizontal()) return;
        Vec3 origin = Vec3.atLowerCornerOf(be.getBlockPos());
        Vec3 gland = frontPoint(f, 12.0, 2.4, 7.0);
        java.util.UUID owner = be.tetherOwner(0);
        if (owner != null) {
            Player p = be.getLevel().getPlayerByUUID(owner);
            if (p != null) TetherRope.draw(ps, buf, gland, TetherRope.handPos(p, partial).subtract(origin), light);
        } else if (be.plugs().get(0).isEmpty() && !be.cordShown(0)) {
            Vec3 out = new Vec3(f.getStepX(), f.getStepY(), f.getStepZ()).scale(0.17);   // the back end of the connector
            Vec3 from = block.slotWorldPos(be.getBlockState(), be.getBlockPos(), 0).add(out).subtract(origin);
            TetherRope.draw(ps, buf, from, gland, light);
        }
    }

    /** The charger's screen on its upper block: state, credit and price, in the north frame then turned to face the viewer. */
    private void drawScreen(PlugSocketBlockEntity be, EvChargerBlock charger, Direction f, PoseStack ps, MultiBufferSource buf, int light) {
        if (!f.getAxis().isHorizontal()) return;
        // the screen is in the block above, so light it like that block
        int screenLight = be.getLevel() != null
                ? net.minecraft.client.renderer.LevelRenderer.getLightColor(be.getLevel(), be.getBlockPos().above()) : light;
        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-(f.toYRot() + 180f)));
        ps.translate(0.0, 26.25 / 16.0 - 0.5, 7.6 / 16.0 - 0.5);   // centre of the glass (block above), just in front of it
        ps.mulPose(Axis.YP.rotationDegrees(180f));

        String l1;
        int c1;
        String l2;
        int c2;
        String l3;
        if (be.isStopped()) {
            l1 = "STOPPED"; c1 = 0xFF5555;
        } else if (be.isPersonal()) {
            l1 = "PRIVATE"; c1 = 0x55AAFF;
        } else {
            l1 = be.credit() > 0 ? "READY" : "PAY"; c1 = be.credit() > 0 ? 0x55FF55 : 0xFFAA00;
        }
        if (be.isPersonal()) {
            l2 = "FREE"; c2 = 0xFFFFFF;
            String n = be.ownerName();
            l3 = n.length() > 8 ? n.substring(0, 8) : n;
        } else {
            l2 = Integer.toString(be.credit()); c2 = be.credit() > 0 ? 0xFFFFFF : 0xFF5555;
            l3 = be.feePerMinute(charger) + "/min";
        }
        int widest = Math.max(font.width(l1), Math.max(font.width(l2), font.width(l3)));
        float s = 0.0105f * Math.min(1f, 46f / Math.max(1, widest));
        ps.scale(s, -s, s);
        var pose = ps.last().pose();
        font.drawInBatch(l1, -font.width(l1) / 2f, -15f, c1, false, pose, buf, Font.DisplayMode.NORMAL, 0, screenLight);
        font.drawInBatch(l2, -font.width(l2) / 2f, -4f, c2, false, pose, buf, Font.DisplayMode.NORMAL, 0, screenLight);
        font.drawInBatch(l3, -font.width(l3) / 2f, 7f, 0xBBBBBB, false, pose, buf, Font.DisplayMode.NORMAL, 0, screenLight);
        ps.popPose();
    }
}
