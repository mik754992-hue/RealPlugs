package dan200.computercraft.api.upgrades;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** COMPILE-TIME STUB of CC: Tweaked 1.113's UpgradeBase (signatures read from the real jar). Excluded from the released jar. */
public interface UpgradeBase {
    UpgradeType<?> getType();

    Component getAdjective();

    ItemStack getCraftingItem();

    default boolean isItemSuitable(ItemStack stack) {
        throw new UnsupportedOperationException("stub");
    }
}
