-- rpdns: keep the DNS records of a router in a text file.
--   rpdns apply [file]   make the router's records match the file (default zones.txt)
--   rpdns list           show the router's records
-- The file has one record per line:  name address   (# starts a comment)

local M = {}

function M.parseZone(text)
  local records, errors = {}, {}
  local n = 0
  for line in (text .. "\n"):gmatch("([^\n]*)\n") do
    n = n + 1
    line = line:gsub("#.*$", ""):gsub("^%s+", ""):gsub("%s+$", "")
    if line ~= "" then
      local name, ip = line:match("^(%S+)%s+(%S+)$")
      if name and ip:match("^%d+%.%d+%.%d+%.%d+$") then records[name:lower()] = ip
      else errors[#errors + 1] = "line " .. n .. ": " .. line end
    end
  end
  return records, errors
end

-- what must change to turn `have` (name -> ip) into `want`: { add = {name = ip}, remove = {name} }
function M.diff(have, want)
  local add, remove = {}, {}
  for name, ip in pairs(want) do if have[name] ~= ip then add[name] = ip end end
  for name in pairs(have) do if want[name] == nil then remove[#remove + 1] = name end end
  table.sort(remove)
  return add, remove
end

if RPWEB_TEST then return M end

local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpdns" or running == "rpdns.lua") then return M end

local args = { ... }
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local have = {}
for _, r in ipairs(nic.getDnsRecords()) do have[r.name] = r.ip end

if args[1] == "list" then
  for name, ip in pairs(have) do print(name .. "  " .. ip) end
elseif args[1] == "apply" then
  local f = fs.open(args[2] or "zones.txt", "r")
  if not f then error("cannot read " .. (args[2] or "zones.txt"), 0) end
  local text = f.readAll(); f.close()
  local want, errors = M.parseZone(text)
  for _, e in ipairs(errors) do print("skipped " .. e) end
  local add, remove = M.diff(have, want)
  for name in pairs(add) do
    local ok, why = nic.addDnsRecord(name, add[name])
    print((ok and "set " or ("FAILED " .. tostring(why) .. ": ")) .. name .. " " .. add[name])
  end
  for _, name in ipairs(remove) do nic.removeDnsRecord(name); print("removed " .. name) end
else
  print("rpdns apply [file] | rpdns list")
end
