#!/usr/bin/env python3
"""Generates the Wi-Fi Access Point block (one RJ45 port, three antennas, link/activity/radio lights) from the av_panel model.
Run from the repo root: python3 scripts/gen_wifi_access_point.py. Idempotent. Needs gen_network_switch.py next to it."""
import copy
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_network_switch import A, BLACK, D, RES, ROOT, box, faces, lenses, shifted  # noqa: E402

ID = "wifi_access_point"
WHITE = [1, 1, 3, 3]
GRAPHITE = [9, 1, 11, 3]
BLUE = [13, 5, 15, 7]


def main():
    src = json.loads((A / "models/block/av_panel.json").read_text())
    els = src["elements"]
    out = []
    plate = copy.deepcopy(els[0])
    plate["faces"] = faces(WHITE)
    out.append(plate)
    out.extend(shifted(e, -2) for e in els[3:5])               # the frame of the port (centre x = 8)
    out.extend(shifted(e, -2) for e in els[12:15])             # its RJ45 jack
    out.extend(copy.deepcopy(e) for e in els[19:21])           # side terminals
    out.extend(lenses(8))                                      # link + activity light
    out.append(box([11.5, 11.2, 11.7], [12.5, 12.0, 12.0], BLACK))    # radio light (blue when a port is connected)
    out.append(box([1.0, 2.4, 11.9], [15.0, 3.2, 12.0], BLUE))        # label strip
    for x in (2.0, 7.6, 13.2):                                 # three antennas
        out.append(box([x, 14.0, 13.0], [x + 0.8, 16.0, 13.8], GRAPHITE))
    model = {"parent": "minecraft:block/block", "textures": src["textures"], "elements": out}
    (A / f"models/block/{ID}.json").write_text(json.dumps(model, indent=1) + "\n")

    state = json.loads((A / "blockstates/av_panel.json").read_text())
    (A / f"blockstates/{ID}.json").write_text(
        json.dumps(state, indent=1).replace("realplugs:block/av_panel", f"realplugs:block/{ID}") + "\n")
    (A / f"models/item/{ID}.json").write_text(json.dumps({"parent": f"realplugs:block/{ID}"}, indent=1) + "\n")
    loot = (D / "loot_table/blocks/power_strip.json").read_text().replace("realplugs:power_strip", f"realplugs:{ID}")
    (D / f"loot_table/blocks/{ID}.json").write_text(loot)
    recipe = {"type": "minecraft:crafting_shapeless", "category": "redstone",
              "ingredients": [{"item": "realplugs:network_switch"}, {"item": "minecraft:lightning_rod"}, {"item": "minecraft:redstone"}],
              "result": {"id": f"realplugs:{ID}", "count": 1}}
    (D / f"recipe/{ID}.json").write_text(json.dumps(recipe, indent=1) + "\n")

    lang_path = A / "lang/en_us.json"
    lang = json.loads(lang_path.read_text())
    lang[f"block.realplugs.{ID}"] = "Wi-Fi Access Point"
    lang_path.write_text(json.dumps(lang, indent=1, ensure_ascii=False) + "\n")

    tag_path = RES / "data/minecraft/tags/block/mineable/pickaxe.json"
    tag = json.loads(tag_path.read_text())
    if f"realplugs:{ID}" not in tag["values"]:
        tag["values"].append(f"realplugs:{ID}")
    tag_path.write_text(json.dumps(tag, indent=1) + "\n")

    defs = ROOT / "src/main/java/com/realplugs/SocketDefs.java"
    s = defs.read_text()
    if f'"{ID}"' not in s:
        line = '        new SocketDef("%s", 0, 16, 2, 14, 4, new PlugTypes.Standard[]{PlugTypes.Standard.RJ45})\n' % ID
        s = re.sub(r'(new SocketDef\("network_router"[^\n]*\))\n', lambda m: m.group(1) + ",\n" + line, s, count=1)
        defs.write_text(s)
    print("ok")


if __name__ == "__main__":
    main()
