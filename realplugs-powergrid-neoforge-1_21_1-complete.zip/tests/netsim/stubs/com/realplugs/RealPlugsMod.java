package com.realplugs; public class RealPlugsMod { public static final String MODID="realplugs"; }
