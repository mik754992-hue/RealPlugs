-- rpfiles: share a folder over the network.
--   rpfiles serve [slot] [folder] [name] [--password pw]   share a folder (default "share"); with a password others may also upload/delete
--   rpfiles ls  <host> [path]
--   rpfiles get <host> <path> [local file]
--   rpfiles put <host> <path> <local file> <password>
--   rpfiles rm  <host> <path> <password>
-- Port 21. A request is one line, the answer is "OK <length>" + a line break + the data, or "ERR <why>".

local M = {}
local CHUNK = 1400
local PORT = 21
local MAX = 60000

-- a path that stays inside the shared folder
function M.safePath(p)
  p = tostring(p or "")
  if p:find("..", 1, true) or p:find("\\", 1, true) or p:find("%z") then return nil end
  p = p:gsub("^/+", ""):gsub("/+$", "")
  if not p:match("^[%w_%-%. /]*$") then return nil end
  return p
end

-- "GET path" / "LS path" / "PUT path length password" / "RM path password"
function M.parseRequest(line)
  local op, rest = line:match("^(%u+)%s?(.*)$")
  if not op then return nil end
  if op == "LS" or op == "GET" then return { op = op, path = rest } end
  if op == "PUT" then
    local path, len, pw = rest:match("^(.-) (%d+) ?(.*)$")
    if not path then return nil end
    return { op = op, path = path, len = tonumber(len), password = pw }
  end
  if op == "RM" then
    local path, pw = rest:match("^(.-) ?([^ ]*)$")
    return { op = op, path = path, password = pw }
  end
  return nil
end

function M.buildRequest(op, path, a, b)
  if op == "PUT" then return "PUT " .. path .. " " .. a .. " " .. (b or "") .. "\n" end
  if op == "RM" then return "RM " .. path .. " " .. (a or "") .. "\n" end
  return op .. " " .. (path or "") .. "\n"
end

function M.ok(body) return "OK " .. #body .. "\n" .. body end
function M.err(why) return "ERR " .. why .. "\n" end

-- from raw text: { ok=true, body=} / { ok=false, why=} / nil while more must arrive
function M.parseAnswer(raw)
  local nl = raw:find("\n", 1, true)
  if not nl then return nil end
  local head = raw:sub(1, nl - 1)
  local why = head:match("^ERR (.*)$")
  if why then return { ok = false, why = why } end
  local len = tonumber(head:match("^OK (%d+)$"))
  if not len then return { ok = false, why = "bad answer" } end
  local body = raw:sub(nl + 1)
  if #body < len then return nil end
  return { ok = true, body = body:sub(1, len) }
end

-- fsys: { exists, isDir, list, size, read(path) -> text, write(path, text), delete(path) }; returns the answer text
function M.handle(req, body, root, fsys, password)
  local p = M.safePath(req.path)
  if p == nil then return M.err("bad path") end
  local full = (p == "") and root or (root .. "/" .. p)
  if req.op == "LS" then
    if not fsys.isDir(full) then return M.err("not a folder") end
    local names = fsys.list(full)
    table.sort(names)
    local lines = {}
    for _, n in ipairs(names) do
      local f = full .. "/" .. n
      lines[#lines + 1] = n .. "\t" .. (fsys.isDir(f) and "dir" or tostring(fsys.size(f)))
    end
    return M.ok(table.concat(lines, "\n"))
  elseif req.op == "GET" then
    if not fsys.exists(full) or fsys.isDir(full) then return M.err("no such file") end
    local text = fsys.read(full)
    if #text > MAX then return M.err("file too large") end
    return M.ok(text)
  elseif req.op == "PUT" or req.op == "RM" then
    if not password or password == "" then return M.err("this share is read-only") end
    if req.password ~= password then return M.err("wrong password") end
    if p == "" then return M.err("bad path") end
    if req.op == "RM" then
      if not fsys.exists(full) then return M.err("no such file") end
      fsys.delete(full); return M.ok("")
    end
    if req.len > MAX then return M.err("file too large") end
    fsys.write(full, body)
    return M.ok("")
  end
  return M.err("unknown request")
end

if RPWEB_TEST then return M end

local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpfiles" or running == "rpfiles.lua") then return M end

local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)

local function sendAll(slot, id, text)
  for i = 1, math.max(1, #text), CHUNK do
    local ok = nic.tcpSend(slot, id, text:sub(i, i + CHUNK - 1))
    if ok == false then return false end
  end
  return true
end

-- one request to a server: returns the answer table
local function ask(host, line, payload)
  local slot = 1
  local id, err = nic.connect(slot, host, PORT)
  if not id then return { ok = false, why = tostring(err) } end
  local timer = os.startTimer(15)
  local buf = ""
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then pcall(nic.tcpClose, slot, id); return { ok = false, why = "timed out" }
    elseif ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot and ev[5] == id then
      if ev[4] == "connected" then
        if not sendAll(slot, id, line .. (payload or "")) then return { ok = false, why = "send failed" } end
      elseif ev[4] == "data" then
        buf = buf .. ev[6]
        local a = M.parseAnswer(buf)
        if a then pcall(nic.tcpClose, slot, id); os.cancelTimer(timer); return a end
      elseif ev[4] == "closed" then
        return M.parseAnswer(buf) or { ok = false, why = "connection " .. tostring(ev[6] or "closed") }
      end
    end
  end
end

local function readFile(p) local f = fs.open(p, "rb"); if not f then return nil end local t = f.readAll(); f.close(); return t end

local function serve(slot, root, name, password)
  fs.makeDir(root)
  local ok, why = nic.listen(slot, PORT)
  if ok == false then error("cannot listen: " .. tostring(why), 0) end
  if name then nic.setHostname(slot, name) end
  local fsys = {
    exists = fs.exists, isDir = fs.isDir, list = fs.list, size = fs.getSize, read = readFile,
    write = function(p, t) local f = fs.open(p, "wb"); f.write(t); f.close() end, delete = fs.delete,
  }
  local buffers = {}
  print("rpfiles sharing /" .. root .. (password and " (uploads need the password)" or " (read-only)") .. " on port " .. PORT .. "  (Ctrl+T stops)")
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then pcall(nic.unlisten, slot, PORT); return end
    if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot then
      local kind, id = ev[4], ev[5]
      if kind == "accepted" then buffers[id] = { data = "" }
      elseif kind == "closed" then buffers[id] = nil
      elseif kind == "data" and buffers[id] then
        local b = buffers[id]
        b.data = b.data .. ev[6]
        local nl = b.data:find("\n", 1, true)
        if nl then
          local req = M.parseRequest(b.data:sub(1, nl - 1))
          local body = b.data:sub(nl + 1)
          local answer
          if not req then answer = M.err("bad request")
          elseif req.op == "PUT" and #body < req.len and req.len <= MAX then answer = nil   -- wait for the rest
          else answer = M.handle(req, body:sub(1, req.len or 0), root, fsys, password) end
          if answer then
            print((req and req.op or "?") .. " " .. (req and req.path or "") .. " -> " .. answer:match("^%u+"))
            sendAll(slot, id, answer)
            pcall(nic.tcpClose, slot, id)
            buffers[id] = nil
          end
        end
      end
    end
  end
end

local args = { ... }
local cmd = args[1]
if cmd == "serve" then
  local slot, root, name, pw = 1, "share", nil, nil
  local i, plain = 2, {}
  while args[i] do
    if args[i] == "--password" then pw = args[i + 1]; i = i + 1 else plain[#plain + 1] = args[i] end
    i = i + 1
  end
  if tonumber(plain[1]) then slot = tonumber(table.remove(plain, 1)) end
  root = plain[1] or root; name = plain[2]
  serve(slot, root, name, pw)
elseif cmd == "ls" and args[2] then
  local a = ask(args[2], M.buildRequest("LS", args[3] or ""))
  if not a.ok then print("error: " .. a.why) else
    for line in (a.body .. "\n"):gmatch("([^\n]*)\n") do
      local n, s = line:match("^(.-)\t(.*)$")
      if n then print(s == "dir" and (n .. "/") or (n .. "  (" .. s .. " bytes)")) end
    end
  end
elseif cmd == "get" and args[2] and args[3] then
  local a = ask(args[2], M.buildRequest("GET", args[3]))
  if not a.ok then print("error: " .. a.why) else
    local target = args[4] or fs.getName(args[3])
    local f = fs.open(target, "wb"); f.write(a.body); f.close()
    print("saved " .. target .. " (" .. #a.body .. " bytes)")
  end
elseif cmd == "put" and args[2] and args[3] and args[4] then
  local text = readFile(args[4])
  if not text then error("cannot read " .. args[4], 0) end
  local a = ask(args[2], M.buildRequest("PUT", args[3], #text, args[5] or ""), text)
  print(a.ok and "uploaded" or ("error: " .. a.why))
elseif cmd == "rm" and args[2] and args[3] then
  local a = ask(args[2], M.buildRequest("RM", args[3], args[4] or ""))
  print(a.ok and "deleted" or ("error: " .. a.why))
else
  print("rpfiles serve [slot] [folder] [name] [--password pw] | ls <host> [path] | get <host> <path> [file] | put <host> <path> <file> <pw> | rm <host> <path> <pw>")
end

return M
