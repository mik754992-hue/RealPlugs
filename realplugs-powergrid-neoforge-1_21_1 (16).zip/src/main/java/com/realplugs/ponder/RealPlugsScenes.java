package com.realplugs.ponder;

import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/**
 * Ponder scenes. Airport schematic (5 x 5 x 10): a pillar at x=3, z=5 with a Universal Power Strip at y=1 and a USB
 * Charging Hub at y=2 on each of its four faces. House schematic (4 x 4 x 4): one Wall Outlet at (1, 1, 1) facing east.
 */
public final class RealPlugsScenes {
    private RealPlugsScenes() {}

    /** Power strips, hubs and panels. */
    public static void chargingIsland(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("charging_island", "Power strips and USB hubs");
        scene.configureBasePlate(0, 0, 10);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos strip = util.grid().at(2, 1, 5);
        BlockPos hub = util.grid().at(2, 2, 5);

        scene.overlay().showText(90)
                .text("Power strips, hubs and panels can be mounted on any wall, floor or ceiling")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(90)
                .text("A Universal Power Strip has four slots: US, EU, UK and USB-A")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(90)
                .text("A USB Charging Hub has two USB-A slots and two USB-C slots")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(hub, Direction.WEST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(110)
                .text("Power comes in through the two small connectors on the sides: red is hot and blue is neutral. Connect them with Power Grid wires")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.NORTH))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(110)
                .text("Right-click a slot with a plug of the same connector. A slot only passes power while something is plugged into it")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(120);

        scene.effects().indicateSuccess(strip);
        scene.idle(20);
    }

    /** Wall outlets. */
    public static void wallOutlet(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("wall_outlet", "Wall outlets");
        scene.configureBasePlate(0, 0, 4);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos outlet = util.grid().at(1, 1, 1);

        scene.overlay().showText(80)
                .text("Wall outlets sit flat against a wall. This one is a US outlet with two slots")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showText(100)
                .text("Wire power into the small red (hot) and blue (neutral) connectors on its sides")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.NORTH))
                .placeNearTarget();
        scene.idle(110);

        scene.overlay().showText(100)
                .text("Hold a plug of the matching connector and right-click a slot. A plug that does not fit is refused")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(110);

        scene.overlay().showText(90)
                .text("EU, UK, AU and DC barrel outlets work the same way, each with its own connector")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(100);

        scene.effects().indicateSuccess(outlet);
        scene.idle(20);
    }

    /** Plugs and adapters. */
    public static void plugsAndAdapters(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("plugs_and_adapters", "Plugs and adapters");
        scene.configureBasePlate(0, 0, 4);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos outlet = util.grid().at(1, 1, 1);

        scene.overlay().showText(110)
                .text("Plugs come in many connectors: US, EU, UK, AU, USB-A, USB-C, Micro-USB, Lightning, HDMI, DisplayPort, Ethernet and DC barrel")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(110)
                .text("An adapter plugs into a slot and has its own slots for a different connector, so an EU device can use a US outlet")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(90)
                .text("Multi-taps turn one slot into several")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(100)
                .text("Right-click a slot with an empty hand to take its plug or adapter back out")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(110);
    }

    /** Plug cords. */
    public static void cords(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("plug_cords", "Plug cords");
        scene.configureBasePlate(0, 0, 10);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos strip = util.grid().at(2, 1, 5);
        BlockPos hub = util.grid().at(2, 2, 5);

        scene.overlay().showText(110)
                .text("A plug cord is a Power Grid cord with a plug on each end. Some have the same plug on both ends, others change connector, like US to USB-A")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(110)
                .text("Right-click a free slot with the cord, then a second slot to finish the lead. Each end only fits slots of its own connector")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(hub, Direction.WEST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(100)
                .text("A slot holding a cord passes power like a plugged-in plug, so the cord carries that one slot")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(110);
    }
}
