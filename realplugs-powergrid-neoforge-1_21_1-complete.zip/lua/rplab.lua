-- rplab: sets a computer up as the web server of the Real Plugs test lab (datapacks/realplugs_testlab).
-- It writes a small site into /www (a home page and a guest book with logins), then you run:  rpweb serve 1 lab
local function write(path, text)
  local f = fs.open(path, "w"); f.write(text); f.close()
end
fs.makeDir("www")
write("www/index.html", [[<html><title>Real Plugs lab</title><body>
<center><h1>Real Plugs lab</h1></center>
<div style="color:lime">Your network works if you can read this.</div>
<p><a href="/guests.lua">Guest book</a> - <a href="/mail">Webmail</a> (if rpmail serve is running on this name)</p>
<p>Served by <b>{{host}}</b> at {{time}}. Hits: {{hits}}</p></body></html>]])
write("www/guests.lua", [[
local book = data_load("guests") or {}
local me = session().user
if request.form.act == "register" then
  local ok, why = users_add(request.form.name or "", request.form.pw or "")
  if ok then session().user = request.form.name:lower(); redirect("/guests.lua") return end
  echo("<p>" .. tostring(why) .. "</p>")
elseif request.form.act == "login" then
  if users_check(request.form.name or "", request.form.pw or "") then session().user = request.form.name:lower(); redirect("/guests.lua") return end
  echo("<p>wrong name or password</p>")
elseif request.form.act == "write" and me and (request.form.text or "") ~= "" then
  book[#book + 1] = { me, request.form.text:sub(1, 80) }
  if #book > 30 then table.remove(book, 1) end
  data_save("guests", book); redirect("/guests.lua") return
end
echo("<html><title>Guest book</title><body><h1>Guest book</h1>")
for i = #book, 1, -1 do echo("<p><b>" .. book[i][1] .. "</b>: " .. book[i][2] .. "</p>") end
if me then
  echo('<form method="post"><input type="hidden" name="act" value="write">' .. me .. ' says <input name="text" size="30"> <button>Sign</button></form>')
else
  echo('<form method="post"><input type="hidden" name="act" value="login">Name <input name="name"> Password <input type="password" name="pw"> <button>Log in</button></form>')
  echo('<form method="post"><input type="hidden" name="act" value="register">New: <input name="name"> <input type="password" name="pw"> <button>Register</button></form>')
end
echo('<p><a href="/">home</a></p></body></html>')
]])
print("lab site written to /www. Now run:  rpweb serve 1 lab")
