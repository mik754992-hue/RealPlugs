package com.realplugs.net;

import com.realplugs.PlugSocketBlockEntity;
import com.realplugs.RealPlugsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * The network model behind the "realplugs_socket" CC: Tweaked peripheral.
 *
 * <ul>
 *   <li>Every RJ45 slot of a socket is an interface with its own MAC address and its own IP settings.</li>
 *   <li>An ethernet cord (a Power Grid cord with an RJ45 plug on each end) between two RJ45 slots is a link:
 *       two cabled interfaces are a point-to-point connection.</li>
 *   <li>A LAN segment is everything connected by cords through sockets that are set to bridge mode (a switch).</li>
 *   <li>Inside a segment, addresses of the same subnet reach each other directly. Anything else goes to the interface's
 *       gateway, which has to be an interface of a socket in router mode. A router passes packets on to the network
 *       that holds the destination, or to its uplink.</li>
 *   <li>An uplink interface is a modem: the ISP gives it a public address (100.64.0.0/10), and it can reach every
 *       other uplink on the server, with a delay that grows with the distance. A router with an uplink does NAT for
 *       the private addresses behind it.</li>
 *   <li>Datagrams (UDP-like) and connections (TCP-like: listen, connect, in-order data, close, refused/reset) carry ports and
 *       at most 1500 characters per packet. Raw Ethernet frames stay inside a segment. Hostnames resolve inside the
 *       segment and, for uplinks, across the internet. Nothing is simulated that is not listed here.</li>
 *   <li>The Network Switch block is a socket whose ports are always bridged.</li>
 * </ul>
 * Nothing here is ever simulated tick by tick: routes are worked out when a packet is sent. Server thread only.
 */
@EventBusSubscriber(modid = RealPlugsMod.MODID)
public final class NetworkManager {
    public static final int MTU = 1500;
    private static final int TTL = 16;

    public record Iface(ServerLevel level, BlockPos pos, int slot) {}

    public static final class Packet {
        long src, dst;
        int srcPort, dstPort;
        int proto;   // 0 = datagram, 1 = connection segment
        int flags;   // SYN, ACK, FIN, RST, DATA
        String payload = "";

        Packet copy() {
            Packet p = new Packet();
            p.src = src;
            p.dst = dst;
            p.srcPort = srcPort;
            p.dstPort = dstPort;
            p.proto = proto;
            p.flags = flags;
            p.payload = payload;
            return p;
        }
    }

    public static final class Route {
        Iface target;
        Packet packet;
        int ticks;
        String error;
    }

    private record Pending(long due, long seq, GlobalPos where, int slot, Packet packet) {}

    private record WanEntry(GlobalPos where, int slot) {}

    private static final PriorityQueue<Pending> QUEUE = new PriorityQueue<>(Comparator.comparingLong(Pending::due).thenComparingLong(Pending::seq));
    private static long seq;
    private static final Map<Long, WanEntry> WAN = new HashMap<>();
    /** Hostnames of uplink interfaces, across the whole server. */
    private static final Map<String, Long> DNS = new HashMap<>();

    private NetworkManager() {}

    // ------------------------------------------------------------------ lookups

    public static PlugSocketBlockEntity beOf(ServerLevel level, BlockPos pos) {
        if (!level.isLoaded(pos)) return null;
        return level.getBlockEntity(pos) instanceof PlugSocketBlockEntity b ? b : null;
    }

    private static PlugSocketBlockEntity be(Iface i) {
        return beOf(i.level(), i.pos());
    }

    private static boolean usable(Iface i) {
        PlugSocketBlockEntity b = be(i);
        return b != null && i.slot() >= 0 && i.slot() < b.slotCount() && b.isRj45(i.slot());
    }

    public static String mac(Iface i) {
        int h = Objects.hash(i.level().dimension().location().toString(), i.pos().asLong(), i.slot());
        return String.format("02:52:50:%02x:%02x:%02x", (h >> 16) & 255, (h >> 8) & 255, h & 255);
    }

    /** The interface at the other end of the cord in this slot, if there is one. */
    public static Iface peer(Iface i) {
        PlugSocketBlockEntity b = be(i);
        if (b == null) return null;
        int[] p = b.cordPeer(i.slot());
        return p == null ? null : new Iface(i.level(), new BlockPos(p[0], p[1], p[2]), p[3]);
    }

    private static List<Iface> neighbors(Iface i) {
        List<Iface> out = new ArrayList<>();
        PlugSocketBlockEntity b = be(i);
        if (b == null) return out;
        Iface peer = peer(i);
        if (peer != null) out.add(peer);
        if (b.net().bridge || b.isSwitchBlock()) {
            for (int s = 0; s < b.slotCount(); s++) {
                if (s != i.slot() && b.isRj45(s)) out.add(new Iface(i.level(), i.pos(), s));
            }
        } else if (b.isRouterBlock() && i.slot() != PlugSocketBlockEntity.ROUTER_WAN) {
            for (int s = 0; s < PlugSocketBlockEntity.ROUTER_WAN; s++) {   // the LAN ports are one segment
                if (s != i.slot()) out.add(new Iface(i.level(), i.pos(), s));
            }
        }
        return out;
    }

    /** Every interface that shares a segment with this one (itself included). */
    public static List<Iface> domain(Iface start) {
        List<Iface> out = new ArrayList<>();
        Set<Iface> seen = new HashSet<>();
        ArrayDeque<Iface> todo = new ArrayDeque<>();
        todo.add(start);
        seen.add(start);
        while (!todo.isEmpty() && out.size() < 256) {
            Iface i = todo.poll();
            if (!usable(i)) continue;
            out.add(i);
            for (Iface n : neighbors(i)) if (seen.add(n)) todo.add(n);
        }
        return out;
    }

    private static Iface findByIp(List<Iface> domain, long ip) {
        for (Iface i : domain) {
            PlugSocketBlockEntity b = be(i);
            if (b != null && NetConfig.parse(b.net().ip(i.slot())) == ip) return i;
        }
        return null;
    }

    // ------------------------------------------------------------------ routing

    private static Route fail(String why) {
        Route r = new Route();
        r.error = why;
        return r;
    }

    private static Route ok(Iface target, Packet p, int ticks) {
        Route r = new Route();
        r.target = target;
        r.packet = p;
        r.ticks = ticks;
        return r;
    }

    /** The packet leaves through this interface. */
    private static Route out(Iface at, Packet p, int ttl, int ticks) {
        if (ttl <= 0) return fail("time to live exceeded");
        PlugSocketBlockEntity b = be(at);
        if (b == null) return fail("interface offline");
        NetConfig c = b.net();
        if (c.uplink[at.slot()]) return wan(at, p, ttl, ticks);
        long mine = NetConfig.parse(c.ip(at.slot()));
        if (mine < 0) return fail("interface has no address");
        List<Iface> dom = domain(at);
        if (NetConfig.sameSubnet(mine, p.dst, c.prefix[at.slot()])) {
            Iface t = findByIp(dom, p.dst);
            return t == null ? fail("host unreachable") : ok(t, p, ticks);
        }
        long gw = NetConfig.parse(c.gateway(at.slot()));
        if (gw < 0) return fail("no route to host");
        Iface g = findByIp(dom, gw);
        return g == null ? fail("gateway unreachable") : forward(g, p, ttl - 1, ticks + 1);
    }

    /** A packet arrives at a router's interface to be passed on. */
    private static Route forward(Iface in, Packet p, int ttl, int ticks) {
        PlugSocketBlockEntity b = be(in);
        if (b == null) return fail("gateway offline");
        NetConfig c = b.net();
        if (!c.routing) return fail("gateway is not a router");
        // 1. a network this router is attached to
        for (int s = 0; s < b.slotCount(); s++) {
            if (s == in.slot() || !b.isRj45(s) || c.uplink[s]) continue;
            long ipS = NetConfig.parse(c.ip(s));
            if (ipS >= 0 && NetConfig.sameSubnet(ipS, p.dst, c.prefix[s])) {
                return out(new Iface(in.level(), in.pos(), s), p, ttl, ticks);
            }
        }
        // 2. the internet, through the uplink (with NAT)
        for (int s = 0; s < b.slotCount(); s++) {
            if (!b.isRj45(s) || !c.uplink[s]) continue;
            return out(new Iface(in.level(), in.pos(), s), natOut(c, s, p), ttl, ticks);
        }
        // 3. another router
        for (int s = 0; s < b.slotCount(); s++) {
            if (s == in.slot() || !b.isRj45(s) || c.gateway(s).isEmpty()) continue;
            return out(new Iface(in.level(), in.pos(), s), p, ttl, ticks);
        }
        return fail("no route");
    }

    private static Packet natOut(NetConfig c, int uplinkSlot, Packet p) {
        String key = NetConfig.format(p.src) + ":" + p.srcPort;
        Integer port = c.natOut.get(key);
        if (port == null) {
            for (Map.Entry<Integer, String> f : c.forwards.entrySet()) {   // a forwarded service answers from its public port
                if (f.getValue().equals(key)) {
                    port = f.getKey();
                    break;
                }
            }
        }
        if (port == null) {
            port = c.nextNatPort++;
            if (c.nextNatPort > 65535) c.nextNatPort = 49152;
            c.natOut.put(key, port);
            c.natIn.put(port, key);
        }
        Packet q = p.copy();
        q.src = NetConfig.parse(c.ip(uplinkSlot));
        q.srcPort = port;
        return q;
    }

    private static Route wan(Iface at, Packet p, int ttl, int ticks) {
        if (peer(at) == null) return fail("the line is down (no cable on the uplink)");
        WanEntry e = WAN.get(p.dst);
        if (e == null) return fail("destination unreachable on the internet");
        ServerLevel lvl = at.level().getServer().getLevel(e.where().dimension());
        if (lvl == null) return fail("destination unreachable on the internet");
        Iface t = new Iface(lvl, e.where().pos(), e.slot());
        PlugSocketBlockEntity tb = be(t);
        if (tb == null || !tb.net().uplink[e.slot()] || peer(t) == null) return fail("destination unreachable on the internet");
        int delay;
        if (lvl == at.level()) {
            double dx = t.pos().getX() - at.pos().getX();
            double dz = t.pos().getZ() - at.pos().getZ();
            delay = 1 + (int) Math.min(10, Math.sqrt(dx * dx + dz * dz) / 512);
        } else {
            delay = 6;
        }
        return inbound(t, p, ttl - 1, ticks + delay);
    }

    /** A packet comes in through an uplink interface. */
    private static Route inbound(Iface t, Packet p, int ttl, int ticks) {
        PlugSocketBlockEntity b = be(t);
        if (b == null) return fail("destination offline");
        NetConfig c = b.net();
        if (c.routing) {
            String priv = c.natIn.get(p.dstPort);
            if (priv == null) priv = c.forwards.get(p.dstPort);   // port forwarding
            if (priv != null) {
                int colon = priv.lastIndexOf(':');
                long privIp = NetConfig.parse(priv.substring(0, colon));
                int privPort = Integer.parseInt(priv.substring(colon + 1));
                Packet q = p.copy();
                q.dst = privIp;
                q.dstPort = privPort;
                for (int s = 0; s < b.slotCount(); s++) {
                    if (s == t.slot() || !b.isRj45(s) || c.uplink[s]) continue;
                    long ipS = NetConfig.parse(c.ip(s));
                    if (ipS >= 0 && NetConfig.sameSubnet(ipS, privIp, c.prefix[s])) {
                        return out(new Iface(t.level(), t.pos(), s), q, ttl, ticks);
                    }
                }
                return fail("nothing behind the router answers");
            }
        }
        return ok(t, p, ticks);
    }

    // ------------------------------------------------------------------ what the peripheral calls

    /** Sends a datagram. Returns null when it was handed over, otherwise why not. */
    public static String send(Iface src, String dstIp, int srcPort, int dstPort, String payload) {
        if (!usable(src)) return "not a network port";
        long dst = NetConfig.parse(dstIp);
        if (dst < 0) return "bad address";
        if (payload.length() > MTU) return "packet too large (more than " + MTU + " characters)";
        if (srcPort < 0 || srcPort > 65535 || dstPort < 0 || dstPort > 65535) return "bad port";
        PlugSocketBlockEntity b = be(src);
        long mine = NetConfig.parse(b.net().ip(src.slot()));
        if (mine < 0) return "interface has no address";
        Packet p = new Packet();
        p.src = mine;
        p.dst = dst;
        p.srcPort = srcPort;
        p.dstPort = dstPort;
        p.payload = payload;
        return dispatch(src, p);
    }

    private static String dispatch(Iface src, Packet p) {
        Route r = out(src, p, TTL, 0);
        if (r.error != null) return r.error;
        schedule(r);
        return null;
    }

    private static void schedule(Route r) {
        if (r.ticks <= 0) {
            deliver(r.target, r.packet);
        } else {
            QUEUE.add(new Pending(r.target.level().getServer().getTickCount() + r.ticks, ++seq,
                    GlobalPos.of(r.target.level().dimension(), r.target.pos()), r.target.slot(), r.packet));
        }
    }

    /** Round trip time in milliseconds, or a negative number and the reason in error[0]. */
    public static int ping(Iface src, String dstIp, String[] error) {
        if (!usable(src)) {
            error[0] = "not a network port";
            return -1;
        }
        long dst = NetConfig.parse(dstIp);
        if (dst < 0) {
            error[0] = "bad address";
            return -1;
        }
        PlugSocketBlockEntity b = be(src);
        long mine = NetConfig.parse(b.net().ip(src.slot()));
        if (mine < 0) {
            error[0] = "interface has no address";
            return -1;
        }
        Packet p = new Packet();
        p.src = mine;
        p.dst = dst;
        Route r = out(src, p, TTL, 0);
        if (r.error != null) {
            error[0] = r.error;
            return -1;
        }
        return 1 + r.ticks * 100;   // one tick is 50 ms each way
    }

    /** Every host port in the segment (the ports of a Network Switch are not hosts). */
    public static List<Iface> scan(Iface src) {
        List<Iface> out = new ArrayList<>();
        for (Iface i : domain(src)) {
            PlugSocketBlockEntity b = be(i);
            if (b == null || b.isSwitchBlock()) continue;
            if (b.isRouterBlock() && i.slot() > 0 && i.slot() != PlugSocketBlockEntity.ROUTER_WAN) continue;   // one entry per router
            out.add(i);
        }
        return out;
    }

    /** DHCP: takes an address from a DHCP server in the same segment. Returns null on success, otherwise why not. */
    public static String autoConfigure(Iface me) {
        if (!usable(me)) return "not a network port";
        PlugSocketBlockEntity b = be(me);
        List<Iface> dom = domain(me);
        for (Iface d : dom) {
            if (d.equals(me)) continue;
            PlugSocketBlockEntity db = be(d);
            if (db == null) continue;
            NetConfig dc = db.net();
            long dip = NetConfig.parse(dc.ip(d.slot()));
            int pre = dc.prefix[d.slot()];
            if (!dc.dhcp[d.slot()] || dip < 0 || pre < 8 || pre > 30) continue;
            long mask = (0xFFFFFFFFL << (32 - pre)) & 0xFFFFFFFFL;
            long net = dip & mask;
            long size = 1L << (32 - pre);
            Set<Long> used = new HashSet<>();
            for (Iface o : dom) {
                PlugSocketBlockEntity ob = be(o);
                if (ob != null) used.add(NetConfig.parse(ob.net().ip(o.slot())));
            }
            for (long off = 2; off < size - 1; off++) {
                long cand = net + off;
                if (used.contains(cand)) continue;
                NetConfig c = b.net();
                c.ip[me.slot()] = NetConfig.format(cand);
                c.prefix[me.slot()] = pre;
                c.gateway[me.slot()] = dc.routing ? NetConfig.format(dip) : "";
                b.netChanged();
                return null;
            }
            return "the DHCP address pool is full";
        }
        return "no DHCP server found";
    }

    /** Turns a port into an uplink (a modem) or back. Returns null on success, otherwise why not. */
    public static String setUplink(Iface me, boolean on) {
        if (!usable(me)) return "not a network port";
        PlugSocketBlockEntity b = be(me);
        NetConfig c = b.net();
        int s = me.slot();
        if (on) {
            if (peer(me) == null) return "no cable on this port";
            if (!c.uplink[s]) {
                long ip = assignPublicIp(me);
                c.ip[s] = NetConfig.format(ip);
                c.prefix[s] = 32;
                c.gateway[s] = "";
                c.uplink[s] = true;
                if (!c.hostname(s).isEmpty()) DNS.putIfAbsent(c.hostname(s), ip);
            }
        } else if (c.uplink[s]) {
            long old = NetConfig.parse(c.ip(s));
            WAN.remove(old);
            DNS.values().removeIf(v -> v == old);
            c.uplink[s] = false;
            c.ip[s] = "";
            c.prefix[s] = 0;
        }
        b.netChanged();
        return null;
    }

    private static long assignPublicIp(Iface i) {
        int h = Objects.hash(i.level().dimension().location().toString(), i.pos().asLong(), i.slot()) & 0x3FFFFF;
        long ip = 0;
        for (int n = 0; n < 0x400000; n++) {
            ip = 0x64400000L + ((h + n) & 0x3FFFFF);   // 100.64.0.0/10
            if (!WAN.containsKey(ip)) break;
        }
        WAN.put(ip, new WanEntry(GlobalPos.of(i.level().dimension(), i.pos()), i.slot()));
        return ip;
    }

    // ------------------------------------------------------------------ raw frames

    /** A raw Ethernet frame to one port of the segment, or to all of them (ff:ff:ff:ff:ff:ff). Null on success. */
    public static String sendFrame(Iface src, String dstMac, int etherType, String payload) {
        if (!usable(src)) return "not a network port";
        if (payload.length() > MTU) return "frame too large (more than " + MTU + " characters)";
        if (etherType < 0 || etherType > 65535) return "bad ether type";
        String dm = dstMac.trim().toLowerCase(Locale.ROOT);
        boolean broadcast = dm.equals("ff:ff:ff:ff:ff:ff");
        String sm = mac(src);
        int n = 0;
        for (Iface i : domain(src)) {
            if (i.equals(src)) continue;
            PlugSocketBlockEntity b = be(i);
            if (b == null || b.isSwitchBlock()) continue;
            if (broadcast || mac(i).equals(dm)) {
                for (NetListener l : b.netListeners()) l.frame(i.slot() + 1, sm, dm, etherType, payload);
                n++;
            }
        }
        return n == 0 && !broadcast ? "no such station in this segment" : null;
    }

    // ------------------------------------------------------------------ connections (TCP-like)

    private static final int SYN = 1, ACK = 2, FIN = 4, RST = 8, DATA = 16;

    private static final class Conn {
        final Iface local;
        final int localPort;
        final long remoteIp;
        final int remotePort;
        final int id;
        boolean established;

        Conn(Iface local, int localPort, long remoteIp, int remotePort, int id) {
            this.local = local;
            this.localPort = localPort;
            this.remoteIp = remoteIp;
            this.remotePort = remotePort;
            this.id = id;
        }
    }

    private static final Map<String, Conn> CONNS = new HashMap<>();
    private static final Set<String> LISTEN = new HashSet<>();
    private static int nextConnId = 1;
    private static int nextEphemeral = 49152;

    private static String ikey(Iface i) {
        return i.level().dimension().location() + "|" + i.pos().asLong() + "|" + i.slot();
    }

    private static String ckey(Iface i, int localPort, long remoteIp, int remotePort) {
        return ikey(i) + "|" + localPort + "|" + remoteIp + "|" + remotePort;
    }

    private static Conn conn(Iface me, int id) {
        for (Conn c : CONNS.values()) if (c.id == id && c.local.equals(me)) return c;
        return null;
    }

    private static void notifyTcp(Iface t, String event, int id, Object... args) {
        PlugSocketBlockEntity b = be(t);
        if (b == null) return;
        for (NetListener l : b.netListeners()) l.tcp(t.slot() + 1, event, id, args);
    }

    private static Packet segment(Iface from, long dst, int srcPort, int dstPort, int flags, String payload) {
        PlugSocketBlockEntity b = be(from);
        Packet p = new Packet();
        p.proto = 1;
        p.flags = flags;
        p.src = b == null ? 0 : NetConfig.parse(b.net().ip(from.slot()));
        p.dst = dst;
        p.srcPort = srcPort;
        p.dstPort = dstPort;
        p.payload = payload;
        return p;
    }

    public static String listen(Iface me, int port, boolean on) {
        if (!usable(me)) return "not a network port";
        if (port < 1 || port > 65535) return "bad port";
        if (on) LISTEN.add(ikey(me) + "|" + port);
        else LISTEN.remove(ikey(me) + "|" + port);
        return null;
    }

    /** Opens a connection: returns its id, or -1 and why not in error[0]. "connected" arrives as an event. */
    public static int connect(Iface me, String dstIp, int dstPort, String[] error) {
        if (!usable(me)) {
            error[0] = "not a network port";
            return -1;
        }
        long dst = NetConfig.parse(dstIp);
        if (dst < 0 || dstPort < 1 || dstPort > 65535) {
            error[0] = "bad address or port";
            return -1;
        }
        PlugSocketBlockEntity b = be(me);
        if (NetConfig.parse(b.net().ip(me.slot())) < 0) {
            error[0] = "interface has no address";
            return -1;
        }
        int local = nextEphemeral++;
        if (nextEphemeral > 65535) nextEphemeral = 49152;
        Packet syn = segment(me, dst, local, dstPort, SYN, "");
        Route r = out(me, syn, TTL, 0);
        if (r.error != null) {
            error[0] = r.error;
            return -1;
        }
        Conn c = new Conn(me, local, dst, dstPort, nextConnId++);
        CONNS.put(ckey(me, local, dst, dstPort), c);
        schedule(r);
        return c.id;
    }

    /** Sends data on an open connection (at most 1500 characters at a time). Null on success. */
    public static String tcpSend(Iface me, int id, String data) {
        Conn c = conn(me, id);
        if (c == null) return "no such connection";
        if (!c.established) return "connection is not open yet";
        if (data.length() > MTU) return "segment too large (more than " + MTU + " characters)";
        String err = dispatch(me, segment(me, c.remoteIp, c.localPort, c.remotePort, DATA, data));
        if (err != null) {
            CONNS.remove(ckey(me, c.localPort, c.remoteIp, c.remotePort));
            notifyTcp(me, "closed", id, "timeout");
        }
        return err;
    }

    public static String tcpClose(Iface me, int id) {
        Conn c = conn(me, id);
        if (c == null) return "no such connection";
        CONNS.remove(ckey(me, c.localPort, c.remoteIp, c.remotePort));
        dispatch(me, segment(me, c.remoteIp, c.localPort, c.remotePort, FIN, ""));
        return null;
    }

    private static void reply(Iface from, Packet orig, int flags) {
        dispatch(from, segment(from, orig.src, orig.dstPort, orig.srcPort, flags, ""));
    }

    private static void tcpIn(Iface t, Packet p) {
        if ((p.flags & SYN) != 0 && (p.flags & ACK) == 0) {
            if (!LISTEN.contains(ikey(t) + "|" + p.dstPort)) {
                reply(t, p, RST);   // connection refused
                return;
            }
            Conn c = new Conn(t, p.dstPort, p.src, p.srcPort, nextConnId++);
            c.established = true;
            CONNS.put(ckey(t, p.dstPort, p.src, p.srcPort), c);
            notifyTcp(t, "accepted", c.id, NetConfig.format(p.src), p.srcPort, p.dstPort);
            reply(t, p, SYN | ACK);
            return;
        }
        String key = ckey(t, p.dstPort, p.src, p.srcPort);
        Conn c = CONNS.get(key);
        if (c == null) {
            if ((p.flags & RST) == 0) reply(t, p, RST);
            return;
        }
        if ((p.flags & RST) != 0) {
            CONNS.remove(key);
            notifyTcp(t, "closed", c.id, c.established ? "connection reset" : "connection refused");
        } else if ((p.flags & SYN) != 0) {   // SYN + ACK
            c.established = true;
            notifyTcp(t, "connected", c.id, NetConfig.format(c.remoteIp), c.remotePort);
        } else if ((p.flags & FIN) != 0) {
            CONNS.remove(key);
            notifyTcp(t, "closed", c.id, "closed by the other side");
        } else if ((p.flags & DATA) != 0 && c.established) {
            notifyTcp(t, "data", c.id, p.payload);
        }
    }

    // ------------------------------------------------------------------ names

    /** Gives a port a hostname. On an uplink it is registered for the whole server. Null on success. */
    public static String setHostname(Iface me, String name) {
        if (!usable(me)) return "not a network port";
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (!n.isEmpty() && !n.matches("[a-z0-9]([a-z0-9.-]{0,60}[a-z0-9])?")) return "bad name (letters, digits, dots and dashes)";
        PlugSocketBlockEntity b = be(me);
        NetConfig c = b.net();
        int s = me.slot();
        long ip = NetConfig.parse(c.ip(s));
        if (c.uplink[s] && !n.isEmpty() && DNS.containsKey(n) && DNS.get(n) != ip) return "name already taken";
        if (!c.hostname(s).isEmpty()) DNS.remove(c.hostname(s), ip);
        c.hostname[s] = n;
        if (c.uplink[s] && !n.isEmpty()) DNS.put(n, ip);
        b.netChanged();
        return null;
    }

    /** An address for a name: a port with that hostname in the segment, or an uplink with that name anywhere. */
    public static String resolve(Iface me, String name, String[] error) {
        String n = name.trim().toLowerCase(Locale.ROOT);
        for (Iface i : domain(me)) {
            PlugSocketBlockEntity b = be(i);
            if (b != null && n.equals(b.net().hostname(i.slot())) && !b.net().ip(i.slot()).isEmpty()) return b.net().ip(i.slot());
        }
        Long ip = DNS.get(n);
        if (ip != null && WAN.containsKey(ip)) return NetConfig.format(ip);
        error[0] = "name not found";
        return null;
    }

    /** An address or a name to an address. */
    public static String address(Iface me, String hostOrIp, String[] error) {
        if (NetConfig.parse(hostOrIp) >= 0) return hostOrIp.trim();
        return resolve(me, hostOrIp, error);
    }

    // ------------------------------------------------------------------ bookkeeping

    /** A socket with uplinks has loaded: it is on the internet again. */
    public static void register(PlugSocketBlockEntity be) {
        if (!(be.getLevel() instanceof ServerLevel level)) return;
        NetConfig c = be.net();
        for (int s = 0; s < be.slotCount(); s++) {
            long ip = NetConfig.parse(c.ip(s));
            if (c.uplink[s] && ip >= 0) {
                WAN.put(ip, new WanEntry(GlobalPos.of(level.dimension(), be.getBlockPos()), s));
                if (!c.hostname(s).isEmpty()) DNS.putIfAbsent(c.hostname(s), ip);
            }
        }
    }

    /** A socket is gone (broken or its chunk unloaded): its uplinks are off the internet. */
    public static void unregister(PlugSocketBlockEntity be) {
        if (!(be.getLevel() instanceof ServerLevel level)) return;
        GlobalPos here = GlobalPos.of(level.dimension(), be.getBlockPos());
        WAN.values().removeIf(e -> e.where().equals(here));
        DNS.values().removeIf(ip -> !WAN.containsKey(ip));
        CONNS.values().removeIf(c -> c.local.level() == level && c.local.pos().equals(be.getBlockPos()));
        String prefix = level.dimension().location() + "|" + be.getBlockPos().asLong() + "|";
        LISTEN.removeIf(k -> k.startsWith(prefix));
    }

    private static void deliver(Iface t, Packet p) {
        PlugSocketBlockEntity b = be(t);
        if (b == null) return;
        if (p.proto == 1) {
            tcpIn(t, p);
            return;
        }
        for (NetListener l : b.netListeners()) {
            l.packet(t.slot() + 1, NetConfig.format(p.src), p.srcPort, p.dstPort, p.payload);
        }
    }

    /** Drops uplinks whose socket was broken (the block entity can't tell us itself, see PlugSocketBlockEntity). */
    private static void sweepBroken(MinecraftServer server) {
        WAN.values().removeIf(e -> {
            ServerLevel lvl = server.getLevel(e.where().dimension());
            if (lvl == null || !lvl.isLoaded(e.where().pos())) return false;
            return !(lvl.getBlockEntity(e.where().pos()) instanceof PlugSocketBlockEntity b) || b.isRemoved();
        });
        DNS.values().removeIf(ip -> !WAN.containsKey(ip));
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        long now = server.getTickCount();
        if (now % 40 == 0) sweepBroken(server);
        Pending p;
        while ((p = QUEUE.peek()) != null && p.due() <= now) {
            QUEUE.poll();
            ServerLevel level = server.getLevel(p.where().dimension());
            if (level == null) continue;
            deliver(new Iface(level, p.where().pos(), p.slot()), p.packet());
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        QUEUE.clear();
        WAN.clear();
        DNS.clear();
        CONNS.clear();
        LISTEN.clear();
    }
}
