package com.realplugs;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import com.realplugs.ponder.RealPlugsPonderPlugin;
import net.createmod.ponder.foundation.PonderIndex;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = RealPlugsMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.SOCKET.get(), PlugSocketRenderer::new);
        event.registerEntityRenderer(ModEntities.PLUG.get(), PlugEntityRenderer::new);
        event.registerEntityRenderer(ModEntities.PORT.get(), PortEntityRenderer::new);
    }

    @SubscribeEvent
    public static void clientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(() -> PonderIndex.addPlugin(new RealPlugsPonderPlugin()));
    }
}
