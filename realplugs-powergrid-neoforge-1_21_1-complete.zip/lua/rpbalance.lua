-- rpbalance: a load balancer. One name, one address, several web servers behind it.
--   rpbalance serve <slot> <backend> <backend> ... [--sticky] [--least]
-- Visitors connect to this computer on port 80; each request goes to one backend (round robin, or the one with the fewest open
-- requests with --least, or always the same one per visitor with --sticky). A backend that refuses a connection is left out
-- for 30 seconds. Every answer gets an "X-Served-By" header so you can see who served it.
local M = {}

-- opts = { strategy = "round"|"least"|"sticky", downFor = seconds }
function M.new(backends, opts)
  opts = opts or {}
  local B = { list = {}, next = 1, strategy = opts.strategy or "round", downFor = opts.downFor or 30 }
  for _, name in ipairs(backends) do B.list[#B.list + 1] = { name = name, open = 0, downUntil = 0, served = 0 } end
  local function up(b, now) return b.downUntil <= now end
  -- the backend for a visitor (an address) at time `now`; nil when all are down
  function B.pick(visitor, now)
    now = now or 0
    local n = #B.list
    if n == 0 then return nil end
    if B.strategy == "sticky" and visitor then
      local h = 0
      for i = 1, #visitor do h = (h * 31 + visitor:byte(i)) % 1000003 end
      for k = 0, n - 1 do
        local b = B.list[(h + k) % n + 1]
        if up(b, now) then b.open = b.open + 1; b.served = b.served + 1; return b end
      end
      return nil
    elseif B.strategy == "least" then
      local best
      for _, b in ipairs(B.list) do
        if up(b, now) and (not best or b.open < best.open) then best = b end
      end
      if best then best.open = best.open + 1; best.served = best.served + 1 end
      return best
    end
    for k = 0, n - 1 do
      local i = (B.next - 1 + k) % n + 1
      local b = B.list[i]
      if up(b, now) then B.next = i % n + 1; b.open = b.open + 1; b.served = b.served + 1; return b end
    end
    return nil
  end
  function B.done(b) if b.open > 0 then b.open = b.open - 1 end end
  function B.markDown(b, now) b.downUntil = (now or 0) + B.downFor; B.done(b) end
  return B
end

-- adds a header to the head of an HTTP response
function M.addHeader(raw, name, value)
  local head, rest = raw:match("^(.-)\r?\n\r?\n(.*)$")
  if not head then return raw end
  return head .. "\r\n" .. name .. ": " .. value .. "\r\n\r\n" .. rest
end

-- the request is complete when the head is there and (for a POST) the whole body
function M.requestComplete(buf)
  local head, body = buf:match("^(.-)\r?\n\r?\n(.*)$")
  if not head then return false end
  local len = tonumber(head:match("[Cc]ontent%-[Ll]ength:%s*(%d+)")) or 0
  return #body >= len
end

if RPWEB_TEST then return M end
local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpbalance" or running == "rpbalance.lua") then return M end

local args = { ... }
if args[1] ~= "serve" or not args[3] then
  print("rpbalance serve <slot> <backend> <backend> ... [--sticky] [--least]")
  return
end
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)
local slot = tonumber(args[2]) or 1
local backends, strategy = {}, "round"
for i = 3, #args do
  if args[i] == "--sticky" then strategy = "sticky" elseif args[i] == "--least" then strategy = "least"
  else backends[#backends + 1] = args[i] end
end
local B = M.new(backends, { strategy = strategy })
nic.listen(slot, 80)
print("balancing port 80 over " .. #backends .. " servers (" .. strategy .. ")  Ctrl+T stops")

local clients = {}   -- client connection id -> { ip =, buf =, backend =, bid =, reply = "" , request = "" }
local byBackend = {} -- backend connection id -> client connection id

local function startBackend(cid)
  local c = clients[cid]
  for _ = 1, #backends do
    local b = B.pick(c.ip, os.clock())
    if not b then break end
    local id = nic.connect(slot, b.name, 80)
    if id then c.backend, c.bid = b, id; byBackend[id] = cid; return true end
    B.markDown(b, os.clock())
  end
  return false
end

while true do
  local ev = { os.pullEventRaw() }
  if ev[1] == "terminate" then pcall(nic.unlisten, slot, 80); return end
  if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot then
    local kind, id = ev[4], ev[5]
    if kind == "accepted" and ev[8] == 80 then
      clients[id] = { ip = ev[6], buf = "", reply = "" }
    elseif clients[id] and kind == "data" then
      local c = clients[id]
      c.buf = c.buf .. tostring(ev[6])
      if not c.bid and M.requestComplete(c.buf) and #c.buf < 20000 then
        if not startBackend(id) then
          nic.tcpSend(slot, id, "HTTP/1.0 503 Service Unavailable\r\n\r\nno server is available")
          nic.tcpClose(slot, id); clients[id] = nil
        end
      end
    elseif clients[id] and kind == "closed" then
      local c = clients[id]
      if c.bid then byBackend[c.bid] = nil; pcall(nic.tcpClose, slot, c.bid); B.done(c.backend) end
      clients[id] = nil
    elseif byBackend[id] then
      local cid = byBackend[id]
      local c = clients[cid]
      if kind == "connected" and c then
        nic.tcpSend(slot, id, c.buf)
      elseif kind == "data" and c then
        c.reply = c.reply .. tostring(ev[6])
      elseif (kind == "closed" or kind == "refused") and c then
        byBackend[id] = nil
        if kind == "refused" or c.reply == "" then
          B.markDown(c.backend, os.clock())
          c.bid = nil
          if not startBackend(cid) then
            nic.tcpSend(slot, cid, "HTTP/1.0 503 Service Unavailable\r\n\r\nno server is available")
            nic.tcpClose(slot, cid); clients[cid] = nil
          end
        else
          B.done(c.backend)
          nic.tcpSend(slot, cid, M.addHeader(c.reply, "X-Served-By", c.backend.name))
          nic.tcpClose(slot, cid); clients[cid] = nil
        end
      end
    end
  end
end
