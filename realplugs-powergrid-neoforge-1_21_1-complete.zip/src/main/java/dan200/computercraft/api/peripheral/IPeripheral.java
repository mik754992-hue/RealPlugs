package dan200.computercraft.api.peripheral;

/** COMPILE-TIME STUB of CC: Tweaked's IPeripheral. Excluded from the released jar. */
public interface IPeripheral {
    String getType();

    boolean equals(IPeripheral other);

    default void attach(IComputerAccess computer) {}

    default void detach(IComputerAccess computer) {}
}
