package com.realplugs.cc;

import com.realplugs.PlugItem;
import com.realplugs.PlugSocketBlock;
import com.realplugs.PlugSocketBlockEntity;
import com.realplugs.PlugTypes;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IPeripheral;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Read-only CC: Tweaked peripheral for every outlet / power strip.
 * Slot numbers are 1-based in Lua, counted from the viewer's left like the in-world slots.
 * Everything runs on the main thread because it reads block entity state.
 */
public class SocketPeripheral implements IPeripheral {
    private final PlugSocketBlockEntity be;

    public SocketPeripheral(PlugSocketBlockEntity be) {
        this.be = be;
    }

    @Override
    public String getType() {
        return "realplugs_socket";
    }

    @Override
    public boolean equals(IPeripheral other) {
        return other instanceof SocketPeripheral p && p.be == be;
    }

    @Override
    public int hashCode() {
        return System.identityHashCode(be);
    }

    @LuaFunction(mainThread = true)
    public final String getSocketId() {
        return BuiltInRegistries.BLOCK.getKey(be.getBlockState().getBlock()).getPath();
    }

    @LuaFunction(mainThread = true)
    public final int getSlotCount() {
        return be.plugs().size();
    }

    /** Connector standard of a slot, e.g. "us_power", "usb_c". nil when the slot does not exist. */
    @LuaFunction(mainThread = true)
    public final String getSlotStandard(int slot) {
        if (!valid(slot) || !(be.getBlockState().getBlock() instanceof PlugSocketBlock b)) return null;
        return b.def.slots()[slot - 1].key;
    }

    @LuaFunction(mainThread = true)
    public final boolean isPlugged(int slot) {
        return valid(slot) && !be.plugs().get(slot - 1).isEmpty();
    }

    @LuaFunction(mainThread = true)
    public final int getPluggedCount() {
        int n = 0;
        for (ItemStack s : be.plugs()) if (!s.isEmpty()) n++;
        return n;
    }

    /** What sits in a slot: {name, standard, adapter, inner = {...}} or nil when it is empty. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getPlug(int slot) {
        if (!valid(slot)) return null;
        return describe(be.plugs().get(slot - 1));
    }

    /** One entry per slot: {slot, standard, plugged, plug?}. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getSlots() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (int i = 1; i <= be.plugs().size(); i++) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("slot", i);
            m.put("standard", getSlotStandard(i));
            Map<String, Object> plug = describe(be.plugs().get(i - 1));
            m.put("plugged", plug != null);
            if (plug != null) m.put("plug", plug);
            out.add(m);
        }
        return out;
    }

    private boolean valid(int slot) {
        return slot >= 1 && slot <= be.plugs().size();
    }

    private static Map<String, Object> describe(ItemStack s) {
        if (s.isEmpty() || !(s.getItem() instanceof PlugItem pi)) return null;
        int type = PlugItem.typeOf(s);
        Map<String, Object> m = new LinkedHashMap<>();
        PlugTypes.Standard std = PlugItem.plugStandard(s);
        m.put("name", pi.adapter ? PlugTypes.adapter(type).name() : PlugTypes.plug(type).name());
        m.put("standard", std == null ? "unknown" : std.key);
        m.put("adapter", pi.adapter);
        if (pi.adapter) {
            m.put("accepts", PlugTypes.adapter(type).accepts().key);
            List<Map<String, Object>> inner = new ArrayList<>();
            for (ItemStack in : PlugItem.inners(s)) {
                Map<String, Object> d = describe(in);
                if (d != null) inner.add(d);
            }
            m.put("inner", inner);
        }
        return m;
    }
}
