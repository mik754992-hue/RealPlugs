package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(BuiltInRegistries.ITEM, RealPlugsMod.MODID);

    public static final DeferredHolder<Item, PlugItem> PLUG =
            ITEMS.register("plug", () -> new PlugItem(new Item.Properties(), false));
    public static final DeferredHolder<Item, PlugItem> ADAPTER =
            ITEMS.register("adapter", () -> new PlugItem(new Item.Properties(), true));

    public static final DeferredHolder<Item, ExtensionCableItem> EXTENSION_CABLE =
            ITEMS.register("extension_cable", () -> new ExtensionCableItem(new Item.Properties()));

    public static final DeferredHolder<Item, PortItem> PORT =
            ITEMS.register("port", () -> new PortItem(new Item.Properties()));

    public static final DeferredHolder<Item, PlugCordItem> PLUG_CORD =
            ITEMS.register("plug_cord", () -> new PlugCordItem(new Item.Properties()));

    /** Network cables: RJ45 cords with a speed class (see NetCableItem). */
    public static final DeferredHolder<Item, NetCableItem> CAT5_CABLE =
            ITEMS.register("cat5_cable", () -> new NetCableItem(new Item.Properties(), com.realplugs.net.CableTier.CAT5));
    public static final DeferredHolder<Item, NetCableItem> CAT6_CABLE =
            ITEMS.register("cat6_cable", () -> new NetCableItem(new Item.Properties(), com.realplugs.net.CableTier.CAT6));
    public static final DeferredHolder<Item, NetCableItem> FIBRE_CABLE =
            ITEMS.register("fibre_cable", () -> new NetCableItem(new Item.Properties(), com.realplugs.net.CableTier.FIBRE));

    /** The built-in cord of an EV charger once pulled out (no recipe, not in the creative tab; see BuiltinCord). */
    public static final DeferredHolder<Item, ChargerCordItem> CHARGER_CORD =
            ITEMS.register("charger_cord", () -> new ChargerCordItem(new Item.Properties().stacksTo(1)));

    public static final DeferredHolder<Item, WifiAnalyzerItem> WIFI_ANALYZER =
            ITEMS.register("wifi_analyzer", () -> new WifiAnalyzerItem(new Item.Properties().stacksTo(1)));

    public static final Map<String, DeferredHolder<Item, BlockItem>> SOCKET_ITEMS = new LinkedHashMap<>();

    static {
        for (SocketDef def : SocketDefs.ALL) {
            if (def.id().equals(SocketDefs.ANCHOR_ID) || def.id().startsWith("ext_")) continue;   // helper blocks have no item
            SOCKET_ITEMS.put(def.id(), ITEMS.register(def.id(),
                    () -> new BlockItem(ModBlocks.SOCKETS.get(def.id()).get(), new Item.Properties())));
        }
    }
}
