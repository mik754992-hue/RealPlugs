---
name: Feature request
about: Suggest a new plug, adapter, outlet or behaviour
labels: enhancement
---

**What would you like to see?**

**Why would it be useful?**
