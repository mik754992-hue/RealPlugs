#!/usr/bin/env python3
"""Software preview of the EV charger models (both halves stacked), no game needed.
Usage: python3 scripts/preview_ev_chargers.py [out.png]    (needs Pillow and numpy)
Follows Minecraft's cuboid face / UV conventions, nearest-neighbour textures and the usual per-face shading."""
import json
import math
import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "src/main/resources/assets/realplugs"
TYPES = ["type1", "type2", "ccs", "chademo", "nacs"]
SHADE = {"up": 1.0, "down": 0.5, "north": 0.8, "south": 0.8, "east": 0.6, "west": 0.6}


def corners(face, a, b):
    (x0, y0, z0), (x1, y1, z1) = a, b
    return {
        "down": [(x0, y0, z1), (x0, y0, z0), (x1, y0, z0), (x1, y0, z1)],
        "up": [(x0, y1, z0), (x0, y1, z1), (x1, y1, z1), (x1, y1, z0)],
        "north": [(x1, y1, z0), (x1, y0, z0), (x0, y0, z0), (x0, y1, z0)],
        "south": [(x0, y1, z1), (x0, y0, z1), (x1, y0, z1), (x1, y1, z1)],
        "west": [(x0, y1, z0), (x0, y0, z0), (x0, y0, z1), (x0, y1, z1)],
        "east": [(x1, y1, z1), (x1, y0, z1), (x1, y0, z0), (x1, y1, z0)],
    }[face]


def load_model(name, kind):
    m = json.load(open(RES / f"models/{kind}/ev_charger_{name}.json"))
    tex = {k: Image.open(RES / "textures" / (v.split(":")[1] + ".png")).convert("RGBA")
           for k, v in m["textures"].items() if k != "particle" and ":" in v}
    return m, tex


def render(models, yaw, pitch, scale, size, origin_shift):
    W, H = size
    img = np.zeros((H, W, 4), np.uint8)
    img[..., :3] = (96, 128, 96)
    img[..., 3] = 255
    zbuf = np.full((H, W), 1e9)
    cy, sy = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    cp, sp = math.cos(math.radians(pitch)), math.sin(math.radians(pitch))

    def project(p):
        x, y, z = -(p[0] - 8) + origin_shift[0], p[1] - 16, p[2] - 8   # a viewer looking south sees +x on the LEFT
        x, z = x * cy + z * sy, -x * sy + z * cy
        y, z = y * cp - z * sp, y * sp + z * cp
        return np.array([W / 2 + x * scale, H / 2 - y * scale, z])

    for m, tex in models:
        for e in m["elements"]:
            for fname, f in e["faces"].items():
                p = [project(c) for c in corners(fname, e["from"], e["to"])]
                im = tex[f["texture"][1:]]
                tw, th = im.size
                u0, v0, u1, v1 = f["uv"]
                px = np.array(im)
                p0, p1, p3 = p[0], p[1], p[3]
                eu, ev = p3[:2] - p0[:2], p1[:2] - p0[:2]
                det = eu[0] * ev[1] - eu[1] * ev[0]
                if abs(det) < 1e-6:
                    continue
                if det < 0:  # back-facing (screen y points down)
                    continue
                xs = [q[0] for q in p]; ys = [q[1] for q in p]
                xa, xb = max(0, int(min(xs))), min(W - 1, int(max(xs)) + 1)
                ya, yb = max(0, int(min(ys))), min(H - 1, int(max(ys)) + 1)
                if xb < xa or yb < ya:
                    continue
                gx, gy = np.meshgrid(np.arange(xa, xb + 1) + 0.5, np.arange(ya, yb + 1) + 0.5)
                dx, dy = gx - p0[0], gy - p0[1]
                s = (dx * ev[1] - dy * ev[0]) / det
                t = (eu[0] * dy - eu[1] * dx) / det
                ok = (s >= 0) & (s <= 1) & (t >= 0) & (t <= 1)
                u = (u0 + s * (u1 - u0)) / 16 * tw
                v = (v0 + t * (v1 - v0)) / 16 * th
                ui = np.clip(u.astype(int), 0, tw - 1)
                vi = np.clip(v.astype(int), 0, th - 1)
                col = px[vi, ui]
                z = p0[2] + s * (p3[2] - p0[2]) + t * (p1[2] - p0[2])
                sub = zbuf[ya:yb + 1, xa:xb + 1]
                mask = ok & (col[..., 3] > 8) & (z < sub)
                sub[mask] = z[mask]
                shaded = (col[..., :3] * SHADE[fname]).astype(np.uint8)
                out = img[ya:yb + 1, xa:xb + 1]
                out[mask, :3] = shaded[mask]
    return Image.fromarray(img)


def main():
    out = sys.argv[1] if len(sys.argv) > 1 else "ev_chargers_preview.png"
    tiles = []
    for yaw, pitch in ((0, 0), (-35, 18)):
        for t in TYPES:
            m, tex = load_model(t, "item")   # the item model holds both halves
            tiles.append(render([(m, tex)], yaw, pitch, 9.0, (190, 330), (0, 0)))
    sheet = Image.new("RGB", (190 * 5, 330 * 2), (30, 30, 30))
    for i, t in enumerate(tiles):
        sheet.paste(t.convert("RGB"), ((i % 5) * 190, (i // 5) * 330))
    sheet.save(out)
    print("wrote", out)


if __name__ == "__main__":
    main()
