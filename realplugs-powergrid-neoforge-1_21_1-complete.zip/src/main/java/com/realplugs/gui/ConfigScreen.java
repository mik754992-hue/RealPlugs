package com.realplugs.gui;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.chat.Component;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * The settings screen: a form the server describes. Pages with text boxes, on/off buttons and choice buttons; "Apply" sends the
 * fields that changed and the server answers with the new form and a message.
 */
public class ConfigScreen extends Screen {
    private record Field(String id, String label, String type, String[] choices) {}

    private final BlockPos pos;
    private final String deviceTitle;
    private final List<String> info = new ArrayList<>();
    private final List<String> pageTitles = new ArrayList<>();
    private final List<List<Field>> pages = new ArrayList<>();
    private final Map<String, String> original = new LinkedHashMap<>();
    private final Map<String, String> values = new LinkedHashMap<>();
    private String message;
    private int page;

    private static final int W = 360, H = 214;

    public ConfigScreen(BlockPos pos, CompoundTag view, String message, int page) {
        super(Component.literal(view.getString("title")));
        this.pos = pos;
        this.deviceTitle = view.getString("title");
        this.message = message == null ? "" : message;
        for (Tag t : view.getList("info", Tag.TAG_STRING)) info.add(t.getAsString());
        for (Tag pt : view.getList("pages", Tag.TAG_COMPOUND)) {
            CompoundTag pc = (CompoundTag) pt;
            pageTitles.add(pc.getString("title"));
            List<Field> fields = new ArrayList<>();
            for (Tag ft : pc.getList("fields", Tag.TAG_COMPOUND)) {
                CompoundTag fc = (CompoundTag) ft;
                String id = fc.getString("id");
                String choices = fc.getString("choices");
                fields.add(new Field(id, fc.getString("label"), fc.getString("type"), choices.isEmpty() ? new String[0] : choices.split(",")));
                original.put(id, fc.getString("value"));
                values.put(id, fc.getString("value"));
            }
            pages.add(fields);
        }
        this.page = Math.max(0, Math.min(page, Math.max(0, pages.size() - 1)));
    }

    public BlockPos pos() {
        return pos;
    }

    public int page() {
        return page;
    }

    @Override
    protected void init() {
        int left = (this.width - W) / 2;
        int top = (this.height - H) / 2;
        // page switch
        addRenderableWidget(Button.builder(Component.literal("<"), b -> switchPage(page - 1)).bounds(left + 8, top + 22, 20, 18).build());
        addRenderableWidget(Button.builder(Component.literal(">"), b -> switchPage(page + 1)).bounds(left + W - 28, top + 22, 20, 18).build());
        // fields of the page, two columns of six
        if (!pages.isEmpty()) {
            List<Field> fields = pages.get(page);
            for (int i = 0; i < fields.size() && i < 12; i++) {
                Field f = fields.get(i);
                int col = i / 6, row = i % 6;
                int x = left + 10 + col * (W / 2);
                int y = top + 50 + row * 22;
                int boxX = x + 70;
                int boxW = W / 2 - 90;
                switch (f.type()) {
                    case "bool" -> addRenderableWidget(Button.builder(Component.literal(onOff(values.get(f.id()))), b -> {
                        values.put(f.id(), values.get(f.id()).equals("true") ? "false" : "true");
                        b.setMessage(Component.literal(onOff(values.get(f.id()))));
                    }).bounds(boxX, y, boxW, 18).build());
                    case "choice" -> addRenderableWidget(Button.builder(Component.literal(values.get(f.id())), b -> {
                        int at = java.util.Arrays.asList(f.choices()).indexOf(values.get(f.id()));
                        values.put(f.id(), f.choices()[(at + 1) % f.choices().length]);
                        b.setMessage(Component.literal(values.get(f.id())));
                    }).bounds(boxX, y, boxW, 18).build());
                    default -> {
                        EditBox box = new EditBox(this.font, boxX, y, boxW, 18, Component.literal(f.label()));
                        box.setMaxLength(48);
                        box.setValue(values.get(f.id()));
                        box.setResponder(v -> values.put(f.id(), v));
                        addRenderableWidget(box);
                    }
                }
            }
        }
        addRenderableWidget(Button.builder(Component.literal("Apply"), b -> apply()).bounds(left + 10, top + H - 26, 80, 18).build());
        addRenderableWidget(Button.builder(Component.literal("Close"), b -> onClose()).bounds(left + W - 90, top + H - 26, 80, 18).build());
    }

    private static String onOff(String v) {
        return "true".equals(v) ? "on" : "off";
    }

    private void switchPage(int to) {
        if (pages.isEmpty()) return;
        page = (to + pages.size()) % pages.size();
        rebuildWidgets();
    }

    private void apply() {
        CompoundTag changes = new CompoundTag();
        for (Map.Entry<String, String> e : values.entrySet()) {
            if (!e.getValue().equals(original.get(e.getKey()))) changes.putString(e.getKey(), e.getValue());
        }
        if (changes.isEmpty()) {
            message = "Nothing changed.";
            return;
        }
        PacketDistributor.sendToServer(new ConfigPayloads.ApplyPayload(pos, changes));
        message = "Sending...";
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.render(g, mouseX, mouseY, partialTick);   // background panel (below), then the widgets
        int left = (this.width - W) / 2;
        int top = (this.height - H) / 2;
        g.drawCenteredString(this.font, deviceTitle, this.width / 2, top + 6, 0xFFFFFF);
        String pt = pages.isEmpty() ? "" : pageTitles.get(page) + "  (" + (page + 1) + "/" + pages.size() + ")";
        g.drawCenteredString(this.font, pt, this.width / 2, top + 27, 0xFFFFAA);
        if (!pages.isEmpty()) {
            List<Field> fields = pages.get(page);
            for (int i = 0; i < fields.size() && i < 12; i++) {
                int col = i / 6, row = i % 6;
                g.drawString(this.font, fields.get(i).label(), left + 10 + col * (W / 2), top + 55 + row * 22, 0xCCCCCC, false);
            }
        }
        int y = top + 50 + 6 * 22 - 2;
        if (!info.isEmpty()) g.drawString(this.font, String.join("  |  ", info), left + 10, y, 0x88AACC, false);
        if (!message.isEmpty()) g.drawString(this.font, message, left + 100, top + H - 21, 0x88FF88, false);
    }

    @Override
    public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        super.renderBackground(g, mouseX, mouseY, partialTick);
        int left = (this.width - W) / 2;
        int top = (this.height - H) / 2;
        g.fill(left, top, left + W, top + H, 0xF0101018);
        g.renderOutline(left, top, W, H, 0xFF5577AA);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
