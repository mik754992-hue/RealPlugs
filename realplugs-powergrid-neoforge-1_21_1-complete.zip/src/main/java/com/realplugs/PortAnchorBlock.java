package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.EntityCollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.patryk3211.powergrid.electricity.base.IDecoratedTerminal;
import org.patryk3211.powergrid.electricity.base.ITerminalPlacement;
import org.patryk3211.powergrid.electricity.base.TerminalBoundingBox;
import org.patryk3211.powergrid.electricity.wire.powercord.AutoCordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

/**
 * An invisible one-slot "outlet" placed in the empty block in front of a port (see PortEntity). A computer has no
 * electrical side, so a cord has nothing to attach to; this block is what the cord end really sits on. The cord
 * is drawn ending exactly at the port.
 *
 * It only has a selection box while you hold a cord, so it never gets in the way of anything else, and it can only be
 * removed by removing its port.
 */
public class PortAnchorBlock extends PlugSocketBlock {
    /**
     * What the block "is" when no cord is held: a quarter-pixel cube in the outer corner of its cell. It must not be an
     * empty shape (Power Grid asks for its bounds), and this is too small to ever get in the way of a click.
     */
    private static final VoxelShape TINY = Block.box(0, 0, 0, 0.25, 0.25, 0.25);

    public PortAnchorBlock(Properties props, SocketDef def) {
        super(props, def);
    }

    @Override
    protected RenderShape getRenderShape(BlockState state) {
        return RenderShape.INVISIBLE;
    }

    /** A plate against the computer face, but only while a cord is in hand, so ordinary clicks pass through to the computer. */
    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        if (ctx instanceof EntityCollisionContext ecc && ecc.getEntity() instanceof Player p
                && (p.getMainHandItem().getItem() instanceof CordItem || p.getOffhandItem().getItem() instanceof CordItem)) {
            return super.getShape(state, level, pos, ctx);
        }
        return TINY;
    }

    /** The hover/placement box for a cord: a small box around the port itself. */
    @Override
    public ITerminalPlacement cordTerminal(BlockState state, Level level, BlockHitResult hit) {
        BlockPos pos = hit.getBlockPos();
        PortEntity port = PortEntity.at(level, pos);
        if (port == null) return terminal(state, 2);
        Vec3 c = port.position().subtract(pos.getX(), pos.getY(), pos.getZ());
        Direction f = port.getFace();
        double h = 0.12;
        double depth = 0.08;
        AABB box = new AABB(
                c.x - (f.getAxis() == Direction.Axis.X ? 0 : h), c.y - (f.getAxis() == Direction.Axis.Y ? 0 : h), c.z - (f.getAxis() == Direction.Axis.Z ? 0 : h),
                c.x + (f.getAxis() == Direction.Axis.X ? 0 : h), c.y + (f.getAxis() == Direction.Axis.Y ? 0 : h), c.z + (f.getAxis() == Direction.Axis.Z ? 0 : h))
                .expandTowards(f.getStepX() * depth, f.getStepY() * depth, f.getStepZ() * depth)
                .intersect(new AABB(0, 0, 0, 1, 1, 1));
        return new TerminalBoundingBox(IDecoratedTerminal.CORD, box);
    }

    /** The cord end sits on this block's slot, drawn at the port's exact spot. */
    @Override
    public AutoCordEndpoint getEndpoint(UseOnContext ctx) {
        BlockPos pos = ctx.getClickedPos();
        Level level = ctx.getLevel();
        PortEntity port = PortEntity.at(level, pos);
        Vec3 where = port != null ? port.position() : Vec3.atCenterOf(pos);
        Direction face = port != null ? port.getFace() : level.getBlockState(pos).getValue(FACING);
        return new AutoCordEndpoint(pos, 2, 1, where, face);
    }

    // nothing to plug into or open here: the port entity handles plugs
    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        return InteractionResult.PASS;
    }
}
