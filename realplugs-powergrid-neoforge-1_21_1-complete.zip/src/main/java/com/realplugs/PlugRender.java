package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;

/** Draws a plug/adapter and, for adapters, every plug sitting in its sockets. */
public final class PlugRender {
    private PlugRender() {}

    public static void draw(ItemRenderer items, ItemStack s, PoseStack ps, MultiBufferSource buf,
                            int light, int overlay, Level level, int seed) {
        items.renderStatic(s, ItemDisplayContext.FIXED, light, overlay, ps, buf, level, seed);
        if (s.getItem() instanceof PlugItem pi && pi.adapter) {
            float[][] sockets = PlugTypes.adapter(PlugItem.typeOf(s)).sockets();
            List<ItemStack> in = PlugItem.inners(s);
            for (int k = 0; k < in.size() && k < sockets.length; k++) {
                ps.pushPose();
                // adapter model coords (x,y in 1/16) -> item space; the display transform flips x and z
                ps.translate(-(sockets[k][0] - 8f) / 16.0, (sockets[k][1] - 8f) / 16.0, 0.4375);
                ps.scale(0.9f, 0.9f, 0.9f);
                items.renderStatic(in.get(k), ItemDisplayContext.FIXED, light, overlay, ps, buf, level, seed + k + 1);
                ps.popPose();
            }
        }
    }
}
