package com.realplugs.api;

import com.realplugs.EvChargerBlock;
import com.realplugs.PlugSocketBlock;
import com.realplugs.PlugSocketBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Small public API for other mods. Everything here is safe to call from any mod without it being a hard dependency of
 * ours as long as you guard the calls with ModList.get().isLoaded("realplugs").
 *
 * <ul>
 *   <li>Port hosts: which blocks a Port item can be stuck on (sneak + right-click). CC: Tweaked and LittleTiles blocks are
 *       built in; other mods call {@link #registerPortHostNamespace} or {@link #registerPortHostBlock} while loading.</li>
 *   <li>Read-only queries about the socket / charger block at a position (server side).</li>
 * </ul>
 */
public final class RealPlugsApi {
    private static final Set<String> HOST_NAMESPACES = ConcurrentHashMap.newKeySet();
    private static final Set<ResourceLocation> HOST_BLOCKS = ConcurrentHashMap.newKeySet();

    static {
        HOST_NAMESPACES.add("computercraft");
        HOST_NAMESPACES.add("littletiles");
    }

    private RealPlugsApi() {}

    /** Every block of this mod (registry namespace) accepts ports. */
    public static void registerPortHostNamespace(String namespace) {
        HOST_NAMESPACES.add(namespace);
    }

    /** One specific block accepts ports. */
    public static void registerPortHostBlock(ResourceLocation blockId) {
        HOST_BLOCKS.add(blockId);
    }

    public static boolean isPortHost(ResourceLocation blockId) {
        return HOST_NAMESPACES.contains(blockId.getNamespace()) || HOST_BLOCKS.contains(blockId);
    }

    /**
     * What a socket block (outlet, power strip, charger, EV port anchor ...) looks like right now.
     *
     * @param slotStandards the connector standard of every slot, by key ("us_power", "usb_c", "ccs" ...)
     * @param slotOccupied  whether each slot currently has a plug, a cord or a built-in cord in it (and, for a public charger, credit)
     * @param charger       true for an EV charger
     * @param credit        a charger's credit in spurs (0 for everything else)
     * @param feePerMinute  a charger's price per minute in spurs (0 for everything else)
     * @param stopped       a charger whose STOP button was pressed
     * @param privateMode   a charger in private mode
     */
    public record SocketInfo(String id, List<String> slotStandards, List<Boolean> slotOccupied, boolean charger,
                             int credit, int feePerMinute, boolean stopped, boolean privateMode) {}

    /** The socket at this position, if it is one of ours. Server side (or client for synced data). */
    public static Optional<SocketInfo> socketAt(Level level, BlockPos pos) {
        BlockState state = level.getBlockState(pos);
        if (!(state.getBlock() instanceof PlugSocketBlock block)) return Optional.empty();
        List<String> standards = new ArrayList<>();
        List<Boolean> occupied = new ArrayList<>();
        PlugSocketBlockEntity be = level.getBlockEntity(pos) instanceof PlugSocketBlockEntity b ? b : null;
        for (int i = 0; i < block.def.slots().length; i++) {
            standards.add(block.def.slots()[i].key);
            occupied.add(be != null && be.isSlotOccupied(i));
        }
        boolean charger = state.getBlock() instanceof EvChargerBlock;
        int fee = charger && be != null ? be.feePerMinute((EvChargerBlock) state.getBlock()) : 0;
        return Optional.of(new SocketInfo(block.def.id(), standards, occupied, charger,
                be == null ? 0 : be.credit(), fee, be != null && be.isStopped(), be != null && be.isPersonal()));
    }
}
