# Changelog

## Unreleased
- EV chargers: the built-in cord can now be plugged into an EV port. Pulling it out gives you a Charger Cord (a real plug cord with its first end in the charger's slot); right-click an EV port with it to connect, or the charger's socket to put it back. The item is deleted whenever it is not its charger's pulled-out cord, so it cannot be used to make free cords.
- Fix: the plug cord and extension cable handlers looked for the cord's first end in the wrong place in Power Grid's cord data (`half` instead of `endpoint`), so the "second end must be the other connector" check never ran and the extension cable's second click could not place the strip.
- EV chargers are now two blocks high, like the pillars in a parking lot: the lower block has the connector socket, coin plate and cable gland; the upper block has a big screen and a button row (price -, price +, private-mode padlock, red STOP bar). Placing a charger needs two free blocks; both halves break together and drop one charger. New hidden blocks `ev_charger_<id>_top`.
- EV chargers: STOP button ends a session at any time (the built-in cord snaps back and the slot goes dead; unused credit stays on the charger). Pull the cord out, insert a plug or press STOP again to start a new session.
- EV chargers: owner and custom fees. Whoever places a charger owns it and can set its price per minute with the - / + buttons (sneak = steps of 8, 0 = free) and toggle private mode with the padlock. Private chargers only work for the owner, for free; Power Grid cords do not power a private charger.
- EV chargers: parking-lot look (hazard-striped plinth, canopy, light bar, bolt badge, framed screen, per-connector colours). `scripts/preview_ev_chargers.py` renders a preview without the game.
- EV chargers: new models (enclosure with hood, plinth, screen bezel, connector socket, gold coin plate, cable gland, status LED) and new 64x64 textures, one per connector with its own colour and pin layout (`scripts/gen_ev_charger_assets.py` regenerates them).
- EV chargers: built-in cord. The connector sits docked in the socket with a cable to the gland; right-click with an empty hand to pull it out (slot occupied and billed) and again to dock it.
- Fix crash "Ticking block entity" (NullPointerException on `tetherOwner`) when loading a world with sockets: Power Grid builds the circuit inside the block entity's super constructor, before our tether arrays existed. They are now created lazily.
- New connector standards: AU (Type I), Micro-USB, DisplayPort.
- New blocks: Wall Outlet (AU), Power Strip (UK), Power Strip (AU), Network & AV Wall Plate (2 Ethernet + 2 HDMI).
- New plugs: AU, Micro-USB, DisplayPort. New adapters: US to AU, AU to US, EU to UK, UK to EU, Micro-USB Wall, DisplayPort to HDMI.
- CC: Tweaked peripheral `realplugs_socket` on every outlet (read slot standards and what is plugged in).
- Plug Cord item (one per connector standard): a real Power Grid cord with a plug on each end. Each end is slot-specific: it fits a matching, free slot, closes that slot's contact and blocks the slot from taking a plug.
- 15 multi-standard plug cords with a different connector on each end (US to USB-A, HDMI to DisplayPort, and so on). The second end has to be the cord's other connector.
- Cords use one box per slot instead of one big box over the plate, and every cord end (including Power Grid's copper cord) is slot-specific.
- Power Grid copper cords also plug into every outlet, strip and panel.
- Ports: socket items (one per connector standard) you place at an exact spot on any CC: Tweaked block; a matching plug can be plugged in.
- Lightning connector: plug, port, Lightning cord, and US/USB-A/USB-C to Lightning cords.
- Ports are now chunky colour-coded boxes (they were thin grey plates that all looked the same).
- Cord ends in outlets, strips and panels are drawn with Real Plugs plug models, at the exact slot position.
- Pocket computer ports: every port is a CC: Tweaked pocket upgrade (craft it on or `pocket.equipBack()`), a matching plug can be plugged in, readable from Lua as `realplugs_port`.
- Fixed plugs and ports stuck on computers being impossible to click: their hitbox sat above the spot instead of centred on it, and is slightly larger.
- Ports are now just the port (a colour-coded bezel with the connector opening), not a box with a port on it, and an outline shows where one will be placed while you hold it.
- Fixed plugged ports always showing the Lightning model (the model overrides were in the wrong order).
- Outlet, strip and panel hot/neutral inputs are now small connectors on the sides of the plate instead of big bars across the front.
- Fixed the hitbox of blocks placed on the floor or ceiling being the wrong way round.
- Ponder scenes for outlets, strips, hubs, panels, plugs, adapters and cords, using the airport and house showcase schematics (camera turned 90 degrees).
- Plug cords (and copper cords) can be plugged into computer ports: a hidden anchor block in front of each port gives the cord something electrical to attach to.
- Fixed a crash when holding a cord and looking at a computer port (the hidden anchor block's shape was empty).
- Pocket computer ports: messages for plugging in and out, and holding a cord now explains that cords can't plug into a pocket computer instead of opening the screen.
- Pocket computer tether: right-click an outlet slot of the same connector with a port-equipped pocket computer to link them. A cable is drawn to your hand, the slot behaves as if a cord were in it, and it snaps when you walk away. Readable from Lua as `isLinked()` / `getLink()`.
- New connectors: VGA, 3.5 mm Aux, RCA, XLR and USB-B (plugs, ports, cords, pocket ports), plus six more two-connector cords (VGA to HDMI, VGA to DisplayPort, Aux to RCA, XLR to Aux, USB-A to USB-B, USB-C to USB-B).
- Extension cables: plug one end into a matching slot, place the strip end on any surface. Eight connectors (US, EU, UK, AU, USB-A, USB-C, HDMI, Ethernet).
- EV chargers: five pay-to-charge chargers (Wall Box Type 1 and 2, Fast Charger CCS and CHAdeMO, Supercharger NACS) and EV port blocks, with five new EV connectors (plugs, ports, cables, pocket ports). Pay with coins (item tags), per-minute billing, price screen. Card payment is not supported yet.
- Crafting recipes for all of the above.

## 1.0.0
- Wall outlets (US, EU, UK), DC jack panel, USB charging hub and three power strips, all real Power Grid electrical blocks.
- Plugs (US, EU, UK, USB-A, USB-C, HDMI, Ethernet, DC barrel) and ten adapters, with connector-standard checks.
- Plugs and adapters can be stuck onto CC: Tweaked computers (visual only).
- Crafting recipes for every block, plug and adapter.
- Metadata (version, dependency ranges) now comes from `gradle.properties`; Architectury is declared as a dependency.
- Build configuration no longer needs the network just to configure the project.
- CI validates models, blockstates, loot tables, recipes and lang entries; tagged releases publish the jar automatically.
- The unfinished placeholder plug/adapter no longer shows in the creative tab.
