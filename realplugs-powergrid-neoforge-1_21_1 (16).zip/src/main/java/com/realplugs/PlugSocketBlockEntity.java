package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.patryk3211.powergrid.electricity.base.ElectricBehaviour;
import org.patryk3211.powergrid.electricity.base.ElectricBlockEntity;
import org.patryk3211.powergrid.electricity.base.IElectricEntity;
import org.patryk3211.powergrid.electricity.sim.SwitchedWire;
import org.patryk3211.powergrid.electricity.wire.BaseWireEntity;
import org.patryk3211.powergrid.electricity.wire.BlockWireEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.CordEntity;

import net.minecraft.world.phys.AABB;
import java.util.Map;
import java.util.UUID;
import java.util.Set;

/**
 * Electrical model of an outlet / power strip:
 *   terminal 0        = hot bus      (wire the supply here)
 *   terminal 1        = neutral bus  (supply neutral, and every device's return, goes here)
 *   terminal 2 + i    = tap of slot i, connected to the hot bus ONLY while a plug (or a plug cord) sits in slot i
 */
public class PlugSocketBlockEntity extends ElectricBlockEntity {
    /** Resistance of a closed slot contact in ohms. */
    private static final float CONTACT_RESISTANCE = 0.005f;

    private NonNullList<ItemStack> plugs;
    private SwitchedWire[] taps;
    /** Who is tethered to each slot (pocket computer port). Synced to the client so the rope can be drawn. */
    private final UUID[] tetherOwner = new UUID[8];
    /** Game time until which the tether is valid; the pocket computer renews it every few ticks. Server only. */
    private final long[] tetherUntil = new long[8];
    /** Game time this extension end first ticked (server only), so a freshly placed one is given time to get its cable. */
    private long placedAt;
    /** Bit i set = a plug cord end sits in slot i. Synced to the client so the renderer can draw the plug. */
    private int cordMask;

    public PlugSocketBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    /** Created lazily because the circuit can be built before our own constructor body would have run. */
    public NonNullList<ItemStack> plugs() {
        if (plugs == null) {
            int n = getBlockState().getBlock() instanceof PlugSocketBlock b ? b.slots : 1;
            plugs = NonNullList.withSize(n, ItemStack.EMPTY);
        }
        return plugs;
    }

    @Override
    public void buildCircuit(IElectricEntity.CircuitBuilder builder) {
        int n = plugs().size();
        builder.setTerminalCount(2 + n);
        taps = new SwitchedWire[n];
        for (int i = 0; i < n; i++) {
            taps[i] = builder.connectSwitch(CONTACT_RESISTANCE,
                    builder.terminalNode(0), builder.terminalNode(2 + i), occupied(i));
        }
    }

    /** Close the contact of every slot that holds a plug, open the rest. */
    public void refreshTaps() {
        if (taps == null) return;
        for (int i = 0; i < taps.length; i++) {
            if (taps[i] != null) taps[i].setState(occupied(i));
        }
    }

    @Override
    public ElectricBehaviour specifyElectricBehaviour() {
        return new SocketBehaviour(this);
    }

    /** True when a Real Plugs plug cord is plugged into this slot (its end sits on the slot's tap terminal). */
    public boolean hasPgCord(int slot) {
        ElectricBehaviour eb = getElectricBehaviour();
        if (eb == null) return false;
        for (Map.Entry<BlockWireEndpoint, Set<BaseWireEntity>> e : eb.getConnections().entrySet()) {
            if (e.getKey().getTerminal() != 2 + slot) continue;
            for (BaseWireEntity w : e.getValue()) if (w instanceof CordEntity) return true;
        }
        return false;
    }

    /** A cord end or a pocket computer tether is in this slot. */
    public boolean hasCord(int slot) {
        return hasPgCord(slot) || tetherOwner(slot) != null;
    }

    public UUID tetherOwner(int slot) {
        return slot >= 0 && slot < tetherOwner.length ? tetherOwner[slot] : null;
    }

    /** Starts or renews a tether; called by the pocket computer's port upgrade. */
    public void renewTether(int slot, UUID owner, long until) {
        if (slot < 0 || slot >= tetherOwner.length) return;
        boolean changed = !owner.equals(tetherOwner[slot]);
        tetherOwner[slot] = owner;
        tetherUntil[slot] = until;
        if (changed) {
            cordsChanged();
            notifyUpdate();
        }
    }

    public void releaseTether(int slot, UUID owner) {
        if (slot < 0 || slot >= tetherOwner.length || !owner.equals(tetherOwner[slot])) return;
        tetherOwner[slot] = null;
        cordsChanged();
        notifyUpdate();
    }

    /** Is a Power Grid cord attached to the hot bus (terminal 0)? That is where an extension cable ends. */
    public boolean hasBusCord() {
        ElectricBehaviour eb = getElectricBehaviour();
        if (eb == null) return false;
        for (Map.Entry<BlockWireEndpoint, Set<BaseWireEntity>> e : eb.getConnections().entrySet()) {
            if (e.getKey().getTerminal() != 0) continue;
            for (BaseWireEntity w : e.getValue()) if (w instanceof CordEntity) return true;
        }
        return false;
    }

    @Override
    public void tick() {
        super.tick();
        if (level == null || level.isClientSide || level.getGameTime() % 10 != 0) return;
        long now = level.getGameTime();
        if (getBlockState().getBlock() instanceof ExtensionEndBlock) {
            if (placedAt == 0) placedAt = now;
            if (now - placedAt > 100 && !hasBusCord()) {   // the cable was broken (or never connected)
                level.removeBlock(worldPosition, false);
                return;
            }
        }
        boolean changed = false;
        for (int i = 0; i < tetherOwner.length; i++) {
            if (tetherOwner[i] != null && tetherUntil[i] < now) {   // the pocket computer stopped renewing it
                tetherOwner[i] = null;
                changed = true;
            }
        }
        if (changed) {
            cordsChanged();
            notifyUpdate();
        }
    }

    /** The rope can reach as far as the tether does. */
    @Override
    protected AABB createRenderBoundingBox() {
        return new AABB(worldPosition).inflate(PocketTether.RANGE + 2);
    }

    private boolean occupied(int slot) {
        return !plugs().get(slot).isEmpty() || hasCord(slot);
    }

    /** Called by SocketBehaviour whenever a wire or cord is attached or removed. */
    public void cordsChanged() {
        if (level == null || isRemoved()) return;
        refreshTaps();
        if (level.isClientSide) return;
        int mask = 0;
        for (int i = 0; i < plugs().size(); i++) if (hasCord(i)) mask |= 1 << i;
        if (mask != cordMask) {
            cordMask = mask;
            notifyUpdate();
        }
    }

    /** For the renderer: is a cord end shown in this slot? */
    public boolean cordShown(int slot) {
        return (cordMask >> slot & 1) != 0;
    }

    public void setPlug(int slot, ItemStack stack) {
        plugs().set(slot, stack);
        plugsChanged();
    }

    public void plugsChanged() {
        refreshTaps();
        notifyUpdate();
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        NonNullList<ItemStack> list = plugs();
        for (int i = 0; i < list.size(); i++) list.set(i, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        cordMask = tag.getInt("CordMask");
        for (int i = 0; i < tetherOwner.length; i++) {
            tetherOwner[i] = tag.contains("Tether" + i) ? UUID.fromString(tag.getString("Tether" + i)) : null;
        }
        refreshTaps();
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        ContainerHelper.saveAllItems(tag, plugs(), registries);
        tag.putInt("CordMask", cordMask);
        if (clientPacket) {   // leases are not saved: after a reload nothing is tethered until the computer renews it
            for (int i = 0; i < tetherOwner.length; i++) {
                if (tetherOwner[i] != null) tag.putString("Tether" + i, tetherOwner[i].toString());
            }
        }
    }
}
