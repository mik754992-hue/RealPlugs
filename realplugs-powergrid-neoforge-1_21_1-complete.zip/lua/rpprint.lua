-- rpprint: a network print server for ComputerCraft printers.
--   rpprint serve [slot]                 run next to a printer (wired modem or adjacent) with paper and ink; port 515
--   rpprint send <host> <file> [title]   print a file on a print server
--   rpprint queue <host>                 show what is waiting
-- Jobs are plain text; long lines wrap and pages are filled in order.
local M = {}
local PORT = 515

-- text -> a list of pages, each a list of lines (width x height of the printer page)
function M.paginate(text, w, h)
  local lines = {}
  for raw in (tostring(text):gsub("\r", "") .. "\n"):gmatch("([^\n]*)\n") do
    raw = raw:gsub("\t", "  ")
    if raw == "" then lines[#lines + 1] = "" end
    while #raw > 0 do
      if #raw <= w then lines[#lines + 1] = raw; break end
      local cut = raw:sub(1, w):match("^.*()%s") 
      if not cut or cut < w / 2 then cut = w + 1 end
      lines[#lines + 1] = (raw:sub(1, cut - 1):gsub("%s+$", ""))
      raw = raw:sub(cut):gsub("^%s+", "")
    end
  end
  while #lines > 0 and lines[#lines] == "" do lines[#lines] = nil end
  local pages = {}
  for i = 1, #lines, h do
    local p = {}
    for j = i, math.min(i + h - 1, #lines) do p[#p + 1] = lines[j] end
    pages[#pages + 1] = p
  end
  return pages
end

-- a queue: add(from, title, text) -> id or nil, why; next(); cancel(id); list()
function M.queue(maxJobs, maxChars)
  local Q = { jobs = {}, nextId = 1 }
  maxJobs, maxChars = maxJobs or 20, maxChars or 20000
  function Q.add(from, title, text)
    if #Q.jobs >= maxJobs then return nil, "the queue is full" end
    if #text > maxChars then return nil, "the job is too big" end
    local id = Q.nextId; Q.nextId = id + 1
    Q.jobs[#Q.jobs + 1] = { id = id, from = from, title = (title ~= "" and title or "job " .. id):sub(1, 24), text = text }
    return id
  end
  function Q.next() return table.remove(Q.jobs, 1) end
  function Q.cancel(id)
    for i, j in ipairs(Q.jobs) do if j.id == id then table.remove(Q.jobs, i); return true end end
    return false
  end
  function Q.list()
    local t = {}
    for _, j in ipairs(Q.jobs) do t[#t + 1] = j.id .. " " .. j.title .. " (" .. j.from .. ")" end
    return t
  end
  return Q
end

-- "PRINT <title>\n<length>\n" header is followed by exactly <length> characters
function M.encode(title, text) return "PRINT " .. title:gsub("[\r\n]", " ") .. "\n" .. #text .. "\n" .. text end
function M.decode(buf)
  local title, len, rest = buf:match("^PRINT ([^\n]*)\n(%d+)\n(.*)$")
  if not title then return nil end
  len = tonumber(len)
  if #rest < len then return nil, "more" end
  return title, rest:sub(1, len)
end

if RPWEB_TEST then return M end
local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpprint" or running == "rpprint.lua") then return M end
local args = { ... }
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)

local function dialog(slot, host, payload, untilClosed)
  local id, why = nic.connect(slot, host, PORT)
  if not id then error(why or "cannot connect", 0) end
  local got, sent = "", false
  local timer = os.startTimer(15)
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then return got end
    if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot and ev[5] == id then
      if ev[4] == "connected" and not sent then nic.tcpSend(slot, id, payload); sent = true
      elseif ev[4] == "data" then got = got .. tostring(ev[6]); if not untilClosed then pcall(nic.tcpClose, slot, id); return got end
      elseif ev[4] == "closed" or ev[4] == "refused" then return got end
    end
  end
end

if args[1] == "send" and args[3] then
  local f = fs.open(args[3], "r")
  if not f then error("no such file: " .. args[3], 0) end
  local text = f.readAll(); f.close()
  print(dialog(1, args[2], M.encode(args[4] or fs.getName(args[3]), text)))
elseif args[1] == "queue" and args[2] then
  print(dialog(1, args[2], "QUEUE\n"))
elseif args[1] == "serve" then
  local slot = tonumber(args[2]) or 1
  local printer = peripheral.find("printer")
  if not printer then error("no printer found", 0) end
  local Q = M.queue()
  nic.listen(slot, PORT)
  print("print server on port " .. PORT .. "  (Ctrl+T stops)")
  local bufs = {}
  local function printJob(job)
    local w, h = 25, 21
    if printer.newPage() then
      w, h = printer.getPageSize()
      printer.endPage()
    end
    for n, page in ipairs(M.paginate(job.text, w, h)) do
      if not printer.newPage() then return false, "out of paper or ink" end
      printer.setPageTitle(job.title .. " " .. n)
      for y, line in ipairs(page) do printer.setCursorPos(1, y); printer.write(line) end
      printer.endPage()
    end
    return true
  end
  local timer = os.startTimer(2)
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then pcall(nic.unlisten, slot, PORT); return end
    if ev[1] == "timer" and ev[2] == timer then
      local job = Q.next()
      if job then
        local ok, why = printJob(job)
        print(ok and ("printed " .. job.title) or ("failed: " .. tostring(why) .. " (" .. job.title .. ")"))
        if not ok then Q.jobs[#Q.jobs + 1] = job; Q.jobs[#Q.jobs] = nil end
      end
      timer = os.startTimer(2)
    elseif ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot then
      local kind, id = ev[4], ev[5]
      if kind == "accepted" and ev[8] == PORT then bufs[id] = { ip = ev[6], data = "" }
      elseif kind == "data" and bufs[id] then
        local b = bufs[id]
        b.data = b.data .. tostring(ev[6])
        if b.data:sub(1, 5) == "QUEUE" then
          local l = Q.list()
          nic.tcpSend(slot, id, #l == 0 and "the queue is empty\n" or table.concat(l, "\n") .. "\n")
          nic.tcpClose(slot, id); bufs[id] = nil
        else
          local title, text = M.decode(b.data)
          if title then
            local jid, why = Q.add(b.ip, title, text)
            nic.tcpSend(slot, id, jid and ("queued as job " .. jid .. "\n") or ("refused: " .. why .. "\n"))
            nic.tcpClose(slot, id); bufs[id] = nil
          elseif text ~= "more" and #b.data > 30000 then nic.tcpClose(slot, id); bufs[id] = nil end
        end
      elseif kind == "closed" then bufs[id] = nil end
    end
  end
else
  print("rpprint serve [slot] | send <host> <file> [title] | queue <host>")
end
return M
