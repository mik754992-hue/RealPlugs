package net.minecraft.nbt;
import java.util.*;
public class CompoundTag implements Tag {
    final Map<String,Object> m = new LinkedHashMap<>();
    public void putBoolean(String k, boolean v){m.put(k,v);} public boolean getBoolean(String k){return (Boolean)m.getOrDefault(k,false);}
    public void putInt(String k,int v){m.put(k,v);} public int getInt(String k){return (Integer)m.getOrDefault(k,0);}
    public void putString(String k,String v){m.put(k,v);} public String getString(String k){return (String)m.getOrDefault(k,"");}
    public void put(String k,Tag v){m.put(k,v);}
    public CompoundTag getCompound(String k){Object o=m.get(k);return o==null?new CompoundTag():(CompoundTag)o;}
    public ListTag getList(String k,int t){Object o=m.get(k);return o==null?new ListTag():(ListTag)o;}
    public boolean contains(String k){return m.containsKey(k);}
    public Set<String> getAllKeys(){return m.keySet();}
}
