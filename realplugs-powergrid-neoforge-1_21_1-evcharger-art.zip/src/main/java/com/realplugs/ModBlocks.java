package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.LinkedHashMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(BuiltInRegistries.BLOCK, RealPlugsMod.MODID);

    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_LIGHT_GRAY)
                .strength(0.5f)
                .sound(SoundType.METAL)
                .noOcclusion();
    }

    /** The hidden anchor behind a port: no collision, no drops, cannot be broken, only removed with its port. */
    private static BlockBehaviour.Properties anchorProps() {
        return BlockBehaviour.Properties.of()
                .noCollission()
                .noOcclusion()
                .noLootTable()
                .strength(-1.0f, 3600000.0f)
                .pushReaction(PushReaction.IGNORE);
    }

    /** Every outlet / power strip, by id. The list itself lives in SocketDefs. */
    public static final Map<String, DeferredHolder<Block, PlugSocketBlock>> SOCKETS = new LinkedHashMap<>();

    static {
        for (SocketDef def : SocketDefs.ALL) {
            SOCKETS.put(def.id(), BLOCKS.register(def.id(), () -> def.id().equals(SocketDefs.ANCHOR_ID)
                    ? new PortAnchorBlock(anchorProps(), def)
                    : def.id().startsWith("ev_charger_")
                    ? new EvChargerBlock(props(), def, EvChargerBlock.pricePerMinute(def.id()))
                    : def.id().startsWith("ext_")
                    ? new ExtensionEndBlock(props().noLootTable(), def)
                    : new PlugSocketBlock(props(), def)));
        }
    }
}
