RPWEB_TEST = true
local fails = 0
local function eq(a,b,w) if a~=b then print("FAIL "..w..": got "..tostring(a).." expected "..tostring(b)); fails=fails+1 else print("  ok  "..w) end end
local F = dofile("lua/rpfiles.lua")
eq(F.safePath("/a/b.txt"),"a/b.txt","leading slash"); eq(F.safePath("../x"),nil,"dotdot"); eq(F.safePath("a/../b"),nil,"inner dotdot"); eq(F.safePath("a\\b"),nil,"backslash"); eq(F.safePath(""),"","root"); eq(F.safePath("a b/c.lua"),"a b/c.lua","spaces ok"); eq(F.safePath("a;b"),nil,"odd chars")
local r = F.parseRequest("PUT docs/my file.txt 12 secret"); eq(r.op,"PUT","put op"); eq(r.path,"docs/my file.txt","put path with space"); eq(r.len,12,"put len"); eq(r.password,"secret","put pw")
eq(F.parseRequest("GET a/b").path,"a/b","get path"); eq(F.parseRequest("LS ").path,"","ls root"); local rm = F.parseRequest("RM a/b.txt pw"); eq(rm.path,"a/b.txt","rm path"); eq(rm.password,"pw","rm pw"); eq(F.parseRequest("lol"),nil,"junk")
eq(F.buildRequest("PUT","a.txt",5,"pw"),"PUT a.txt 5 pw\n","build put"); eq(F.parseRequest((F.buildRequest("RM","x/y","pw"):gsub("\n",""))).password,"pw","build rm round trip")
local a = F.parseAnswer(F.ok("hello")); eq(a.ok,true,"ok answer"); eq(a.body,"hello","body"); eq(F.parseAnswer("OK 10\nabc"),nil,"waits for the rest"); eq(F.parseAnswer("ERR no"),nil,"needs newline"); eq(F.parseAnswer(F.err("bad path")).why,"bad path","err answer")
eq(F.parseAnswer(F.ok("")).body,"","empty body ok")
-- fake file system
local store = { ["share/a.txt"]="AAA", ["share/sub/b.txt"]="BBBB" }
local dirs = { ["share"]=true, ["share/sub"]=true }
local fsys = { exists=function(p) return store[p]~=nil or dirs[p] end, isDir=function(p) return dirs[p] or false end,
  list=function(p) local out={} for k in pairs(store) do local n=k:match("^"..p.."/([^/]+)") if n then out[#out+1]=n end end for d in pairs(dirs) do local n=d:match("^"..p.."/([^/]+)$") if n then out[#out+1]=n end end local seen,u={},{} for _,n in ipairs(out) do if not seen[n] then seen[n]=1 u[#u+1]=n end end return u end,
  size=function(p) return #store[p] end, read=function(p) return store[p] end, write=function(p,t) store[p]=t end, delete=function(p) store[p]=nil end }
local function run(line, body, pw) local rq=F.parseRequest(line) return F.parseAnswer(F.handle(rq, body or "", "share", fsys, pw)) end
local ls = run("LS "); eq(ls.ok and ls.body,"a.txt\t3\nsub\tdir","ls root")
eq(run("GET a.txt").body,"AAA","get"); eq(run("GET sub/b.txt").body,"BBBB","get sub"); eq(run("GET nope").why,"no such file","get missing"); eq(run("GET ../etc").why,"bad path","path escape refused"); eq(run("GET sub").why,"no such file","get a folder")
eq(run("PUT n.txt 3 pw","xyz",nil).why,"this share is read-only","read-only share"); eq(run("PUT n.txt 3 bad","xyz","pw").why,"wrong password","wrong password")
eq(run("PUT n.txt 3 pw","xyz","pw").ok,true,"upload ok"); eq(store["share/n.txt"],"xyz","file stored"); eq(run("RM n.txt pw",nil,"pw").ok,true,"delete ok"); eq(store["share/n.txt"],nil,"file gone")
eq(run("PUT  3 pw","xyz","pw").why,"bad path","cannot overwrite the root")
-- chat
local C = dofile("lua/rpchat.lua")
eq(C.validNick("Bob_1"),true,"nick ok"); eq(C.validNick("a"),false,"nick too short"); eq(C.validNick("bad nick"),false,"nick with space")
local c1,c2,c3 = C.parseInput("hello there"); eq(c1,"say","say"); eq(c2,"hello there","say text")
c1,c2,c3 = C.parseInput("/mail bob hi bob"); eq(c1,"mail","mail cmd"); eq(c2,"bob","mail to"); eq(c3,"hi bob","mail text"); eq(C.parseInput("/mail bob"),"error","mail needs text"); eq(C.parseInput("/who"),"who","who"); eq(C.parseInput("/nope"),"error","unknown"); eq(C.parseInput("   "),nil,"blank")
local sent = {}
local function send(id,line) sent[#sent+1]=id..":"..line end
local mailstore = { saved = 0, save = function(s) end }
local S = C.newServer(send, mailstore)
S.connect(1); S.connect(2); S.connect(3)
S.line(1,"SAY too early"); eq(sent[#sent],"1:ERR Send NICK <name> first.","must pick a nick")
S.line(1,"NICK alice"); S.line(2,"NICK bob"); S.line(3,"NICK alice"); eq(sent[#sent],"3:ERR That name is taken.","duplicate nick refused (case-insensitive)")
S.line(3,"NICK x"); eq(sent[#sent],"3:ERR Nicknames are 2 to 16 letters, digits, _ or -.","bad nick refused")
sent = {}; S.line(1,"SAY hi all")
local got = table.concat(sent,"|"); eq(got,"1:MSG alice hi all|2:MSG alice hi all","say reaches every named client") 
sent = {}; S.line(1,"WHO"); eq(sent[1],"1:SYS Here: alice, bob","who lists names")
sent = {}; S.line(1,"MAIL Bob see you at 5"); eq(sent[1],"1:SYS Mail sent to Bob","mail sent"); eq(sent[2],"2:SYS New mail from alice. Type /inbox","online user told")
sent = {}; S.line(2,"INBOX"); eq(sent[1],"2:MAIL alice see you at 5","inbox delivers"); sent = {}; S.line(2,"INBOX"); eq(sent[1],"2:SYS No mail.","inbox empties")
S.line(1,"MAIL carol later"); S.disconnect(1); sent = {}; S.connect(4); S.line(4,"NICK carol"); local hasMail=false for _,l in ipairs(sent) do if l:find("You have 1 mail",1,true) then hasMail=true end end; eq(hasMail,true,"offline mail announced at login")
eq(C.display("MSG alice hi"),"<alice> hi","display msg"); eq(C.display("MAIL bob yo"),"[mail from bob] yo","display mail"); eq(C.display("ERR no"),"! no","display err"); eq(C.display("SYS hello"),"* hello","display sys")
print(fails==0 and "ALL OK" or (fails.." FAILED")); os.exit(fails==0 and 0 or 1)
