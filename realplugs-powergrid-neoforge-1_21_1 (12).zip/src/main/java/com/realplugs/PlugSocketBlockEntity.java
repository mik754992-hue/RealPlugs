package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import org.patryk3211.powergrid.electricity.base.ElectricBehaviour;
import org.patryk3211.powergrid.electricity.base.ElectricBlockEntity;
import org.patryk3211.powergrid.electricity.base.IElectricEntity;
import org.patryk3211.powergrid.electricity.sim.SwitchedWire;
import org.patryk3211.powergrid.electricity.wire.BaseWireEntity;
import org.patryk3211.powergrid.electricity.wire.BlockWireEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.CordEntity;

import java.util.Map;
import java.util.Set;

/**
 * Electrical model of an outlet / power strip:
 *   terminal 0        = hot bus      (wire the supply here)
 *   terminal 1        = neutral bus  (supply neutral, and every device's return, goes here)
 *   terminal 2 + i    = tap of slot i, connected to the hot bus ONLY while a plug (or a plug cord) sits in slot i
 */
public class PlugSocketBlockEntity extends ElectricBlockEntity {
    /** Resistance of a closed slot contact in ohms. */
    private static final float CONTACT_RESISTANCE = 0.005f;

    private NonNullList<ItemStack> plugs;
    private SwitchedWire[] taps;
    /** Bit i set = a plug cord end sits in slot i. Synced to the client so the renderer can draw the plug. */
    private int cordMask;

    public PlugSocketBlockEntity(BlockEntityType<?> type, BlockPos pos, BlockState state) {
        super(type, pos, state);
    }

    /** Created lazily because the circuit can be built before our own constructor body would have run. */
    public NonNullList<ItemStack> plugs() {
        if (plugs == null) {
            int n = getBlockState().getBlock() instanceof PlugSocketBlock b ? b.slots : 1;
            plugs = NonNullList.withSize(n, ItemStack.EMPTY);
        }
        return plugs;
    }

    @Override
    public void buildCircuit(IElectricEntity.CircuitBuilder builder) {
        int n = plugs().size();
        builder.setTerminalCount(2 + n);
        taps = new SwitchedWire[n];
        for (int i = 0; i < n; i++) {
            taps[i] = builder.connectSwitch(CONTACT_RESISTANCE,
                    builder.terminalNode(0), builder.terminalNode(2 + i), occupied(i));
        }
    }

    /** Close the contact of every slot that holds a plug, open the rest. */
    public void refreshTaps() {
        if (taps == null) return;
        for (int i = 0; i < taps.length; i++) {
            if (taps[i] != null) taps[i].setState(occupied(i));
        }
    }

    @Override
    public ElectricBehaviour specifyElectricBehaviour() {
        return new SocketBehaviour(this);
    }

    /** True when a Real Plugs plug cord is plugged into this slot (its end sits on the slot's tap terminal). */
    public boolean hasCord(int slot) {
        ElectricBehaviour eb = getElectricBehaviour();
        if (eb == null) return false;
        for (Map.Entry<BlockWireEndpoint, Set<BaseWireEntity>> e : eb.getConnections().entrySet()) {
            if (e.getKey().getTerminal() != 2 + slot) continue;
            for (BaseWireEntity w : e.getValue()) if (w instanceof CordEntity) return true;
        }
        return false;
    }

    private boolean occupied(int slot) {
        return !plugs().get(slot).isEmpty() || hasCord(slot);
    }

    /** Called by SocketBehaviour whenever a wire or cord is attached or removed. */
    public void cordsChanged() {
        if (level == null || isRemoved()) return;
        refreshTaps();
        if (level.isClientSide) return;
        int mask = 0;
        for (int i = 0; i < plugs().size(); i++) if (hasCord(i)) mask |= 1 << i;
        if (mask != cordMask) {
            cordMask = mask;
            notifyUpdate();
        }
    }

    /** For the renderer: is a cord end shown in this slot? */
    public boolean cordShown(int slot) {
        return (cordMask >> slot & 1) != 0;
    }

    public void setPlug(int slot, ItemStack stack) {
        plugs().set(slot, stack);
        plugsChanged();
    }

    public void plugsChanged() {
        refreshTaps();
        notifyUpdate();
    }

    @Override
    protected void read(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.read(tag, registries, clientPacket);
        NonNullList<ItemStack> list = plugs();
        for (int i = 0; i < list.size(); i++) list.set(i, ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, list, registries);
        cordMask = tag.getInt("CordMask");
        refreshTaps();
    }

    @Override
    protected void write(CompoundTag tag, HolderLookup.Provider registries, boolean clientPacket) {
        super.write(tag, registries, clientPacket);
        ContainerHelper.saveAllItems(tag, plugs(), registries);
        tag.putInt("CordMask", cordMask);
    }
}
