package dan200.computercraft.api.pocket;

import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.Entity;

/** COMPILE-TIME STUB of CC: Tweaked 1.113's IPocketAccess (only what Real Plugs uses). Excluded from the released jar. */
public interface IPocketAccess {
    ServerLevel getLevel();

    Entity getEntity();

    DataComponentPatch getUpgradeData();

    void setUpgradeData(DataComponentPatch data);

    void invalidatePeripheral();
}
