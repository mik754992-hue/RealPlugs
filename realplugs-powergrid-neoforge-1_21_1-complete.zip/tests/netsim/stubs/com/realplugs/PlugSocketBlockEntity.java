package com.realplugs;
import com.realplugs.net.*; import net.minecraft.core.BlockPos; import net.minecraft.server.level.ServerLevel; import java.util.*;
public class PlugSocketBlockEntity {
  public static final int ROUTER_WAN = 3;
  public final ServerLevel level; public final BlockPos pos; public final String kind; public final int slots; public final NetConfig net = new NetConfig();
  public final Map<Integer,int[]> peers = new HashMap<>(); public final int[] act = new int[8]; public final Map<Object,NetListener> listeners = new HashMap<>();
  public PlugSocketBlockEntity(ServerLevel l, BlockPos p, String kind, int slots){level=l;pos=p;this.kind=kind;this.slots=slots; l.bes.put(p,this);}
  public ServerLevel getLevel(){return level;} public BlockPos getBlockPos(){return pos;} public boolean isRemoved(){return false;}
  public NetConfig net(){return net;} public void netChanged(){} public Collection<NetListener> netListeners(){return new ArrayList<>(listeners.values());}
  public int slotCount(){return slots;} public boolean isRj45(int s){return s>=0&&s<slots;}
  public boolean isAccessPointBlock(){return kind.equals("ap");} public boolean isRouterBlock(){return kind.equals("router");} public boolean isSwitchBlock(){return kind.equals("switch");}
  public int[] cordPeer(int s){return peers.get(s);} public final Map<Integer,CableTier> tiers = new HashMap<>(); public CableTier cordTier(int s){return tiers.get(s);} public void markActivity(int s){act[s]++;}
}
