package com.realplugs;

import com.realplugs.net.CableTier;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * A network cable: a plug cord with an RJ45 plug on each end and a speed class (Cat5, Cat6, fibre). It is its own item
 * (Power Grid remembers the item of every cord entity), which is how the network model finds out which cable a link uses.
 * Delay and the packets-per-second cap are in {@link CableTier}; the maximum length is in the item's wire_types file.
 */
public class NetCableItem extends PlugCordItem {
    /** Both ends of a network cable are RJ45. */
    public static final CordTypes.CordDef RJ45_CORD = new CordTypes.CordDef("ethernet", PlugTypes.Standard.RJ45, PlugTypes.Standard.RJ45);

    private final CableTier tier;

    public NetCableItem(Properties props, CableTier tier) {
        super(props);
        this.tier = tier;
    }

    public CableTier tier() {
        return tier;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("tooltip.realplugs.cable_speed", tier.speed).withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable(tier.delayTicks == 0 ? "tooltip.realplugs.cable_delay_none" : "tooltip.realplugs.cable_delay",
                tier.delayTicks * 50).withStyle(ChatFormatting.GRAY));
        if (tier.packetsPerSecond > 0) {
            tips.add(Component.translatable("tooltip.realplugs.cable_cap", tier.packetsPerSecond).withStyle(ChatFormatting.GRAY));
        } else {
            tips.add(Component.translatable("tooltip.realplugs.cable_nocap").withStyle(ChatFormatting.GRAY));
        }
    }
}
