package com.realplugs;

import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomModelData;

import java.util.ArrayList;
import java.util.List;

/** One class for both plugs/cables and adapters. Look, name and connector standard come from custom_model_data. */
public class PlugItem extends Item {
    public final boolean adapter;

    public PlugItem(Properties props, boolean adapter) {
        super(props);
        this.adapter = adapter;
    }

    public static int typeOf(ItemStack stack) {
        CustomModelData d = stack.get(DataComponents.CUSTOM_MODEL_DATA);
        return d == null ? 0 : d.value();
    }

    /** The standard of the plug end that goes INTO a socket (for an adapter: its plug side). */
    public static PlugTypes.Standard plugStandard(ItemStack stack) {
        if (!(stack.getItem() instanceof PlugItem p)) return null;
        int t = typeOf(stack);
        return p.adapter ? PlugTypes.adapter(t).plugs() : PlugTypes.plug(t).plugs();
    }

    @Override
    public String getDescriptionId(ItemStack stack) {
        int i = typeOf(stack);
        String base = getDescriptionId();
        if (i <= 0) return base;
        if (adapter) return i < PlugTypes.ADAPTERS.length ? base + "." + PlugTypes.ADAPTERS[i].name() : base;
        return i < PlugTypes.PLUGS.length ? base + "." + PlugTypes.PLUGS[i].name() : base;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tips, TooltipFlag flag) {
        PlugTypes.Standard std = plugStandard(stack);
        if (std != null) {
            tips.add(Component.translatable("tooltip.realplugs.plugs_into", Component.translatable(std.langKey()))
                    .withStyle(ChatFormatting.GRAY));
        }
        if (adapter) {
            PlugTypes.AdapterDef d = PlugTypes.adapter(typeOf(stack));
            tips.add(Component.translatable("tooltip.realplugs.accepts", Component.translatable(d.accepts().langKey()),
                    d.sockets().length).withStyle(ChatFormatting.GRAY));
        }
    }

    // ---- plugs sitting inside an adapter ----

    public static List<ItemStack> inners(ItemStack adapterStack) {
        return adapterStack.getOrDefault(ModComponents.INNER.get(), List.of());
    }

    public static void setInners(ItemStack adapterStack, List<ItemStack> list) {
        if (list.isEmpty()) adapterStack.remove(ModComponents.INNER.get());
        else adapterStack.set(ModComponents.INNER.get(), List.copyOf(list));
    }

    /** Can this plug/adapter be plugged into that adapter right now (standard matches, a socket is free)? */
    public static boolean canInsert(ItemStack adapterStack, ItemStack insert) {
        if (!(adapterStack.getItem() instanceof PlugItem a) || !a.adapter) return false;
        PlugTypes.Standard std = plugStandard(insert);
        if (std == null) return false;
        PlugTypes.AdapterDef d = PlugTypes.adapter(typeOf(adapterStack));
        return std == d.accepts() && inners(adapterStack).size() < d.sockets().length;
    }

    public static void addInner(ItemStack adapterStack, ItemStack one) {
        List<ItemStack> l = new ArrayList<>(inners(adapterStack));
        l.add(one);
        setInners(adapterStack, l);
    }

    /** Remove and return the last plug from the adapter (EMPTY if none). */
    public static ItemStack popInner(ItemStack adapterStack) {
        List<ItemStack> l = new ArrayList<>(inners(adapterStack));
        if (l.isEmpty()) return ItemStack.EMPTY;
        ItemStack out = l.remove(l.size() - 1).copy();
        setInners(adapterStack, l);
        return out;
    }

    public static ItemStack takeOne(ItemStack held, Player player) {
        ItemStack one = held.copy();
        one.setCount(1);
        if (!player.getAbilities().instabuild) held.shrink(1);
        return one;
    }

    public static void give(Player player, ItemStack stack) {
        if (!player.getInventory().add(stack)) player.drop(stack, false);
    }
}
