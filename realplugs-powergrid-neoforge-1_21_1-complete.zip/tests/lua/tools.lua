RPWEB_TEST = true
package.path = "lua/?.lua;" .. package.path
local fails = 0
local function eq(a,b,w) if a~=b then print("FAIL "..w..": got "..tostring(a).." expected "..tostring(b)); fails=fails+1 else print("  ok  "..w) end end
local web = require("rpweb")
-- rpmon
local mon = dofile("lua/rpmon.lua")
eq(mon.fmtBytes(500),"500B","bytes"); eq(mon.fmtBytes(2048),"2.0k","kb"); eq(mon.fmtBytes(3*1048576),"3.0M","mb")
eq(mon.bar(5,10,10),"#####.....","bar half"); eq(mon.bar(0,0,4),"....","bar zero max"); eq(mon.bar(99,10,4),"####","bar capped")
eq(mon.fmtSniff("1.1.1.1","2.2.2.2","udp",5,6,"a\nb"),"1.1.1.1         > 2.2.2.2         udp   :5>6 a.b","sniff line")
local r = mon.rates({rxPackets=10,txPackets=0},{rxPackets=30,txPackets=5},2); eq(r.rx,10,"rx rate"); eq(r.tx,2.5,"tx rate")
-- rpdns
local dns = dofile("lua/rpdns.lua")
local rec, errs = dns.parseZone("# zone\nNAS.home 192.168.1.50  # my nas\nweb 192.168.1.60\nbad line here\nx 999\n")
eq(rec["nas.home"],"192.168.1.50","zone record lower-cased"); eq(rec.web,"192.168.1.60","zone web"); eq(#errs,2,"two bad lines")
local add, remove = dns.diff({a="1.1.1.1",b="2.2.2.2",c="3.3.3.3"},{a="1.1.1.1",b="9.9.9.9",d="4.4.4.4"})
eq(add.b,"9.9.9.9","changed record"); eq(add.d,"4.4.4.4","new record"); eq(add.a,nil,"unchanged skipped"); eq(#remove,1,"one removed"); eq(remove[1],"c","c removed")
-- rpadmin with a fake router
local admin = dofile("lua/rpadmin.lua")
local calls = {}
local nic = setmetatable({}, { __index = function(_, name) return function(...) calls[#calls+1] = name .. "(" .. table.concat({...}, ",") .. ")"; return true end end })
nic.getInterfaces = function() return { {ip="192.168.1.1",prefix=24,linkUp=true}, {ip="",prefix=0} } end
nic.getStats = function() return { rxPackets=5, txPackets=6 } end
nic.getDhcp = function() return { enabled=true, first="192.168.1.2", last="192.168.1.254" } end
nic.getDhcpLeases = function() return { {mac="02:00:00:00:00:01", ip="192.168.1.2", reserved=false}, {mac="02:00:00:00:00:02", ip="192.168.1.50", reserved=true} } end
nic.getDnsRecords = function() return { {name="nas.home", ip="192.168.1.50"} } end
nic.getPortForwards = function() return { {publicPort=8080, ip="192.168.1.50", port=80} } end
nic.getFirewallPolicy = function() return "allow" end; nic.getFirewallBlocked = function() return 3 end
nic.getFirewallRules = function() return { {position=1, action="reject", direction="in", protocol="tcp", src="any", dst="any", port=22} } end
nic.getTunnels = function() return { {name="b", peer="100.64.1.1", network="192.168.2.0/24"} } end
nic.isAccessPoint = function() return true end
nic.getAccessPoint = function() return { ssid="Home", secured=true, range=24, clients=2, guestSsid="Guests" } end
nic.getWifiClients = function() return { {mac="02:aa", ip="192.168.1.9", signal=80} } end
local route = admin.makeRoute(nic, "pw", 1)
local function ask(q) return route({ path="/", query=q }) end
eq(route({path="/other", query={}}),nil,"other paths not handled")
local login = ask({}); eq(login.body:find("Log in",1,true)~=nil,true,"login form"); eq(login.body:find("Wrong",1,true),nil,"no error before trying")
eq(ask({key="no"}).body:find("Wrong password",1,true)~=nil,true,"wrong password refused")
local pg = ask({key="pw"}).body
for _,s in ipairs{"Ports","192.168.1.1","DHCP (port 1)","02:00:00:00:00:02","reserved","nas.home","8080","Policy: <b>allow</b>","reject","VPN tunnels","192.168.2.0/24","Wi-Fi","Guests","02:aa"} do
  eq(pg:find(s,1,true)~=nil,true,"admin page shows "..s) end
local rr = ask({key="pw",act="dns_add",name="x.home",ip="1.2.3.4"}); eq(rr.status,302,"action redirects"); eq(rr.location:find("key=pw",1,true)~=nil,true,"redirect keeps key"); eq(rr.location:find("msg=Done",1,true)~=nil,true,"redirect carries message")
eq(calls[#calls],"addDnsRecord(x.home,1.2.3.4)","dns_add called")
ask({key="pw",act="fw_add",action="drop",dir="in",proto="icmp",src="any",dst="any",port="0"}); eq(calls[#calls],"addFirewallRule(drop,in,icmp,any,any,any,0)" == calls[#calls] and calls[#calls] or calls[#calls],"fw_add called")
ask({key="pw",act="fw_del",n="1"}); eq(calls[#calls],"removeFirewallRule(1)","fw_del")
ask({key="pw",act="resv_add",mac="02:00:00:00:00:09",ip="192.168.1.77"}); eq(calls[#calls],"reserveAddress(1,02:00:00:00:00:09,192.168.1.77)","reserve")
ask({key="pw",act="ap_set",ssid="Home",pass=""}); eq(calls[#calls],"setAccessPoint(Home)","open network set without password")
ask({key="pw",act="guest_set",ssid="",pass=""}); eq(calls[#calls],"clearGuestNetwork()","empty guest name switches it off")
-- the whole thing through the web layer (query string from an rpweb form)
local ctx = { read=function() return nil end, isDir=function() return false end, vars={}, route=route }
local resp = web.parseResponse(web.handle("GET /?key=pw HTTP/1.0\r\n\r\n", ctx)); eq(resp.status,200,"served through rpweb"); eq(resp.body:find("Router admin",1,true)~=nil,true,"admin html served")
local redirected = web.parseResponse(web.handle("GET /?key=pw&act=dns_del&name=nas.home HTTP/1.0\r\n\r\n", ctx)); eq(redirected.status,302,"action through rpweb redirects")
-- the admin page must render in the browser without losing its forms
local rendered = web.render(pg, 50, web.parseUrl("http://router/"))
eq(#rendered.forms >= 8, true, "admin page has its forms ("..#rendered.forms..")")
print(fails==0 and "ALL OK" or (fails.." FAILED")); os.exit(fails==0 and 0 or 1)
