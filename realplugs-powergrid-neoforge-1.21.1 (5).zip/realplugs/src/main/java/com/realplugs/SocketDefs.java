package com.realplugs;

/** GENERATED: every outlet / power strip block (id, plate geometry in 1/16 block, slot standards). */
public final class SocketDefs {
    public static final SocketDef[] ALL = {
        new SocketDef("outlet", 2, 14, 1, 15, 3, new PlugTypes.Standard[]{PlugTypes.Standard.US_POWER, PlugTypes.Standard.US_POWER}),
        new SocketDef("eu_outlet", 2, 14, 1, 15, 3, new PlugTypes.Standard[]{PlugTypes.Standard.EU_POWER, PlugTypes.Standard.EU_POWER}),
        new SocketDef("uk_outlet", 2, 14, 1, 15, 3, new PlugTypes.Standard[]{PlugTypes.Standard.UK_POWER, PlugTypes.Standard.UK_POWER}),
        new SocketDef("dc_outlet", 2, 14, 1, 15, 3, new PlugTypes.Standard[]{PlugTypes.Standard.BARREL, PlugTypes.Standard.BARREL}),
        new SocketDef("usb_hub", 0, 16, 2, 14, 4, new PlugTypes.Standard[]{PlugTypes.Standard.USB_A, PlugTypes.Standard.USB_A, PlugTypes.Standard.USB_C, PlugTypes.Standard.USB_C}),
        new SocketDef("power_strip", 0, 16, 2, 14, 4, new PlugTypes.Standard[]{PlugTypes.Standard.US_POWER, PlugTypes.Standard.US_POWER, PlugTypes.Standard.US_POWER, PlugTypes.Standard.US_POWER}),
        new SocketDef("eu_power_strip", 0, 16, 2, 14, 4, new PlugTypes.Standard[]{PlugTypes.Standard.EU_POWER, PlugTypes.Standard.EU_POWER, PlugTypes.Standard.EU_POWER, PlugTypes.Standard.EU_POWER}),
        new SocketDef("universal_power_strip", 0, 16, 2, 14, 4, new PlugTypes.Standard[]{PlugTypes.Standard.US_POWER, PlugTypes.Standard.EU_POWER, PlugTypes.Standard.UK_POWER, PlugTypes.Standard.USB_A})
    };

    private SocketDefs() {}
}
