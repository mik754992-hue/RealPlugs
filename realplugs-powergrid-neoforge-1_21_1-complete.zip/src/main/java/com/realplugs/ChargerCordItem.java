package com.realplugs;

/**
 * The cord pulled out of an EV charger (see BuiltinCord). It is a plug cord in every way, but its own item type: Power Grid
 * takes the item cost of a cord from the first item OF THE SAME TYPE anywhere in the inventory (PlayerUtilities.removeItems
 * matches on the item only). As a plain plug cord, that used up some other plug cord from the player's inventory and left
 * this one behind; as its own item, the one connecting cord is the one that gets used up.
 */
public class ChargerCordItem extends PlugCordItem {
    public ChargerCordItem(Properties props) {
        super(props);
    }
}
