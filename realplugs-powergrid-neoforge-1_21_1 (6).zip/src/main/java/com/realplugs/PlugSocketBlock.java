package com.realplugs;

import com.simibubi.create.foundation.block.IBE;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.patryk3211.powergrid.electricity.base.DirectionalElectricBlock;
import org.patryk3211.powergrid.electricity.base.IDecoratedTerminal;
import org.patryk3211.powergrid.electricity.base.TerminalBoundingBox;

import java.util.ArrayList;
import java.util.List;

/**
 * A wall plate with N plug slots, wired into Create: Power Grid. Every slot has its own connector standard
 * (see SocketDef) and only accepts plugs/adapters whose plug side matches it.
 * Authored facing NORTH (front faces north, back is at the south edge); FACING is the front direction.
 * Terminals (1/16 block units, north frame): hot bus bar on top, neutral bus bar at the bottom,
 * and one tap stud per slot. See PlugSocketBlockEntity for the circuit.
 */
public class PlugSocketBlock extends DirectionalElectricBlock implements IBE<PlugSocketBlockEntity> {
    private static final double STUD = 1.5;   // how far studs/bars stick out of the plate front

    public final SocketDef def;
    public final int slots;
    private final int xMin, xMax, yMin, yMax, depth;

    public PlugSocketBlock(Properties props, SocketDef def) {
        super(props);
        this.def = def;
        this.slots = def.slots().length;
        this.xMin = def.xMin();
        this.xMax = def.xMax();
        this.yMin = def.yMin();
        this.yMax = def.yMax();
        this.depth = def.depth();

        double zf = 16 - depth;     // front face of the plate
        double zs = zf - STUD;      // front of the studs
        double sw = (xMax - xMin) / (double) slots;

        List<TerminalBoundingBox> terminals = new ArrayList<>();
        VoxelShape shape = Block.box(xMin, yMin, zf, xMax, yMax, 16);

        // 0: hot bus (top), 1: neutral bus (bottom)
        terminals.add(new TerminalBoundingBox(IDecoratedTerminal.CONNECTOR,
                xMin + 1, yMax - 2, zs, xMax - 1, yMax - 0.5, zf).withColor(IDecoratedTerminal.RED));
        terminals.add(new TerminalBoundingBox(IDecoratedTerminal.CONNECTOR,
                xMin + 1, yMin + 0.5, zs, xMax - 1, yMin + 2, zf).withColor(IDecoratedTerminal.BLUE));
        shape = Shapes.or(shape,
                Block.box(xMin + 1, yMax - 2, zs, xMax - 1, yMax - 0.5, zf),
                Block.box(xMin + 1, yMin + 0.5, zs, xMax - 1, yMin + 2, zf));

        // 2 + i: tap stud of slot i (slot 0 is on the viewer's left = +x in the north frame)
        for (int i = 0; i < slots; i++) {
            double cx = xMax - (i + 0.5) * sw;
            terminals.add(new TerminalBoundingBox(IDecoratedTerminal.OUTPUT,
                    cx - 1.25, yMin + 2.5, zs, cx + 1.25, yMin + 4, zf).withColor(IDecoratedTerminal.RED));
            shape = Shapes.or(shape, Block.box(cx - 1.25, yMin + 2.5, zs, cx + 1.25, yMin + 4, zf));
        }

        setTerminalCollection(directionalNorthTerminals(this, terminals.toArray(new TerminalBoundingBox[0]), shape));
    }

    // ---- geometry helpers for the renderer (north frame, block-centered, in blocks) ----
    public double slotCenterX(int i) {
        double sw = (xMax - xMin) / (double) slots;
        return (xMax - (i + 0.5) * sw) / 16.0 - 0.5;
    }
    public double plugCenterY() { return (((yMin + 4.5) + (yMax - 2.5)) / 2.0) / 16.0 - 0.5; }
    public double frontLocalZ() { return (16.0 - depth) / 16.0 - 0.5; }
    public float plugScale() {
        double sw = (xMax - xMin) / (double) slots;
        double regionH = (yMax - 2.5) - (yMin + 4.5);
        return (float) Math.min(0.4, Math.min(sw / 16.0 * 1.1, regionH / 16.0));
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        // the back of the plate sits against the face you clicked
        return defaultBlockState().setValue(FACING, ctx.getClickedFace());
    }

    @Override
    public Class<PlugSocketBlockEntity> getBlockEntityClass() {
        return PlugSocketBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends PlugSocketBlockEntity> getBlockEntityType() {
        return ModBlockEntities.SOCKET.get();
    }

    /** Which slot (counted from the viewer's left) did the player click? */
    private int slotAt(BlockState state, BlockPos pos, Vec3 hit) {
        Direction f = state.getValue(FACING);
        Direction right = f.getAxis().isHorizontal() ? f.getCounterClockWise() : Direction.WEST;
        Vec3 rel = hit.subtract(pos.getX(), pos.getY(), pos.getZ());
        double c = right.getAxis() == Direction.Axis.X ? rel.x : rel.z;
        double u = right.getAxisDirection() == Direction.AxisDirection.POSITIVE ? c : 1.0 - c;
        double t = (u * 16.0 - xMin) / (xMax - xMin);
        return Mth.clamp((int) Math.floor(t * slots), 0, slots - 1);
    }

    private static ItemInteractionResult noFit(Level level, Player player, PlugTypes.Standard needs) {
        if (!level.isClientSide) {
            player.displayClientMessage(Component.translatable("message.realplugs.no_fit",
                    Component.translatable(needs.langKey())), true);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Holding a plug/adapter: it has to match the slot's standard (or the adapter that is already there). */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (!(held.getItem() instanceof PlugItem)
                || !(level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        int slot = slotAt(state, pos, hit.getLocation());
        PlugTypes.Standard needs = def.slots()[slot];
        ItemStack target = be.plugs().get(slot);

        if (target.isEmpty()) {
            if (PlugItem.plugStandard(held) != needs) return noFit(level, player, needs);
            if (!level.isClientSide) be.setPlug(slot, PlugItem.takeOne(held, player));
        } else if (target.getItem() instanceof PlugItem ti && ti.adapter) {
            if (!PlugItem.canInsert(target, held)) {
                return noFit(level, player, PlugTypes.adapter(PlugItem.typeOf(target)).accepts());
            }
            if (!level.isClientSide) {
                PlugItem.addInner(target, PlugItem.takeOne(held, player));
                be.plugsChanged();
            }
        } else {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Empty hand: pull the last plug out of the adapter first, then the plug/adapter itself. Everything else is Power Grid's. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player.getMainHandItem().isEmpty() && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
            int slot = slotAt(state, pos, hit.getLocation());
            ItemStack target = be.plugs().get(slot);
            if (!target.isEmpty()) {
                if (!level.isClientSide) {
                    ItemStack in = PlugItem.popInner(target);
                    if (!in.isEmpty()) {
                        be.plugsChanged();
                        PlugItem.give(player, in);
                    } else {
                        ItemStack out = target.copy();
                        be.setPlug(slot, ItemStack.EMPTY);
                        PlugItem.give(player, out);
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return super.useWithoutItem(state, level, pos, player, hit);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
            for (ItemStack s : be.plugs()) {
                if (!s.isEmpty()) Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), s);
            }
        }
        super.onRemove(state, level, pos, newState, moving);
    }
}
