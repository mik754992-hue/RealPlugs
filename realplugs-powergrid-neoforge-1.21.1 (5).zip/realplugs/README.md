# Real Plugs for Create: Power Grid (NeoForge 1.21.1)

Wall outlets and power strips that are **real Create: Power Grid electrical blocks**, plus plugs,
cables and adapters you plug into them, and plugs you can stick onto CC: Tweaked computers.

Needs: Minecraft 1.21.1, NeoForge 21.1.x, Create 6.0.9+, Create: Power Grid 0.6.x (+ Architectury). CC: Tweaked optional.

## Build on GitHub
1. Push the contents of this folder to the root of a repo (keep `libs/`, it holds the Power Grid jar the build compiles against).
2. `.github/workflows/build.yml` runs on push. Download `realplugs-jar` from the run's Artifacts.
3. Put the jar in `mods/` next to Create, Power Grid and Architectury.

## Outlets, strips and what fits where
Every slot has a **connector standard**. A plug only goes into a slot of the same standard; anything else is refused
with a message on screen ("That doesn't fit - this needs: ...").

| Block | Slots |
|---|---|
| Wall Outlet (US) | 2 x US plug |
| Wall Outlet (EU) | 2 x EU plug |
| Wall Outlet (UK) | 2 x UK plug |
| DC Power Jack Panel | 2 x barrel jack |
| USB Charging Hub | 2 x USB-A, 2 x USB-C |
| Power Strip (US) | 4 x US plug |
| Power Strip (EU) | 4 x EU plug |
| Universal Power Strip | US, EU, UK, USB-A |

**Adapters** take one standard on the front and plug into another with the back. Plugging into an adapter works the same
way: the plug must match what the adapter accepts. Hover over any plug or adapter to see what it plugs into / accepts.

| Adapter | Accepts (front) | Plugs into (back) |
|---|---|---|
| US to EU | US plug | EU socket |
| EU to US | EU plug | US socket |
| US to UK | US plug | UK socket |
| UK to US | UK plug | US socket |
| USB-A Wall Adapter | USB-A | US socket |
| USB-C Wall Adapter | USB-C | US socket |
| HDMI to USB-C | HDMI | USB-C port |
| USB-A to USB-C | USB-A | USB-C port |
| Multi-Tap (US) | 3 x US plug | US socket |
| Multi-Tap (EU) | 3 x EU plug | EU socket |

Plugs: US, EU, UK, USB-A, USB-C, HDMI, Ethernet, DC barrel.

## How the outlets work electrically
Each outlet / power strip has these Power Grid terminals (use Power Grid wires or copper cords on them):
- **Red bar on top = hot bus.** Wire your supply's hot side here.
- **Blue bar at the bottom = neutral bus.** Supply neutral AND every device's return go here.
- **One small copper stud per slot = that slot's hot tap.** Wire the device's hot side here.

A slot's tap is connected to the hot bus **only while a plug (or adapter) is plugged into that slot**.
Unplug it and the tap is cut off.

## How to play
- **Plugging in**: right-click a slot with a plug or adapter. Empty hand removes it (the last plug in an adapter comes out first).
- **Adapters**: put an adapter in a socket, then right-click it with plugs that match its front. Multi-taps hold three.
- **On a computer**: hold a plug/adapter, **sneak + right-click** a CC computer where you want it. Only device-side
  connectors (USB-A, USB-C, HDMI, Ethernet, barrel) fit a computer, mains plugs are refused. These are visual only.
  Use the same right-click with a matching plug on a stuck-on adapter, and an empty hand removes things.
- Everything is in the **Real Plugs** creative tab. Place the outlets against a wall (the back sits on the clicked face).

## Models
Everything is a real 3D cuboid model, not a flat sprite. All colours come from one shared palette,
`assets/realplugs/textures/block/palette.png` (4x4 cells, each element samples one cell), so you can
re-colour every model by editing that one PNG.

Plug and adapter models share one orientation: the **cable / body side faces NORTH (-z, toward the viewer)** and the
**prongs / plug side point SOUTH (+z, into the socket)**. Keep that and your own model will sit correctly in a socket,
on a computer and inside an adapter.

## Add your own plug / cable / adapter / outlet
Plugs, adapters and outlets are all listed in the generator script, so the easiest way to add one is to edit
`PlugTypes.java` / `SocketDefs.java` and add the matching files by hand:
1. **Plug or adapter**: append an entry to `PLUGS` or `ADAPTERS` in `PlugTypes.java` (the array position is its
   custom_model_data number), choose its `Standard`, then add `models/item/plug_<name>.json` (or `adapter_<name>.json`),
   one line in the `overrides` list of `models/item/plug.json` (or `adapter.json`), and the name in `lang/en_us.json`
   (`item.realplugs.plug.<name>` / `item.realplugs.adapter.<name>`). Adapter `sockets` are the front socket centres in model units.
2. **Outlet**: add a `SocketDef` to `SocketDefs.java`, plus `blockstates/<id>.json`, `models/block/<id>.json`,
   `models/item/<id>.json`, a loot table, the pickaxe tag entry and a lang name. Copy an existing outlet's files.
3. **New connector standard**: add a value to the `Standard` enum and a `standard.realplugs.<key>` lang entry.
4. Model orientation: **cable/body faces NORTH (-z), prongs point SOUTH (+z)**. Build in Blockbench and keep the `display` block.

Give one by command: `/give @s realplugs:plug[custom_model_data=3]`

## Known gaps
- Plugs and adapters are visual markers: a plugged item only closes the slot contact, it does not carry its own load.
- Plugs on computers do nothing electrically. No pocket-computer plug yet.
- Untested build: dependency versions in `build.gradle` (Create `6.0.11-319`, Ponder, Flywheel, Registrate) may need adjusting.
