# Real Plugs for Create: Power Grid (NeoForge 1.21.1)

Wall outlets and power strips that are **real Create: Power Grid electrical blocks**, plus plugs,
cables and adapters you plug into them, and plugs you can stick onto CC: Tweaked computers.

Needs: Minecraft 1.21.1, NeoForge 21.1.x, Create 6.0.9+, Create: Power Grid 0.6.x (+ Architectury). CC: Tweaked optional.

## Requirements
| | Version |
|---|---|
| Minecraft | 1.21.1 |
| NeoForge | 21.1.x |
| Create | 6.0.9 and up (6.0.x) |
| Create: Power Grid | 0.6.x |
| Architectury | 13.0.8 or newer (needed by Power Grid) |
| CC: Tweaked | optional |

## Install
Drop the jar into `mods/` next to Create, Power Grid and Architectury.

## Build on GitHub
1. Push the **contents** of this folder to the root of a repo. Keep the hidden `.github/` folder and `libs/`
   (the Power Grid jar the build compiles against).
2. The `build` workflow runs on every push. Download `realplugs-jar` from the run's Artifacts.
3. To publish a release, push a tag such as `v1.0.0`: the `release` workflow attaches the jar to a GitHub release.

## Build locally
Needs JDK 21 and Gradle 8.10+.
```
gradle build        # jar ends up in build/libs/
gradle runClient    # test in a dev client
python3 scripts/validate_assets.py   # check models, lang, loot tables and recipes agree
```
Version numbers and dependency ranges live in `gradle.properties`; `neoforge.mods.toml` is filled from them.

## Outlets, strips and what fits where
Every slot has a **connector standard**. A plug only goes into a slot of the same standard; anything else is refused
with a message on screen ("That doesn't fit - this needs: ...").

| Block | Slots |
|---|---|
| Wall Outlet (US) | 2 x US plug |
| Wall Outlet (EU) | 2 x EU plug |
| Wall Outlet (UK) | 2 x UK plug |
| DC Power Jack Panel | 2 x barrel jack |
| USB Charging Hub | 2 x USB-A, 2 x USB-C |
| Power Strip (US) | 4 x US plug |
| Power Strip (EU) | 4 x EU plug |
| Universal Power Strip | US, EU, UK, USB-A |
| Wall Outlet (AU) | 2 x AU plug |
| Power Strip (UK) | 4 x UK plug |
| Power Strip (AU) | 4 x AU plug |
| Network & AV Wall Plate | 2 x Ethernet, 2 x HDMI |

**Adapters** take one standard on the front and plug into another with the back. Plugging into an adapter works the same
way: the plug must match what the adapter accepts. Hover over any plug or adapter to see what it plugs into / accepts.

| Adapter | Accepts (front) | Plugs into (back) |
|---|---|---|
| US to EU | US plug | EU socket |
| EU to US | EU plug | US socket |
| US to UK | US plug | UK socket |
| UK to US | UK plug | US socket |
| USB-A Wall Adapter | USB-A | US socket |
| USB-C Wall Adapter | USB-C | US socket |
| HDMI to USB-C | HDMI | USB-C port |
| USB-A to USB-C | USB-A | USB-C port |
| Multi-Tap (US) | 3 x US plug | US socket |
| Multi-Tap (EU) | 3 x EU plug | EU socket |
| US to AU | US plug | AU socket |
| AU to US | AU plug | US socket |
| EU to UK | EU plug | UK socket |
| UK to EU | UK plug | EU socket |
| Micro-USB Wall Adapter | Micro-USB | US socket |
| DisplayPort to HDMI | DisplayPort | HDMI port |

Plugs: US, EU, UK, AU, USB-A, USB-C, Micro-USB, HDMI, DisplayPort, Ethernet, DC barrel.

## Crafting
All recipes are shapeless.

**Blocks**
| Result | Ingredients |
|---|---|
| Wall Outlet (US) | iron ingot, copper ingot, redstone |
| Wall Outlet (EU) | US outlet + green dye |
| Wall Outlet (UK) | US outlet + blue dye |
| DC Power Jack Panel | US outlet + black dye |
| USB Charging Hub | US outlet + quartz + lapis lazuli |
| Power Strip (US) | 2 US outlets + iron ingot |
| Power Strip (EU) | 2 EU outlets + iron ingot |
| Universal Power Strip | US outlet + EU outlet + UK outlet + USB hub |
| Wall Outlet (AU) | US outlet + yellow dye |
| Power Strip (UK) | 2 UK outlets + iron ingot |
| Power Strip (AU) | 2 AU outlets + iron ingot |
| Network & AV Wall Plate | US outlet + glass pane + string |

**Plugs** (copper ingot + iron nugget + one extra, gives 2)
| Plug | Extra ingredient |
|---|---|
| US | redstone |
| EU | lapis lazuli |
| UK | gold nugget |
| USB-A | quartz |
| USB-C | amethyst shard |
| HDMI | glass pane |
| Ethernet | string |
| DC barrel | coal |
| AU | flint |
| Micro-USB | prismarine shard |
| DisplayPort | glowstone dust |

**Adapters** (all also need an iron ingot)
| Adapter | Ingredients |
|---|---|
| US to EU | US outlet + EU plug |
| EU to US | EU outlet + US plug |
| US to UK | US outlet + UK plug |
| UK to US | UK outlet + US plug |
| Multi-Tap (US) | US outlet + US plug |
| Multi-Tap (EU) | EU outlet + EU plug |
| USB-A Wall Adapter | USB-A plug + US plug |
| USB-C Wall Adapter | USB-C plug + US plug |
| HDMI to USB-C | HDMI plug + USB-C plug |
| USB-A to USB-C | USB-A plug + USB-C plug |
| US to AU | US outlet + AU plug |
| AU to US | AU outlet + US plug |
| EU to UK | EU outlet + UK plug |
| UK to EU | UK outlet + EU plug |
| Micro-USB Wall Adapter | Micro-USB plug + US plug |
| DisplayPort to HDMI | DisplayPort plug + HDMI plug |

## CC: Tweaked peripheral
Every outlet, strip and panel is a read-only peripheral (type `realplugs_socket`) when CC: Tweaked is installed.
Attach a computer directly or through a wired modem. Slots are numbered from 1, counting from the viewer's left.

| Method | Returns |
|---|---|
| `getSocketId()` | block id, e.g. `"power_strip"` |
| `getSlotCount()` | number of slots |
| `getSlotStandard(slot)` | connector standard of the slot, e.g. `"us_power"` (nil if no such slot) |
| `isPlugged(slot)` | true if something sits in the slot |
| `getPluggedCount()` | how many slots are in use |
| `getPlug(slot)` | `{name, standard, adapter, accepts?, inner?}` or nil if empty |
| `getSlots()` | one table per slot: `{slot, standard, plugged, plug?}` |

```lua
local strip = peripheral.find("realplugs_socket")
for _, s in ipairs(strip.getSlots()) do
  print(s.slot, s.standard, s.plugged and s.plug.name or "empty")
end
```

## How the outlets work electrically
Each outlet / power strip has these Power Grid terminals (use Power Grid wires or copper cords on them):
- **Red bar on top = hot bus.** Wire your supply's hot side here.
- **Blue bar at the bottom = neutral bus.** Supply neutral AND every device's return go here.
- **One small copper stud per slot = that slot's hot tap.** Wire the device's hot side here.

A slot's tap is connected to the hot bus **only while a plug (or adapter) is plugged into that slot**.
Unplug it and the tap is cut off.

## How to play
- **Plugging in**: right-click a slot with a plug or adapter. Empty hand removes it (the last plug in an adapter comes out first).
- **Adapters**: put an adapter in a socket, then right-click it with plugs that match its front. Multi-taps hold three.
- **On a computer**: hold a plug/adapter, **sneak + right-click** a CC computer where you want it. Only device-side
  connectors (USB-A, USB-C, HDMI, Ethernet, barrel) fit a computer, mains plugs are refused. These are visual only.
  Use the same right-click with a matching plug on a stuck-on adapter, and an empty hand removes things.
- Everything is in the **Real Plugs** creative tab. Place the outlets against a wall (the back sits on the clicked face).

## Models
Everything is a real 3D cuboid model, not a flat sprite. All colours come from one shared palette,
`assets/realplugs/textures/block/palette.png` (4x4 cells, each element samples one cell), so you can
re-colour every model by editing that one PNG.

Plug and adapter models share one orientation: the **cable / body side faces NORTH (-z, toward the viewer)** and the
**prongs / plug side point SOUTH (+z, into the socket)**. Keep that and your own model will sit correctly in a socket,
on a computer and inside an adapter.

## Add your own plug / cable / adapter / outlet
Plugs, adapters and outlets are all listed in `PlugTypes.java` / `SocketDefs.java`. To add one, edit those and add the matching files by hand:
1. **Plug or adapter**: append an entry to `PLUGS` or `ADAPTERS` in `PlugTypes.java` (the array position is its
   custom_model_data number), choose its `Standard`, then add `models/item/plug_<name>.json` (or `adapter_<name>.json`),
   one line in the `overrides` list of `models/item/plug.json` (or `adapter.json`), the name in `lang/en_us.json`
   (`item.realplugs.plug.<name>` / `item.realplugs.adapter.<name>`) and a recipe `data/realplugs/recipe/plug_<name>.json`. Adapter `sockets` are the front socket centres in model units.
2. **Outlet**: add a `SocketDef` to `SocketDefs.java`, plus `blockstates/<id>.json`, `models/block/<id>.json`,
   `models/item/<id>.json`, a loot table, a recipe, the pickaxe tag entry and a lang name. Copy an existing outlet's files, then run `python3 scripts/validate_assets.py` to catch anything you forgot.
3. **New connector standard**: add a value to the `Standard` enum and a `standard.realplugs.<key>` lang entry.
4. Model orientation: **cable/body faces NORTH (-z), prongs point SOUTH (+z)**. Build in Blockbench and keep the `display` block.

Give one by command: `/give @s realplugs:plug[custom_model_data=3]`

## Known gaps
- Plugs and adapters are visual markers: a plugged item only closes the slot contact, it does not carry its own load.
- Plugs on computers do nothing electrically. No pocket-computer plug yet.
- No extension-cord item yet. For a long run, wire an outlet's terminals to the load with Power Grid's own wires or copper cords.
- The CC peripheral is read-only and the stubs it compiles against (`src/main/java/dan200`) are not packaged into the jar. If you add CC: Tweaked itself to the dev runtime, delete those stubs first.
- Recipes and the build setup have not been run in-game or on CI yet: if a dependency version in `gradle.properties` (Create, Flywheel, Registrate) or `build.gradle` (Ponder) doesn't resolve, adjust it there.

## License
Real Plugs is MIT licensed (see `LICENSE`). `libs/powergrid-*.jar` is Create: Power Grid (Apache-2.0), see `libs/README.md`.
