package net.minecraft.core;
public class BlockPos { final int x,y,z; public BlockPos(int x,int y,int z){this.x=x;this.y=y;this.z=z;}
 public int getX(){return x;} public int getY(){return y;} public int getZ(){return z;}
 public long asLong(){return ((long)x&0x3FFFFFF)<<38|((long)z&0x3FFFFFF)<<12|((long)y&0xFFF);}
 public double distSqr(BlockPos o){double dx=x-o.x,dy=y-o.y,dz=z-o.z;return dx*dx+dy*dy+dz*dz;}
 @Override public boolean equals(Object o){return o instanceof BlockPos p&&p.x==x&&p.y==y&&p.z==z;} @Override public int hashCode(){return java.util.Objects.hash(x,y,z);} }
