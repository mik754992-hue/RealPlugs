# Changelog

## Unreleased
- New connector standards: AU (Type I), Micro-USB, DisplayPort.
- New blocks: Wall Outlet (AU), Power Strip (UK), Power Strip (AU), Network & AV Wall Plate (2 Ethernet + 2 HDMI).
- New plugs: AU, Micro-USB, DisplayPort. New adapters: US to AU, AU to US, EU to UK, UK to EU, Micro-USB Wall, DisplayPort to HDMI.
- CC: Tweaked peripheral `realplugs_socket` on every outlet (read slot standards and what is plugged in).
- Plug Cord item (one per connector standard): a real Power Grid cord with a plug on each end. Each end is slot-specific: it fits a matching, free slot, closes that slot's contact and blocks the slot from taking a plug.
- 15 multi-standard plug cords with a different connector on each end (US to USB-A, HDMI to DisplayPort, and so on). The second end has to be the cord's other connector.
- Cords use one box per slot instead of one big box over the plate, and every cord end (including Power Grid's copper cord) is slot-specific.
- Power Grid copper cords also plug into every outlet, strip and panel.
- Ports: socket items (one per connector standard) you place at an exact spot on any CC: Tweaked block; a matching plug can be plugged in.
- Lightning connector: plug, port, Lightning cord, and US/USB-A/USB-C to Lightning cords.
- Ports are now chunky colour-coded boxes (they were thin grey plates that all looked the same).
- Cord ends in outlets, strips and panels are drawn with Real Plugs plug models, at the exact slot position.
- Pocket computer ports: every port is a CC: Tweaked pocket upgrade (craft it on or `pocket.equipBack()`), a matching plug can be plugged in, readable from Lua as `realplugs_port`.
- Fixed plugs and ports stuck on computers being impossible to click: their hitbox sat above the spot instead of centred on it, and is slightly larger.
- Ports are now just the port (a colour-coded bezel with the connector opening), not a box with a port on it, and an outline shows where one will be placed while you hold it.
- Fixed plugged ports always showing the Lightning model (the model overrides were in the wrong order).
- Outlet, strip and panel hot/neutral inputs are now small connectors on the sides of the plate instead of big bars across the front.
- Fixed the hitbox of blocks placed on the floor or ceiling being the wrong way round.
- Ponder scenes for outlets, strips, hubs, panels, plugs, adapters and cords, using the airport and house showcase schematics.
- Crafting recipes for all of the above.

## 1.0.0
- Wall outlets (US, EU, UK), DC jack panel, USB charging hub and three power strips, all real Power Grid electrical blocks.
- Plugs (US, EU, UK, USB-A, USB-C, HDMI, Ethernet, DC barrel) and ten adapters, with connector-standard checks.
- Plugs and adapters can be stuck onto CC: Tweaked computers (visual only).
- Crafting recipes for every block, plug and adapter.
- Metadata (version, dependency ranges) now comes from `gradle.properties`; Architectury is declared as a dependency.
- Build configuration no longer needs the network just to configure the project.
- CI validates models, blockstates, loot tables, recipes and lang entries; tagged releases publish the jar automatically.
- The unfinished placeholder plug/adapter no longer shows in the creative tab.
