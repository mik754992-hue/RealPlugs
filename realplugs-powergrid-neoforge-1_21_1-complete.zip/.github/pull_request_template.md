## What does this change?

## Checklist
- [ ] `python3 scripts/validate_assets.py` passes
- [ ] `gradle build` passes
- [ ] README / CHANGELOG updated if behaviour changed
