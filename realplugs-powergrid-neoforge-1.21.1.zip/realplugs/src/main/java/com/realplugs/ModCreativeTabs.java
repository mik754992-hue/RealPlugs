package com.realplugs;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RealPlugsMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.realplugs"))
                    .icon(() -> new ItemStack(ModItems.PLUG.get()))
                    .displayItems((params, out) -> {
                        out.accept(ModItems.OUTLET.get());
                        out.accept(ModItems.POWER_STRIP.get());
                        for (int i = 0; i < PlugTypes.PLUGS.length; i++) out.accept(variant(ModItems.PLUG.get(), i));
                        for (int i = 0; i < PlugTypes.ADAPTERS.length; i++) out.accept(variant(ModItems.ADAPTER.get(), i));
                    })
                    .build());

    private static ItemStack variant(Item item, int type) {
        ItemStack s = new ItemStack(item);
        if (type > 0) s.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(type));
        return s;
    }
}
