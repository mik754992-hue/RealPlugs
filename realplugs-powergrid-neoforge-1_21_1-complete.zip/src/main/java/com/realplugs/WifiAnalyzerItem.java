package com.realplugs;

import com.realplugs.net.NetworkManager;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;

/** Right-click: lists the Wi-Fi networks you can hear where you stand, with their signal strength. */
public class WifiAnalyzerItem extends Item {
    public WifiAnalyzerItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (level instanceof ServerLevel sl) {
            player.getCooldowns().addCooldown(this, 10);
            List<NetworkManager.WifiNet> nets = NetworkManager.wifiScanAt(sl, player.blockPosition());
            if (nets.isEmpty()) {
                player.displayClientMessage(Component.literal("Wi-Fi analyzer: no networks in range.").withStyle(ChatFormatting.GRAY), false);
            } else {
                player.displayClientMessage(Component.literal("Wi-Fi analyzer: " + nets.size() + (nets.size() == 1 ? " network" : " networks")
                        + " in range").withStyle(ChatFormatting.AQUA), false);
                for (NetworkManager.WifiNet n : nets) {
                    int bars = Math.max(1, Math.min(10, (n.signal() + 5) / 10));
                    ChatFormatting color = n.signal() > 66 ? ChatFormatting.GREEN : n.signal() > 33 ? ChatFormatting.YELLOW : ChatFormatting.RED;
                    String meter = "#".repeat(bars) + "-".repeat(10 - bars);
                    player.displayClientMessage(Component.literal("  [" + meter + "] " + n.signal() + "%  " + n.ssid()
                            + (n.secured() ? "  (password)" : "  (open)") + "  " + n.distance() + " blocks").withStyle(color), false);
                }
            }
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }
}
