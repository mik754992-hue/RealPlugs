package com.realplugs;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

import java.util.List;

/**
 * A real Power Grid cord with a plug of one connector standard on each end.
 * The variant (custom_model_data) uses the same numbering as the plug item, so index 3 is the US plug cord.
 *
 * Power Grid does the cord itself (the hanging cord entity, length limit, item cost, electrical connection) because
 * this extends its CordItem and has a wire_types entry; PlugCordHandler decides where an end may be plugged.
 */
public class PlugCordItem extends CordItem {
    public PlugCordItem(Properties props) {
        super(props);
    }

    public static PlugTypes.Standard standardOf(ItemStack stack) {
        return PlugTypes.plug(PlugItem.typeOf(stack)).plugs();
    }

    @Override
    public String getDescriptionId(ItemStack stack) {
        int i = PlugItem.typeOf(stack);
        String base = getDescriptionId();
        return i > 0 && i < PlugTypes.PLUGS.length ? base + "." + PlugTypes.PLUGS[i].name() : base;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("tooltip.realplugs.cord_ends", Component.translatable(standardOf(stack).langKey()))
                .withStyle(ChatFormatting.GRAY));
    }
}
