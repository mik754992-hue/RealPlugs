package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import org.patryk3211.powergrid.electricity.base.DirectionalElectricBlock;

public class PlugSocketRenderer implements BlockEntityRenderer<PlugSocketBlockEntity> {
    private final ItemRenderer items;

    public PlugSocketRenderer(BlockEntityRendererProvider.Context ctx) {
        this.items = ctx.getItemRenderer();
    }

    @Override
    public void render(PlugSocketBlockEntity be, float partial, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        if (be.getLevel() == null || !(be.getBlockState().getBlock() instanceof PlugSocketBlock block)) return;
        Direction f = be.getBlockState().getValue(DirectionalElectricBlock.FACING);
        var plugs = be.plugs();
        float scale = block.plugScale();

        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        // same rotation the blockstate applies, so we can work in the north-facing frame
        if (f.getAxis().isHorizontal()) {
            ps.mulPose(Axis.YP.rotationDegrees(-(f.toYRot() + 180f)));
        } else {
            ps.mulPose(Axis.XP.rotationDegrees(f == Direction.UP ? 90f : -90f));
        }

        for (int i = 0; i < plugs.size(); i++) {
            ItemStack s = plugs.get(i);
            if (s.isEmpty()) continue;

            ps.pushPose();
            ps.translate(block.slotCenterX(i), block.plugCenterY(), block.frontLocalZ() - 0.02);
            ps.mulPose(Axis.YP.rotationDegrees(180f));
            ps.scale(scale, scale, scale);
            items.renderStatic(s, ItemDisplayContext.FIXED, light, overlay, ps, buf, be.getLevel(), i);

            ItemStack inner = PlugItem.inner(s);   // adapter: show what is plugged into it, in front
            if (!inner.isEmpty()) {
                ps.translate(0, 0, 0.45);
                ps.scale(0.9f, 0.9f, 0.9f);
                items.renderStatic(inner, ItemDisplayContext.FIXED, light, overlay, ps, buf, be.getLevel(), i + 100);
            }
            ps.popPose();
        }
        ps.popPose();
    }
}
