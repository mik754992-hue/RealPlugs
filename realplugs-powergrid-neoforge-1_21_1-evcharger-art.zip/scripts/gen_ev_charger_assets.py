#!/usr/bin/env python3
"""Generates the EV charger textures and block models.

Run from the repo root:  python3 scripts/gen_ev_charger_assets.py   (needs Pillow)

Textures (64x64, so 4 texels per 1/16 block, i.e. four times the vanilla density):
  ev_charger_<id>.png   front art of the enclosure (u 3..13) + a swatch strip (u 0..3) used by every small part
  ev_charger_body.png   sides, top and back, shared by all five chargers
Geometry stays inside the same footprint as before (3..13 wide, 8..16 deep, front plate at z = 8), so the hitboxes,
the coin panel / screen click zones, the plug position and the screen text in PlugSocketRenderer all still line up.
"""
import json
import random
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
TEX = ROOT / "src/main/resources/assets/realplugs/textures/block"
MODELS = ROOT / "src/main/resources/assets/realplugs/models/block"

CHARGERS = {
    #              accent colour          fast charger?
    "type1":   ((47, 111, 214), False),
    "type2":   ((47, 174, 90), False),
    "ccs":     ((240, 140, 42), True),
    "chademo": ((216, 69, 58), True),
    "nacs":    ((43, 183, 196), True),
}

GRAPHITE = (35, 38, 43)
STEEL = (170, 176, 184)
GOLD = (217, 176, 74)
BLACK = (11, 12, 14)
WHITE = (236, 239, 242)
LED_GREEN = (56, 214, 100)
RED = (200, 50, 45)
BLUE = (50, 100, 200)
RUBBER = (23, 24, 27)
DSTEEL = (91, 96, 104)

ENCL = (223, 226, 230)      # enclosure
ENCL_HI = (244, 246, 248)
ENCL_LO = (176, 181, 188)
ENCL_DK = (146, 151, 158)


def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


def px(d, x, y, c):
    d.point((x, y), fill=c)


def rect(d, x0, y0, x1, y1, c):
    d.rectangle((x0, y0, x1, y1), fill=c)


def noise(im, box, amount, seed):
    rnd = random.Random(seed)
    x0, y0, x1, y1 = box
    p = im.load()
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            r, g, b, a = p[x, y]
            if a == 0:
                continue
            k = rnd.randint(-amount, amount)
            p[x, y] = (max(0, min(255, r + k)), max(0, min(255, g + k)), max(0, min(255, b + k)), a)


# swatch cells: (column, row) -> colour, each cell is 4x4 texels = 1x1 uv units, in u 0..3
def swatches(accent):
    return {
        "graphite": (0, 0, GRAPHITE), "steel": (1, 0, STEEL), "accent": (2, 0, accent),
        "gold": (0, 1, GOLD), "black": (1, 1, BLACK), "white": (2, 1, WHITE),
        "green": (0, 2, LED_GREEN), "red": (1, 2, RED), "blue": (2, 2, BLUE),
        "rubber": (0, 3, RUBBER), "dsteel": (1, 3, DSTEEL), "accent_dk": (2, 3, shade(accent, 0.6)),
    }


def pins(d, std, ox, oy):
    """Connector face, 16x16 texels at (ox, oy)."""
    ring = (62, 67, 75)
    inner = (24, 27, 32)
    pin = (200, 205, 212)
    big = (218, 178, 80)

    def disc(cx, cy, r, c):
        d.ellipse((ox + cx - r, oy + cy - r, ox + cx + r, oy + cy + r), fill=c)

    if std == "type1":
        disc(8, 8, 7, ring); disc(8, 8, 6, inner)
        for cx, cy, r in ((5, 5, 1), (11, 5, 1), (8, 4, 1), (5, 10, 2), (11, 10, 2)):
            disc(cx, cy, r, pin if r == 1 else big)
    elif std == "type2":
        disc(8, 8, 7, ring); disc(8, 8, 6, inner)
        for cx, cy in ((4, 8), (6, 5), (10, 5), (12, 8), (8, 11)):
            disc(cx, cy, 1, pin)
        disc(8, 8, 1, big)
    elif std == "ccs":
        disc(8, 5, 5, ring); disc(8, 5, 4, inner)
        rect(d, ox + 2, oy + 9, ox + 13, oy + 14, ring); rect(d, ox + 3, oy + 10, ox + 12, oy + 13, inner)
        for cx, cy in ((5, 4), (11, 4), (8, 3), (6, 6), (10, 6)):
            px(d, ox + cx, oy + cy, pin)
        disc(5, 11, 2, big); disc(11, 11, 2, big)
    elif std == "chademo":
        disc(8, 8, 7, ring); disc(8, 8, 6, inner)
        disc(5, 8, 2, big); disc(11, 8, 2, big)
        for cx, cy in ((4, 4), (8, 3), (12, 4), (6, 12), (10, 12)):
            px(d, ox + cx, oy + cy, pin)
    else:  # nacs: slim pill
        d.rounded_rectangle((ox + 1, oy + 4, ox + 14, oy + 11), radius=3, fill=ring)
        d.rounded_rectangle((ox + 2, oy + 5, ox + 13, oy + 10), radius=2, fill=inner)
        disc(5, 8, 2, big); disc(11, 8, 2, big); px(d, ox + 8, oy + 6, pin); px(d, ox + 8, oy + 9, pin)


def bolt(d, ox, oy, c):
    pts = [(3, 0), (0, 4), (2, 4), (1, 8), (5, 3), (3, 3), (4, 0)]
    d.polygon([(ox + x, oy + y) for x, y in pts], fill=c)


def front_texture(name, accent, fast):
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    for cname, (c, r, col) in swatches(accent).items():
        rect(d, c * 4, r * 4, c * 4 + 3, r * 4 + 3, col)

    # enclosure: model x 3..13 -> texel 12..52, y 15.6..1.6 -> texel 1.6..57.6
    rect(d, 12, 0, 51, 63, ENCL)
    rect(d, 12, 0, 12, 63, ENCL_LO); rect(d, 51, 0, 51, 63, ENCL_LO)
    rect(d, 13, 0, 13, 63, ENCL_HI); rect(d, 50, 0, 50, 63, shade(ENCL, 0.93))
    noise(im, (12, 0, 51, 63), 3, hash(name) & 0xFFFF)

    # header band
    rect(d, 12, 0, 51, 1, accent)
    # screen bezel (model x 4..12, y 12..15.5 -> texels 16..48, 2..16)
    rect(d, 16, 2, 47, 15, (20, 23, 27))
    rect(d, 16, 2, 47, 2, (52, 57, 64)); rect(d, 16, 2, 16, 15, (52, 57, 64))
    rect(d, 18, 4, 45, 13, (8, 28, 18))
    rect(d, 18, 4, 45, 5, (12, 40, 26))
    rect(d, 18, 13, 45, 13, (6, 20, 13))
    # stripe under the screen (the socket bezel is drawn over its middle)
    rect(d, 12, 17, 51, 18, accent)
    if fast:
        rect(d, 12, 20, 51, 20, shade(accent, 0.75))
    # socket bezel: x 5..11 -> texels 20..44, y 12..6 -> v 16..40 (covers the stripe, so the stripe stops at its edges)
    rect(d, 20, 16, 43, 39, (33, 37, 43))
    rect(d, 20, 16, 43, 16, (60, 66, 74)); rect(d, 20, 16, 20, 39, (60, 66, 74))
    rect(d, 43, 16, 43, 39, (18, 20, 24)); rect(d, 20, 39, 43, 39, (18, 20, 24))
    rect(d, 21, 17, 42, 38, (28, 31, 36))
    # connector face: x 6..10 -> 24..40, y 11..7 -> v 20..36
    rect(d, 24, 20, 39, 35, BLACK)
    pins(d, name, 24, 20)
    # coin plate: x 5..11 -> 20..44, y 5.5..2.5 -> v 42..54
    rect(d, 20, 42, 43, 53, GOLD)
    rect(d, 20, 42, 43, 42, (244, 214, 120)); rect(d, 20, 42, 20, 53, (244, 214, 120))
    rect(d, 43, 42, 43, 53, (140, 104, 36)); rect(d, 20, 53, 43, 53, (140, 104, 36))
    rect(d, 22, 44, 41, 51, (196, 154, 58))
    rect(d, 26, 46, 37, 49, BLACK)          # coin slot (x 6.5..9.5, y 4.3..3.7)
    d.ellipse((22, 45, 25, 48), fill=(244, 214, 120)); d.ellipse((38, 45, 41, 48), fill=(244, 214, 120))
    # plinth (y 1.6..0 -> v 57.6..64), full width so the wider plinth element can use it
    rect(d, 8, 58, 55, 63, GRAPHITE)
    rect(d, 8, 58, 55, 58, (70, 75, 83))
    # emblem under the coin plate area is too small; fast chargers get a bolt next to the screen stripe
    if fast:
        bolt(d, 14, 22, accent)
    return im


def body_texture():
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # side (u 0..8 -> texels 0..32, full height)
    rect(d, 0, 0, 31, 63, ENCL)
    rect(d, 0, 0, 0, 63, ENCL_LO); rect(d, 31, 0, 31, 63, ENCL_LO)
    rect(d, 1, 0, 1, 63, ENCL_HI)
    rect(d, 0, 6, 31, 6, ENCL_LO)                 # seam under the hood
    rect(d, 0, 58, 31, 58, ENCL_LO)               # seam above the plinth
    for i in range(6):                           # vents
        y = 44 + i * 2
        rect(d, 8, y, 23, y, ENCL_DK)
    noise(im, (0, 0, 31, 63), 3, 11)
    # top (u 8..16, v 0..8 -> texels 32..63, 0..31)
    rect(d, 32, 0, 63, 31, ENCL_HI)
    rect(d, 32, 0, 63, 0, ENCL_LO); rect(d, 32, 31, 63, 31, ENCL_LO)
    rect(d, 32, 0, 32, 31, ENCL_LO); rect(d, 63, 0, 63, 31, ENCL_LO)
    noise(im, (32, 0, 63, 31), 3, 12)
    # back (u 8..16, v 8..16 -> texels 32..63, 32..63): a mounting plate
    rect(d, 32, 32, 63, 63, ENCL_LO)
    rect(d, 34, 34, 61, 61, ENCL_DK)
    rect(d, 36, 36, 59, 59, ENCL_LO)
    for x, y in ((38, 38), (57, 38), (38, 57), (57, 57)):
        d.ellipse((x - 1, y - 1, x + 1, y + 1), fill=DSTEEL)
    noise(im, (32, 32, 63, 63), 3, 13)
    return im


def sw(cell):
    c, r = {"graphite": (0, 0), "steel": (1, 0), "accent": (2, 0), "gold": (0, 1), "black": (1, 1), "white": (2, 1),
            "green": (0, 2), "red": (1, 2), "blue": (2, 2), "rubber": (0, 3), "dsteel": (1, 3), "accent_dk": (2, 3)}[cell]
    return [c + 0.25, r + 0.25, c + 0.75, r + 0.75]


def face(uv, tex="#front"):
    return {"uv": uv, "texture": tex}


def solid(cell):
    return {f: face(sw(cell)) for f in ("north", "east", "south", "west", "up", "down")}


def box(a, b, faces):
    return {"from": a, "to": b, "faces": faces}


def north_uv(x0, y0, x1, y1):
    """UV (0..16 space) of a front-facing box so the texture lines up with its position."""
    return [x0, 16 - y1, x1, 16 - y0]


def elements(fast):
    body_side = face([0, 0, 8, 16], "#body")
    els = []
    # enclosure
    els.append(box([3, 1.6, 8], [13, 15.6, 16], {
        "north": face(north_uv(3, 1.6, 13, 15.6)),
        "south": face([8, 8, 16, 16], "#body"),
        "east": face([0, 1.6, 8, 15.6], "#body"), "west": face([0, 1.6, 8, 15.6], "#body"),
        "up": face([8, 0, 16, 8], "#body"), "down": face(sw("steel"))}))
    # plinth and hood
    els.append(box([2.6, 0, 7.4], [13.4, 1.6, 16], {
        "north": face(north_uv(2.6, 0, 13.4, 1.6)), "south": face(sw("graphite")), "east": face(sw("graphite")),
        "west": face(sw("graphite")), "up": face(sw("dsteel")), "down": face(sw("graphite"))}))
    hood_front = 7.2 if fast else 7.4
    els.append(box([2.6, 15.6, hood_front], [13.4, 16, 16], solid("accent")))
    # screen (bezel + glass are painted on the texture; the text is drawn by the renderer)
    els.append(box([4, 12, 7.7], [12, 15.5, 8], {
        "north": face(north_uv(4, 12, 12, 15.5)), "south": face(sw("black")), "east": face(sw("black")),
        "west": face(sw("black")), "up": face(sw("graphite")), "down": face(sw("graphite"))}))
    # connector socket: bezel and face
    els.append(box([5, 6, 7.6], [11, 12, 8], {
        "north": face(north_uv(5, 6, 11, 12)), "south": face(sw("graphite")), "east": face(sw("graphite")),
        "west": face(sw("graphite")), "up": face(sw("dsteel")), "down": face(sw("graphite"))}))
    els.append(box([6, 7, 7.5], [10, 11, 7.6], {
        "north": face(north_uv(6, 7, 10, 11)), "south": face(sw("black")), "east": face(sw("black")),
        "west": face(sw("black")), "up": face(sw("black")), "down": face(sw("black"))}))
    # coin plate and slot
    els.append(box([5, 2.5, 7.7], [11, 5.5, 8], {
        "north": face(north_uv(5, 2.5, 11, 5.5)), "south": face(sw("gold")), "east": face(sw("gold")),
        "west": face(sw("gold")), "up": face(sw("gold")), "down": face(sw("gold"))}))
    els.append(box([6.5, 3.7, 7.6], [9.5, 4.3, 7.7], solid("black")))
    # status LED
    els.append(box([11, 6, 7.6], [12, 7, 7.7], solid("green")))
    # cable gland: where the built-in cord leaves the charger (PlugSocketRenderer draws the cable from here)
    els.append(box([11.2, 1.6, 7.2], [12.8, 3.2, 8], solid("rubber")))
    els.append(box([11, 1.6, 7.6], [13, 2.0, 8], solid("dsteel")))
    # side bus connectors: red hot on +x, blue neutral on -x (these are Power Grid terminals)
    els.append(box([12.0, 6.75, 8.4], [14.5, 9.25, 15.6], solid("red")))
    els.append(box([1.5, 6.75, 8.4], [4.0, 9.25, 15.6], solid("blue")))
    return els


def build():
    TEX.mkdir(parents=True, exist_ok=True)
    body_texture().save(TEX / "ev_charger_body.png")
    for name, (accent, fast) in CHARGERS.items():
        front_texture(name, accent, fast).save(TEX / f"ev_charger_{name}.png")
        path = MODELS / f"ev_charger_{name}.json"
        old = json.loads(path.read_text()) if path.exists() else {}
        model = {
            "parent": "minecraft:block/block",
            "textures": {"front": f"realplugs:block/ev_charger_{name}", "body": "realplugs:block/ev_charger_body",
                         "particle": "realplugs:block/ev_charger_body"},
            "display": old.get("display", {}),
            "elements": elements(fast),
        }
        path.write_text(json.dumps(model, indent=1) + "\n")
        print("wrote", name)


if __name__ == "__main__":
    build()
