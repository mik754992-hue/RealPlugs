package com.realplugs;

import net.minecraft.network.chat.Component;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.patryk3211.powergrid.electricity.base.ITerminalPlacement;
import org.patryk3211.powergrid.electricity.wire.BlockWireEndpoint;
import org.patryk3211.powergrid.electricity.wire.IWireEndpoint;
import org.patryk3211.powergrid.electricity.wire.WireConnection;
import org.patryk3211.powergrid.electricity.wire.powercord.AutoCordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.IAcceptCord;
import org.patryk3211.powergrid.electricity.wire.powercord.ICordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.ICordPlacementHandler;

/**
 * Registered in front of Power Grid's own handler. For a plug cord clicked on one of our outlets it picks the slot,
 * checks that the slot's connector standard is one of the cord's two (and, for the second end, the other one) and that the slot is free, then makes a cord end
 * on that slot's tap terminal (2 + slot) and the neutral bus, so only that slot is powered by the cord. Anything else (other blocks, other cords) is passed on untouched.
 */
public class PlugCordHandler implements ICordPlacementHandler {
    private final IAcceptCord.Handler stock = new IAcceptCord.Handler();

    @Override
    public InteractionResultHolder<ICordEndpoint> place(BlockState state, UseOnContext ctx) {
        if (!(ctx.getItemInHand().getItem() instanceof PlugCordItem) || !(state.getBlock() instanceof PlugSocketBlock block)) {
            return InteractionResultHolder.pass(null);
        }
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        BlockPos pos = ctx.getClickedPos();
        CordTypes.CordDef cord = PlugCordItem.defOf(ctx.getItemInHand());

        // a port's hidden anchor stands in for the port; otherwise it is one of our outlet slots
        PortEntity port = block instanceof PortAnchorBlock ? PortEntity.at(level, pos) : null;
        if (block instanceof PortAnchorBlock && port == null) return InteractionResultHolder.fail(null);
        int slot = port != null ? 0 : block.slotAtHit(state, pos, ctx.getClickLocation());
        PlugTypes.Standard here = port != null ? port.standard() : block.def.slots()[slot];

        // If the first end is already plugged in, which connector did it use? (null = not one of our slots)
        boolean hasFirst = false;
        PlugTypes.Standard first = null;
        for (TypedDataComponent<?> c : ctx.getItemInHand().getComponents()) {
            if (c.value() instanceof WireConnection wc && wc.hasHalf()) {
                hasFirst = true;
                first = standardOfEnd(level, wc.half());
            }
        }

        boolean fits;
        if (hasFirst && first != null) {
            // the two ends have to be this cord's two connectors, one each way round
            fits = (first == cord.a() && here == cord.b()) || (first == cord.b() && here == cord.a());
        } else {
            fits = here == cord.a() || here == cord.b();
        }
        if (!fits) {
            tell(level, player, Component.translatable("message.realplugs.cord_wrong_slot",
                    Component.translatable(cord.a().langKey()), Component.translatable(cord.b().langKey()),
                    Component.translatable(here.langKey())));
            return InteractionResultHolder.fail(null);
        }
        boolean busy = port != null && !port.getPlugged().isEmpty();
        if (busy || (level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be
                && (!be.plugs().get(slot).isEmpty() || be.hasCord(slot)))) {
            tell(level, player, Component.translatable("message.realplugs.cord_slot_taken"));
            return InteractionResultHolder.fail(null);
        }
        return InteractionResultHolder.success(block.getEndpoint(ctx));
    }

    @Override
    public ITerminalPlacement terminal(BlockState state, Level level, BlockHitResult hit) {
        return stock.terminal(state, level, hit);
    }

    /** Connector standard of the slot a cord end sits on, or null when that end is not on one of our slots. */
    private static PlugTypes.Standard standardOfEnd(Level level, IWireEndpoint end) {
        if (!(end instanceof AutoCordEndpoint auto)) return null;
        BlockWireEndpoint e = auto.getEndpoint1();
        if (e.getTerminal() < 2) return null;
        if (level.getBlockState(e.getPos()).getBlock() instanceof PortAnchorBlock) {
            PortEntity p = PortEntity.at(level, e.getPos());
            return p == null ? null : p.standard();
        }
        if (level.getBlockState(e.getPos()).getBlock() instanceof PlugSocketBlock b) {
            int slot = e.getTerminal() - 2;
            return slot < b.def.slots().length ? b.def.slots()[slot] : null;
        }
        return null;
    }

    private static void tell(Level level, Player player, Component msg) {
        if (!level.isClientSide && player != null) player.displayClientMessage(msg, true);
    }
}
