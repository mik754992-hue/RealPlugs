-- rpddns: dynamic DNS. A name that follows a server when its public address changes.
--   rpddns serve [slot]                          the name server (UDP port 5353)
--   rpddns client <server> <name> <key> [min]    keep <name> pointing at this network's public address (default every 5 min)
--   rpddns lookup <server> <name>
-- The first update of a name claims it with its key. Behind a router the address the server sees is the router's public
-- address, so a forwarded port (rpadmin) is all a site needs. rpweb uses it when the file .rpweb_ddns holds the server.
local M = {}
local PORT = 5353
local web = require("rpweb")

function M.validName(n) return type(n) == "string" and #n >= 1 and #n <= 40 and n:match("^[%a%d][%w%-%.]*$") ~= nil end

-- store = { names = { name = { ip =, key = hash } } }; line = one datagram; srcIp = who sent it. Returns the answer.
function M.handle(store, line, srcIp)
  store.names = store.names or {}
  local op, rest = tostring(line):match("^DDNS (%u+) ?(.*)$")
  if op == "LOOKUP" then
    local n = rest:lower()
    local r = store.names[n]
    return r and ("DDNS A " .. n .. " " .. r.ip) or "DDNS NXDOMAIN"
  elseif op == "UPDATE" then
    local name, key, ip = rest:match("^(%S+) (%S+) ?(%S*)$")
    if not name or not M.validName(name) then return "DDNS ERR bad name" end
    name = name:lower()
    if #key < 3 then return "DDNS ERR key too short" end
    ip = (ip ~= "" and ip:match("^%d+%.%d+%.%d+%.%d+$")) or srcIp
    local r = store.names[name]
    if r and r.key ~= web.hash(key) then return "DDNS ERR wrong key" end
    local count = 0
    for _ in pairs(store.names) do count = count + 1 end
    if not r and count >= 200 then return "DDNS ERR the server is full" end
    store.names[name] = { ip = ip, key = web.hash(key) }
    return "DDNS OK " .. name .. " " .. ip, name, ip
  end
  return "DDNS ERR bad request"
end

function M.parseAnswer(s)
  local ip = tostring(s):match("^DDNS A %S+ (%d+%.%d+%.%d+%.%d+)$")
  return ip
end

if RPWEB_TEST then return M end

local function ask(nic, slot, host, payload)
  local side = peripheral.getName(nic)
  local lp = 20000 + math.random(0, 9999)
  nic.listen(slot, lp)
  nic.send(slot, host, lp, PORT, payload)
  local timer = os.startTimer(3)
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then pcall(nic.unlisten, slot, lp); return nil end
    if ev[1] == "realplugs_packet" and ev[2] == side and ev[3] == slot and ev[6] == lp then
      os.cancelTimer(timer); pcall(nic.unlisten, slot, lp); return ev[7]
    end
  end
end

-- used by rpweb: the address of a name, or nil
function M.lookup(nic, slot, server, name)
  return M.parseAnswer(ask(nic, slot, server, "DDNS LOOKUP " .. name))
end

local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpddns" or running == "rpddns.lua") then return M end
local args = { ... }
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)
local cmd = args[1]
if cmd == "serve" then
  local slot = tonumber(args[2]) or 1
  local store = {}
  local f = fs.open("ddns.db", "r")
  if f then store = textutils.unserialise(f.readAll()) or {}; f.close() end
  nic.listen(slot, PORT)
  print("dynamic DNS on port " .. PORT .. "  (Ctrl+T stops)")
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then pcall(nic.unlisten, slot, PORT); return end
    if ev[1] == "realplugs_packet" and ev[2] == side and ev[3] == slot and ev[6] == PORT then
      local answer, name, ip = M.handle(store, ev[7], ev[4])
      nic.send(slot, ev[4], PORT, ev[5], answer)
      if name then
        pcall(nic.addDnsRecord, slot, name, ip)   -- the segment of this server resolves it natively
        local out = fs.open("ddns.db", "w"); out.write(textutils.serialise(store)); out.close()
        print(name .. " -> " .. ip)
      end
    end
  end
elseif cmd == "client" and args[4] then
  local minutes = tonumber(args[5]) or 5
  while true do
    print(tostring(ask(nic, 1, args[2], "DDNS UPDATE " .. args[3] .. " " .. args[4]) or "no answer"))
    sleep(minutes * 60)
  end
elseif cmd == "lookup" and args[3] then
  print(M.lookup(nic, 1, args[2], args[3]) or "not found")
else
  print("rpddns serve [slot] | client <server> <name> <key> [min] | lookup <server> <name>")
end
return M
