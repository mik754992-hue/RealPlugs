-- rpweb: websites on a Real Plugs network, from CC: Tweaked computers.
--
--   rpweb init                      make a starter site in /www
--   rpweb serve [slot] [name]       serve /www as a website (port 80); name = the address people type
--   rpweb browse [address]          text browser (arrow keys / mouse, G = go, B = back, Q = quit)
--
-- Needs a computer next to a Real Plugs socket (wall plate, AV panel, router port ...) that is on a
-- network: a LAN behind a router (name it with `name`), or an uplink to the server-wide "internet".
-- Put it on a computer's disk with:  edit rpweb   (paste this file, Ctrl, Save, Exit)

local M = {}

local CHUNK = 1400          -- the network carries at most 1500 characters per segment
local MAX_PAGE = 60000      -- biggest page the server sends / the browser takes
local ROOT = "www"

-- ------------------------------------------------------------------ addresses

function M.parseUrl(url)
  url = tostring(url or ""):gsub("^%s+", ""):gsub("%s+$", "")
  local scheme = url:match("^(%a+)://")
  if scheme then
    if scheme:lower() ~= "http" then return nil, "only http:// addresses work here" end
    url = url:gsub("^%a+://", "")
  end
  local hostport, path = url:match("^([^/]+)(/.*)$")
  if not hostport then hostport, path = url, "/" end
  local host, port = hostport:match("^(.-):(%d+)$")
  if not host then host, port = hostport, "80" end
  if host == "" then return nil, "no address" end
  return { host = host:lower(), port = tonumber(port), path = path }
end

function M.formatUrl(u)
  return "http://" .. u.host .. (u.port ~= 80 and (":" .. u.port) or "") .. u.path
end

local function normalize(path)
  local out = {}
  for part in path:gmatch("[^/]+") do
    if part == ".." then out[#out] = nil elseif part ~= "." then out[#out + 1] = part end
  end
  local r = "/" .. table.concat(out, "/")
  if path:sub(-1) == "/" and r ~= "/" then r = r .. "/" end
  return r
end

-- a link found on page `base` (a parsed address) -> full address text
function M.resolve(base, href)
  href = href:gsub("^%s+", ""):gsub("%s+$", "")
  if href:match("^%a+://") then return href end
  local hostpart = base.host .. (base.port ~= 80 and (":" .. base.port) or "")
  if href:sub(1, 1) == "/" then return "http://" .. hostpart .. normalize(href) end
  local dir = base.path:match("^(.*/)") or "/"
  return "http://" .. hostpart .. normalize(dir .. href)
end

-- ------------------------------------------------------------------ the protocol (a small HTTP/1.0)

function M.buildRequest(host, path)
  return "GET " .. path .. " HTTP/1.0\r\nHost: " .. host .. "\r\nUser-Agent: rpweb/1\r\n\r\n"
end

function M.parseResponse(raw)
  local s, e = raw:find("\r\n\r\n", 1, true)
  if not s then return nil end
  local head, body = raw:sub(1, s - 1), raw:sub(e + 1)
  local status, reason = head:match("^HTTP/%d%.%d (%d+) ?([^\r\n]*)")
  if not status then return nil end
  local headers = {}
  for k, v in head:gmatch("\r\n([^:\r\n]+):%s*([^\r\n]*)") do headers[k:lower()] = v end
  return { status = tonumber(status), reason = reason, headers = headers, body = body }
end

function M.responseComplete(raw)
  local r = M.parseResponse(raw)
  if not r then return false end
  local len = tonumber(r.headers["content-length"])
  return len ~= nil and #r.body >= len
end

local MIME = { html = "text/html", htm = "text/html", txt = "text/plain", md = "text/plain", lua = "text/plain" }

local function response(code, reason, mime, body)
  return "HTTP/1.0 " .. code .. " " .. reason .. "\r\nContent-Type: " .. mime ..
         "\r\nContent-Length: " .. #body .. "\r\nServer: rpweb/1\r\n\r\n" .. body
end

local function unescape(s)
  return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

-- ctx: read(path) -> text or nil, isDir(path) -> bool, vars = {hits=, time=, host=}
function M.handle(request, ctx)
  local method, target = request:match("^(%u+) (%S+)")
  if not method then return response(400, "Bad Request", "text/plain", "bad request") end
  if method ~= "GET" and method ~= "HEAD" then return response(405, "Method Not Allowed", "text/plain", "GET only") end
  local path = unescape(target:gsub("[?#].*$", ""))
  if path:sub(1, 1) ~= "/" or path:find("..", 1, true) or path:find("%z") or path:find("\\", 1, true) then
    return response(400, "Bad Request", "text/plain", "bad path")
  end
  local file = ROOT .. path
  if path:sub(-1) == "/" then file = file .. "index.html"
  elseif ctx.isDir(file) then return "HTTP/1.0 301 Moved\r\nLocation: " .. path .. "/\r\nContent-Length: 0\r\n\r\n" end
  local text = ctx.read(file)
  if not text then
    local nf = ctx.read(ROOT .. "/404.html")
      or "<h1>404</h1><p>No page called " .. path:gsub("<", "&lt;") .. " here.</p><p><a href=\"/\">Home</a></p>"
    return response(404, "Not Found", "text/html", nf)
  end
  local ext = file:match("%.(%w+)$")
  local mime = MIME[ext and ext:lower() or ""] or "text/plain"
  if mime ~= "text/plain" or ext == "txt" then   -- {{hits}}, {{time}}, {{host}} work in pages
    text = text:gsub("{{(%w+)}}", function(k) local v = ctx.vars[k]; return v ~= nil and tostring(v) or nil end)
  end
  if #text > MAX_PAGE then return response(413, "Too Large", "text/plain", "page too large") end
  return response(200, "OK", mime, method == "HEAD" and "" or text)
end

-- ------------------------------------------------------------------ rendering pages (a small subset of HTML)

local ENT = { lt = "<", gt = ">", amp = "&", quot = '"', nbsp = " ", apos = "'" }
local function entities(s)
  return (s:gsub("&(#?%w+);", function(e)
    if ENT[e] then return ENT[e] end
    local n = e:match("^#(%d+)$")
    if n and tonumber(n) < 256 then return string.char(tonumber(n)) end
  end))
end

local function attr(attrs, name)
  local v = attrs:match(name .. '%s*=%s*"([^"]*)"') or attrs:match(name .. "%s*=%s*'([^']*)'") or attrs:match(name .. "%s*=%s*([^%s>]+)")
  return v and entities(v)
end

-- returns { lines = { {segs = { {t=, fg=, link=} }}, ... }, links = { href, ... }, title = }
function M.render(html, width, base)
  local lines, links, title = {}, {}, nil
  local cur, curLen, indent = {}, 0, 0
  local fgStack, fg = {}, "white"
  local linkId, inPre, skip, inTitle = nil, false, nil, false
  local listStack, titleBuf = {}, {}

  local function flush()
    lines[#lines + 1] = { segs = cur }
    cur, curLen = {}, 0
  end
  local function newline() if curLen > 0 or #cur > 0 then flush() end end
  local function blank()
    newline()
    if #lines > 0 and #lines[#lines].segs > 0 then lines[#lines + 1] = { segs = {} } end
  end
  local function put(text, color, link)
    if text == "" then return end
    if curLen == 0 and indent > 0 then cur[#cur + 1] = { t = string.rep(" ", indent), fg = "white" }; curLen = indent end
    cur[#cur + 1] = { t = text, fg = color, link = link }
    curLen = curLen + #text
  end
  local function words(text)
    if inPre then
      local first = true
      for piece in (text .. "\n"):gmatch("([^\n]*)\n") do
        if not first then newline() end
        first = false
        put(piece, fg, linkId)
      end
      return
    end
    text = entities(text):gsub("%s+", " ")
    for lead, w in text:gmatch("( ?)([^ ]+)") do
      local need = #w + ((curLen > indent and lead ~= "") and 1 or 0)
      if curLen > indent and curLen + need > width then newline() end
      if curLen > indent and lead ~= "" then put(" ", fg, linkId) end
      while #w > width - indent do   -- a word longer than a line
        put(w:sub(1, width - indent - curLen), fg, linkId)
        newline()
        w = w:sub(width - indent + 1)
      end
      put(w, fg, linkId)
    end
    if text:sub(-1) == " " and curLen > indent then put(" ", fg, linkId) end
  end

  html = html:gsub("<!%-%-.-%-%->", "")
  local pos = 1
  while pos <= #html do
    local s, e, closing, tag, attrs = html:find("<(/?)(%w+)([^>]*)>", pos)
    local text = html:sub(pos, (s or #html + 1) - 1)
    if text ~= "" and not skip then
      if inTitle then titleBuf[#titleBuf + 1] = text else words(text) end
    end
    if not s then break end
    pos = e + 1
    tag = tag:lower()
    local close = closing == "/"
    if skip then
      if close and tag == skip then skip = nil end
    elseif tag == "script" or tag == "style" then
      if not close then skip = tag end
    elseif tag == "title" then
      inTitle = not close
      if close then title = entities(table.concat(titleBuf)):gsub("%s+", " ") end
    elseif tag == "h1" or tag == "h2" or tag == "h3" then
      blank()
      if close then fg = table.remove(fgStack) or "white" else
        fgStack[#fgStack + 1] = fg
        fg = tag == "h1" and "yellow" or tag == "h2" and "orange" or "lightBlue"
      end
    elseif tag == "p" or tag == "div" or tag == "table" or tag == "center" or tag == "ul" or tag == "ol" or tag == "blockquote" then
      blank()
      if tag == "ul" or tag == "ol" then
        if close then table.remove(listStack); indent = math.max(0, indent - 2)
        else listStack[#listStack + 1] = { n = 0, ordered = tag == "ol" }; indent = indent + 2 end
      elseif tag == "blockquote" then indent = close and math.max(0, indent - 4) or indent + 4 end
    elseif tag == "br" or tag == "tr" then newline()
    elseif tag == "td" or tag == "th" then if not close then put("  ", fg) end
    elseif tag == "hr" then blank(); put(string.rep("-", width), "gray"); newline()
    elseif tag == "li" and not close then
      newline()
      local l = listStack[#listStack]
      local mark = "* "
      if l then l.n = l.n + 1; if l.ordered then mark = l.n .. ". " end end
      indent = indent - 2
      put(mark, "lime")
      indent = indent + 2
    elseif tag == "pre" then blank(); inPre = not close
    elseif tag == "b" or tag == "strong" or tag == "i" or tag == "em" or tag == "u" then
      if close then fg = table.remove(fgStack) or "white" else fgStack[#fgStack + 1] = fg; fg = "white" end
    elseif tag == "font" or tag == "span" then
      if close then fg = table.remove(fgStack) or "white" else
        fgStack[#fgStack + 1] = fg
        fg = attr(attrs, "color") or fg
      end
    elseif tag == "a" then
      if close then
        if linkId then put("[" .. linkId .. "]", "gray") end
        linkId = nil
        fg = table.remove(fgStack) or "white"
      else
        local href = attr(attrs, "href")
        if href then
          links[#links + 1] = base and M.resolve(base, href) or href
          linkId = #links
        end
        fgStack[#fgStack + 1] = fg
        if href then fg = "lightBlue" end
      end
    elseif tag == "img" then
      put("[image: " .. (attr(attrs, "alt") or "?") .. "]", "gray")
    end
  end
  newline()
  while #lines > 0 and #lines[#lines].segs == 0 do lines[#lines] = nil end
  return { lines = lines, links = links, title = title }
end

function M.renderText(text, width)
  local lines = {}
  for line in (text .. "\n"):gmatch("([^\n]*)\n") do
    line = line:gsub("\r", ""):gsub("\t", "  ")
    repeat
      lines[#lines + 1] = { segs = { { t = line:sub(1, width), fg = "white" } } }
      line = line:sub(width + 1)
    until line == ""
  end
  return { lines = lines, links = {}, title = nil }
end

-- ------------------------------------------------------------------ everything below needs ComputerCraft

if RPWEB_TEST then return M end

local function findNic()
  local nic = peripheral.find("realplugs_socket")
  if not nic then error("no Real Plugs socket next to this computer", 0) end
  return nic, peripheral.getName(nic)
end

local function pcallClose(nic, slot, id) pcall(nic.tcpClose, slot, id) end

-- gets a page: returns response table, or nil + reason
function M.fetch(nic, slot, url, hops)
  hops = hops or 0
  local u, err = M.parseUrl(url)
  if not u then return nil, err end
  local side = peripheral.getName(nic)
  local id, cerr = nic.connect(slot, u.host, u.port)
  if not id then return nil, cerr or "cannot connect" end
  local timer = os.startTimer(10)
  local buf = ""
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then
      pcallClose(nic, slot, id)
      return nil, "timed out"
    elseif ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot and ev[5] == id then
      if ev[4] == "connected" then
        local ok, why = nic.tcpSend(slot, id, M.buildRequest(u.host, u.path))
        if ok == false then return nil, why end
      elseif ev[4] == "data" then
        buf = buf .. ev[6]
        if #buf > MAX_PAGE + 2000 then pcallClose(nic, slot, id); return nil, "page too large" end
        if M.responseComplete(buf) then break end
      elseif ev[4] == "closed" then
        if buf == "" then return nil, "connection " .. tostring(ev[6] or "closed") end
        break
      end
    end
  end
  os.cancelTimer(timer)
  pcallClose(nic, slot, id)
  local r = M.parseResponse(buf)
  if not r then return nil, "not a web server" end
  r.url = M.formatUrl(u)
  local loc = r.headers["location"]
  if (r.status == 301 or r.status == 302) and loc and hops < 4 then
    return M.fetch(nic, slot, M.resolve(u, loc), hops + 1)
  end
  return r
end

-- ------------------------------------------------------------------ server

local function serve(slot, name)
  local nic, side = findNic()
  local ok, why = nic.listen(slot, 80)
  if ok == false then error("cannot listen: " .. tostring(why), 0) end
  if name then
    local ok2, why2 = nic.setHostname(slot, name)
    if ok2 == false then print("name not set: " .. tostring(why2)) end
  end
  local ifs = nic.getInterfaces()[slot]
  local host = name or (ifs and ifs.ip) or "?"
  local ctx = {
    read = function(path)
      if not fs.exists(path) or fs.isDir(path) then return nil end
      local f = fs.open(path, "rb"); if not f then return nil end
      local t = f.readAll(); f.close(); return t
    end,
    isDir = function(path) return fs.exists(path) and fs.isDir(path) end,
    vars = { hits = 0, host = host },
  }
  local buffers = {}
  term.clear(); term.setCursorPos(1, 1)
  print("rpweb server on slot " .. slot .. ": http://" .. host .. "/")
  print("pages are in /" .. ROOT .. "  (Ctrl+T stops)")
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then
      pcall(nic.unlisten, slot, 80)
      print("stopped"); return
    elseif ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot then
      local kind, id = ev[4], ev[5]
      if kind == "accepted" then
        buffers[id] = { ip = ev[6], data = "" }
      elseif kind == "data" and buffers[id] then
        local b = buffers[id]
        b.data = b.data .. ev[6]
        if b.data:find("\r\n\r\n", 1, true) or b.data:find("\n\n", 1, true) or #b.data > 4000 then
          ctx.vars.hits = ctx.vars.hits + 1
          ctx.vars.time = textutils.formatTime(os.time(), true)
          local out = M.handle(b.data, ctx)
          print(b.ip .. "  " .. (b.data:match("^(%u+ %S+)") or "?") .. "  " .. (out:match("^HTTP/%d%.%d (%d+)") or "?"))
          for i = 1, #out, CHUNK do
            local sent, serr = nic.tcpSend(slot, id, out:sub(i, i + CHUNK - 1))
            if sent == false then break end
          end
          pcallClose(nic, slot, id)
          buffers[id] = nil
        end
      elseif kind == "closed" then
        buffers[id] = nil
      end
    end
  end
end

-- ------------------------------------------------------------------ browser

local function browse(slot, start)
  local nic = findNic()
  local w, h = term.getSize()
  local page, scroll, history = nil, 0, {}
  local current, status = nil, "G = go to an address (or a link number), B = back, R = reload, Q = quit"

  local function color(name)
    return colors[name] or colors.white
  end

  local function draw()
    term.setBackgroundColor(colors.black)
    term.clear()
    term.setCursorPos(1, 1)
    term.setBackgroundColor(colors.gray); term.setTextColor(colors.white)
    term.clearLine()
    term.write(" " .. (current or "(no page)"):sub(1, w - 2))
    term.setBackgroundColor(colors.black)
    if page then
      for row = 1, h - 2 do
        local line = page.lines[scroll + row]
        if not line then break end
        term.setCursorPos(1, row + 1)
        for _, seg in ipairs(line.segs) do
          term.setTextColor(color(seg.fg))
          term.write(seg.t)
        end
      end
    end
    term.setCursorPos(1, h)
    term.setBackgroundColor(colors.gray); term.setTextColor(colors.lightGray)
    term.clearLine()
    term.write((status or ""):sub(1, w))
    term.setBackgroundColor(colors.black)
  end

  local function load(url, push)
    status = "Loading " .. url .. " ..."
    current = url
    draw()
    local r, err = M.fetch(nic, slot, url)
    if not r then
      page = M.renderText("Could not load this page.\n\n" .. tostring(err), w)
      status = "Error: " .. tostring(err)
      scroll = 0
      return
    end
    if push and current and page and page.url then history[#history + 1] = page.url end
    local base = M.parseUrl(r.url)
    local mime = r.headers["content-type"] or "text/plain"
    page = mime:find("html", 1, true) and M.render(r.body, w, base) or M.renderText(r.body, w)
    page.url = r.url
    current = r.url
    scroll = 0
    status = r.status .. " " .. r.reason .. (page.title and ("  -  " .. page.title) or "") ..
             "  (" .. #page.links .. " links, G = go)"
  end

  local function go(text)
    text = text:gsub("^%s+", ""):gsub("%s+$", "")
    if text == "" then return end
    if text:match("^%d+$") then
      local href = page and page.links[tonumber(text)]
      if href then load(href, true) else status = "No link " .. text end
    else
      load(text, true)
    end
  end

  if start and start ~= "" then load(start, false) end
  while true do
    draw()
    local ev = { os.pullEvent() }
    local maxScroll = page and math.max(0, #page.lines - (h - 2)) or 0
    if ev[1] == "key" then
      local k = ev[2]
      if k == keys.q then break
      elseif k == keys.up then scroll = math.max(0, scroll - 1)
      elseif k == keys.down then scroll = math.min(maxScroll, scroll + 1)
      elseif k == keys.pageUp then scroll = math.max(0, scroll - (h - 3))
      elseif k == keys.pageDown or k == keys.space then scroll = math.min(maxScroll, scroll + (h - 3))
      elseif k == keys.home then scroll = 0
      elseif k == keys["end"] then scroll = maxScroll
      elseif k == keys.b or k == keys.backspace then
        local back = table.remove(history)
        if back then load(back, false) else status = "Nothing to go back to" end
      elseif k == keys.r and current then load(current, false)
      elseif k == keys.g then
        term.setCursorPos(1, h); term.setBackgroundColor(colors.black); term.setTextColor(colors.white); term.clearLine()
        term.write("Go: ")
        go(read())
      end
    elseif ev[1] == "mouse_scroll" then
      scroll = math.max(0, math.min(maxScroll, scroll + ev[2] * 2))
    elseif ev[1] == "mouse_click" and page then
      local line = page.lines[scroll + ev[4] - 1]
      if line then
        local x = 1
        for _, seg in ipairs(line.segs) do
          if ev[3] >= x and ev[3] < x + #seg.t and seg.link then go(tostring(seg.link)); break end
          x = x + #seg.t
        end
      end
    elseif ev[1] == "term_resize" then
      w, h = term.getSize()
      if current then load(current, false) end
    end
  end
  term.setBackgroundColor(colors.black); term.setTextColor(colors.white); term.clear(); term.setCursorPos(1, 1)
end

-- ------------------------------------------------------------------ starter site

local function init()
  fs.makeDir(ROOT)
  local function write(path, text)
    if fs.exists(path) then print("kept " .. path); return end
    local f = fs.open(path, "w"); f.write(text); f.close(); print("made " .. path)
  end
  write(ROOT .. "/index.html", [[<html><head><title>My first website</title></head>
<body>
<h1>Welcome to {{host}}</h1>
<p>This page is served by a computer in my base. You are visitor number {{hits}}.
It is {{time}} on the server.</p>
<h2>Pages</h2>
<ul>
<li><a href="about.html">About this site</a></li>
<li><a href="notes.txt">A plain text file</a></li>
</ul>
<hr>
<p>Change this page with <b>edit www/index.html</b>.</p>
</body></html>
]])
  write(ROOT .. "/about.html", [[<html><head><title>About</title></head>
<body>
<h1>About</h1>
<p>Everything here is plain HTML in the <b>www</b> folder: headings, paragraphs, lists,
<font color="lime">coloured text</font>, rules and links to other pages
(<a href="/">home</a>).</p>
<p>Tags the browser understands: h1 h2 h3 p br hr ul ol li a b i font(color) pre center blockquote table img(alt).
Pages can contain {{hits}} (visitors), {{time}} and {{host}}.</p>
</body></html>
]])
  write(ROOT .. "/notes.txt", "A plain text page.\nNo tags here, just lines.\n")
  write(ROOT .. "/404.html", "<h1>404</h1><p>That page does not exist.</p><p><a href=\"/\">Home</a></p>\n")
end

-- ------------------------------------------------------------------ command line

local args = { ... }
local cmd = args[1]
if cmd == "init" then
  init()
elseif cmd == "serve" then
  serve(tonumber(args[2]) or 1, args[3] or (args[2] and not tonumber(args[2]) and args[2]) or nil)
elseif cmd == "browse" then
  browse(1, args[2])
else
  print("rpweb init | rpweb serve [slot] [name] | rpweb browse [address]")
end
