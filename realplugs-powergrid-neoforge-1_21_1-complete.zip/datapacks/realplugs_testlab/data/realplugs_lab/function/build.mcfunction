# Builds a small network lab in front of you and gives you the cables. Run it on flat ground:  /function realplugs_lab:build
# Router, switch and Wi-Fi access point work without a computer. The web server and the client need a computer each.
execute at @s run fill ~ ~-1 ~ ~16 ~-1 ~6 minecraft:smooth_stone
execute at @s run fill ~ ~ ~ ~16 ~4 ~6 minecraft:air
execute at @s run setblock ~2 ~ ~2 realplugs:network_router[facing=south]
execute at @s run setblock ~5 ~ ~2 realplugs:network_switch[facing=south]
execute at @s run setblock ~8 ~ ~2 realplugs:wifi_access_point[facing=south]
execute at @s run setblock ~11 ~ ~2 computercraft:computer_advanced[facing=south]
execute at @s run setblock ~14 ~ ~2 computercraft:computer_advanced[facing=south]
execute at @s run setblock ~2 ~ ~5 minecraft:oak_sign[rotation=0]
give @s realplugs:cat5_cable 4
give @s realplugs:cat6_cable 4
give @s realplugs:fibre_cable 2
give @s realplugs:wifi_analyzer 1
tellraw @s [{"text":"Real Plugs lab built. ","color":"green"},{"text":"Left to right: router, switch, access point, web-server computer, client computer.","color":"gray"}]
tellraw @s {"text":"Connect them with the cables you were given (Cat5 and Cat6 for the LAN, fibre between router and switch if you like). Put a RJ45 socket next to each computer, then follow lua/README in the mod: rplab on the server, rpweb browse on the client.","color":"gray"}
