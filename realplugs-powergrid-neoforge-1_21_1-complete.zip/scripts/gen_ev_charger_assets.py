#!/usr/bin/env python3
"""Generates the EV charger textures and block models.

Run from the repo root:  python3 scripts/gen_ev_charger_assets.py   (needs Pillow)

Textures (64x64, so 4 texels per 1/16 block, i.e. four times the vanilla density):
  ev_charger_<id>.png   front art of the enclosure (u 3..13) + a swatch strip (u 0..3) used by every small part
  ev_charger_body.png   sides, top and back, shared by all five chargers
  ev_charger_<id>_top.png   front art of the upper block (screen, buttons)
Every charger is two blocks high: ev_charger_<id> is the lower half (socket, coin plate, cable gland, the block entity)
and ev_charger_<id>_top is the upper half (screen, +/-/mode/STOP buttons). The item model shows both halves.
Footprint: 3..13 wide, 8..16 deep, front plate at z = 8. The plug position, coin plate and gland positions are used by
EvChargerBlock / PlugSocketRenderer, and the screen/button zones by EvChargerTopBlock.zoneOf: keep them in sync.
Texture art is painted in VIEWER coordinates (texel x = 4 * distance from the viewer's left edge, texel y = 4 * (16 - y));
north faces use north_uv() below, which flips the model x axis accordingly.
"""
import json
import random
from pathlib import Path

from PIL import Image, ImageDraw

ROOT = Path(__file__).resolve().parent.parent
TEX = ROOT / "src/main/resources/assets/realplugs/textures/block"
MODELS = ROOT / "src/main/resources/assets/realplugs/models/block"

CHARGERS = {
    #              accent colour          fast charger?
    "type1":   ((47, 111, 214), False),
    "type2":   ((47, 174, 90), False),
    "ccs":     ((240, 140, 42), True),
    "chademo": ((216, 69, 58), True),
    "nacs":    ((43, 183, 196), True),
}

GRAPHITE = (35, 38, 43)
STEEL = (170, 176, 184)
GOLD = (217, 176, 74)
BLACK = (11, 12, 14)
WHITE = (236, 239, 242)
LED_GREEN = (56, 214, 100)
RED = (200, 50, 45)
BLUE = (50, 100, 200)
RUBBER = (23, 24, 27)
DSTEEL = (91, 96, 104)

ENCL = (223, 226, 230)      # enclosure
ENCL_HI = (244, 246, 248)
ENCL_LO = (176, 181, 188)
ENCL_DK = (146, 151, 158)


def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)


def px(d, x, y, c):
    d.point((x, y), fill=c)


def rect(d, x0, y0, x1, y1, c):
    d.rectangle((x0, y0, x1, y1), fill=c)


def noise(im, box, amount, seed):
    rnd = random.Random(seed)
    x0, y0, x1, y1 = box
    p = im.load()
    for y in range(y0, y1 + 1):
        for x in range(x0, x1 + 1):
            r, g, b, a = p[x, y]
            if a == 0:
                continue
            k = rnd.randint(-amount, amount)
            p[x, y] = (max(0, min(255, r + k)), max(0, min(255, g + k)), max(0, min(255, b + k)), a)


# swatch cells: (column, row) -> colour, each cell is 4x4 texels = 1x1 uv units, in u 0..3
def swatches(accent):
    return {
        "graphite": (0, 0, GRAPHITE), "steel": (1, 0, STEEL), "accent": (2, 0, accent),
        "gold": (0, 1, GOLD), "black": (1, 1, BLACK), "white": (2, 1, WHITE),
        "green": (0, 2, LED_GREEN), "red": (1, 2, RED), "blue": (2, 2, BLUE),
        "rubber": (0, 3, RUBBER), "dsteel": (1, 3, DSTEEL), "accent_dk": (2, 3, shade(accent, 0.6)),
    }


def pins(d, std, ox, oy):
    """Connector face, 16x16 texels at (ox, oy)."""
    ring = (62, 67, 75)
    inner = (24, 27, 32)
    pin = (200, 205, 212)
    big = (218, 178, 80)

    def disc(cx, cy, r, c):
        d.ellipse((ox + cx - r, oy + cy - r, ox + cx + r, oy + cy + r), fill=c)

    if std == "type1":
        disc(8, 8, 7, ring); disc(8, 8, 6, inner)
        for cx, cy, r in ((5, 5, 1), (11, 5, 1), (8, 4, 1), (5, 10, 2), (11, 10, 2)):
            disc(cx, cy, r, pin if r == 1 else big)
    elif std == "type2":
        disc(8, 8, 7, ring); disc(8, 8, 6, inner)
        for cx, cy in ((4, 8), (6, 5), (10, 5), (12, 8), (8, 11)):
            disc(cx, cy, 1, pin)
        disc(8, 8, 1, big)
    elif std == "ccs":
        disc(8, 5, 5, ring); disc(8, 5, 4, inner)
        rect(d, ox + 2, oy + 9, ox + 13, oy + 14, ring); rect(d, ox + 3, oy + 10, ox + 12, oy + 13, inner)
        for cx, cy in ((5, 4), (11, 4), (8, 3), (6, 6), (10, 6)):
            px(d, ox + cx, oy + cy, pin)
        disc(5, 11, 2, big); disc(11, 11, 2, big)
    elif std == "chademo":
        disc(8, 8, 7, ring); disc(8, 8, 6, inner)
        disc(5, 8, 2, big); disc(11, 8, 2, big)
        for cx, cy in ((4, 4), (8, 3), (12, 4), (6, 12), (10, 12)):
            px(d, ox + cx, oy + cy, pin)
    else:  # nacs: slim pill
        d.rounded_rectangle((ox + 1, oy + 4, ox + 14, oy + 11), radius=3, fill=ring)
        d.rounded_rectangle((ox + 2, oy + 5, ox + 13, oy + 10), radius=2, fill=inner)
        disc(5, 8, 2, big); disc(11, 8, 2, big); px(d, ox + 8, oy + 6, pin); px(d, ox + 8, oy + 9, pin)


def bolt(d, ox, oy, c):
    pts = [(3, 0), (0, 4), (2, 4), (1, 8), (5, 3), (3, 3), (4, 0)]
    d.polygon([(ox + x, oy + y) for x, y in pts], fill=c)



# ---------------------------------------------------------------------------------------------------------------
# art in viewer coordinates: xv = distance from the viewer's LEFT edge of the block (0..16), y = height (0..16)

def tx(xv):
    return int(round(xv * 4))


def ty(y):
    return int(round((16 - y) * 4))


def rv(d, xv0, y0, xv1, y1, c):
    """Filled rectangle from viewer-space box (xv0..xv1, y0..y1)."""
    x0, x1 = tx(xv0), tx(xv1) - 1
    y0t, y1t = ty(y1), ty(y0) - 1
    d.rectangle((x0, y0t, max(x0, x1), max(y0t, y1t)), fill=c)   # at least one texel, however thin


GLYPHS = {
    "S": ["###", "#..", "###", "..#", "###"], "T": ["###", ".#.", ".#.", ".#.", ".#."],
    "O": ["###", "#.#", "#.#", "#.#", "###"], "P": ["###", "#.#", "###", "#..", "#.."],
    "-": ["...", "...", "###", "...", "..."], "+": [".#.", ".#.", "###", ".#.", ".#."],
    "L": [".#.", "#.#", "###", "###", "###"],   # padlock
}


def glyph(d, ch, ox, oy, c, k=2):
    for r, row in enumerate(GLYPHS[ch]):
        for col, v in enumerate(row):
            if v == "#":
                d.rectangle((ox + col * k, oy + r * k, ox + col * k + k - 1, oy + r * k + k - 1), fill=c)


def bolt_big(d, ox, oy, h, c):
    """Lightning bolt, h texels tall."""
    pts = [(0.62, 0.0), (0.12, 0.58), (0.45, 0.58), (0.30, 1.0), (0.90, 0.38), (0.55, 0.38), (0.80, 0.0)]
    w = h * 0.7
    d.polygon([(ox + x * w, oy + y * h) for x, y in pts], fill=c)


def enclosure(im, d, name, accent, fast, seed):
    rect(d, 12, 0, 51, 63, ENCL)
    rect(d, 12, 0, 12, 63, ENCL_LO); rect(d, 51, 0, 51, 63, ENCL_LO)
    rect(d, 13, 0, 13, 63, ENCL_HI); rect(d, 50, 0, 50, 63, shade(ENCL, 0.93))
    noise(im, (12, 0, 51, 63), 3, seed)


def paint_swatches(d, accent):
    for cname, (c, r, col) in swatches(accent).items():
        rect(d, c * 4, r * 4, c * 4 + 3, r * 4 + 3, col)


def lower_texture(name, accent, fast):
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    paint_swatches(d, accent)
    enclosure(im, d, name, accent, fast, hash(name) & 0xFFFF)
    # badge panel with the bolt (y 12.5..15.5)
    rv(d, 4, 12.5, 12, 15.5, (28, 31, 36))
    rv(d, 4, 15.4, 12, 15.5, (70, 76, 84))
    bolt_big(d, tx(8) - 4, ty(15.5) + 1, 10, accent)
    for xv in (4.6, 11.0):
        rv(d, xv, 13.3, xv + 0.4, 14.7, shade(accent, 0.7))
    if fast:
        for xv in (5.4, 10.2):
            rv(d, xv, 13.3, xv + 0.4, 14.7, shade(accent, 0.7))
    # accent band above the socket
    rv(d, 3, 12.0, 13, 12.5, accent)
    # socket bezel (x 5..11, y 6..12)
    rect(d, 20, 16, 43, 39, (33, 37, 43))
    rect(d, 20, 16, 43, 16, (60, 66, 74)); rect(d, 20, 16, 20, 39, (60, 66, 74))
    rect(d, 43, 16, 43, 39, (18, 20, 24)); rect(d, 20, 39, 43, 39, (18, 20, 24))
    rect(d, 21, 17, 42, 38, (28, 31, 36))
    # connector face (x 6..10, y 7..11)
    rect(d, 24, 20, 39, 35, BLACK)
    pins(d, name, 24, 20)
    # coin plate (x 5..11, y 2.5..5.5)
    rect(d, 20, 42, 43, 53, GOLD)
    rect(d, 20, 42, 43, 42, (244, 214, 120)); rect(d, 20, 42, 20, 53, (244, 214, 120))
    rect(d, 43, 42, 43, 53, (140, 104, 36)); rect(d, 20, 53, 43, 53, (140, 104, 36))
    rect(d, 22, 44, 41, 51, (196, 154, 58))
    rect(d, 26, 46, 37, 49, BLACK)
    d.ellipse((22, 45, 25, 48), fill=(244, 214, 120)); d.ellipse((38, 45, 41, 48), fill=(244, 214, 120))
    # plinth (y 0..2): yellow/black hazard stripes like a bollard guard
    rect(d, 8, 56, 55, 63, GRAPHITE)
    for y in range(57, 63):
        for x in range(10, 55):
            if ((x + y) // 3) % 2 == 0:
                px(d, x, y, (236, 190, 36))
    rect(d, 8, 56, 55, 56, (70, 75, 83))
    return im


def upper_texture(name, accent, fast):
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    paint_swatches(d, accent)
    enclosure(im, d, name, accent, fast, (hash(name) + 7) & 0xFFFF)
    # glass (x 4..12, y 7.5..13.5): dark with a faint diagonal reflection
    rv(d, 4, 7.5, 12, 13.5, (8, 28, 30))
    for i in range(0, 24):
        x = 16 + i * 2
        for y in range(ty(13.5), ty(7.5)):
            if (x + y) % 17 == 0:
                px(d, x, y, (14, 44, 46))
    rv(d, 4, 13.3, 12, 13.5, (14, 44, 46))
    # buttons (y 4..7): minus 4..6.5, plus 7..9.5, mode 10..12
    for xv0, xv1, ch in ((4, 6.5, "-"), (7, 9.5, "+"), (10, 12, "L")):
        rv(d, xv0, 4, xv1, 7, DSTEEL)
        rv(d, xv0, 6.8, xv1, 7, (150, 156, 164))
        rv(d, xv0, 4, xv1, 4.2, (50, 54, 60))
        w = tx(xv1) - tx(xv0)
        glyph(d, ch, tx(xv0) + (w - 6) // 2, ty(7) + 1, WHITE)
    # STOP bar (x 4..12, y 0.5..3.5)
    rv(d, 4, 0.5, 12, 3.5, RED)
    rv(d, 4, 3.3, 12, 3.5, (236, 110, 100))
    rv(d, 4, 0.5, 12, 0.7, (120, 24, 22))
    x0 = tx(4) + 1
    for i, ch in enumerate("STOP"):
        glyph(d, ch, x0 + i * 8, ty(3.5) + 1, WHITE)
    # panel seam between the screen block and the button block
    rv(d, 3, 7.0, 13, 7.1, ENCL_LO)
    return im


def body_texture():
    im = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    # side (u 0..8 -> texels 0..32, v = 16 - y)
    rect(d, 0, 0, 31, 63, ENCL)
    rect(d, 0, 0, 0, 63, ENCL_LO); rect(d, 31, 0, 31, 63, ENCL_LO)
    rect(d, 1, 0, 1, 63, ENCL_HI)
    rect(d, 0, 6, 31, 6, ENCL_LO)                 # seam under the cap
    rect(d, 0, 56, 31, 56, ENCL_LO)               # seam above the plinth
    for i in range(6):                           # vents (y 2.5..5)
        y = 40 + i * 2
        rect(d, 8, y, 23, y, ENCL_DK)
    for i in range(4):                           # vents high up (y 12..14)
        y = 8 + i * 2
        rect(d, 8, y, 23, y, ENCL_DK)
    noise(im, (0, 0, 31, 63), 3, 11)
    # top (u 8..16, v 0..8 -> texels 32..63, 0..31)
    rect(d, 32, 0, 63, 31, ENCL_HI)
    rect(d, 32, 0, 63, 0, ENCL_LO); rect(d, 32, 31, 63, 31, ENCL_LO)
    rect(d, 32, 0, 32, 31, ENCL_LO); rect(d, 63, 0, 63, 31, ENCL_LO)
    noise(im, (32, 0, 63, 31), 3, 12)
    # back (u 8..16, v 8..16 -> texels 32..63, 32..63): a mounting plate
    rect(d, 32, 32, 63, 63, ENCL_LO)
    rect(d, 34, 34, 61, 61, ENCL_DK)
    rect(d, 36, 36, 59, 59, ENCL_LO)
    for x, y in ((38, 38), (57, 38), (38, 57), (57, 57)):
        d.ellipse((x - 1, y - 1, x + 1, y + 1), fill=DSTEEL)
    noise(im, (32, 32, 63, 63), 3, 13)
    return im


def sw(cell):
    c, r = {"graphite": (0, 0), "steel": (1, 0), "accent": (2, 0), "gold": (0, 1), "black": (1, 1), "white": (2, 1),
            "green": (0, 2), "red": (1, 2), "blue": (2, 2), "rubber": (0, 3), "dsteel": (1, 3), "accent_dk": (2, 3)}[cell]
    return [c + 0.25, r + 0.25, c + 0.75, r + 0.75]


# ---------------------------------------------------------------------------------------------------------------
# models. Elements are written in viewer coordinates (xv) and converted to model x (= 16 - xv) by box().

def solid(cell, key):
    return {f: {"uv": sw(cell), "texture": key} for f in ("north", "east", "south", "west", "up", "down")}


def north_uv(xv0, y0, xv1, y1):
    return [xv0, 16 - y1, xv1, 16 - y0]


def side_uv(y0, y1):
    return [0, 16 - y1, 8, 16 - y0]


def box(xv0, y0, z0, xv1, y1, z1, faces, yoff=0):
    return {"from": [round(16 - xv1, 4), round(y0 + yoff, 4), z0], "to": [round(16 - xv0, 4), round(y1 + yoff, 4), z1],
            "faces": faces}


def pface(uv, key):
    return {"uv": uv, "texture": key}


def lower_elements(fast, key, yoff=0):
    k = key
    els = []
    els.append(box(3, 2, 8, 13, 16, 16, {
        "north": pface(north_uv(3, 2, 13, 16), k),
        "south": pface([8, 8, 16, 16], "#body"),
        "east": pface(side_uv(2, 16), "#body"), "west": pface(side_uv(2, 16), "#body"),
        "up": pface([8, 0, 16, 8], "#body"), "down": pface(sw("steel"), k)}, yoff))
    els.append(box(2.4, 0, 7.2, 13.6, 2, 16, {
        "north": pface(north_uv(2.4, 0, 13.6, 2), k), "south": pface(sw("graphite"), k), "east": pface(sw("graphite"), k),
        "west": pface(sw("graphite"), k), "up": pface(sw("dsteel"), k), "down": pface(sw("graphite"), k)}, yoff))
    # connector socket: bezel and face (the plug is drawn over it by PlugSocketRenderer)
    els.append(box(5, 6, 7.6, 11, 12, 8, {
        "north": pface(north_uv(5, 6, 11, 12), k), "south": pface(sw("graphite"), k), "east": pface(sw("graphite"), k),
        "west": pface(sw("graphite"), k), "up": pface(sw("dsteel"), k), "down": pface(sw("graphite"), k)}, yoff))
    els.append(box(6, 7, 7.5, 10, 11, 7.6, {
        "north": pface(north_uv(6, 7, 10, 11), k), "south": pface(sw("black"), k), "east": pface(sw("black"), k),
        "west": pface(sw("black"), k), "up": pface(sw("black"), k), "down": pface(sw("black"), k)}, yoff))
    # coin plate and slot
    els.append(box(5, 2.5, 7.7, 11, 5.5, 8, {
        "north": pface(north_uv(5, 2.5, 11, 5.5), k), "south": pface(sw("gold"), k), "east": pface(sw("gold"), k),
        "west": pface(sw("gold"), k), "up": pface(sw("gold"), k), "down": pface(sw("gold"), k)}, yoff))
    els.append(box(6.5, 3.7, 7.6, 9.5, 4.3, 7.7, solid("black", k), yoff))
    # status LED, left of the socket
    els.append(box(4, 6, 7.6, 5, 7, 7.7, solid("green", k), yoff))
    # cable gland: where the built-in cord leaves the charger (PlugSocketRenderer draws the cable from xv 4, y 2.4)
    els.append(box(3.2, 2, 7.2, 4.8, 3.2, 8, solid("rubber", k), yoff))
    els.append(box(3, 2, 7.6, 5, 2.4, 8, solid("dsteel", k), yoff))
    # side bus connectors (Power Grid terminals): red hot on the viewer's left, blue neutral on the right
    els.append(box(1.5, 6.75, 8.4, 4.0, 9.25, 15.6, solid("red", k), yoff))
    els.append(box(12.0, 6.75, 8.4, 14.5, 9.25, 15.6, solid("blue", k), yoff))
    return els


def upper_elements(fast, key, yoff=0):
    k = key
    els = []
    els.append(box(3, 0, 8, 13, 15.6, 16, {
        "north": pface(north_uv(3, 0, 13, 15.6), k),
        "south": pface([8, 8, 16, 16], "#body"),
        "east": pface(side_uv(0, 15.6), "#body"), "west": pface(side_uv(0, 15.6), "#body"),
        "up": pface([8, 0, 16, 8], "#body"), "down": pface(sw("steel"), k)}, yoff))
    # cap, overhanging a little like a canopy
    els.append(box(2.4, 15.6, 7.2 if fast else 7.4, 13.6, 16, 16, solid("accent", k), yoff))
    # light bar under the cap
    els.append(box(4, 14.4, 7.6, 12, 15.1, 7.7, solid("accent", k), yoff))
    # screen: frame and glass (the text is drawn by the renderer)
    for (a, b, c, e) in ((3.5, 7, 4, 14), (12, 7, 12.5, 14), (3.5, 7, 12.5, 7.5), (3.5, 13.5, 12.5, 14)):
        els.append(box(a, b, 7.55, c, e, 8, solid("black", k), yoff))
    els.append(box(4, 7.5, 7.7, 12, 13.5, 8, {
        "north": pface(north_uv(4, 7.5, 12, 13.5), k), "south": pface(sw("black"), k), "east": pface(sw("black"), k),
        "west": pface(sw("black"), k), "up": pface(sw("graphite"), k), "down": pface(sw("graphite"), k)}, yoff))
    # buttons: minus, plus, mode (padlock) and the big red STOP bar
    for (a, e) in ((4, 6.5), (7, 9.5), (10, 12)):
        els.append(box(a, 4, 7.7, e, 7, 8, {
            "north": pface(north_uv(a, 4, e, 7), k), "south": pface(sw("dsteel"), k), "east": pface(sw("dsteel"), k),
            "west": pface(sw("dsteel"), k), "up": pface(sw("dsteel"), k), "down": pface(sw("dsteel"), k)}, yoff))
    els.append(box(4, 0.5, 7.6, 12, 3.5, 8, {
        "north": pface(north_uv(4, 0.5, 12, 3.5), k), "south": pface(sw("red"), k), "east": pface(sw("red"), k),
        "west": pface(sw("red"), k), "up": pface(sw("red"), k), "down": pface(sw("red"), k)}, yoff))
    return els


def display_for(old, scale_k, dy):
    out = {}
    for name, t in old.items():
        t = dict(t)
        if "scale" in t:
            t["scale"] = [round(v * scale_k, 4) for v in t["scale"]]
        tr = list(t.get("translation", [0, 0, 0]))
        tr[1] = tr[1] + dy
        t["translation"] = tr
        out[name] = t
    return out


def write(path, model):
    path.write_text(json.dumps(model, indent=1) + "\n")


def build():
    TEX.mkdir(parents=True, exist_ok=True)
    item_dir = MODELS.parent / "item"
    states = MODELS.parent.parent / "blockstates"
    body_texture().save(TEX / "ev_charger_body.png")
    for name, (accent, fast) in CHARGERS.items():
        lower_texture(name, accent, fast).save(TEX / f"ev_charger_{name}.png")
        upper_texture(name, accent, fast).save(TEX / f"ev_charger_{name}_top.png")
        path = MODELS / f"ev_charger_{name}.json"
        old = json.loads(path.read_text()) if path.exists() else {}
        display = old.get("display", {})
        common = {"body": "realplugs:block/ev_charger_body", "particle": "realplugs:block/ev_charger_body"}
        # lower half (the block with the block entity)
        write(path, {"parent": "minecraft:block/block",
                     "textures": {"front": f"realplugs:block/ev_charger_{name}", **common},
                     "display": display, "elements": lower_elements(fast, "#front")})
        # upper half
        write(MODELS / f"ev_charger_{name}_top.json", {
            "parent": "minecraft:block/block",
            "textures": {"front": f"realplugs:block/ev_charger_{name}_top", **common},
            "display": display, "elements": upper_elements(fast, "#front")})
        # item: both halves in one model (elements may reach y = 32), shown at half size
        write(item_dir / f"ev_charger_{name}.json", {
            "parent": "minecraft:block/block",
            "textures": {"front": f"realplugs:block/ev_charger_{name}", "upper": f"realplugs:block/ev_charger_{name}_top",
                         **common},
            "display": display_for(display, 0.5, -4),
            "elements": lower_elements(fast, "#front") + upper_elements(fast, "#upper", 16)})
        # blockstate of the upper half (horizontal facings only)
        variants = {f"facing={f}": ({"model": f"realplugs:block/ev_charger_{name}_top"} if y == 0 else
                                    {"model": f"realplugs:block/ev_charger_{name}_top", "y": y})
                    for f, y in (("north", 0), ("east", 90), ("south", 180), ("west", 270))}
        write(states / f"ev_charger_{name}_top.json", {"variants": variants})
        print("wrote", name)


if __name__ == "__main__":
    build()
