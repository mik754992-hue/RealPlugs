package com.realplugs;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.EntityRenderersEvent;

@EventBusSubscriber(modid = RealPlugsMod.MODID, bus = EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientSetup {
    @SubscribeEvent
    public static void registerRenderers(EntityRenderersEvent.RegisterRenderers event) {
        event.registerBlockEntityRenderer(ModBlockEntities.SOCKET.get(), PlugSocketRenderer::new);
        event.registerEntityRenderer(ModEntities.PLUG.get(), PlugEntityRenderer::new);
        event.registerEntityRenderer(ModEntities.PORT.get(), PortEntityRenderer::new);
    }
}
