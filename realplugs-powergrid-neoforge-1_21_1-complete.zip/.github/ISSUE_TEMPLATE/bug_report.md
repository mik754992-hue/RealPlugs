---
name: Bug report
about: Something is broken or crashes
labels: bug
---

**What happened?**

**What did you expect?**

**Steps to reproduce**
1.

**Versions**
- Real Plugs:
- Minecraft / NeoForge:
- Create / Create: Power Grid / Architectury:
- CC: Tweaked (if used):

**Log or crash report** (use a paste site such as mclo.gs for long logs)
