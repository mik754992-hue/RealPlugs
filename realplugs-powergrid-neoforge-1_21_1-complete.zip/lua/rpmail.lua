-- rpmail: mail for players. An SMTP-style server (port 25), a POP-style mailbox server (port 110) and a "webmail" page on port 80.
--   rpmail serve [slot] <domain>            run the mail server (accounts live in mail.db)
--   rpmail adduser <name> <password>        make an account (run on the server computer, before or after serve)
--   rpmail send <server> <from> <to> <subject> <text...>   send a message
--   rpmail inbox <server> <user> <password>                 list the mailbox
-- Addresses look like name@domain. Mail for another domain is handed to the mail server at that name (the domain is also its
-- network name), so two servers with different domains can exchange mail. Webmail: open http://<server>/mail in rpweb.
local web = require("rpweb")
local M = {}
local MAX_BOX, MAX_BODY, MAX_RCPT = 100, 8000, 10

local function addrParts(a)
  local u, d = tostring(a):match("^<?([%w_%.%-]+)@([%w%.%-]+)>?$")
  if u then return u:lower(), d:lower() end
end
M.addrParts = addrParts

function M.newStore() return { users = {}, boxes = {} } end
function M.addUser(store, name, pw)
  name = tostring(name):lower()
  if not name:match("^[%w_%-]+$") or #name > 16 then return nil, "names are 1 to 16 letters, digits, _ or -" end
  if #pw < 3 then return nil, "the password is too short" end
  if store.users[name] then return nil, "that account exists" end
  store.users[name] = web.hash(pw); store.boxes[name] = {}
  return true
end
function M.checkUser(store, name, pw)
  local h = store.users[tostring(name):lower()]
  return h ~= nil and h == web.hash(tostring(pw))
end
function M.deliver(store, user, msg)
  local box = store.boxes[user]
  if not box then return false end
  if #box >= MAX_BOX then table.remove(box, 1) end
  box[#box + 1] = { from = msg.from, to = msg.to, subject = msg.subject, body = msg.body, date = msg.date, read = false }
  return true
end

-- "From: a\nSubject: s\n\nbody" -> subject, body
function M.splitMessage(data)
  local head, body = data:match("^(.-)\n\n(.*)$")
  if not head then head, body = "", data end
  local subject = head:match("[Ss]ubject:%s*([^\n]*)") or ""
  return subject:sub(1, 60), body
end

-- The SMTP side. send(id, line) sends one line to a connection. remote(domain, msg) -> true or nil, why (for other domains).
function M.newSmtp(store, domain, send, remote, now)
  local S, sess = {}, {}
  now = now or function() return 0 end
  function S.connect(id) sess[id] = { state = "cmd", rcpt = {} }; send(id, "220 " .. domain .. " rpmail ready") end
  function S.disconnect(id) sess[id] = nil end
  function S.line(id, line)
    local s = sess[id]
    if not s then return end
    if s.state == "data" then
      if line == "." then
        s.state = "cmd"
        local subject, body = M.splitMessage(table.concat(s.data, "\n"))
        local failed
        for _, r in ipairs(s.rcpt) do
          local msg = { from = s.from, to = r.user .. "@" .. r.domain, subject = subject, body = body, date = now() }
          if r.domain == domain then M.deliver(store, r.user, msg)
          else
            local ok, why = remote(r.domain, msg)
            if not ok then failed = why or "could not forward" end
          end
        end
        s.rcpt, s.data = {}, nil
        send(id, failed and ("451 " .. failed) or "250 queued")
      else
        if line:sub(1, 2) == ".." then line = line:sub(2) end
        s.size = s.size + #line + 1
        if s.size <= MAX_BODY then s.data[#s.data + 1] = line end
      end
      return
    end
    local cmd, arg = line:match("^(%a+)%s*(.*)$")
    cmd = cmd and cmd:upper()
    if cmd == "HELO" or cmd == "EHLO" then send(id, "250 hello")
    elseif cmd == "MAIL" then
      local u, d = addrParts(arg:match("^[Ff][Rr][Oo][Mm]:%s*(.*)$") or "")
      if not u then send(id, "501 bad address") else s.from = u .. "@" .. d; s.rcpt = {}; send(id, "250 ok") end
    elseif cmd == "RCPT" then
      local u, d = addrParts(arg:match("^[Tt][Oo]:%s*(.*)$") or "")
      if not s.from then send(id, "503 MAIL first")
      elseif not u then send(id, "501 bad address")
      elseif #s.rcpt >= MAX_RCPT then send(id, "452 too many recipients")
      elseif d == domain and not store.users[u] then send(id, "550 no such user")
      elseif d ~= domain and not remote then send(id, "550 relaying not allowed")
      else s.rcpt[#s.rcpt + 1] = { user = u, domain = d }; send(id, "250 ok") end
    elseif cmd == "DATA" then
      if #s.rcpt == 0 then send(id, "503 RCPT first")
      else s.state, s.data, s.size = "data", {}, 0; send(id, "354 end with a line holding only a dot") end
    elseif cmd == "RSET" then s.from, s.rcpt = nil, {}; send(id, "250 ok")
    elseif cmd == "NOOP" then send(id, "250 ok")
    elseif cmd == "QUIT" then send(id, "221 bye"); return "close"
    else send(id, "500 unknown command") end
  end
  return S
end

-- The mailbox side (POP-like): USER, PASS, STAT, LIST, RETR n, DELE n, QUIT
function M.newPop(store, send)
  local P, sess = {}, {}
  function P.connect(id) sess[id] = {}; send(id, "+OK rpmail mailbox ready") end
  function P.disconnect(id) sess[id] = nil end
  function P.line(id, line)
    local s = sess[id]
    if not s then return end
    local cmd, arg = line:match("^(%a+)%s*(.*)$")
    cmd = cmd and cmd:upper()
    if cmd == "USER" then s.user = arg:lower(); send(id, "+OK")
    elseif cmd == "PASS" then
      if s.user and M.checkUser(store, s.user, arg) then s.auth = true; send(id, "+OK logged in")
      else s.auth = nil; send(id, "-ERR wrong name or password") end
    elseif cmd == "QUIT" then send(id, "+OK bye"); return "close"
    elseif not s.auth then send(id, "-ERR log in first")
    else
      local box = store.boxes[s.user] or {}
      local n = tonumber(arg)
      if cmd == "STAT" then send(id, "+OK " .. #box)
      elseif cmd == "LIST" then
        send(id, "+OK " .. #box)
        for i, m in ipairs(box) do send(id, i .. " " .. m.from .. " " .. m.subject) end
        send(id, ".")
      elseif cmd == "RETR" and box[n] then
        local m = box[n]; m.read = true
        send(id, "+OK message " .. n)
        local text = "From: " .. m.from .. "\nTo: " .. m.to .. "\nSubject: " .. m.subject .. "\n\n" .. m.body
        for l in (text .. "\n"):gmatch("([^\n]*)\n") do send(id, l:sub(1, 1) == "." and "." .. l or l) end
        send(id, ".")
      elseif cmd == "DELE" and box[n] then table.remove(box, n); send(id, "+OK deleted")
      else send(id, "-ERR no such message") end
    end
  end
  return P
end

-- ------------------------------------------------------------------ webmail (a route for rpweb: /mail)
function M.webRoute(store, domain)
  local sessions, count = {}, 0
  local esc = web.escape
  local function page(title, body, cookies)
    return { status = 200, mime = "text/html", cookies = cookies,
      body = "<html><title>" .. esc(title) .. "</title><body><h1>" .. esc(domain) .. " webmail</h1>" .. body .. "</body></html>" }
  end
  local function loginForm(msg)
    return page("webmail", (msg and ("<p><font color=\"red\">" .. esc(msg) .. "</font></p>") or "") ..
      '<form method="post" action="/mail"><input type="hidden" name="act" value="login">' ..
      'Name <input name="user" size="12"> Password <input type="password" name="pass" size="12"> <button>Log in</button></form>')
  end
  return function(req)
    local path = req.path or ""
    if path ~= "/mail" then return nil end
    local sid = req.cookies and req.cookies.rpmsid
    local user = sid and sessions[sid]
    local form = req.form or {}
    if form.act == "login" then
      if M.checkUser(store, form.user or "", form.pass or "") then
        local id = ""
        for _ = 1, 16 do id = id .. string.format("%x", math.random(0, 15)) end
        if count > 100 then sessions, count = {}, 0 end
        sessions[id] = form.user:lower(); count = count + 1
        return { status = 302, mime = "text/html", body = "", location = "/mail", cookies = { web.setCookieLine("rpmsid", id) } }
      end
      return loginForm("wrong name or password")
    end
    if not user then return loginForm() end
    local q = req.query or {}
    if q.logout then
      sessions[sid] = nil
      return { status = 302, mime = "text/html", body = "", location = "/mail", cookies = { web.setCookieLine("rpmsid", "", 0) } }
    end
    local box = store.boxes[user] or {}
    if form.act == "send" then
      local u, d = addrParts(form.to or "")
      local note
      if not u then note = "bad address"
      elseif d == domain and store.boxes[u] then
        M.deliver(store, u, { from = user .. "@" .. domain, to = u .. "@" .. d, subject = (form.subject or ""):sub(1, 60), body = (form.body or ""):sub(1, MAX_BODY), date = 0 })
        note = "sent"
      else note = "only addresses at " .. domain .. " work from webmail" end
      return page("webmail", "<p>" .. esc(note) .. '</p><p><a href="/mail">inbox</a></p>')
    end
    if form.act == "delete" and box[tonumber(form.n)] then table.remove(box, tonumber(form.n)); return { status = 302, mime = "text/html", body = "", location = "/mail" } end
    local n = tonumber(q.read)
    if n and box[n] then
      local m = box[n]; m.read = true
      return page("message", "<p>From: " .. esc(m.from) .. "<br>Subject: " .. esc(m.subject) .. "</p><pre>" .. esc(m.body) .. "</pre>" ..
        '<form method="post" action="/mail"><input type="hidden" name="act" value="delete"><input type="hidden" name="n" value="' .. n .. '"><button>Delete</button></form><p><a href="/mail">inbox</a></p>')
    end
    local rows = {}
    for i = #box, 1, -1 do
      local m = box[i]
      rows[#rows + 1] = (m.read and "" or "* ") .. '<a href="/mail?read=' .. i .. '">' .. esc(m.subject ~= "" and m.subject or "(no subject)") .. "</a> from " .. esc(m.from) .. "<br>"
    end
    return page("inbox", "<p>" .. esc(user .. "@" .. domain) .. ' - <a href="/mail?logout=1">log out</a></p>' ..
      (#rows == 0 and "<p>No mail.</p>" or table.concat(rows)) ..
      '<h2>Write</h2><form method="post" action="/mail"><input type="hidden" name="act" value="send">To <input name="to" size="24"><br>Subject <input name="subject" size="24"><br>' ..
      '<textarea name="body" rows="5" cols="30"></textarea><br><button>Send</button></form>')
  end
end

-- a client conversation helper's pure part: the lines to send for one message
function M.smtpScript(from, to, subject, body)
  local t = { "HELO client", "MAIL FROM:<" .. from .. ">", "RCPT TO:<" .. to .. ">", "DATA" }
  local text = "Subject: " .. subject .. "\n\n" .. body
  for l in (text .. "\n"):gmatch("([^\n]*)\n") do t[#t + 1] = l:sub(1, 1) == "." and "." .. l or l end
  t[#t + 1] = "."; t[#t + 1] = "QUIT"
  return t
end

if RPWEB_TEST then return M end
local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpmail" or running == "rpmail.lua") then return M end

local args = { ... }
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)

local function loadStore()
  local f = fs.open("mail.db", "r")
  local st = M.newStore()
  if f then st = textutils.unserialise(f.readAll()) or st; f.close() end
  return st
end
local function saveStore(st) local f = fs.open("mail.db", "w"); f.write(textutils.serialise(st)); f.close() end

-- sends the lines of `script` to host:port, one after each reply line that starts with `ok` (mail: "2" or "3")
local function converse(slot, host, port, script, okPrefix)
  local id, why = nic.connect(slot, host, port)
  if not id then return nil, why or "cannot connect" end
  local buf, step, timer = "", 0, os.startTimer(20)
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then return nil, "timed out" end
    if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot and ev[5] == id then
      if ev[4] == "data" then
        buf = buf .. tostring(ev[6])
        while true do
          local line, rest = buf:match("^([^\n]*)\n(.*)$")
          if not line then break end
          buf = rest
          line = line:gsub("\r", "")
          if line:sub(1, 1) == "4" or line:sub(1, 1) == "5" then pcall(nic.tcpClose, slot, id); return nil, line end
          step = step + 1
          if script[step] then nic.tcpSend(slot, id, script[step] .. "\r\n")
          else pcall(nic.tcpClose, slot, id); return true end
        end
      elseif ev[4] == "refused" or ev[4] == "closed" then return step >= #script and true or nil, "connection closed" end
    end
  end
end

local cmd = args[1]
if cmd == "adduser" and args[3] then
  local st = loadStore()
  local ok, why = M.addUser(st, args[2], args[3])
  if ok then saveStore(st); print("account " .. args[2] .. " created") else print(why) end
elseif cmd == "send" and args[6] then
  local from, to = args[3], args[4]
  local ok, why = converse(1, args[2], 25, M.smtpScript(from, to, args[5], table.concat(args, " ", 6)))
  print(ok and "sent" or ("failed: " .. tostring(why)))
elseif cmd == "inbox" and args[4] then
  local id = nic.connect(1, args[2], 110)
  if not id then error("cannot connect", 0) end
  local buf, step, script, timer = "", 0, { "USER " .. args[3], "PASS " .. args[4], "LIST", "QUIT" }, os.startTimer(15)
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then break end
    if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == 1 and ev[5] == id then
      if ev[4] == "data" then
        buf = buf .. tostring(ev[6])
        if step == 0 or buf:find("\n%.\r?\n") or buf:find("%-ERR") then
          if step == 0 then buf = ""; step = 1; nic.tcpSend(1, id, script[1] .. "\r\n")
          elseif step == 1 and buf:find("^%+OK") then buf = ""; step = 2; nic.tcpSend(1, id, script[2] .. "\r\n")
          elseif step == 2 then buf = ""; step = 3; nic.tcpSend(1, id, script[3] .. "\r\n")
          else print((buf:gsub("\r", ""))); pcall(nic.tcpClose, 1, id); break end
        elseif step == 1 and buf:find("\n") then buf = ""; step = 2; nic.tcpSend(1, id, script[2] .. "\r\n")
        end
      elseif ev[4] == "closed" or ev[4] == "refused" then break end
    end
  end
elseif cmd == "serve" and (args[2] or args[3]) then
  local slot = tonumber(args[2]) and tonumber(args[2]) or 1
  local domain = (tonumber(args[2]) and args[3] or args[2]):lower()
  local store = loadStore()
  local conns = {}
  local function sendLine(id, line) nic.tcpSend(slot, id, line .. "\r\n") end
  local function remote(d, msg)
    local ok, why = converse(slot, d, 25, M.smtpScript(msg.from, msg.to, msg.subject, msg.body))
    return ok, why
  end
  local smtp = M.newSmtp(store, domain, sendLine, remote, function() return os.epoch("utc") end)
  local pop = M.newPop(store, sendLine)
  local route = M.webRoute(store, domain)
  for _, port in ipairs({ 25, 110, 80 }) do nic.listen(slot, port) end
  print("mail server for " .. domain .. ": SMTP 25, mailboxes 110, webmail http://" .. domain .. "/mail   Ctrl+T stops")
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then for _, port in ipairs({ 25, 110, 80 }) do pcall(nic.unlisten, slot, port) end; return end
    if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot then
      local kind, id = ev[4], ev[5]
      if kind == "accepted" then
        local port = ev[8]
        if port == 25 or port == 110 or port == 80 then
          conns[id] = { port = port, buf = "" }
          if port == 25 then smtp.connect(id) elseif port == 110 then pop.connect(id) end
        end
      elseif kind == "closed" then
        local c = conns[id]
        if c then if c.port == 25 then smtp.disconnect(id) elseif c.port == 110 then pop.disconnect(id) end end
        conns[id] = nil
      elseif kind == "data" and conns[id] then
        local c = conns[id]
        c.buf = c.buf .. tostring(ev[6])
        if #c.buf > 20000 then nic.tcpClose(slot, id); conns[id] = nil
        elseif c.port == 80 then
          local req = web.parseRequest(c.buf)
          if req then
            local r = route(req) or { status = 404, mime = "text/html", body = "<h1>404</h1><p>webmail is at /mail</p>" }
            nic.tcpSend(slot, id, web.respond(r)); nic.tcpClose(slot, id); conns[id] = nil
            saveStore(store)
          end
        else
          while true do
            local line, rest = c.buf:match("^([^\n]*)\n(.*)$")
            if not line then break end
            c.buf = rest
            line = line:gsub("\r", "")
            local r = (c.port == 25 and smtp or pop).line(id, line)
            if r == "close" then nic.tcpClose(slot, id); conns[id] = nil; saveStore(store); break end
          end
        end
      end
    end
  end
else
  print("rpmail serve [slot] <domain> | adduser <name> <pw> | send <server> <from> <to> <subject> <text> | inbox <server> <user> <pw>")
end
return M
