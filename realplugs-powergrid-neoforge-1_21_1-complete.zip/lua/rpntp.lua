-- rpntp: network time.
--   rpntp serve [slot] [--zone hours] [--source utc|ingame]   run a time server (UDP port 123)
--   rpntp sync <host> [slot]    ask a time server 3 times, keep the best answer in /.rpntp
--   rpntp clock                 show the network time (needs a sync first)
-- Other programs can  require("rpntp").now()  to get the network time in milliseconds.
local M = {}
local PORT = 123
local FILE = ".rpntp"

function M.request(t1) return string.format("NTP1 %.0f", t1) end
function M.parseRequest(s) local t = tostring(s):match("^NTP1 (%d+)$"); return t and tonumber(t) end
function M.reply(t1, t2) return string.format("NTP1 %.0f %.0f", t1, t2) end
function M.parseReply(s)
  local a, b = tostring(s):match("^NTP1 (%d+) (%d+)$")
  if a then return tonumber(a), tonumber(b) end
end

-- t1 = client send time, t2 = server time, t4 = client receive time (all ms). Returns the clock offset and the round trip.
function M.offset(t1, t2, t4) return t2 - (t1 + t4) / 2, t4 - t1 end

-- the sample with the shortest round trip is the most trustworthy
function M.best(samples)
  local b
  for _, s in ipairs(samples) do if not b or s.rtt < b.rtt then b = s end end
  return b
end

-- milliseconds since 1970 (+ a zone in hours) -> year, month, day, hour, minute, second
function M.civil(ms, zone)
  local secs = math.floor(ms / 1000 + (zone or 0) * 3600)
  local days = math.floor(secs / 86400)
  local rem = secs - days * 86400
  local z = days + 719468
  local era = math.floor(z / 146097)
  local doe = z - era * 146097
  local yoe = math.floor((doe - math.floor(doe / 1460) + math.floor(doe / 36524) - math.floor(doe / 146096)) / 365)
  local y = yoe + era * 400
  local doy = doe - (365 * yoe + math.floor(yoe / 4) - math.floor(yoe / 100))
  local mp = math.floor((5 * doy + 2) / 153)
  local d = doy - math.floor((153 * mp + 2) / 5) + 1
  local m = mp < 10 and mp + 3 or mp - 9
  if m <= 2 then y = y + 1 end
  return y, m, d, math.floor(rem / 3600), math.floor(rem % 3600 / 60), rem % 60
end

function M.format(ms, zone)
  return string.format("%04d-%02d-%02d %02d:%02d:%02d", M.civil(ms, zone))
end

-- saved state: "offset zone" in one line
function M.parseState(text)
  local o, z = tostring(text or ""):match("^(%-?[%d%.]+) (%-?[%d%.]+)")
  if o then return { offset = tonumber(o), zone = tonumber(z) } end
  return { offset = 0, zone = 0 }
end

function M.now()
  local f = fs and fs.open(FILE, "r")
  local st = M.parseState(f and f.readAll())
  if f then f.close() end
  return os.epoch("utc") + st.offset, st
end

if RPWEB_TEST then return M end
local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpntp" or running == "rpntp.lua") then return M end

local args = { ... }
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)

local function udpAsk(slot, host, payload, timeout)
  local lp = 20000 + math.random(0, 9999)
  nic.listen(slot, lp)
  nic.send(slot, host, lp, PORT, payload)
  local timer = os.startTimer(timeout or 3)
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then pcall(nic.unlisten, slot, lp); return nil end
    if ev[1] == "realplugs_packet" and ev[2] == side and ev[3] == slot and ev[6] == lp then
      os.cancelTimer(timer); pcall(nic.unlisten, slot, lp); return ev[7]
    end
  end
end

local cmd = args[1]
if cmd == "serve" then
  local slot, zone, source = 1, 0, "utc"
  local i = 2
  while args[i] do
    if args[i] == "--zone" then zone = tonumber(args[i + 1]) or 0; i = i + 1
    elseif args[i] == "--source" then source = args[i + 1] or "utc"; i = i + 1
    elseif tonumber(args[i]) then slot = tonumber(args[i]) end
    i = i + 1
  end
  nic.listen(slot, PORT)
  print("time server on port " .. PORT .. " (" .. source .. ", zone " .. zone .. ")  Ctrl+T stops")
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then pcall(nic.unlisten, slot, PORT); return end
    if ev[1] == "realplugs_packet" and ev[2] == side and ev[3] == slot and ev[6] == PORT then
      local t1 = M.parseRequest(ev[7])
      if t1 then nic.send(slot, ev[4], PORT, ev[5], M.reply(t1, os.epoch(source) + zone * 3600000)) end
    end
  end
elseif cmd == "sync" and args[2] then
  local slot = tonumber(args[3]) or 1
  local samples = {}
  for _ = 1, 3 do
    local t1 = os.epoch("utc")
    local raw = udpAsk(slot, args[2], M.request(t1))
    local t4 = os.epoch("utc")
    local a, t2 = M.parseReply(raw)
    if a == t1 then local o, rtt = M.offset(t1, t2, t4); samples[#samples + 1] = { offset = o, rtt = rtt } end
  end
  local b = M.best(samples)
  if not b then error("no answer from " .. args[2], 0) end
  local f = fs.open(FILE, "w"); f.write(string.format("%.0f 0", b.offset)); f.close()
  print(string.format("clock offset %+.0f ms (round trip %.0f ms)", b.offset, b.rtt))
elseif cmd == "clock" then
  while true do
    local ms = M.now()
    term.clear(); term.setCursorPos(1, 1)
    print("network time (UTC)"); print(M.format(ms, 0))
    sleep(1)
  end
else
  print("rpntp serve [slot] [--zone h] [--source utc|ingame] | sync <host> [slot] | clock")
end
return M
