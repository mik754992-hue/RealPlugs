package com.realplugs.numismatics;

import dev.ithundxr.createnumismatics.Numismatics;
import dev.ithundxr.createnumismatics.content.backend.BankAccount;
import dev.ithundxr.createnumismatics.content.backend.IDeductable;
import dev.ithundxr.createnumismatics.content.backend.ReasonHolder;
import dev.ithundxr.createnumismatics.content.bank.AuthorizedCardItem;
import dev.ithundxr.createnumismatics.content.bank.CardItem;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

import java.util.UUID;

/**
 * Paying with a Create: Numismatics card. Only ever touched when Numismatics is loaded (see EvChargerBlock), so the
 * Numismatics classes it references always exist. Uses the same entry point as Numismatics' own depositor:
 * IDeductable.get(card, player, reason) finds the account behind the card (and checks the player may use it),
 * deduct(spurs, reason) takes the money. Server side only.
 */
public final class NumismaticsPay {
    private NumismaticsPay() {}

    /** Takes the amount (in spurs) from the card's account. Returns null on success, else why it failed. */
    public static Component pay(ItemStack card, Player player, int spurs) {
        ReasonHolder reason = new ReasonHolder();
        IDeductable account = IDeductable.get(card, player, reason);
        if (account == null) return reason.getMessageOrDefault(Component.translatable("message.realplugs.ev_card_invalid"));
        if (account.deduct(spurs, reason)) return null;
        return reason.getMessageOrDefault();
    }

    /** The bank account behind a card (the main account for an authorized card), or null if it is not bound. */
    public static UUID accountOf(ItemStack card) {
        if (card.getItem() instanceof CardItem) return CardItem.isBound(card) ? CardItem.get(card) : null;
        if (card.getItem() instanceof AuthorizedCardItem && AuthorizedCardItem.isBound(card)) {
            AuthorizedCardItem.AuthorizationPair pair = AuthorizedCardItem.get(card);
            return pair == null ? null : pair.accountID();
        }
        return null;
    }

    /** Puts money back into an account (the deposit call). Returns false if the account no longer exists. */
    public static boolean refund(UUID accountId, int spurs) {
        BankAccount account = Numismatics.BANK.getAccount(accountId);
        if (account == null) return false;
        account.deposit(spurs);
        Numismatics.BANK.markBankDirty();
        return true;
    }
}
