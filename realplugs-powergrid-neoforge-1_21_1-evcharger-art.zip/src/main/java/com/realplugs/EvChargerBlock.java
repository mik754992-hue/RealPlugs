package com.realplugs;

import com.mojang.math.Axis;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Quaternionf;
import org.joml.Vector3f;

/**
 * A pay-to-charge EV charger: one slot of an EV connector, fed by the input connectors on its sides like any outlet.
 * The slot only passes power while there is credit, and the credit runs down per minute while something is plugged in
 * or a cord is attached. Pay by right-clicking the gold coin panel on the front with coins (sneak to insert the whole
 * stack). Coin values come from item tags, see EvCoins.
 *
 * Every charger has a built-in cord: its connector sits docked in the socket. Right-click the socket (or the cable
 * gland below the coin panel) with an empty hand to pull the cord out, and again to put it back. While it is out the
 * slot counts as occupied, exactly as if a cord were plugged in (the slot closes and the credit runs down); it docks
 * itself if you walk more than PocketTether.RANGE away. A plug placed in the socket works as before.
 */
public class EvChargerBlock extends PlugSocketBlock {
    private final int pricePerMinute;

    public EvChargerBlock(Properties props, SocketDef def, int pricePerMinute) {
        super(props, def);
        this.pricePerMinute = pricePerMinute;
    }

    public int pricePerMinute() {
        return pricePerMinute;
    }

    /** Spurs per minute: wall boxes are cheap, fast chargers cost more. */
    public static int pricePerMinute(String id) {
        return switch (id) {
            case "ev_charger_type1", "ev_charger_type2" -> 2;
            case "ev_charger_ccs", "ev_charger_chademo" -> 6;
            default -> 8;
        };
    }

    /** Chargers stand upright: on a floor or ceiling they face the way the player is looking, not up or down. */
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        Direction d = ctx.getClickedFace().getAxis().isHorizontal() ? ctx.getClickedFace() : ctx.getHorizontalDirection().getOpposite();
        return defaultBlockState().setValue(FACING, d);
    }

    /** Where on the front plate (north frame, 1/16 units: x to the viewer's left, y up) a world hit position is. */
    private Vector3f frontPoint(BlockState state, BlockPos pos, Vec3 hit) {
        Direction f = state.getValue(FACING);
        if (!f.getAxis().isHorizontal()) return new Vector3f(-1, -1, -1);
        Quaternionf q = Axis.YP.rotationDegrees(-(f.toYRot() + 180f));
        Vector3f v = new Vector3f((float) (hit.x - pos.getX() - 0.5), (float) (hit.y - pos.getY() - 0.5), (float) (hit.z - pos.getZ() - 0.5));
        q.conjugate(new Quaternionf()).transform(v);
        return new Vector3f((v.x + 0.5f) * 16f, (v.y + 0.5f) * 16f, (v.z + 0.5f) * 16f);
    }

    /** The gold coin panel on the front. */
    private boolean onCoinPanel(BlockState state, BlockPos pos, BlockHitResult hit) {
        Vector3f p = frontPoint(state, pos, hit.getLocation());
        return p.x >= 5 && p.x <= 11 && p.y >= 2.5f && p.y <= 5.5f;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
            int coin = EvCoins.valueOf(held);
            if (coin > 0 && onCoinPanel(state, pos, hit)) {
                if (!level.isClientSide) {
                    int n = player.isShiftKeyDown() ? held.getCount() : 1;
                    be.addCredit(coin * n);
                    if (!player.getAbilities().instabuild) held.shrink(n);
                    player.displayClientMessage(Component.translatable("message.realplugs.ev_credit", be.credit(), pricePerMinute), true);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (EvCoins.isNumismaticsCard(held) && onCoinPanel(state, pos, hit)) {
                if (!level.isClientSide) {
                    player.displayClientMessage(Component.translatable("message.realplugs.ev_card_unsupported"), true);
                }
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return super.useItemOn(held, state, level, pos, player, hand, hit);
    }

    /** The dock (the connector socket) and the cable gland, where the built-in cord is pulled out and put back. */
    private boolean onCordDock(Vector3f p) {
        boolean socket = p.x >= 5 && p.x <= 11 && p.y >= 6 && p.y <= 12;
        boolean gland = p.x >= 10.8f && p.x <= 13 && p.y >= 1.4f && p.y <= 3.4f;
        return socket || gland;
    }

    /** Empty hand on the dock: pull the built-in cord out, or put it back if you are the one holding it. */
    private void toggleBuiltinCord(PlugSocketBlockEntity be, Level level, Player player) {
        if (be.hasPgCord(0)) {
            player.displayClientMessage(Component.translatable("message.realplugs.cord_slot_taken"), true);
        } else if (be.builtinCordHolder() != null) {
            if (be.builtinCordHolder().equals(player.getUUID())) {
                be.dockBuiltinCord();
                player.displayClientMessage(Component.translatable("message.realplugs.ev_cord_docked"), true);
            } else {
                player.displayClientMessage(Component.translatable("message.realplugs.ev_cord_in_use"), true);
            }
        } else if (be.tetherOwner(0) != null) {
            player.displayClientMessage(Component.translatable("message.realplugs.ev_cord_in_use"), true);
        } else {
            be.pullBuiltinCord(player, level.getGameTime());
            player.displayClientMessage(Component.translatable(be.credit() > 0
                    ? "message.realplugs.ev_cord_out" : "message.realplugs.ev_cord_out_no_credit"), true);
        }
    }

    /** Empty hand on the panel or the screen: show the credit and price. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        Vector3f p = frontPoint(state, pos, hit.getLocation());
        if (p.y >= 2.5f && p.y <= 15.5f && p.x >= 4 && p.x <= 12 && (p.y >= 12 || onCoinPanel(state, pos, hit))) {
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
                player.displayClientMessage(Component.translatable("message.realplugs.ev_status", be.credit(), pricePerMinute), true);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (player.getMainHandItem().isEmpty() && onCordDock(p)
                && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be && be.plugs().get(0).isEmpty()) {
            if (!level.isClientSide) toggleBuiltinCord(be, level, player);
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return super.useWithoutItem(state, level, pos, player, hit);
    }
}
