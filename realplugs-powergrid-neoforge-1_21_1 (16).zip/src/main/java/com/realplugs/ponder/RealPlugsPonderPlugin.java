package com.realplugs.ponder;

import com.realplugs.RealPlugsMod;
import net.createmod.ponder.api.registration.PonderPlugin;
import net.createmod.ponder.api.registration.PonderSceneRegistrationHelper;
import net.minecraft.resources.ResourceLocation;

/** Registers the Real Plugs Ponder scenes. The schematics live in assets/realplugs/ponder/. */
public class RealPlugsPonderPlugin implements PonderPlugin {
    @Override
    public String getModId() {
        return RealPlugsMod.MODID;
    }

    @Override
    public void registerScenes(PonderSceneRegistrationHelper<ResourceLocation> helper) {
        // one scene shared by several items: strips, hubs and panels (airport schematic)
        helper.forComponents(rls("universal_power_strip", "usb_hub", "power_strip", "eu_power_strip",
                        "uk_power_strip", "au_power_strip", "av_panel"))
                .addStoryBoard("airport_showcase", RealPlugsScenes::chargingIsland);

        // wall outlets (house schematic)
        helper.forComponents(rls("outlet", "eu_outlet", "uk_outlet", "au_outlet", "dc_outlet"))
                .addStoryBoard("house_showcase", RealPlugsScenes::wallOutlet);

        // plugs and adapters (house schematic)
        helper.forComponents(rls("plug", "adapter"))
                .addStoryBoard("house_showcase", RealPlugsScenes::plugsAndAdapters);

        // cords (airport schematic)
        helper.forComponents(rls("plug_cord"))
                .addStoryBoard("airport_showcase", RealPlugsScenes::cords);
    }

    private static ResourceLocation[] rls(String... paths) {
        ResourceLocation[] out = new ResourceLocation[paths.length];
        for (int i = 0; i < paths.length; i++) out[i] = rl(paths[i]);
        return out;
    }

    private static ResourceLocation rl(String path) {
        return ResourceLocation.fromNamespaceAndPath(RealPlugsMod.MODID, path);
    }
}
