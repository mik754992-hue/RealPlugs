package com.realplugs.cc;

import com.realplugs.PlugSocketBlockEntity;
import com.realplugs.gui.ConfigBridge;
import com.realplugs.net.NetConfig;
import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.MethodResult;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;

import java.util.Optional;

/**
 * What the Network Configurator screen shows and does. Every change goes through the same methods a computer would call
 * (SocketPeripheral), so a setting means exactly the same and is checked exactly the same from the screen and from Lua.
 * Only touched when CC: Tweaked is loaded.
 */
public final class ConfigBackend implements ConfigBridge.Backend {
    private static CompoundTag field(String id, String label, String value, String type, String choices) {
        CompoundTag f = new CompoundTag();
        f.putString("id", id);
        f.putString("label", label);
        f.putString("value", value);
        f.putString("type", type);
        f.putString("choices", choices);
        return f;
    }

    private static CompoundTag text(String id, String label, String value) {
        return field(id, label, value == null ? "" : value, "text", "");
    }

    private static CompoundTag bool(String id, String label, boolean v) {
        return field(id, label, v ? "true" : "false", "bool", "");
    }

    @Override
    public CompoundTag view(PlugSocketBlockEntity be) {
        NetConfig c = be.net();
        CompoundTag out = new CompoundTag();
        boolean router = be.isRouterBlock(), sw = be.isSwitchBlock(), ap = be.isAccessPointBlock();
        out.putString("title", ap ? "Wi-Fi access point" : router ? "Network router" : sw ? "Network switch" : "Network socket");
        ListTag info = new ListTag();
        info.add(StringTag.valueOf("firewall stopped " + c.fwBlocked + " packets"));
        out.put("info", info);
        ListTag pages = new ListTag();

        if (ap) {
            CompoundTag p = new CompoundTag();
            p.putString("title", "Wi-Fi");
            ListTag f = new ListTag();
            f.add(text("apSsid", "Name", c.apSsid));
            f.add(text("apKey", "Password", c.apKey));
            f.add(text("apRange", "Range", Integer.toString(c.apRange)));
            f.add(text("guestSsid", "Guest name", c.apGuestSsid));
            f.add(text("guestKey", "Guest pass", c.apGuestKey));
            p.put("fields", f);
            pages.add(p);
        }
        if (router || sw || !ap) {
            CompoundTag p = new CompoundTag();
            p.putString("title", router ? "Router and firewall" : "Firewall");
            ListTag f = new ListTag();
            f.add(field("fwPolicy", "Firewall", c.fwPolicy, "choice", "allow,reject,drop"));
            if (router) {
                long ip = NetConfig.parse(c.ip(0));
                long base = ip < 0 || c.prefix[0] < 1 ? -1 : ip & ((0xFFFFFFFFL << (32 - c.prefix[0])) & 0xFFFFFFFFL);
                boolean has = base >= 0 && c.dhcpFirst[0] > 0;
                f.add(text("dhcpFirst", "DHCP from", has ? NetConfig.format(base + c.dhcpFirst[0]) : ""));
                f.add(text("dhcpLast", "DHCP to", has ? NetConfig.format(base + c.dhcpLast[0]) : ""));
            }
            p.put("fields", f);
            pages.add(p);
        }
        for (int s = 0; s < be.plugs().size(); s++) {
            if (!be.isRj45(s)) continue;
            int n = s + 1;
            CompoundTag p = new CompoundTag();
            p.putString("title", "Port " + n + (c.uplink[s] ? " (uplink)" : router && s == PlugSocketBlockEntity.ROUTER_WAN ? " (WAN)" : ""));
            ListTag f = new ListTag();
            f.add(text("ip" + n, "Address", c.ip(s)));
            f.add(text("prefix" + n, "Net size", c.prefix[s] == 0 ? "" : Integer.toString(c.prefix[s])));
            f.add(text("gw" + n, "Gateway", c.gateway(s)));
            f.add(bool("dhcp" + n, "DHCP server", c.dhcp[s]));
            f.add(text("vlan" + n, "VLAN", Integer.toString(c.vlan[s])));
            f.add(text("host" + n, "Hostname", c.hostname(s)));
            f.add(text("qosRate" + n, "Limit pkt/s", Integer.toString(c.qosRate[s])));
            f.add(text("qosDelay" + n, "Extra delay", Integer.toString(c.qosDelay[s])));
            if (router && s == PlugSocketBlockEntity.ROUTER_WAN) {
                f.add(field("range" + n, "Public pool", com.realplugs.net.PublicRange.byIndex(c.uplinkRange[s]).id, "choice", "isp,wide,compact"));
            }
            if (!ap) {
                f.add(text("roam" + n, "Roam margin", Integer.toString(c.roamMargin(s))));
                f.add(text("wifiSsid" + n, "Join Wi-Fi", c.wifiSsid(s)));
                f.add(text("wifiKey" + n, "Wi-Fi pass", c.wifiKey(s)));
            }
            p.put("fields", f);
            pages.add(p);
        }
        out.put("pages", pages);
        return out;
    }

    // ---------------------------------------------------------------- apply

    private static String err(MethodResult r) {
        Object[] o = r.getResult();
        if (o == null || o.length == 0) return null;
        if (o[0] == null || Boolean.FALSE.equals(o[0])) return o.length > 1 ? String.valueOf(o[1]) : "that did not work";
        return null;
    }

    private static int num(String s, int dflt) {
        try {
            return Integer.parseInt(s.trim());
        } catch (NumberFormatException e) {
            return dflt;
        }
    }

    @Override
    public String apply(PlugSocketBlockEntity be, CompoundTag ch) {
        SocketPeripheral p = new SocketPeripheral(be);
        NetConfig c = be.net();
        StringBuilder problems = new StringBuilder();
        int done = 0;
        try {
            if (ch.contains("fwPolicy")) { note(problems, err(p.setFirewallPolicy(ch.getString("fwPolicy")))); done++; }
            if (ch.contains("dhcpFirst") || ch.contains("dhcpLast")) {
                String a = ch.contains("dhcpFirst") ? ch.getString("dhcpFirst") : null;
                String z = ch.contains("dhcpLast") ? ch.getString("dhcpLast") : null;
                long ip = NetConfig.parse(c.ip(0));
                long base = ip < 0 || c.prefix[0] < 1 ? -1 : ip & ((0xFFFFFFFFL << (32 - c.prefix[0])) & 0xFFFFFFFFL);
                if (a == null) a = c.dhcpFirst[0] > 0 && base >= 0 ? NetConfig.format(base + c.dhcpFirst[0]) : "";
                if (z == null) z = c.dhcpLast[0] > 0 && base >= 0 ? NetConfig.format(base + c.dhcpLast[0]) : "";
                if (!a.isBlank() && !z.isBlank()) { note(problems, err(p.setDhcpRange(1, a.trim(), z.trim()))); done++; }
            }
            if (ch.contains("apSsid") || ch.contains("apKey")) {
                String ssid = ch.contains("apSsid") ? ch.getString("apSsid") : c.apSsid;
                String key = ch.contains("apKey") ? ch.getString("apKey") : c.apKey;
                note(problems, err(p.setAccessPoint(ssid, Optional.of(key)))); done++;
            }
            if (ch.contains("apRange")) { note(problems, err(p.setWifiRange(num(ch.getString("apRange"), 0)))); done++; }
            if (ch.contains("guestSsid") || ch.contains("guestKey")) {
                String ssid = ch.contains("guestSsid") ? ch.getString("guestSsid") : c.apGuestSsid;
                String key = ch.contains("guestKey") ? ch.getString("guestKey") : c.apGuestKey;
                if (ssid.isBlank()) p.clearGuestNetwork(); else note(problems, err(p.setGuestNetwork(ssid, Optional.of(key))));
                done++;
            }
            for (int s = 0; s < be.plugs().size(); s++) {
                if (!be.isRj45(s)) continue;
                int n = s + 1;
                if (ch.contains("ip" + n) || ch.contains("prefix" + n) || ch.contains("gw" + n)) {
                    String ip = ch.contains("ip" + n) ? ch.getString("ip" + n) : c.ip(s);
                    int prefix = ch.contains("prefix" + n) ? num(ch.getString("prefix" + n), 0) : c.prefix[s];
                    String gw = ch.contains("gw" + n) ? ch.getString("gw" + n) : c.gateway(s);
                    if (ip.isBlank()) p.clearAddress(n);
                    else note(problems, err(p.setAddress(n, ip.trim(), prefix, Optional.of(gw.trim()))));
                    done++;
                }
                if (ch.contains("dhcp" + n)) { p.setDhcp(n, ch.getString("dhcp" + n).equals("true")); done++; }
                if (ch.contains("vlan" + n)) { note(problems, err(p.setVlan(n, num(ch.getString("vlan" + n), 0)))); done++; }
                if (ch.contains("host" + n)) { note(problems, err(p.setHostname(n, ch.getString("host" + n).trim()))); done++; }
                if (ch.contains("qosRate" + n) || ch.contains("qosDelay" + n)) {
                    int rate = ch.contains("qosRate" + n) ? num(ch.getString("qosRate" + n), 0) : c.qosRate[s];
                    int delay = ch.contains("qosDelay" + n) ? num(ch.getString("qosDelay" + n), 0) : c.qosDelay[s];
                    note(problems, err(p.setQos(n, rate, delay))); done++;
                }
                if (ch.contains("range" + n)) { note(problems, err(p.setPublicRange(n, ch.getString("range" + n)))); done++; }
                if (ch.contains("roam" + n)) { note(problems, err(p.setRoaming(n, num(ch.getString("roam" + n), NetConfig.ROAM_DEFAULT)))); done++; }
                if (ch.contains("wifiSsid" + n) || ch.contains("wifiKey" + n)) {
                    String ssid = ch.contains("wifiSsid" + n) ? ch.getString("wifiSsid" + n) : c.wifiSsid(s);
                    String key = ch.contains("wifiKey" + n) ? ch.getString("wifiKey" + n) : c.wifiKey(s);
                    if (ssid.isBlank()) p.leaveWifi(n); else note(problems, err(p.joinWifi(n, ssid.trim(), Optional.of(key))));
                    done++;
                }
            }
        } catch (LuaException e) {
            note(problems, e.getMessage());
        }
        if (problems.length() > 0) return "Not everything worked: " + problems;
        return done == 0 ? "Nothing to change." : "Saved.";
    }

    private static void note(StringBuilder sb, String problem) {
        if (problem == null) return;
        if (sb.length() > 0) sb.append("; ");
        sb.append(problem);
    }
}
