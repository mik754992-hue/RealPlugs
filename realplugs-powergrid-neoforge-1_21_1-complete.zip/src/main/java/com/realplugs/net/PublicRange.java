package com.realplugs.net;

/** The address pool an uplink (a modem) takes its public address from. Chosen per uplink port before it is switched on. */
public enum PublicRange {
    ISP("isp", 0x64400000L, 0x400000L, "100.64.0.0/10"),
    WIDE("wide", 0x2C000000L, 0x1000000L, "44.0.0.0/8"),
    COMPACT("compact", 0xC6120000L, 0x20000L, "198.18.0.0/15");

    public final String id;
    public final long base;
    public final long size;
    public final String cidr;

    PublicRange(String id, long base, long size, String cidr) {
        this.id = id;
        this.base = base;
        this.size = size;
        this.cidr = cidr;
    }

    public static PublicRange byId(String id) {
        for (PublicRange r : values()) if (r.id.equalsIgnoreCase(id)) return r;
        return null;
    }

    public static PublicRange byIndex(int i) {
        return i >= 0 && i < values().length ? values()[i] : ISP;
    }
}
