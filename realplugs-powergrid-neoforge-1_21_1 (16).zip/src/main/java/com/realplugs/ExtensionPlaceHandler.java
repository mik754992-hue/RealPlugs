package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.component.TypedDataComponent;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.patryk3211.powergrid.electricity.base.ITerminalPlacement;
import org.patryk3211.powergrid.electricity.wire.BlockWireEndpoint;
import org.patryk3211.powergrid.electricity.wire.IWireEndpoint;
import org.patryk3211.powergrid.electricity.wire.WireConnection;
import org.patryk3211.powergrid.electricity.wire.powercord.AutoCordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.IAcceptCord;
import org.patryk3211.powergrid.electricity.wire.powercord.ICordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.ICordPlacementHandler;

/**
 * Registered in front of Power Grid's handler. For an extension cable:
 *  - first click on a free slot of the cable's connector: the plug end goes in (same checks as plug cords);
 *  - second click on a surface: the strip end block is placed on the clicked face and the cord ends on it.
 */
public class ExtensionPlaceHandler implements ICordPlacementHandler {
    /** How far apart the two ends may be (Power Grid's cords stop at 16). */
    private static final double MAX_DISTANCE = 15.0;

    private final IAcceptCord.Handler stock = new IAcceptCord.Handler();

    @Override
    public InteractionResultHolder<ICordEndpoint> place(BlockState state, UseOnContext ctx) {
        ItemStack held = ctx.getItemInHand();
        if (!(held.getItem() instanceof ExtensionCableItem)) return InteractionResultHolder.pass(null);

        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        ExtensionTypes.Def def = ExtensionCableItem.defOf(held);

        BlockPos firstPos = null;
        for (TypedDataComponent<?> c : held.getComponents()) {
            if (c.value() instanceof WireConnection wc && wc.hasHalf()) {
                IWireEndpoint half = wc.half();
                if (half instanceof AutoCordEndpoint auto) firstPos = auto.getEndpoint1().getPos();
                else if (half instanceof BlockWireEndpoint b) firstPos = b.getPos();
                else firstPos = BlockPos.ZERO;
            }
        }

        // ---- first end: a free slot that takes this cable's plug ----
        if (firstPos == null) {
            if (!(state.getBlock() instanceof PlugSocketBlock block) || block instanceof PortAnchorBlock) {
                return InteractionResultHolder.pass(null);
            }
            BlockPos pos = ctx.getClickedPos();
            int slot = block.slotAtHit(state, pos, ctx.getClickLocation());
            PlugTypes.Standard here = block.def.slots()[slot];
            if (here != def.plug()) {
                tell(level, player, Component.translatable("message.realplugs.cord_wrong_slot",
                        Component.translatable(def.plug().langKey()), Component.translatable(def.plug().langKey()),
                        Component.translatable(here.langKey())));
                return InteractionResultHolder.fail(null);
            }
            if (level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be
                    && (!be.plugs().get(slot).isEmpty() || be.hasCord(slot))) {
                tell(level, player, Component.translatable("message.realplugs.cord_slot_taken"));
                return InteractionResultHolder.fail(null);
            }
            return InteractionResultHolder.success(block.getEndpoint(ctx));
        }

        // ---- second end: place the strip on a surface ----
        if (state.getBlock() instanceof IAcceptCord) {
            tell(level, player, Component.translatable("message.realplugs.extension_surface"));
            return InteractionResultHolder.fail(null);
        }
        Direction face = ctx.getClickedFace();
        BlockPos target = ctx.getClickedPos().relative(face);
        if (!level.getBlockState(target).canBeReplaced()) {
            tell(level, player, Component.translatable("message.realplugs.extension_no_room"));
            return InteractionResultHolder.fail(null);
        }
        if (Vec3.atCenterOf(target).distanceTo(Vec3.atCenterOf(firstPos)) > MAX_DISTANCE) {
            tell(level, player, Component.translatable("message.realplugs.extension_too_far"));
            return InteractionResultHolder.fail(null);
        }
        if (!(ModBlocks.SOCKETS.get(def.endBlock()).get() instanceof ExtensionEndBlock end)) {
            return InteractionResultHolder.fail(null);
        }
        BlockState placed = end.withFront(face);
        if (!level.isClientSide) {
            level.setBlock(target, placed, 3);
            // make sure the new block's electrical side is ready before Power Grid connects the cord to it
            if (level.getBlockEntity(target) instanceof PlugSocketBlockEntity be) be.tick();
        }
        Vec3 centre = end.slotWorldPos(placed, target, 1).add(end.slotWorldPos(placed, target, 2)).scale(0.5);
        return InteractionResultHolder.success(new AutoCordEndpoint(target, 0, 1, centre, face));
    }

    @Override
    public ITerminalPlacement terminal(BlockState state, Level level, BlockHitResult hit) {
        return stock.terminal(state, level, hit);
    }

    private static void tell(Level level, Player player, Component msg) {
        if (!level.isClientSide && player != null) player.displayClientMessage(msg, true);
    }
}
