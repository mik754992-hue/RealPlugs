#!/usr/bin/env python3
"""Generates the Network Switch block (4 RJ45 ports, always bridged) from the av_panel model.
Run from the repo root: python3 scripts/gen_network_switch.py. Idempotent."""
import copy
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "src/main/resources"
A = RES / "assets/realplugs"
D = RES / "data/realplugs"
ID = "network_switch"

# palette cells (4x4 px each) used by the models: uv inside the cell is enough
GRAPHITE = [9, 1, 11, 3]
GREEN = [1, 9, 3, 11]
WHITE = [1, 1, 3, 3]


def faces(uv):
    return {f: {"uv": uv, "texture": "#p"} for f in ("north", "east", "south", "west", "up", "down")}


def box(frm, to, uv):
    return {"from": frm, "to": to, "faces": faces(uv)}


def shifted(el, dx):
    e = copy.deepcopy(el)
    e["from"][0] = round(e["from"][0] + dx, 4)
    e["to"][0] = round(e["to"][0] + dx, 4)
    return e


def main():
    src = json.loads((A / "models/block/av_panel.json").read_text())
    els = src["elements"]
    out = []
    plate = copy.deepcopy(els[0])
    plate["faces"] = faces(GRAPHITE)
    out.append(plate)
    out.extend(copy.deepcopy(e) for e in els[1:9])            # the four port frames
    out.extend(copy.deepcopy(e) for e in els[9:15])           # RJ45 jacks of slots 0 and 1
    out.extend(shifted(e, -4) for e in els[12:15])             # RJ45 jacks of slot 2
    out.extend(shifted(e, -8) for e in els[12:15])             # RJ45 jacks of slot 3
    out.extend(copy.deepcopy(e) for e in els[19:21])           # side terminals
    for xc in (14, 10, 6, 2):                                  # one link light per port
        out.append(box([xc - 0.5, 11.2, 11.7], [xc + 0.5, 12.0, 12.0], GREEN))
    out.append(box([1, 2.4, 11.9], [15, 3.2, 12.0], WHITE))    # label strip
    model = {"parent": "minecraft:block/block", "textures": src["textures"], "elements": out}
    (A / f"models/block/{ID}.json").write_text(json.dumps(model, indent=1) + "\n")

    state = json.loads((A / "blockstates/av_panel.json").read_text())
    text = json.dumps(state, indent=1).replace("realplugs:block/av_panel", f"realplugs:block/{ID}")
    (A / f"blockstates/{ID}.json").write_text(text + "\n")
    (A / f"models/item/{ID}.json").write_text(json.dumps({"parent": f"realplugs:block/{ID}"}, indent=1) + "\n")

    loot = (D / "loot_table/blocks/power_strip.json").read_text().replace("realplugs:power_strip", f"realplugs:{ID}")
    (D / f"loot_table/blocks/{ID}.json").write_text(loot)
    recipe = {"type": "minecraft:crafting_shapeless", "category": "redstone",
              "ingredients": [{"item": "realplugs:av_panel"}, {"item": "realplugs:av_panel"}, {"item": "minecraft:iron_ingot"}],
              "result": {"id": f"realplugs:{ID}", "count": 1}}
    (D / f"recipe/{ID}.json").write_text(json.dumps(recipe, indent=1) + "\n")

    lang_path = A / "lang/en_us.json"
    lang = json.loads(lang_path.read_text())
    lang[f"block.realplugs.{ID}"] = "Network Switch"
    lang_path.write_text(json.dumps(lang, indent=1, ensure_ascii=False) + "\n")

    tag_path = RES / "data/minecraft/tags/block/mineable/pickaxe.json"
    tag = json.loads(tag_path.read_text())
    if f"realplugs:{ID}" not in tag["values"]:
        tag["values"].append(f"realplugs:{ID}")
    tag_path.write_text(json.dumps(tag, indent=1) + "\n")

    defs = ROOT / "src/main/java/com/realplugs/SocketDefs.java"
    s = defs.read_text()
    if f'"{ID}"' not in s:
        line = ('        new SocketDef("%s", 0, 16, 2, 14, 4, new PlugTypes.Standard[]{PlugTypes.Standard.RJ45, PlugTypes.Standard.RJ45, '
                'PlugTypes.Standard.RJ45, PlugTypes.Standard.RJ45})\n' % ID)
        s = re.sub(r'(new SocketDef\("ev_charger_nacs"[^\n]*\))\n', lambda m: m.group(1) + ",\n" + line, s, count=1)
        defs.write_text(s)
    print("ok")


if __name__ == "__main__":
    main()
