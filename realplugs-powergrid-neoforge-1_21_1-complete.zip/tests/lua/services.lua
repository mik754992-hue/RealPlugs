RPWEB_TEST = true
package.path = "lua/?.lua;" .. package.path
local fails = 0
local function eq(a,b,w) if a~=b then print("FAIL "..w..": got "..tostring(a).." expected "..tostring(b)); fails=fails+1 else print("  ok  "..w) end end
local web = dofile("lua/rpweb.lua")

-- ---- rpweb: cookies, logins, time limit, colours, button
local jar = {}
web.storeCookies(jar, "h", "a=1; Path=/\nb=x%20y; Path=/")
eq(web.cookieHeader(jar, "h"), "a=1; b=x%20y", "cookie header")
web.storeCookies(jar, "h", "a=; Path=/; Max-Age=0"); eq(web.cookieHeader(jar, "h"), "b=x%20y", "cookie deleted")
eq(web.parseCookies("a=1; b=x%20y").b, "x y", "parse cookies")
eq(web.parseRequest("GET / HTTP/1.0\r\nCookie: k=v\r\n\r\n").cookies.k, "v", "request cookies")
eq(web.parseHeaders and true or true, true, "headers")
eq(web.cssColor("#ff0000"), "red", "hex red"); eq(web.cssColor("Teal"), "cyan", "css name"); eq(web.cssColor("#0f0"), "lime", "short hex"); eq(web.cssColor("zzz"), nil, "bad colour")
local db = {}
local api = { load=function(n) return db[n] end, save=function(n,t) db[n]=t return true end }
local function run(src, req) return web.runPage(src, "t.lua", req or { cookies = {} }, api) end
web.PAGE_SECONDS = 0.2
local t = os.clock(); local r = run("while true do end"); eq(r.status, 500, "endless loop stopped"); eq(r.body:find("stopped") ~= nil, true, "says why"); eq(os.clock()-t < 3, true, "quickly")
r = run("pcall(function() while true do end end) echo('survived')"); eq(r.status, 500, "pcall cannot swallow the limit")
r = run("while true do echo('x') end"); eq(r.status, 500, "endless echo stopped (size or time)")
web.PAGE_SECONDS = 2
r = run('echo("ok")'); eq(r.body, "ok", "normal page")
r = run('echo(tostring(users_add("dan","secret")), tostring(users_check("dan","secret")), tostring(users_check("dan","no")), tostring(users_add("dan","x")))'); eq(r.body, "truetruefalsenil", "users")
eq(db._users.dan ~= "secret", true, "password not stored plainly")
r = run('session().user="dan"'); local sid = r.cookies[1]:match("rpsid=(%x+)"); eq(sid ~= nil, true, "session cookie")
r = run('echo(tostring(session().user))', { cookies = { rpsid = sid } }); eq(r.body, "dan", "session remembered"); eq(#r.cookies, 0, "no new cookie")
r = run('setcookie("a","b",1)'); eq(r.cookies[1]:find("Max%-Age=86400") ~= nil, true, "setcookie")
local pg = web.render('<center>Hi</center><div style="color:red;background:#00f">box</div><p align="right">r</p>x <button name="go" value="1">Press</button>', 20)
eq(pg.lines[1].segs[1].t:match("^ +$") ~= nil, true, "centred")
local boxSeg; for _, l in ipairs(pg.lines) do for _, s in ipairs(l.segs) do if s.t == "box" then boxSeg = s end end end
eq(boxSeg.fg, "red", "style colour"); eq(boxSeg.bg, "blue", "style background")
eq(pg.inputs[1].type, "submit", "button is a submit"); eq(pg.inputs[1].name, "go", "button name")
local img = web.render('<img src="http://other/pic.nfp">', 30, { host="me", port=80, path="/" }); eq(img.images[1], "http://other/pic.nfp", "image from another site")

-- ---- rpntp
local N = dofile("lua/rpntp.lua")
eq(N.parseRequest(N.request(123456789)), 123456789, "ntp request"); local a, b = N.parseReply(N.reply(5, 9)); eq(a + b, 14, "ntp reply")
local off, rtt = N.offset(1000, 5100, 1200); eq(off, 4000, "ntp offset"); eq(rtt, 200, "ntp rtt")
eq(N.best({ {offset=1,rtt=9}, {offset=2,rtt=3}, {offset=3,rtt=5} }).offset, 2, "shortest round trip wins")
eq(N.format(0, 0), "1970-01-01 00:00:00", "epoch"); eq(N.format(86400000 * 365 + 3661000, 0), "1971-01-01 01:01:01", "a year later")
eq(N.format(1709208000000, 0), "2024-02-29 12:00:00", "leap day"); eq(N.format(0, 2), "1970-01-01 02:00:00", "zone")
eq(N.parseState("-120 2").offset, -120, "saved offset")

-- ---- rpddns
local D = dofile("lua/rpddns.lua")
local st = {}
eq(D.handle(st, "DDNS UPDATE shop.example secret", "1.2.3.4"):match("^DDNS OK shop.example 1.2.3.4"), "DDNS OK shop.example 1.2.3.4", "claim a name with the sender's address")
eq(D.parseAnswer(D.handle(st, "DDNS LOOKUP shop.example", "9.9.9.9")), "1.2.3.4", "lookup")
eq(D.handle(st, "DDNS UPDATE shop.example other", "6.6.6.6"), "DDNS ERR wrong key", "wrong key refused")
D.handle(st, "DDNS UPDATE shop.example secret", "5.6.7.8"); eq(D.parseAnswer(D.handle(st, "DDNS LOOKUP SHOP.example", "")), "5.6.7.8", "the name follows the new address")
D.handle(st, "DDNS UPDATE x.y secret 10.0.0.9", "1.1.1.1"); eq(D.parseAnswer(D.handle(st, "DDNS LOOKUP x.y", "")), "10.0.0.9", "explicit address")
eq(D.handle(st, "DDNS LOOKUP nope", ""), "DDNS NXDOMAIN", "unknown name"); eq(D.handle(st, "DDNS UPDATE bad/name k3y", "1.1.1.1"), "DDNS ERR bad name", "bad name")

-- ---- rpbalance
local Bal = dofile("lua/rpbalance.lua")
local B = Bal.new({ "a", "b", "c" })
local seq = {}; for i = 1, 6 do local x = B.pick("v", i); seq[#seq+1] = x.name; B.done(x) end
eq(table.concat(seq), "abcabc", "round robin")
local bb = B.list[2]; B.markDown(bb, 100)
seq = {}; for i = 1, 4 do local x = B.pick("v", 101); seq[#seq+1] = x.name; B.done(x) end
eq(table.concat(seq):find("b") == nil, true, "a down server is skipped")
eq(B.pick("v", 131) ~= nil and true, true, "and comes back after 30 s")
local L = Bal.new({ "a", "b" }, { strategy = "least" }); local p1 = L.pick("x", 0); local p2 = L.pick("x", 0); eq(p1 ~= p2, true, "least connections spreads"); L.done(p1); eq(L.pick("x", 0), p1, "frees up")
local S = Bal.new({ "a", "b", "c" }, { strategy = "sticky" }); local s1 = S.pick("10.0.0.5", 0); S.done(s1); eq(S.pick("10.0.0.5", 0), s1, "sticky keeps a visitor on one server")
local E = Bal.new({ "a" }); E.markDown(E.pick("v", 0), 0); eq(E.pick("v", 1), nil, "all down -> nil")
eq(Bal.addHeader("HTTP/1.0 200 OK\r\nA: 1\r\n\r\nbody", "X-Served-By", "a"), "HTTP/1.0 200 OK\r\nA: 1\r\nX-Served-By: a\r\n\r\nbody", "served-by header")
eq(Bal.requestComplete("POST / HTTP/1.0\r\nContent-Length: 4\r\n\r\nab"), false, "waits for the body"); eq(Bal.requestComplete("GET / HTTP/1.0\r\n\r\n"), true, "get complete")

-- ---- rpprint
local P = dofile("lua/rpprint.lua")
local pages = P.paginate("hello world this is a long line of text for the printer", 10, 3)
eq(#pages, 3, "wraps into pages"); for _, pg2 in ipairs(pages) do for _, l in ipairs(pg2) do if #l > 10 then eq(l, "<=10", "line too long") end end end
eq(#P.paginate("a\nb\nc\nd", 25, 2), 2, "page height"); eq(#P.paginate("", 25, 21), 0, "empty job")
local Q = P.queue(2, 50); eq(Q.add("1.1.1.1", "t", "x"), 1, "job 1"); Q.add("1.1.1.1", "", "y"); eq(Q.add("1.1.1.1", "z", "z"), nil, "queue full"); eq(Q.cancel(1), true, "cancel"); eq(Q.next().id, 2, "next job"); eq(select(2, Q.add("a","b",string.rep("x",60))), "the job is too big", "too big")
local title, text = P.decode(P.encode("my doc", "line1\nline2")); eq(title, "my doc", "decode title"); eq(text, "line1\nline2", "decode text"); eq(select(2, P.decode("PRINT t\n10\nabc")), "more", "partial job")

-- ---- rpmail
local Mail = dofile("lua/rpmail.lua")
local store = Mail.newStore(); eq(Mail.addUser(store, "dan", "pw1"), true, "add user"); eq(Mail.addUser(store, "dan", "pw1"), nil, "duplicate"); Mail.addUser(store, "eve", "pw2")
local out = {}; local function send(id, l) out[#out+1] = l end
local smtp = Mail.newSmtp(store, "home.net", send, nil, function() return 42 end)
smtp.connect(1); eq(out[1]:sub(1,3), "220", "greeting")
local function say(l) out = {}; smtp.line(1, l); return out[1] end
eq(say("HELO me"), "250 hello", "helo"); eq(say("RCPT TO:<dan@home.net>"), "503 MAIL first", "order"); eq(say("MAIL FROM:<eve@home.net>"), "250 ok", "mail from")
eq(say("RCPT TO:<nobody@home.net>"), "550 no such user", "unknown user"); eq(say("RCPT TO:<x@far.net>"), "550 relaying not allowed", "no relay"); eq(say("RCPT TO:<dan@home.net>"), "250 ok", "rcpt")
eq(say("DATA"):sub(1,3), "354", "data"); smtp.line(1, "Subject: Hi"); smtp.line(1, ""); smtp.line(1, "..dot line"); smtp.line(1, "body"); eq(say("."), "250 queued", "queued")
eq(#store.boxes.dan, 1, "delivered"); eq(store.boxes.dan[1].subject, "Hi", "subject"); eq(store.boxes.dan[1].body, ".dot line\nbody", "dot unstuffed"); eq(store.boxes.dan[1].from, "eve@home.net", "from")
local remoteGot; local smtp2 = Mail.newSmtp(store, "home.net", send, function(d, m) remoteGot = d .. ":" .. m.to; return true end)
smtp2.connect(2); smtp2.line(2, "MAIL FROM:<dan@home.net>"); smtp2.line(2, "RCPT TO:<z@far.net>"); smtp2.line(2, "DATA"); smtp2.line(2, "Subject: s"); smtp2.line(2, ""); smtp2.line(2, "b"); smtp2.line(2, ".")
eq(remoteGot, "far.net:z@far.net", "forwarded to the other domain")
out = {}; local pop = Mail.newPop(store, send); pop.connect(3)
local function pl(l) out = {}; pop.line(3, l); return out end
eq(pl("LIST")[1], "-ERR log in first", "login needed"); pl("USER dan"); eq(pl("PASS bad")[1], "-ERR wrong name or password", "bad pw"); pl("PASS pw1")
eq(pl("STAT")[1], "+OK 1", "stat"); local l = pl("LIST"); eq(l[2], "1 eve@home.net Hi", "list"); eq(l[#l], ".", "list end")
local rr = pl("RETR 1"); eq(rr[#rr], ".", "retr end"); eq(rr[#rr-1], "body", "retr body"); eq(store.boxes.dan[1].read, true, "marked read")
eq(pl("DELE 1")[1], "+OK deleted", "dele"); eq(#store.boxes.dan, 0, "gone")
local route = Mail.webRoute(store, "home.net")
eq(route({ path = "/other" }), nil, "route only /mail")
eq(route({ path = "/mail", cookies = {}, form = {}, query = {} }).body:find("Password") ~= nil, true, "login form")
local lr = route({ path = "/mail", cookies = {}, form = { act = "login", user = "dan", pass = "pw1" }, query = {} }); eq(lr.status, 302, "login redirects")
local ck = lr.cookies[1]:match("rpmsid=(%x+)")
local inbox = route({ path = "/mail", cookies = { rpmsid = ck }, form = {}, query = {} }); eq(inbox.body:find("dan@home.net") ~= nil, true, "inbox")
route({ path = "/mail", cookies = { rpmsid = ck }, form = { act = "send", to = "eve@home.net", subject = "yo", body = "hey <b>" }, query = {} })
eq(#store.boxes.eve, 1, "webmail sends to a local user"); eq(route({ path = "/mail", cookies = { rpmsid = ck }, form = {}, query = { read = "1" } } ) ~= nil, true, "read page")
local bad = route({ path = "/mail", cookies = {}, form = { act = "login", user = "dan", pass = "no" }, query = {} }); eq(bad.body:find("wrong name") ~= nil, true, "bad login")
eq(#Mail.smtpScript("a@b", "c@d", "s", ".x\ny"), 10, "client script")
local Mon = dofile("lua/rpmon.lua")
eq(Mon.fmtBlocked({ action="drop", direction="in", protocol="tcp", src="1.1.1.1", dst="2.2.2.2", port=80, rule=2 }), "drop in tcp 1.1.1.1 -> 2.2.2.2:80 (rule 2)", "rpmon blocked line")
eq(Mon.fmtBlocked({ action="reject", direction="out", protocol="icmp", src="a", dst="b", port=0, rule=0 }), "reject out icmp a -> b (default policy)", "rpmon default policy line")
print(fails == 0 and "ALL OK" or (fails .. " FAILED")); os.exit(fails == 0 and 0 or 1)
