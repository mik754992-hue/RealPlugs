package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(BuiltInRegistries.BLOCK_ENTITY_TYPE, RealPlugsMod.MODID);

    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<PlugSocketBlockEntity>> SOCKET =
            BLOCK_ENTITIES.register("socket", () -> BlockEntityType.Builder.of(
                    (pos, state) -> new PlugSocketBlockEntity(ModBlockEntities.SOCKET.get(), pos, state),
                    ModBlocks.OUTLET.get(), ModBlocks.POWER_STRIP.get()).build(null));
}
