package com.realplugs;

import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * What a coin is worth at an EV charger. Data-driven: the item tags realplugs:ev_coin_1, _8, _16, _64, _512 and _4096
 * list the coins of each value (the file lists Create: Numismatics' coins as optional entries). Add your own coins to
 * these tags with a datapack. The unit is the smallest coin (a spur).
 */
public final class EvCoins {
    private static final int[] VALUES = {4096, 512, 64, 16, 8, 1};
    private static final TagKey<Item>[] TAGS = tags();

    private EvCoins() {}

    @SuppressWarnings("unchecked")
    private static TagKey<Item>[] tags() {
        TagKey<Item>[] out = new TagKey[VALUES.length];
        for (int i = 0; i < VALUES.length; i++) {
            out[i] = TagKey.create(Registries.ITEM, ResourceLocation.fromNamespaceAndPath(RealPlugsMod.MODID, "ev_coin_" + VALUES[i]));
        }
        return out;
    }

    /** Value of ONE of these, or 0 if it is not a coin. */
    public static int valueOf(ItemStack stack) {
        for (int i = 0; i < VALUES.length; i++) if (stack.is(TAGS[i])) return VALUES[i];
        return 0;
    }

    /** Is this a Create: Numismatics card? (Paying with one needs that mod's API, which this version does not use.) */
    public static boolean isNumismaticsCard(ItemStack stack) {
        var key = net.minecraft.core.registries.BuiltInRegistries.ITEM.getKey(stack.getItem());
        return key.getNamespace().equals("numismatics") && key.getPath().contains("card");
    }
}
