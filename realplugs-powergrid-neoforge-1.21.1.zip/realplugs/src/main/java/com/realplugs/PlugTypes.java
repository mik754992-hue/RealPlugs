package com.realplugs;

/**
 * Index 0 is always the placeholder. Index N matches the custom_model_data value N
 * in assets/realplugs/models/item/plug.json (or adapter.json) and the lang key
 * item.realplugs.plug.<name> / item.realplugs.adapter.<name>.
 *
 * To add a new plug: append a name here, add a lang entry, a texture, a model
 * file and one "overrides" line (see README.md).
 */
public final class PlugTypes {
    public static final String[] PLUGS = {
            "placeholder", "usb_a", "usb_c", "us_plug", "eu_plug", "hdmi", "ethernet", "barrel"
    };
    public static final String[] ADAPTERS = {
            "placeholder", "us_to_eu", "usb_wall", "hdmi_to_usb_c", "multi_tap"
    };

    private PlugTypes() {}
}
