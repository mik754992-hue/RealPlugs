package com.realplugs;

import net.minecraft.core.component.DataComponents;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;

/** One class for both plugs/cables and adapters. Look and name come from custom_model_data. */
public class PlugItem extends Item {
    public final boolean adapter;

    public PlugItem(Properties props, boolean adapter) {
        super(props);
        this.adapter = adapter;
    }

    public static int typeOf(ItemStack stack) {
        CustomModelData d = stack.get(DataComponents.CUSTOM_MODEL_DATA);
        return d == null ? 0 : d.value();
    }

    @Override
    public String getDescriptionId(ItemStack stack) {
        int i = typeOf(stack);
        String[] names = adapter ? PlugTypes.ADAPTERS : PlugTypes.PLUGS;
        String base = getDescriptionId();
        return (i > 0 && i < names.length) ? base + "." + names[i] : base;
    }

    /** The plug sitting inside an adapter (adapters can be plugged into). */
    public static ItemStack inner(ItemStack adapterStack) {
        return adapterStack.getOrDefault(ModComponents.INNER.get(), ItemStack.EMPTY);
    }

    public static void setInner(ItemStack adapterStack, ItemStack in) {
        if (in.isEmpty()) {
            adapterStack.remove(ModComponents.INNER.get());
        } else {
            adapterStack.set(ModComponents.INNER.get(), in);
        }
    }

    public static ItemStack takeOne(ItemStack held, Player player) {
        ItemStack one = held.copy();
        one.setCount(1);
        if (!player.getAbilities().instabuild) held.shrink(1);
        return one;
    }

    public static void give(Player player, ItemStack stack) {
        if (!player.getInventory().add(stack)) player.drop(stack, false);
    }
}
