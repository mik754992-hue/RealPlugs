-- rpchat: a chat room with private mail.
--   rpchat serve [slot] [name]      run the chat server (port 5000)
--   rpchat join <host> <nick>       join the room (needs a computer with a keyboard)
-- Inside: type a line to talk. /who  /mail <nick> <text>  /inbox  /quit
-- Mail is kept on the server until it is read.

local M = {}
local PORT = 5000

function M.validNick(n) return type(n) == "string" and n:match("^[%w_%-]+$") ~= nil and #n >= 2 and #n <= 16 end

-- a line typed by a user -> command, argument(s)
function M.parseInput(line)
  line = line:gsub("^%s+", ""):gsub("%s+$", "")
  if line == "" then return nil end
  if line:sub(1, 1) ~= "/" then return "say", line end
  local cmd, rest = line:match("^/(%a+)%s*(.*)$")
  if cmd == "mail" then
    local to, text = rest:match("^(%S+)%s+(.+)$")
    if not to then return "error", "usage: /mail <nick> <text>" end
    return "mail", to, text
  elseif cmd == "who" or cmd == "inbox" or cmd == "quit" then return cmd end
  return "error", "unknown command: " .. line
end

-- Chat server state machine. `send(id, line)` delivers one line to a client; `store` = { mail = { nick = { {from=, text=} } } }
function M.newServer(send, store)
  store.mail = store.mail or {}
  local S = { clients = {}, store = store }

  local function broadcast(line, except)
    for id, c in pairs(S.clients) do if c.nick and id ~= except then send(id, line) end end
  end
  local function nickInUse(n)
    for _, c in pairs(S.clients) do if c.nick and c.nick:lower() == n:lower() then return true end end
    return false
  end

  function S.connect(id) S.clients[id] = {}; send(id, "SYS Welcome. Send NICK <name> first.") end

  function S.disconnect(id)
    local c = S.clients[id]
    S.clients[id] = nil
    if c and c.nick then broadcast("SYS " .. c.nick .. " left") end
  end

  -- a protocol line from a client: NICK / SAY / MAIL / INBOX / WHO
  function S.line(id, line)
    local c = S.clients[id]
    if not c then return end
    local cmd, rest = line:match("^(%u+)%s?(.*)$")
    if cmd == "NICK" then
      if c.nick then send(id, "SYS You are already " .. c.nick); return end
      if not M.validNick(rest) then send(id, "ERR Nicknames are 2 to 16 letters, digits, _ or -."); return end
      if nickInUse(rest) then send(id, "ERR That name is taken."); return end
      c.nick = rest
      send(id, "SYS Hello " .. rest .. ". /who /mail /inbox /quit")
      broadcast("SYS " .. rest .. " joined", id)
      local waiting = #(store.mail[rest:lower()] or {})
      if waiting > 0 then send(id, "SYS You have " .. waiting .. " mail. Type /inbox") end
    elseif not c.nick then send(id, "ERR Send NICK <name> first.")
    elseif cmd == "SAY" then
      if rest ~= "" then broadcast("MSG " .. c.nick .. " " .. rest:sub(1, 300)) end
    elseif cmd == "WHO" then
      local names = {}
      for _, o in pairs(S.clients) do if o.nick then names[#names + 1] = o.nick end end
      table.sort(names)
      send(id, "SYS Here: " .. table.concat(names, ", "))
    elseif cmd == "MAIL" then
      local to, text = rest:match("^(%S+)%s+(.+)$")
      if not to then send(id, "ERR usage: MAIL <nick> <text>"); return end
      local box = store.mail[to:lower()] or {}
      if #box >= 50 then send(id, "ERR Their mailbox is full."); return end
      box[#box + 1] = { from = c.nick, text = text:sub(1, 300) }
      store.mail[to:lower()] = box
      send(id, "SYS Mail sent to " .. to)
      for oid, o in pairs(S.clients) do if o.nick and o.nick:lower() == to:lower() then send(oid, "SYS New mail from " .. c.nick .. ". Type /inbox") end end
      if store.save then store.save() end
    elseif cmd == "INBOX" then
      local box = store.mail[c.nick:lower()] or {}
      if #box == 0 then send(id, "SYS No mail.") end
      for _, m in ipairs(box) do send(id, "MAIL " .. m.from .. " " .. m.text) end
      store.mail[c.nick:lower()] = nil
      if store.save and #box > 0 then store.save() end
    else send(id, "ERR Unknown command.") end
  end
  return S
end

-- the text a client shows for a line from the server
function M.display(line)
  local kind, rest = line:match("^(%u+) ?(.*)$")
  if kind == "MSG" then local nick, text = rest:match("^(%S+) (.*)$"); return "<" .. (nick or "?") .. "> " .. (text or "") end
  if kind == "MAIL" then local from, text = rest:match("^(%S+) (.*)$"); return "[mail from " .. (from or "?") .. "] " .. (text or "") end
  if kind == "ERR" then return "! " .. rest end
  return "* " .. rest
end

if RPWEB_TEST then return M end

local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpchat" or running == "rpchat.lua") then return M end

local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)
local args = { ... }

if args[1] == "serve" then
  local slot, name = tonumber(args[2]) or 1, args[3] or (not tonumber(args[2]) and args[2]) or nil
  local ok, why = nic.listen(slot, PORT)
  if ok == false then error("cannot listen: " .. tostring(why), 0) end
  if name then nic.setHostname(slot, name) end
  local store = {}
  local f = fs.open("chat_mail.db", "r")
  if f then store.mail = textutils.unserialise(f.readAll()) or {}; f.close() end
  store.save = function() local o = fs.open("chat_mail.db", "w"); o.write(textutils.serialise(store.mail)); o.close() end
  local bufs = {}
  local server = M.newServer(function(id, line) nic.tcpSend(slot, id, line .. "\n") end, store)
  print("rpchat server on port " .. PORT .. "  (Ctrl+T stops)")
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then pcall(nic.unlisten, slot, PORT); return end
    if ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot then
      local kind, id = ev[4], ev[5]
      if kind == "accepted" then bufs[id] = ""; server.connect(id)
      elseif kind == "closed" then bufs[id] = nil; server.disconnect(id)
      elseif kind == "data" and bufs[id] then
        bufs[id] = bufs[id] .. ev[6]
        while true do
          local nl = bufs[id]:find("\n", 1, true)
          if not nl then break end
          local line = bufs[id]:sub(1, nl - 1)
          bufs[id] = bufs[id]:sub(nl + 1)
          server.line(id, line)
        end
      end
    end
  end
elseif args[1] == "join" and args[2] and args[3] then
  local slot = 1
  local id, err = nic.connect(slot, args[2], PORT)
  if not id then error("cannot connect: " .. tostring(err), 0) end
  local buf, ready, quit = "", false, false
  local function show(text) print(text) end
  local function events()
    while not quit do
      local ev = { os.pullEvent("realplugs_tcp") }
      if ev[2] == side and ev[3] == slot and ev[5] == id then
        if ev[4] == "connected" then nic.tcpSend(slot, id, "NICK " .. args[3] .. "\n"); ready = true
        elseif ev[4] == "data" then
          buf = buf .. ev[6]
          while true do
            local nl = buf:find("\n", 1, true)
            if not nl then break end
            show(M.display(buf:sub(1, nl - 1)))
            buf = buf:sub(nl + 1)
          end
        elseif ev[4] == "closed" then show("* disconnected"); quit = true end
      end
    end
  end
  local function typing()
    while not quit do
      local cmd, a, b = M.parseInput(read() or "")
      if cmd == "say" then nic.tcpSend(slot, id, "SAY " .. a .. "\n")
      elseif cmd == "mail" then nic.tcpSend(slot, id, "MAIL " .. a .. " " .. b .. "\n")
      elseif cmd == "who" then nic.tcpSend(slot, id, "WHO\n")
      elseif cmd == "inbox" then nic.tcpSend(slot, id, "INBOX\n")
      elseif cmd == "error" then show("! " .. a)
      elseif cmd == "quit" then quit = true end
    end
  end
  parallel.waitForAny(events, typing)
  pcall(nic.tcpClose, slot, id)
else
  print("rpchat serve [slot] [name] | rpchat join <host> <nick>")
end

return M
