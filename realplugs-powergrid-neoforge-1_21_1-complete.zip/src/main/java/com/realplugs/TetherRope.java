package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import org.joml.Matrix4f;

/** Draws the cable from an outlet slot to the hand of the player tethered to it (client only). */
final class TetherRope {
    private TetherRope() {}

    /** Roughly where the pocket computer is held. */
    static Vec3 handPos(Player p, float partial) {
        Vec3 look = p.getViewVector(partial);
        Vec3 right = look.cross(new Vec3(0, 1, 0));
        right = right.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : right.normalize();
        double side = p.getMainArm() == HumanoidArm.RIGHT ? 1 : -1;
        return p.getPosition(partial).add(0, p.getEyeHeight() - 0.45, 0).add(look.scale(0.35)).add(right.scale(0.3 * side));
    }

    /** A sagging cable between two points given relative to the current pose. */
    static void draw(PoseStack ps, MultiBufferSource buf, Vec3 a, Vec3 b, int light) {
        double dx = b.x - a.x;
        double dy = b.y - a.y;
        double dz = b.z - a.z;
        double len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (len < 0.05) return;
        double sag = Math.min(0.45, len * 0.12);
        double hd = Math.sqrt(dx * dx + dz * dz);
        double px = hd < 1.0E-4 ? 1 : -dz / hd;
        double pz = hd < 1.0E-4 ? 0 : dx / hd;
        float w = 0.02f;
        int n = 24;

        VertexConsumer vc = buf.getBuffer(RenderType.leash());
        Matrix4f m = ps.last().pose();
        // one ribbon with a horizontal offset, then the way back with a vertical one, so it reads as a round cable
        for (int i = 0; i <= n; i++) {
            double t = i / (double) n;
            double x = a.x + dx * t;
            double y = a.y + dy * t - sag * 4 * t * (1 - t);
            double z = a.z + dz * t;
            vertex(vc, m, x + px * w, y, z + pz * w, light);
            vertex(vc, m, x - px * w, y, z - pz * w, light);
        }
        for (int i = n; i >= 0; i--) {
            double t = i / (double) n;
            double x = a.x + dx * t;
            double y = a.y + dy * t - sag * 4 * t * (1 - t);
            double z = a.z + dz * t;
            vertex(vc, m, x, y + w, z, light);
            vertex(vc, m, x, y - w, z, light);
        }
    }

    private static void vertex(VertexConsumer vc, Matrix4f m, double x, double y, double z, int light) {
        vc.addVertex(m, (float) x, (float) y, (float) z).setColor(0.10f, 0.10f, 0.12f, 1.0f).setLight(light);
    }
}
