# Real Plugs for Create: Power Grid (NeoForge 1.21.1)

Wall outlets and power strips that are **real Create: Power Grid electrical blocks**, plus plugs,
cables and adapters you plug into them, and plugs you can stick onto CC: Tweaked computers.

Needs: Minecraft 1.21.1, NeoForge 21.1.x, Create 6.0.9+, Create: Power Grid 0.6.x (+ Architectury). CC: Tweaked optional.

## Requirements
| | Version |
|---|---|
| Minecraft | 1.21.1 |
| NeoForge | 21.1.x |
| Create | 6.0.9 and up (6.0.x) |
| Create: Power Grid | 0.6.x |
| Architectury | 13.0.8 or newer (needed by Power Grid) |
| CC: Tweaked | optional (1.121.0 tested by users; 1.113.1 crashes with newer Create, see Troubleshooting) |

## Install
Drop the jar into `mods/` next to Create, Power Grid and Architectury.

## Build on GitHub
1. Push the **contents** of this folder to the root of a repo. Keep the hidden `.github/` folder and `libs/`
   (the Power Grid jar the build compiles against).
2. The `build` workflow runs on every push. Download `realplugs-jar` from the run's Artifacts.
3. To publish a release, push a tag such as `v1.0.0`: the `release` workflow attaches the jar to a GitHub release.

## Build locally
Needs JDK 21 and Gradle 8.10+.
```
gradle build        # jar ends up in build/libs/
gradle runClient    # test in a dev client
python3 scripts/validate_assets.py   # check models, lang, loot tables and recipes agree
```
Version numbers and dependency ranges live in `gradle.properties`; `neoforge.mods.toml` is filled from them.

## Outlets, strips and what fits where
Every slot has a **connector standard**. A plug only goes into a slot of the same standard; anything else is refused
with a message on screen ("That doesn't fit - this needs: ...").

| Block | Slots |
|---|---|
| Wall Outlet (US) | 2 x US plug |
| Wall Outlet (EU) | 2 x EU plug |
| Wall Outlet (UK) | 2 x UK plug |
| DC Power Jack Panel | 2 x barrel jack |
| USB Charging Hub | 2 x USB-A, 2 x USB-C |
| Power Strip (US) | 4 x US plug |
| Power Strip (EU) | 4 x EU plug |
| Universal Power Strip | US, EU, UK, USB-A |
| Wall Outlet (AU) | 2 x AU plug |
| Power Strip (UK) | 4 x UK plug |
| Power Strip (AU) | 4 x AU plug |
| Network & AV Wall Plate | 2 x Ethernet, 2 x HDMI |

**Adapters** take one standard on the front and plug into another with the back. Plugging into an adapter works the same
way: the plug must match what the adapter accepts. Hover over any plug or adapter to see what it plugs into / accepts.

| Adapter | Accepts (front) | Plugs into (back) |
|---|---|---|
| US to EU | US plug | EU socket |
| EU to US | EU plug | US socket |
| US to UK | US plug | UK socket |
| UK to US | UK plug | US socket |
| USB-A Wall Adapter | USB-A | US socket |
| USB-C Wall Adapter | USB-C | US socket |
| HDMI to USB-C | HDMI | USB-C port |
| USB-A to USB-C | USB-A | USB-C port |
| Multi-Tap (US) | 3 x US plug | US socket |
| Multi-Tap (EU) | 3 x EU plug | EU socket |
| US to AU | US plug | AU socket |
| AU to US | AU plug | US socket |
| EU to UK | EU plug | UK socket |
| UK to EU | UK plug | EU socket |
| Micro-USB Wall Adapter | Micro-USB | US socket |
| DisplayPort to HDMI | DisplayPort | HDMI port |

Plugs: US, EU, UK, AU, USB-A, USB-C, USB-B, Micro-USB, Lightning, HDMI, DisplayPort, VGA, Ethernet, DC barrel, 3.5 mm Aux, RCA, XLR, and the EV connectors Type 1, Type 2, CCS, CHAdeMO and NACS.

## Crafting
All recipes are shapeless.

**Blocks**
| Result | Ingredients |
|---|---|
| Wall Outlet (US) | iron ingot, copper ingot, redstone |
| Wall Outlet (EU) | US outlet + green dye |
| Wall Outlet (UK) | US outlet + blue dye |
| DC Power Jack Panel | US outlet + black dye |
| USB Charging Hub | US outlet + quartz + lapis lazuli |
| Power Strip (US) | 2 US outlets + iron ingot |
| Power Strip (EU) | 2 EU outlets + iron ingot |
| Universal Power Strip | US outlet + EU outlet + UK outlet + USB hub |
| Wall Outlet (AU) | US outlet + yellow dye |
| Power Strip (UK) | 2 UK outlets + iron ingot |
| Power Strip (AU) | 2 AU outlets + iron ingot |
| Network & AV Wall Plate | US outlet + glass pane + string |

**Plugs** (copper ingot + iron nugget + one extra, gives 2)
| Plug | Extra ingredient |
|---|---|
| US | redstone |
| EU | lapis lazuli |
| UK | gold nugget |
| USB-A | quartz |
| USB-C | amethyst shard |
| HDMI | glass pane |
| Ethernet | string |
| DC barrel | coal |
| AU | flint |
| Micro-USB | prismarine shard |
| DisplayPort | glowstone dust |
| Lightning | bone meal |
| VGA | blue dye |
| 3.5 mm Aux | black dye |
| RCA | red dye |
| XLR | gunpowder |
| USB-B | slime ball |
| EV Type 1 | clay ball |
| EV Type 2 | sugar |
| EV CCS | blaze powder |
| EV CHAdeMO | fermented spider eye |
| EV NACS | glow ink sac |

**Adapters** (all also need an iron ingot)
| Adapter | Ingredients |
|---|---|
| US to EU | US outlet + EU plug |
| EU to US | EU outlet + US plug |
| US to UK | US outlet + UK plug |
| UK to US | UK outlet + US plug |
| Multi-Tap (US) | US outlet + US plug |
| Multi-Tap (EU) | EU outlet + EU plug |
| USB-A Wall Adapter | USB-A plug + US plug |
| USB-C Wall Adapter | USB-C plug + US plug |
| HDMI to USB-C | HDMI plug + USB-C plug |
| USB-A to USB-C | USB-A plug + USB-C plug |
| US to AU | US outlet + AU plug |
| AU to US | AU outlet + US plug |
| EU to UK | EU outlet + UK plug |
| UK to EU | UK outlet + EU plug |
| Micro-USB Wall Adapter | Micro-USB plug + US plug |
| DisplayPort to HDMI | DisplayPort plug + HDMI plug |

## Ports: sockets for CC: Tweaked blocks
A **Port** is a socket item you stick onto any CC: Tweaked block (computer, monitor, disk drive, printer, speaker, modem...) at an
exact spot. There is one per connector: USB-A, USB-C, USB-B, Micro-USB, Lightning, HDMI, DisplayPort, VGA, Ethernet, DC barrel jack, 3.5 mm Aux, RCA, XLR, and US, EU, UK and AU power.
Each port is a chunky box in its own colour with the connector's hole in the front, so you can tell them apart.

- **Place:** sneak + right-click a CC: Tweaked block, or a **LittleTiles** block, with a port. It lands exactly where you clicked, snapped to the 1/16 grid, on the face you clicked.
- **Plug in:** right-click the port with a **plain plug** of the same standard (adapters don't go in a port). A wrong standard gives a message.
- **Take out:** right-click the port with an empty hand to get the plug back. Sneak + empty hand removes the port (and returns the plug).
- Punching it (or breaking the block it sits on) drops the port and its plug.
- Crafting (shapeless, gives 2): iron ingot + copper ingot + the same extra ingredient as that connector's plug.

**Cords into ports.** Plug cords (and Power Grid's copper cord) can end on a port too:
- Hold the cord and right-click the port. While a cord is in your hand the port steps aside and you aim at the spot where the port sits.
- The port's connector has to be one of the cord's connectors, and the other end follows the usual rule (a US to USB-A cord needs a US slot and a USB-A port).
- The cord is drawn ending exactly at the port, and the port shows its plug seated, like a plugged-in plug. A port holding a plug won't take a cord and the other way round.
- Behind the scenes a computer has no electrical side, so Real Plugs puts a small **invisible anchor block** in the empty block in front of the port for the cord to attach to. It has no collision, drops nothing and cannot be broken; it disappears with its port.
- That needs the block in front of the port to be empty air when you place the port. If it isn't you get a message and the port only takes plugs. Only one port per face of a block can take a cord.
- The anchor has a selection box only while you hold a cord, so it never gets in the way of normal clicks.

Ports are a build feature: they look right and enforce matching connectors, but they do not connect to the computer's peripherals.
Plugs can still be stuck straight onto computers (sneak + right-click) as before.

## Pocket computers with ports
Every port also works as a **CC: Tweaked pocket upgrade** (written against the CC: Tweaked 1.113.1 API and checked against 1.121.0, where everything it uses is unchanged). It becomes the pocket computer's one upgrade slot, so it replaces a modem or speaker.

- **Craft it on:** pocket computer + the port item, the same way you add a modem.
- **Or equip it from the computer:** keep the port item in your inventory and run `pocket.equipBack()` in the pocket computer. `pocket.unequipBack()` takes it off again.
- **Plug in:** hold the pocket computer in one hand and a plain plug of the same standard in the **other hand** (swap with F), then right-click. You get a "Plugged in" message. A wrong standard gives a message. If the screen opens instead, no plug was found in either hand.
- **Tether to an outlet slot.** Right-click a slot of the same connector with the pocket computer (any hand, the port needs to be equipped and empty). The slot shows a plug and a cable is drawn from the slot to your hand. It works like a cord from the slot's point of view: the slot passes power and cannot take a plug or a cord. It is **not** a Power Grid cord and carries no current to the computer.
  - It snaps when you get more than 10 blocks away, change dimension, or the slot stops being free. Sneak + right-click the pocket computer, or right-click the same slot again, to let go.
  - From Lua: `isLinked()` and `getLink()` (`{dimension, x, y, z, slot, socket}`, slot numbers start at 1). A port holding a plug cannot be tethered and the other way round.
  - Because it is only a tether, other players see the cable too, but it can't be drawn through a wall or reach the computer's screen.
- **Real cords do not work here.** A pocket computer is an item, and Power Grid cords need a block to attach to, so holding a cord just shows a message. Use a plug, or a port on a computer block for cords.
- **Unplug:** sneak + right-click the pocket computer to get the plug back.
- **From Lua:** the port is the peripheral on `"back"`, type `realplugs_port`: `getStandard()` (e.g. `"usb_c"`), `isPlugged()`, and `getPlug()` (`{name, standard}` or nil).

```lua
local port = peripheral.wrap("back")
print(port.getStandard(), port.isPlugged())
```

A pocket computer has one upgrade slot, so it carries one port. The datapack entries are `data/realplugs/computercraft/pocket_upgrade/port_*.json`.

## CC: Tweaked peripheral
Every outlet, strip and panel is a read-only peripheral (type `realplugs_socket`) when CC: Tweaked is installed.
Attach a computer directly or through a wired modem. Slots are numbered from 1, counting from the viewer's left.

| Method | Returns |
|---|---|
| `getSocketId()` | block id, e.g. `"power_strip"` |
| `getSlotCount()` | number of slots |
| `getSlotStandard(slot)` | connector standard of the slot, e.g. `"us_power"` (nil if no such slot) |
| `isPlugged(slot)` | true if something sits in the slot |
| `getPluggedCount()` | how many slots are in use |
| `getPlug(slot)` | `{name, standard, adapter, accepts?, inner?}` or nil if empty |
| `getSlots()` | one table per slot: `{slot, standard, plugged, plug?}` |

```lua
local strip = peripheral.find("realplugs_socket")
for _, s in ipairs(strip.getSlots()) do
  print(s.slot, s.standard, s.plugged and s.plug.name or "empty")
end
```

## Plug cords (extension leads)
A **Plug Cord** is a real Power Grid cord with a plug on each end. Power Grid draws the hanging cord, limits its length (16 blocks)
and carries the current; Real Plugs decides where the ends fit. There are two kinds:

- **Same plug on both ends**, one per connector standard: US, EU, UK, AU, USB-A, USB-C, Micro-USB, Lightning, HDMI, DisplayPort, Ethernet, DC barrel.
- **Multi-standard cords** with a different connector on each end, like a phone charger lead (US plug on one end, USB-A on the other).

1. Hold a plug cord and right-click a **slot** on an outlet, strip or panel. The slot must take one of the cord's connectors
   and must be empty, otherwise you get a message and nothing is attached.
2. Right-click the other end onto a second slot or onto any other Power Grid block that accepts cords. If the first end is already
   in one of our slots, the second end has to be the cord's other connector (a US to USB-A cord needs one US slot and one USB-A slot).
3. The cord costs one plug cord item. Break the cord to get it back.

Cord ends in our slots are drawn with the **Real Plugs plug model** of that slot's connector (Power Grid's own plug is switched off on our blocks).
The cord end is **slot-specific**: it sits on that slot's tap and the neutral bus, and while it is plugged in it closes that slot's
contact exactly like a plug would, so only that slot supplies the cord. A slot holding a cord won't take a plug, and the other way round.
At a Power Grid device the far end has no connector standard, since Power Grid's own blocks don't have them.

Crafting (shapeless):
- same-plug cord: the plug + copper ingot + string
- multi-standard cord: one plug of each standard + string

| Multi-standard cords |
|---|
| US to USB-A, US to USB-C, US to Micro-USB |
| EU to USB-A, EU to USB-C |
| UK to USB-A, UK to USB-C |
| AU to USB-A, AU to USB-C |
| US to DC Barrel, EU to DC Barrel |
| HDMI to DisplayPort, HDMI to USB-C |
| USB-A to USB-C, USB-A to Micro-USB |
| US to Lightning, USB-A to Lightning, USB-C to Lightning |
| VGA to HDMI, VGA to DisplayPort |
| Aux to RCA, XLR to Aux |
| USB-A to USB-B, USB-C to USB-B |

Every slot has **its own cord box** (not one big box over the whole plate), so you aim at the slot you want and the cord end sits on that
slot's tap. Power Grid's own **copper cord** works the same way on any slot, without the connector check (clicking a single terminal wires one conductor).

## Extension cables
An **extension cable** is a real Power Grid cord with a plug on one end and a small strip on the other, and you place that strip wherever you like.
There is one per connector: US, EU, UK, AU, USB-A, USB-C, HDMI and Ethernet. The strip end is a ready-made multi-slot block (US, EU, UK and AU
power strips, a USB hub for the USB ones, an AV panel for HDMI and Ethernet), and it is fed by the cable, so everything plugged into it is powered.

1. Right-click a **free slot** of the cable's connector. The plug end goes in (a US cable needs a US slot, and so on).
2. Right-click the **surface** where the strip should stand (a floor, wall or ceiling). The strip appears there and the cord runs to it, up to 15 blocks.
3. Plug things into the strip's slots as usual. Break the cord and the strip goes away with it, and you get the cable back.

Crafting (shapeless): the matching plug + the strip it ends in (power strip, EU/UK/AU strip, USB hub or AV panel) + copper ingot + string.

The strip end cannot go on a socket, and it needs an empty block to stand in. It is a normal block: you can mine it, and what is plugged into it drops.

## EV chargers
Pay-to-charge chargers and the EV ports they charge. Everything runs through the normal cord system, so a **cable of the right EV connector** joins them
(an EV cable is just the same-plug cord of that connector: Type 1, Type 2, CCS, CHAdeMO or NACS).

**Chargers** (one slot each, **two blocks high** like a parking-lot pillar, facing the way you look; placing one needs two free blocks, and both halves break together):
| Charger | Connector | Price |
|---|---|---|
| EV Wall Box (Type 1) | Type 1 | 2 per minute |
| EV Wall Box (Type 2) | Type 2 | 2 per minute |
| EV Fast Charger (CCS) | CCS | 6 per minute |
| EV Fast Charger (CHAdeMO) | CHAdeMO | 6 per minute |
| EV Supercharger (NACS) | NACS | 8 per minute |

**EV ports** are small blocks of the same five connectors (`EV Port (Type 2)` and so on) for you to build into a vehicle or contraption. Wire their side
connectors to your batteries like any outlet.

How it works:
1. Wire power into the charger's side connectors (red hot, blue neutral), like an outlet.
2. Run an EV cable from the charger's slot to an EV port of the same connector. Either end can also hold a plain plug.
3. The slot is dead until you pay. Right-click the **gold panel** on the charger with coins (sneak to insert the whole stack). The screen shows the credit and the price.
4. While a plug or cable is in the slot, the credit counts down once a minute at the charger's price, and the slot closes when it runs out. Leftover credit stays.
5. Right-click the gold panel or the screen with an empty hand to see the credit and price.

**The upper half** has the screen (state, credit, price) and a button row:
| Button | What it does |
|---|---|
| `-` / `+` | Owner only: lower / raise the price per minute by 1 (sneak: by 8). `0` makes it free. The default is the table above. |
| Padlock | Owner only: toggle **private mode**. A private charger only works for its owner, for free, and the screen shows `PRIVATE`. Other players are told it is private. Power Grid cords do not power a private charger; use the built-in cord or a plug. |
| red `STOP` | Ends the session at any time: the built-in cord snaps back and the slot goes dead. The unused credit is handed back to you as coins (biggest first; only if you are the one who paid it, otherwise it stays for whoever did; if no coin of a value is installed, that part stays as credit). Press it again, pull the cord out or insert a plug to start a new session. In private mode only the owner can press it. |

Whoever places a charger is its **owner**. A charger placed some other way (a command, a dispenser) has no owner, so anybody can change its price and mode.

**Built-in cord.** Every charger has its own cord with its connector docked in the socket (a cable runs from the connector down to the cable gland
under the coin panel). Right-click the socket or the gland with an empty hand to **pull the cord out**: you get a *Charger Cord* in your hand (its own item, `realplugs:charger_cord`, so connecting it never uses up other plug cords), a real Power Grid
plug cord whose first end is already in the charger's slot, and the socket shows empty. Then:
- **Plug it into an EV port** by right-clicking the port (or its cord spot) with the cord, like any plug cord: Power Grid hangs the cord between the two and the
  charger now powers the port for as long as there is credit (billed at the charger's price). The connector of the port has to match the charger's.
- **Put it back** by right-clicking the charger's socket or gland with the cord in hand.
- While you carry it the slot already counts as occupied (it closes once there is credit). It docks itself if you walk more than 10 blocks away, die, log out or lose the item.
The cord item only exists while its charger says you are holding it: any Charger Cord that is not (or no longer) its charger's pulled-out cord disappears from your inventory, so pulling the cord out
never makes free cords. A cord that is plugged into a port is removed like any Power Grid cord. A plug placed in the socket, or an EV cable from a Power Grid cord, still works as before;
the built-in cord only comes out of an empty slot and is refused while a cable is in it. In private mode the owner's own built-in cord powers the charger even once it is plugged into a port.

Coin values are **data-driven** by the item tags `realplugs:ev_coin_1`, `_8`, `_16`, `_64`, `_512` and `_4096` (the unit is the smallest coin, a spur).
The tags list Create: Numismatics' coins as optional entries (`numismatics:spur` 1, `bevel` 8, `sprocket` 16, `cog` 64, `crown` 512, `sun` 4096; these ids and values
are from memory, so check them against the mod). Add or fix coins with a datapack.

**Paying by card.** With Create: Numismatics installed, right-click the gold coin plate with a Numismatics card (the normal bank card, or an authorized sub-account card). Each tap takes enough from the card's account to pay for 10 minutes at the charger's price (never less than 16 spurs) and adds it as credit. If the account has too little money, or you are not allowed to use the card, you get Numismatics' own message. Pressing STOP puts the unused card-paid credit back into the same bank account (coins are used up first); coin-paid credit comes back as coins. Without Numismatics a card just says so. Build note: `libs/CreateNumismatics-1_1_0_neoforge-mc1_21_1.jar` is only on the compile classpath; the mod loads fine without Numismatics.
Billing is by time, not by energy used.

## How the outlets work electrically
Each outlet / power strip has these Power Grid terminals (use Power Grid wires or copper cords on them):
- **Red bar on top = hot bus.** Wire your supply's hot side here.
- **Blue bar at the bottom = neutral bus.** Supply neutral AND every device's return go here.
- **One small copper stud per slot = that slot's hot tap.** Wire the device's hot side here.

A slot's tap is connected to the hot bus **only while a plug (or adapter) is plugged into that slot**.
Unplug it and the tap is cut off.

## How to play
- **Plugging in**: right-click a slot with a plug or adapter. Empty hand removes it (the last plug in an adapter comes out first).
- **Adapters**: put an adapter in a socket, then right-click it with plugs that match its front. Multi-taps hold three.
- **On a computer**: hold a plug/adapter, **sneak + right-click** a CC computer where you want it. Only device-side
  connectors (USB-A, USB-C, HDMI, Ethernet, barrel) fit a computer, mains plugs are refused. These are visual only.
  Use the same right-click with a matching plug on a stuck-on adapter, and an empty hand removes things.
- Everything is in the **Real Plugs** creative tab. Place the outlets against a wall (the back sits on the clicked face).

## Models
Everything is a real 3D cuboid model, not a flat sprite. All colours come from one shared palette,
`assets/realplugs/textures/block/palette.png` (4x4 cells, each element samples one cell), so you can
re-colour every model by editing that one PNG.

Plug and adapter models share one orientation: the **cable / body side faces NORTH (-z, toward the viewer)** and the
**prongs / plug side point SOUTH (+z, into the socket)**. Keep that and your own model will sit correctly in a socket,
on a computer and inside an adapter.

## Add your own plug / cable / adapter / outlet
Plugs, adapters and outlets are all listed in `PlugTypes.java` / `SocketDefs.java`. To add one, edit those and add the matching files by hand:
1. **Plug or adapter**: append an entry to `PLUGS` or `ADAPTERS` in `PlugTypes.java` (the array position is its
   custom_model_data number), choose its `Standard`, then add `models/item/plug_<name>.json` (or `adapter_<name>.json`),
   one line in the `overrides` list of `models/item/plug.json` (or `adapter.json`), the name in `lang/en_us.json`
   (`item.realplugs.plug.<name>` / `item.realplugs.adapter.<name>`) and a recipe `data/realplugs/recipe/plug_<name>.json`. Adapter `sockets` are the front socket centres in model units.
2. **Outlet**: add a `SocketDef` to `SocketDefs.java`, plus `blockstates/<id>.json`, `models/block/<id>.json`,
   `models/item/<id>.json`, a loot table, a recipe, the pickaxe tag entry and a lang name. Copy an existing outlet's files, then run `python3 scripts/validate_assets.py` to catch anything you forgot.
3. **New connector standard**: add a value to the `Standard` enum and a `standard.realplugs.<key>` lang entry.
4. Model orientation: **cable/body faces NORTH (-z), prongs point SOUTH (+z)**. Build in Blockbench and keep the `display` block.

Give one by command: `/give @s realplugs:plug[custom_model_data=3]`

## Known gaps
- Plugs and adapters are visual markers: a plugged item only closes the slot contact, it does not carry its own load.
- Plugs, ports and pocket ports do nothing electrically. They are visual and checked for matching connectors.
- Whether a slot holds a cord is read from Power Grid's connection list (`ElectricBehaviour.getConnections`); a copper cord clicked onto a single slot terminal also counts. `SocketBehaviour` hooks attach/remove to update the slot contact.
- Plug cords register a Power Grid wire type (`data/realplugs/powergrid/wire_types/plug_cord.json`) and hook Power Grid's cord handler list. If Power Grid changes either in a later version, that is the first place to look.
- The CC integrations (outlet peripheral, pocket ports) compile against small stubs of CC's API in `src/main/java/dan200`, written from CC: Tweaked 1.113.1 (the signatures Real Plugs uses are identical in 1.121.0). They are left out of the released jar. If you add CC: Tweaked itself to the dev runtime, delete those stubs first.
- Recipes and the build setup have not been run in-game or on CI yet: if a dependency version in `gradle.properties` (Create, Flywheel, Registrate) or `build.gradle` (Ponder) doesn't resolve, adjust it there.

## Ponder
In-game Ponder scenes (hold W over the item, or look at it in the creative tab / JEI and press W) explain the mod. They use the two showcase schematics:
- **Charging island** (strips, hubs, panels): the airport schematic.
- **Wall outlets** and **Plugs and adapters**: the house schematic.
- **Plug cords**: the airport schematic again.

The schematics are in `src/main/resources/assets/realplugs/ponder/`. The airport one had some Power Grid wire entities saved into it; they were removed
because the scene does not need them. The scenes are written in `ponder/RealPlugsScenes.java`.

## Troubleshooting
- **`NoClassDefFoundError: ...create/content/contraptions/BlockMovementChecks...` with CC: Tweaked installed.** That is CC: Tweaked 1.113.x's own Create
  integration looking for a class Create has since moved, not Real Plugs. Update CC: Tweaked (1.121.0 fixes it).

## License
Real Plugs is MIT licensed (see `LICENSE`). `libs/powergrid-*.jar` is Create: Power Grid (Apache-2.0), see `libs/README.md`.

## API for other mods
`com.realplugs.api.RealPlugsApi` (guard calls with `ModList.get().isLoaded("realplugs")`; add this mod as a `compileOnly` dependency):
- `registerPortHostNamespace(String)` / `registerPortHostBlock(ResourceLocation)`: make a mod's blocks (or one block) accept **Ports** (sneak + right-click). CC: Tweaked (`computercraft`) and LittleTiles (`littletiles`) are built in. Call it while your mod loads (constructor or `FMLCommonSetupEvent`).
- `isPortHost(ResourceLocation)`: is this block a port host?
- `socketAt(Level, BlockPos)`: a read-only `SocketInfo` for any socket block of this mod (outlets, strips, chargers, port anchors): its id, the connector standard (`"us_power"`, `"usb_c"`, `"ccs"` ...) and occupied flag of every slot, and for EV chargers the credit, price per minute, STOP and private-mode state.
The connector standards themselves are an enum and cannot be extended from outside yet.

## Networking (CC: Tweaked)
Point-to-point links, LANs and a WAN with an ISP, built from the **RJ45 ports** the mod already has (Network & AV Wall Plate: 2 ports, AV panels: 2 ports) and **Ethernet cords** (a plug cord with an Ethernet plug on each end). A CC computer sees any socket next to it as a `realplugs_socket` peripheral; the ports with an RJ45 connector are network interfaces. Slot numbers start at 1 and count from the viewer's left.

| Concept | How it works |
|---|---|
| Interface | Every RJ45 slot has its own MAC address (`02:52:50:..`) and its own IP address, prefix and gateway. A socket with 2 RJ45 ports is a computer with 2 network cards. |
| Link | An Ethernet cord between two RJ45 slots. Two cabled ports are a point-to-point connection. |
| Segment (LAN) | Everything connected by cords through a **Network Switch** (a block with 4 RJ45 ports, always bridged; craft it from 2 AV panels + an iron ingot) or through any socket in **bridge mode** (`setBridge(true)`: all its RJ45 ports are one switch). Without one, a socket just ends the segment. The ports of a switch are not hosts: they have no address and do not show up in `scan`. |
| Same subnet | Addresses in the same network (prefix) reach each other directly if the host is in the segment. |
| Other subnet | The packet goes to the port's **gateway**, which must be a port of a socket in **router mode** (`setRouting(true)`). A router passes the packet to the network it is attached to, or out through its uplink, or on to another router. |
| DHCP | `setDhcp(slot, true)` on a port with an address makes it a DHCP server for its segment. A client calls `autoConfigure(slot)` and gets address, prefix and gateway (the DHCP port's address when its socket is a router). |
| Internet | `setUplink(slot, true)` on a cabled port turns it into a modem: the ISP gives it a **public address** (100.64.0.0/10). Every uplink on the server can reach every other uplink. The line has to stay cabled, and the socket has to be loaded. |
| NAT | A router with an uplink rewrites the source of packets that leave through it, and sends replies back to the private host, like a home router. |
| Latency | Same segment: instant. Each router hop adds a tick, and the internet adds 1 to 11 ticks (50 ms each) by distance, 6 ticks between dimensions. `ping` reports the round trip in milliseconds. |
| Datagrams | UDP-like: source and destination port, at most 1500 characters. Routed, NAT'd and delayed as described above. |
| Connections | TCP-like: `listen` on a port, `connect` to an address or hostname. A handshake opens the connection ("connected" on the client, "accepted" on the server); data arrives in order; `tcpClose` or the other side closing ends it. A closed port refuses the connection, a vanished peer resets it, and a lost route times it out. Connections go through routers, NAT and the internet like datagrams do (so, as with a real home router, nothing outside can connect in to a host behind NAT). They are forgotten when the server stops or the socket unloads. |
| Raw frames | `sendFrame(slot, mac, etherType, data)` to one port of the segment, or `ff:ff:ff:ff:ff:ff` to all of them: write your own protocols (ARP, a custom discovery ...). Frames stay inside the segment and are not seen by other computers. |
| Names | `setHostname(slot, "name")`. Anything that takes an address also takes a hostname: it is looked up among the hostnames in the segment first, then among the names of uplinks, which are registered server-wide (first come, first served). `resolve(slot, name)` returns the address. |
| DHCP server | Besides handing out addresses (see above) a DHCP server remembers **leases** (the same port gets the same address again), can **reserve** an address for a MAC (`reserveAddress`) and can be limited to a **range** (`setDhcpRange`). Leases of ports that are gone are reused when the pool runs out. |
| Local DNS | `addDnsRecord(name, ip)` on any socket (normally the router): every port in its segment resolves that name, after the hostnames of the segment and before the server-wide uplink names. |
| Firewall | Ordered rules (first match wins) on a router or on any socket with an uplink: action (`allow`, `reject` = the sender is told, `drop` = silence), direction (`in` from the internet, `out` to it, `any`), protocol (`udp`, `tcp`, `icmp` = ping, `any`), source and destination (`"any"`, an address, or `"a.b.c.d/n"`) and a destination port. A **policy** says what happens to a packet no rule matches. Answers to what a LAN host sent are always let in (like a stateful firewall); port forwards are checked against the `in` rules. |
| Wi-Fi | A **Wi-Fi Access Point** bridges its cable port with every port that joined its network by radio within range (24 blocks by default, up to 64). A client port (any RJ45 slot) calls `joinWifi(slot, ssid[, password])` and then behaves as if it were cabled into the access point's segment: DHCP, routing and everything above work. The nearest access point with the same name and password is used; a port reconnects by itself whenever one is in range again. |
| Lights | Routers, switches and access points show their state: a link light per port (green = a cable with two ends, blue = a router's WAN that is online), an activity light (amber, blinks while packets pass through that port) and, on the access point, a blue radio light while a port is connected. |
| VLANs | `setVlan(slot, id)` (0 to 4094, 0 = default). Ports of one switch, or the LAN ports of one router, only share a segment when they are in the same VLAN: a guest port can no longer see your servers. |
| VPN tunnels | `addTunnel(name, peerIp, "192.168.2.0/24", key)` on both routers joins two LANs over the internet (each side names the other router's public address and the network behind it, with the same key). Hosts then reach each other by their private addresses; the networks must differ. Wrong key or unknown router: refused. |
| Sniffing and statistics | `setSniffer(slot, true)` makes a port hear every packet of its segment as `realplugs_sniff` events (side, slot, srcIp, dstIp, protocol, srcPort, dstPort, payload). `getStats(slot)` gives packets and bytes in and out per port (`resetStats`). |
| Repeater | An access point with `setUpstream(ssid[, password])` takes its connection from another access point in range by radio instead of a cable. Give it the same name and password as the upstream one and clients roam between them. |
| Guest network | `setGuestNetwork(ssid[, password])` on an access point adds a second network. Guests can reach routers (the internet) but not the LAN and not each other. |
| Wi-Fi Analyzer | An item (lightning rod, iron, redstone). Right-click to see the networks you can hear where you stand, with signal strength. |

**Network Router block** (craft: Network Switch + redstone + gold ingot): ports 1-3 are the LAN (one segment, like a switch), port 4 is the WAN. It works with no computer at all: the LAN has the address `192.168.1.1/24`, hands out addresses by DHCP and is every host's gateway, and as soon as a cable sits in the WAN port the port goes online by itself (public address from the ISP, NAT for everything behind it). Plug hosts into ports 1-3, put a cable in port 4, and hosts that call `autoConfigure` (or a CC computer on them) can reach the internet. A computer next to the router can still reconfigure it: `setAddress` on a LAN port changes the LAN address for all three, `setDhcp` switches the DHCP server, `addPortForward(publicPort, ip, port)` / `removePortForward` / `getPortForwards()` open a service to the internet (like a home router: without a forward, nothing outside can reach a host behind NAT). `isRouter()` tells the router block from other sockets. Any socket in router mode (`setRouting(true)`) supports port forwarding too.

**Wi-Fi Access Point block** (craft: Network Switch + lightning rod + redstone): one RJ45 port (the cable to your LAN) and a radio. It works with no computer: an open network called `RealPlugs-XXXX` with 24 blocks of range. A computer next to it can change that: `setAccessPoint(ssid[, password])` (a password has 8 to 63 characters; leave it out for an open network), `setWifiRange(blocks)`, `getAccessPoint()` and `getWifiClients()`. A client port calls `scanWifi(slot)` (the networks it can hear, with signal strength), `joinWifi(slot, ssid[, password])`, `leaveWifi(slot)` and `getWifi(slot)`. The access point's port is not a host (like a switch port) and does not show up in `scan`.

**Lua API** (all calls on the socket peripheral):
`getInterfaces()`, `getMac(slot)`, `isLinkUp(slot)`, `getPeerMac(slot)`, `setAddress(slot, ip, prefix[, gateway])`, `clearAddress(slot)`, `setBridge(on)`, `isBridge()`, `setRouting(on)`, `isRouting()`, `setDhcp(slot, on)`, `autoConfigure(slot)`, `setDhcpRange(slot, first, last)`, `getDhcp(slot)`, `reserveAddress(slot, mac, ip)`, `removeReservation(mac)`, `getDhcpLeases()`, `clearDhcpLeases()`, `addDnsRecord(name, ip)`, `removeDnsRecord(name)`, `getDnsRecords()`, `addFirewallRule(action, direction, protocol, src, dst, port)`, `insertFirewallRule(position, ...)`, `removeFirewallRule(position)`, `clearFirewall()`, `setFirewallPolicy(policy)`, `getFirewallPolicy()`, `getFirewallRules()`, `getFirewallBlocked()`, `isAccessPoint()`, `setAccessPoint(ssid[, password])`, `setWifiRange(blocks)`, `getAccessPoint()`, `getWifiClients()`, `scanWifi(slot)`, `joinWifi(slot, ssid[, password])`, `leaveWifi(slot)`, `getWifi(slot)`, `setUpstream`, `clearUpstream`, `setGuestNetwork`, `clearGuestNetwork`, `setVlan(slot, id)`, `getVlan(slot)`, `setSniffer(slot, on)`, `isSniffer(slot)`, `getStats(slot)`, `resetStats(slot)`, `addTunnel`, `removeTunnel`, `getTunnels`, `setUplink(slot, on)`, `isRouter()`, `addPortForward(publicPort, ip, port)`, `removePortForward(publicPort)`, `getPortForwards()`, `setHostname(slot, name)`, `getHostname(slot)`, `resolve(slot, name)`, `send(slot, host, dstPort, srcPort, text)`, `ping(slot, host)`, `sendFrame(slot, mac, etherType, text)`, `listen(slot, port)`, `unlisten(slot, port)`, `connect(slot, host, port)`, `tcpSend(slot, id, text)`, `tcpClose(slot, id)`, `scan(slot)`.
Events: `realplugs_packet` (`side, slot, srcIp, srcPort, dstPort, data`), `realplugs_frame` (`side, slot, srcMac, dstMac, etherType, data`) and `realplugs_tcp` (`side, slot, event, id, ...`: `"accepted", id, remoteIp, remotePort, localPort` / `"connected", id, remoteIp, remotePort` / `"data", id, data` / `"closed", id, reason`). Calls that can fail return `false, reason` (or `nil, reason`).

```lua
-- Point to point: two computers, one cord between their wall plates.
local nic = peripheral.find("realplugs_socket")
nic.setAddress(1, "10.0.0.1", 24)          -- on the other computer: "10.0.0.2"
nic.send(1, "10.0.0.2", 80, 5000, "hello")
local _, side, slot, ip, sport, dport, data = os.pullEvent("realplugs_packet")

-- LAN: a wall plate in bridge mode is the switch; a router hands out addresses.
sw.setBridge(true)                          -- on the switch's computer
router.setAddress(1, "192.168.1.1", 24); router.setDhcp(1, true); router.setRouting(true)
host.autoConfigure(1)                       -- 192.168.1.2, gateway 192.168.1.1

-- Connections and names.
server.setHostname(1, "files"); server.listen(1, 80)
local id = client.connect(1, "files", 80)        -- name looked up in the segment
local _, _, _, ev, cid = os.pullEvent("realplugs_tcp")   -- "connected"
client.tcpSend(1, id, "GET /")

-- DHCP range, a reserved address and a local name on the router.
router.setDhcpRange(1, "192.168.1.100", "192.168.1.200")
router.reserveAddress(1, "02:52:50:12:34:56", "192.168.1.50")   -- always the same address for that port
router.addDnsRecord("nas.home", "192.168.1.50")                 -- any host on the LAN can connect(1, "nas.home", 80)

-- Firewall: nothing from the internet may reach port 22, pings from outside are silently ignored.
router.addFirewallRule("reject", "in", "tcp", "any", "any", 22)
router.addFirewallRule("drop", "in", "icmp", "any", "any", 0)

-- Wi-Fi: no cable between the computer's wall plate and the LAN.
for _, n in ipairs(laptop.scanWifi(1)) do print(n.ssid, n.signal) end
print(laptop.joinWifi(1, "RealPlugs-3FA2"))      --> true   (laptop.joinWifi(1, "home", "secret123") for a protected network)
laptop.autoConfigure(1)                         --> an address from the router behind the access point

-- WAN: the router's second port goes to the ISP line and becomes the modem.
print(router.setUplink(2, true))            --> true  100.64.12.7
print(host.ping(1, "100.64.200.9"))         --> 130   (ms), a server somewhere else
```
Limits: cords made with an extension-cable strip at the far end are not links; routes are worked out when a packet is sent (nothing is simulated per tick); there is no packet loss, no real DNS servers (names are a server-wide table), and a Network Switch does not need power.



### Cable types, QoS and the firewall log

Cat5, Cat6 and Fibre cables are RJ45 cords (craft one from an Ethernet plug; Cat6 from a Cat5 cable, iron nugget and copper ingot; Fibre from an Ethernet plug, glass pane and glowstone dust). A cable adds a delay to every hop it carries and limits how many packets per second leave through each end; the tooltip shows the numbers.

| Cable | Delay per hop | Packets/s per end | Longest |
|---|---|---|---|
| Ethernet cord (old) | 0 | no limit | as before |
| Cat5 | 2 ticks | 40 | 12 blocks |
| Cat6 | 1 tick | 200 | 24 blocks |
| Fibre | 0 | no limit | 64 blocks |

`setQos(slot, rate, delay)` adds your own limit to a port (a switch port limits what the switch sends out of it); the smaller of the cable's and the port's limit counts. Waiting packets keep their order; a packet that would wait over 5 seconds is lost. `getFirewallLog()` lists the last 64 packets the firewall stopped, and `rpmon blocked` shows them.

### Network Configurator, roaming and address pools

The **Network Configurator** (craft: Ethernet plug, redstone, copper ingot, glass pane) opens a settings screen when you right-click a router, switch, access point or computer socket: pages for the firewall, DHCP range and every port (address, gateway, DHCP, VLAN, hostname, limits, roaming, Wi-Fi). Change fields, press Apply; a message says what was refused. It calls the same methods as Lua, so it needs CC: Tweaked installed, but no computer. Only the player holding the item can change settings, within 10 blocks.

Wi-Fi ports stay on their access point while it is in range and move only when another one with the same name and password is stronger by the roaming margin (default 15 signal points, `setRoaming(slot, margin)`).

An uplink takes its public address from a pool: `setPublicRange(slot, "isp" | "wide" | "compact")` before switching it on (100.64.0.0/10, 44.0.0.0/8, 198.18.0.0/15). There is no IPv6.

### More programs (`lua/`)

`rpntp` (time server), `rpmail` (mail and webmail), `rpbalance` (load balancer), `rpddns` (dynamic DNS), `rpprint` (print server), `rpinstall <server>` (fetch all programs from an `rpfiles` server), `rplab` (test-lab site). Each program's first lines say how to run it. The datapack in `datapacks/realplugs_testlab` builds a small lab.

### Websites and other programs (`lua/`)

Real Plugs computers can host websites and run services. Copy a file onto a CC computer with `edit <name>` and paste it in (the computer must be next to a socket that is on a network). `rpweb.lua` is also a library: other programs load it with `require("rpweb")`.

| Program | What it does |
|---|---|
| `rpweb` | `rpweb init` makes a starter site in `/www`; `rpweb serve 1 mysite` serves it on port 80 under the name `mysite`; `rpweb browse mysite` is a tabbed text browser; `rpweb directory 1 hub` runs a search-engine site; `rpweb serve 1 mysite --list hub` announces your site to it. |
| `rpadmin` | `rpadmin <password> [slot] [name]`: a web page to manage the router next to it: ports, DHCP range, leases and reservations, DNS records, port forwards, firewall rules, VPN tunnels, Wi-Fi and guest network. Open it with the browser from any computer on the LAN. |
| `rpmon` | `rpmon [monitor]` shows live traffic per port (packets/s, bars, totals) and the firewall counter; `rpmon sniff <slot> [file]` prints every packet of a segment. |
| `rpfiles` | `rpfiles serve [slot] [folder] [name] [--password pw]` shares a folder; `rpfiles ls / get / put / rm <host> ...` from other computers (uploads and deletes need the password). |
| `rpchat` | `rpchat serve [slot] [name]` runs a chat room with private mail; `rpchat join <host> <nick>` joins it (`/who`, `/mail nick text`, `/inbox`, `/quit`). |
| `rpdns` | `rpdns apply [zones.txt]` makes a router's DNS records match a text file (`name address` per line); `rpdns list`. |

**Websites**
- **Pages:** the site is the files in `/www` (`edit www/index.html`). HTML tags: `h1 h2 h3 p br hr ul ol li a b i u font(color) span(color) pre center blockquote table tr td img form input textarea select`. Colours are CC colour names. Pages may contain `{{hits}}`, `{{time}}` and `{{host}}`. Sub-folders, plain `.txt` files and `404.html` work.
- **Pictures:** `<img src="logo.nfp">` shows a CC `.nfp` image (made with the `paint` program) drawn in coloured cells, up to 6 per page.
- **Forms:** `<form action="/guestbook" method="post">` with `text`, `password`, `hidden`, `checkbox`, `submit`, `textarea` (one line) and `select` fields. Clicking a field in the browser asks for its value; Enter in a text field presses the form's submit button.
- **Programs on the server:** a file ending in `.lua` runs when it is requested (`/guestbook` finds `www/guestbook.lua`). It sees `request` (`method`, `path`, `query`, `form`, `ip`) and may `echo(...)` html, `return` a string or `{redirect = "/"}`, and keep data with `data_load(name)` / `data_save(name, table)` (files in `/data`). `escape(text)` makes text safe for html. Pages run in a sandbox without files, `io` or `os.execute`, but only put your own code there (a page can loop forever).
- **Address:** the `name` is a hostname: unique on a LAN behind a router (or `router.addDnsRecord("mysite", ip)`), server-wide when the computer is on an uplink. A bare address or `http://100.64.1.2:8080/page` works too.
- **Browser:** arrows / PgUp / PgDn / wheel scroll; `G` go (address or link number), `B` back, `R` reload, `T` new tab, `W` close tab, `[` `]` or Tab switch tabs, `D` bookmark, `M` bookmarks, `/` find, `N` next match, `Q` quit. Clicks work on links, fields and buttons.
- **Protocol:** a small HTTP/1.0 (GET, POST, status codes, `Content-Length`) over `listen` / `connect`. Use the firewall to restrict who can reach port 80.

Tests: `sh tests/lua/run.sh` (Lua, needs any Lua 5.3+) and `sh tests/netsim/run.sh` (the network model, needs a JDK) run in CI.
