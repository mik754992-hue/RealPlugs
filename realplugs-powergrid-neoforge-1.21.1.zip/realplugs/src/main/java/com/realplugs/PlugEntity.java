package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** A plug/adapter stuck to a face of a block (a CC: Tweaked computer) at an exact position. */
public class PlugEntity extends Entity {
    private static final EntityDataAccessor<ItemStack> STACK =
            SynchedEntityData.defineId(PlugEntity.class, EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<Direction> FACE =
            SynchedEntityData.defineId(PlugEntity.class, EntityDataSerializers.DIRECTION);

    public BlockPos anchor = BlockPos.ZERO;

    public PlugEntity(EntityType<?> type, Level level) {
        super(type, level);
        this.noPhysics = true;
        this.setNoGravity(true);
    }

    public static PlugEntity create(Level level, BlockPos anchor, Direction face, Vec3 hit, ItemStack stack) {
        PlugEntity e = new PlugEntity(ModEntities.PLUG.get(), level);
        e.anchor = anchor;
        e.entityData.set(STACK, stack);
        e.entityData.set(FACE, face);
        e.setPos(hit.x + face.getStepX() * 0.02, hit.y + face.getStepY() * 0.02, hit.z + face.getStepZ() * 0.02);
        return e;
    }

    public ItemStack getStack() { return entityData.get(STACK); }
    public Direction getFace() { return entityData.get(FACE); }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(STACK, ItemStack.EMPTY);
        builder.define(FACE, Direction.NORTH);
    }

    @Override
    public void tick() {
        super.tick();
        if (!level().isClientSide && tickCount % 20 == 0 && level().isEmptyBlock(anchor)) {
            spawnAtLocation(getStack());
            discard();
        }
    }

    @Override
    public boolean isPickable() { return true; }

    @Override
    public ItemStack getPickResult() { return getStack().copy(); }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        ItemStack held = player.getItemInHand(hand);
        ItemStack mine = getStack();

        // plug something into an adapter that is stuck to the computer
        if (held.getItem() instanceof PlugItem && mine.getItem() instanceof PlugItem mi
                && mi.adapter && PlugItem.inner(mine).isEmpty()) {
            if (!level().isClientSide) {
                ItemStack copy = mine.copy();
                PlugItem.setInner(copy, PlugItem.takeOne(held, player));
                entityData.set(STACK, copy);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }

        // empty hand: pull the inner plug first, then the plug/adapter itself
        if (held.isEmpty()) {
            if (!level().isClientSide) {
                ItemStack in = PlugItem.inner(mine);
                if (!in.isEmpty()) {
                    ItemStack copy = mine.copy();
                    PlugItem.setInner(copy, ItemStack.EMPTY);
                    entityData.set(STACK, copy);
                    PlugItem.give(player, in.copy());
                } else {
                    PlugItem.give(player, mine);
                    discard();
                }
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return true;
        if (source.getEntity() instanceof Player p) {
            if (!p.getAbilities().instabuild) spawnAtLocation(getStack());
            discard();
            return true;
        }
        return false;
    }

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        entityData.set(STACK, ItemStack.parseOptional(level().registryAccess(), tag.getCompound("Stack")));
        entityData.set(FACE, Direction.from3DDataValue(tag.getInt("Face")));
        int[] a = tag.getIntArray("Anchor");
        if (a.length == 3) anchor = new BlockPos(a[0], a[1], a[2]);
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.put("Stack", getStack().saveOptional(level().registryAccess()));
        tag.putInt("Face", getFace().get3DDataValue());
        tag.putIntArray("Anchor", new int[]{anchor.getX(), anchor.getY(), anchor.getZ()});
    }
}
