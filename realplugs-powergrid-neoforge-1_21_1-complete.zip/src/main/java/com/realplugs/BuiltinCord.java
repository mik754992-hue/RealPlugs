package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import org.patryk3211.powergrid.electricity.wire.WireConnection;
import org.patryk3211.powergrid.electricity.wire.powercord.AutoCordEndpoint;

import java.util.UUID;

/**
 * The built-in cord of an EV charger, once it is pulled out of its dock, is a real Power Grid plug cord whose first end
 * is already plugged into the charger's slot (the same state a cord is in after you click the first outlet with it).
 * So the second click, on an EV port, goes through PlugCordHandler and Power Grid's normal cord code: length limit,
 * the cord hanging between the two, the electrical connection, the connector check.
 *
 * The item is marked (custom data) with the charger it belongs to and is only valid while that charger says this
 * player is holding the cord; the sweep below deletes it everywhere else, so pulling the cord out never produces
 * a free cord item.
 */
@EventBusSubscriber(modid = RealPlugsMod.MODID)
public final class BuiltinCord {
    private static final String TAG = "realplugs_builtin";

    private BuiltinCord() {}

    @SuppressWarnings("unchecked")
    private static DataComponentType<WireConnection> connectionType() {
        return (DataComponentType<WireConnection>) BuiltInRegistries.DATA_COMPONENT_TYPE
                .get(ResourceLocation.fromNamespaceAndPath("powergrid", "connection"));
    }

    /** A cord for this charger with its first end in the charger's slot, or EMPTY when that cannot be made. */
    public static ItemStack make(Level level, BlockPos pos, BlockState state, PlugSocketBlock block) {
        PlugTypes.Standard std = block.def.slots()[0];
        int type = -1;
        for (int i = 0; i < CordTypes.ALL.length; i++) {
            if (CordTypes.ALL[i].a() == std && CordTypes.ALL[i].b() == std) {
                type = i;
                break;
            }
        }
        DataComponentType<WireConnection> conn = connectionType();
        if (type < 0 || conn == null) return ItemStack.EMPTY;

        ItemStack s = new ItemStack(ModItems.CHARGER_CORD.get());
        s.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(type));
        s.set(DataComponents.CUSTOM_NAME, Component.translatable("item.realplugs.charger_cord"));
        CompoundTag tag = new CompoundTag();
        tag.putBoolean(TAG, true);
        tag.putIntArray("pos", new int[]{pos.getX(), pos.getY(), pos.getZ()});
        tag.putString("dim", level.dimension().location().toString());
        s.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        s.set(conn, WireConnection.of(new AutoCordEndpoint(pos, 2, 1, block.slotWorldPos(state, pos, 0),
                state.getValue(PlugSocketBlock.FACING))));
        return s;
    }

    public static boolean isMarked(ItemStack s) {
        CustomData d = s.get(DataComponents.CUSTOM_DATA);
        return d != null && d.copyTag().getBoolean(TAG);
    }

    /** Is this the cord of the charger at pos? */
    public static boolean belongsTo(ItemStack s, BlockPos pos) {
        if (!isMarked(s)) return false;
        int[] p = s.get(DataComponents.CUSTOM_DATA).copyTag().getIntArray("pos");
        return p.length == 3 && p[0] == pos.getX() && p[1] == pos.getY() && p[2] == pos.getZ();
    }

    /** Does the player carry the cord of the charger at pos? */
    public static boolean holds(Player player, BlockPos pos) {
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            if (belongsTo(inv.getItem(i), pos)) return true;
        }
        return belongsTo(player.containerMenu.getCarried(), pos);
    }

    /** A cord whose first end is gone was used up (plugged in somewhere): what is left of it is worthless. */
    private static boolean spent(ItemStack s) {
        DataComponentType<WireConnection> conn = connectionType();
        WireConnection wc = conn == null ? null : s.get(conn);
        return wc == null || PlugCordHandler.firstEnd(wc) == null;
    }

    /** Valid = still has its first end, and the charger it came from says this very player is holding its cord. */
    private static boolean valid(Player player, ItemStack s) {
        if (spent(s)) return false;
        CompoundTag tag = s.get(DataComponents.CUSTOM_DATA).copyTag();
        int[] p = tag.getIntArray("pos");
        if (p.length != 3 || player.getServer() == null) return false;
        ServerLevel level = player.getServer().getLevel(
                ResourceKey.create(Registries.DIMENSION, ResourceLocation.parse(tag.getString("dim"))));
        if (level == null) return false;
        BlockPos pos = new BlockPos(p[0], p[1], p[2]);
        if (!level.isLoaded(pos) || !(level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be)) return false;
        UUID holder = be.builtinCordHolder();
        return holder != null && holder.equals(player.getUUID());
    }

    /** Four times a second: a built-in cord that is not (or no longer) its charger's pulled-out cord disappears. */
    @SubscribeEvent
    public static void sweep(PlayerTickEvent.Post event) {
        Player player = event.getEntity();
        if (player.level().isClientSide || player.tickCount % 5 != 0) return;
        Inventory inv = player.getInventory();
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && isMarked(s) && !valid(player, s)) inv.setItem(i, ItemStack.EMPTY);
        }
    }
}
