package com.realplugs.numismatics;

import dev.ithundxr.createnumismatics.content.backend.IDeductable;
import dev.ithundxr.createnumismatics.content.backend.ReasonHolder;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

/**
 * Paying with a Create: Numismatics card. Only ever touched when Numismatics is loaded (see EvChargerBlock), so the
 * Numismatics classes it references always exist. Uses the same entry point as Numismatics' own depositor:
 * IDeductable.get(card, player, reason) finds the account behind the card (and checks the player may use it),
 * deduct(spurs, reason) takes the money. Server side only.
 */
public final class NumismaticsPay {
    private NumismaticsPay() {}

    /** Takes the amount (in spurs) from the card's account. Returns null on success, else why it failed. */
    public static Component pay(ItemStack card, Player player, int spurs) {
        ReasonHolder reason = new ReasonHolder();
        IDeductable account = IDeductable.get(card, player, reason);
        if (account == null) return reason.getMessageOrDefault(Component.translatable("message.realplugs.ev_card_invalid"));
        if (account.deduct(spurs, reason)) return null;
        return reason.getMessageOrDefault();
    }
}
