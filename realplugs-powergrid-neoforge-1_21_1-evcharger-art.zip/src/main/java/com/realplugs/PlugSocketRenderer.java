package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.gui.Font;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.entity.ItemRenderer;
import net.minecraft.core.Direction;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.item.ItemStack;
import org.joml.Vector3f;
import org.patryk3211.powergrid.electricity.base.DirectionalElectricBlock;

public class PlugSocketRenderer implements BlockEntityRenderer<PlugSocketBlockEntity> {
    private final ItemRenderer items;

    private final Font font;

    public PlugSocketRenderer(BlockEntityRendererProvider.Context ctx) {
        this.font = ctx.getFont();
        this.items = ctx.getItemRenderer();
    }

    private static final java.util.Map<PlugTypes.Standard, ItemStack> CORD_PLUGS = new java.util.EnumMap<>(PlugTypes.Standard.class);

    private static ItemStack cordPlug(PlugTypes.Standard std) {
        return CORD_PLUGS.computeIfAbsent(std, k -> {
            ItemStack st = new ItemStack(ModItems.PLUG.get());
            st.set(net.minecraft.core.component.DataComponents.CUSTOM_MODEL_DATA,
                    new net.minecraft.world.item.component.CustomModelData(PlugTypes.plugIndexFor(k)));
            return st;
        });
    }

    @Override
    public void render(PlugSocketBlockEntity be, float partial, PoseStack ps, MultiBufferSource buf, int light, int overlay) {
        if (be.getLevel() == null || !(be.getBlockState().getBlock() instanceof PlugSocketBlock block)) return;
        Direction f = be.getBlockState().getValue(DirectionalElectricBlock.FACING);
        var plugs = be.plugs();
        float scale = block.plugScale();

        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        // same rotation the blockstate applies, so we can work in the north-facing frame
        if (f.getAxis().isHorizontal()) {
            ps.mulPose(Axis.YP.rotationDegrees(-(f.toYRot() + 180f)));
        } else {
            ps.mulPose(Axis.XP.rotationDegrees(f == Direction.UP ? 90f : -90f));
        }

        for (int i = 0; i < plugs.size(); i++) {
            ItemStack s = plugs.get(i);
            if (s.isEmpty() && !(block instanceof PortAnchorBlock)) {
                if (block instanceof EvChargerBlock) {
                    // a charger's own cord sits docked in the socket, and leaves it empty while somebody holds the cord
                    if (be.tetherOwner(i) == null) s = cordPlug(block.def.slots()[i]);
                } else if (be.cordShown(i)) {
                    // a cord is plugged in here: show a plug of this slot's connector standard
                    s = cordPlug(block.def.slots()[i]);
                }
            }
            if (s.isEmpty()) continue;

            ps.pushPose();
            ps.translate(block.slotCenterX(i), block.plugCenterY(), block.frontLocalZ() - 0.02);
            ps.mulPose(Axis.YP.rotationDegrees(180f));
            ps.scale(scale, scale, scale);
            PlugRender.draw(items, s, ps, buf, light, overlay, be.getLevel(), i * 8);
            ps.popPose();
        }
        ps.popPose();

        if (block instanceof EvChargerBlock charger) {
            drawScreen(be, charger, f, ps, buf, light);
        }

        // the cable to anyone tethered to a slot (a pocket computer with a port)
        if (block instanceof EvChargerBlock) {
            drawBuiltinCord(be, block, f, ps, buf, light, partial);
        } else if (!(block instanceof PortAnchorBlock)) {
            Vec3 origin = Vec3.atLowerCornerOf(be.getBlockPos());
            for (int i = 0; i < plugs.size(); i++) {
                java.util.UUID owner = be.tetherOwner(i);
                if (owner == null) continue;
                Player p = be.getLevel().getPlayerByUUID(owner);
                if (p == null) continue;
                Vec3 out = new Vec3(f.getStepX(), f.getStepY(), f.getStepZ()).scale(0.17);   // the back end of the plug
                Vec3 from = block.slotWorldPos(be.getBlockState(), be.getBlockPos(), i).add(out).subtract(origin);
                TetherRope.draw(ps, buf, from, TetherRope.handPos(p, partial).subtract(origin), light);
            }
        }
    }

    /** A point on the charger's front, given in model units of the north frame, relative to the block's corner. */
    private static Vec3 frontPoint(Direction f, double x, double y, double z) {
        Vector3f v = new Vector3f((float) (x / 16.0 - 0.5), (float) (y / 16.0 - 0.5), (float) (z / 16.0 - 0.5));
        Axis.YP.rotationDegrees(-(f.toYRot() + 180f)).transform(v);
        return new Vec3(0.5 + v.x, 0.5 + v.y, 0.5 + v.z);
    }

    /**
     * The charger's built-in cord. Docked: a cable runs from the connector in the socket down to the cable gland.
     * Pulled out: the cable runs from the gland to the hand of whoever holds it.
     */
    private void drawBuiltinCord(PlugSocketBlockEntity be, PlugSocketBlock block, Direction f, PoseStack ps,
                                 MultiBufferSource buf, int light, float partial) {
        if (!f.getAxis().isHorizontal()) return;
        Vec3 origin = Vec3.atLowerCornerOf(be.getBlockPos());
        Vec3 gland = frontPoint(f, 12.0, 2.4, 7.0);
        java.util.UUID owner = be.tetherOwner(0);
        if (owner != null) {
            Player p = be.getLevel().getPlayerByUUID(owner);
            if (p != null) TetherRope.draw(ps, buf, gland, TetherRope.handPos(p, partial).subtract(origin), light);
        } else if (be.plugs().get(0).isEmpty() && !be.cordShown(0)) {
            Vec3 out = new Vec3(f.getStepX(), f.getStepY(), f.getStepZ()).scale(0.17);   // the back end of the connector
            Vec3 from = block.slotWorldPos(be.getBlockState(), be.getBlockPos(), 0).add(out).subtract(origin);
            TetherRope.draw(ps, buf, from, gland, light);
        }
    }

    /** The charger's screen: credit and price, in the north frame (front is -z) then turned to face the viewer. */
    private void drawScreen(PlugSocketBlockEntity be, EvChargerBlock charger, Direction f, PoseStack ps, MultiBufferSource buf, int light) {
        ps.pushPose();
        ps.translate(0.5, 0.5, 0.5);
        ps.mulPose(Axis.YP.rotationDegrees(-(f.toYRot() + 180f)));
        ps.translate(0.0, 13.75 / 16.0 - 0.5, 7.6 / 16.0 - 0.5);   // centre of the screen, just in front of it
        ps.mulPose(Axis.YP.rotationDegrees(180f));
        float s = 0.0072f;
        ps.scale(s, -s, s);
        String l1 = "CREDIT " + be.credit();
        String l2 = charger.pricePerMinute() + " / min";
        int c1 = be.credit() > 0 ? 0x55FF55 : 0xFF5555;
        font.drawInBatch(l1, -font.width(l1) / 2f, -9f, c1, false, ps.last().pose(), buf, Font.DisplayMode.NORMAL, 0, light);
        font.drawInBatch(l2, -font.width(l2) / 2f, 1f, 0xCCCCCC, false, ps.last().pose(), buf, Font.DisplayMode.NORMAL, 0, light);
        ps.popPose();
    }
}
