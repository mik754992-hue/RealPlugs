package com.realplugs.gui;

import com.realplugs.ModItems;
import net.minecraft.world.entity.player.Player;

final class ConfiguratorHolding {
    private ConfiguratorHolding() {}

    /** Only a player holding the Network Configurator can send changes. */
    static boolean holds(Player p) {
        return p.getMainHandItem().is(ModItems.CONFIGURATOR.get()) || p.getOffhandItem().is(ModItems.CONFIGURATOR.get());
    }
}
