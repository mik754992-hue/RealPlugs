package com.realplugs;

/** One outlet / power strip type: plate geometry (1/16 block, north frame) and the connector standard of every slot. */
public record SocketDef(String id, int xMin, int xMax, int yMin, int yMax, int depth, PlugTypes.Standard[] slots) {}
