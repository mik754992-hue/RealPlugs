package dan200.computercraft.api.upgrades;

import com.mojang.serialization.MapCodec;

/** COMPILE-TIME STUB of CC: Tweaked 1.113's UpgradeType. Excluded from the released jar. */
public interface UpgradeType<T extends UpgradeBase> {
    MapCodec<T> codec();

    static <T extends UpgradeBase> UpgradeType<T> create(MapCodec<T> codec) {
        throw new UnsupportedOperationException("stub: the real class comes from CC: Tweaked");
    }
}
