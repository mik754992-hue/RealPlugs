package com.realplugs.net;

import com.realplugs.PlugSocketBlockEntity;
import com.realplugs.RealPlugsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.core.GlobalPos;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.ServerTickEvent;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.PriorityQueue;
import java.util.Set;

/**
 * The network model behind the "realplugs_socket" CC: Tweaked peripheral.
 *
 * <ul>
 *   <li>Every RJ45 slot of a socket is an interface with its own MAC address and its own IP settings.</li>
 *   <li>An ethernet cord (a Power Grid cord with an RJ45 plug on each end) between two RJ45 slots is a link:
 *       two cabled interfaces are a point-to-point connection.</li>
 *   <li>A LAN segment is everything connected by cords through sockets that are set to bridge mode (a switch).</li>
 *   <li>Inside a segment, addresses of the same subnet reach each other directly. Anything else goes to the interface's
 *       gateway, which has to be an interface of a socket in router mode. A router passes packets on to the network
 *       that holds the destination, or to its uplink.</li>
 *   <li>An uplink interface is a modem: the ISP gives it a public address (100.64.0.0/10), and it can reach every
 *       other uplink on the server, with a delay that grows with the distance. A router with an uplink does NAT for
 *       the private addresses behind it.</li>
 *   <li>Datagrams (UDP-like) and connections (TCP-like: listen, connect, in-order data, close, refused/reset) carry ports and
 *       at most 1500 characters per packet. Raw Ethernet frames stay inside a segment. Hostnames resolve inside the
 *       segment and, for uplinks, across the internet. Nothing is simulated that is not listed here.</li>
 *   <li>The Network Switch block is a socket whose ports are always bridged.</li>
 *   <li>A DHCP server keeps leases (the same port gets the same address again), reservations by MAC address and an address
 *       range; any socket can hold local DNS records. A firewall (ordered rules, first match wins) checks what a router
 *       passes on and what arrives on an uplink. A Wi-Fi access point bridges its cable port with every port that joined
 *       its network by radio and is within range.</li>
 * </ul>
 * Nothing here is ever simulated tick by tick: routes are worked out when a packet is sent. Server thread only.
 */
@EventBusSubscriber(modid = RealPlugsMod.MODID)
public final class NetworkManager {
    public static final int MTU = 1500;
    private static final int TTL = 16;
    /** A transmit queue that would make a packet wait longer than this (5 s) drops it instead. */
    private static final int MAX_QUEUE_TICKS = 100;

    public record Iface(ServerLevel level, BlockPos pos, int slot) {}

    public static final class Packet {
        long src, dst;
        int srcPort, dstPort;
        int proto;   // 0 = datagram, 1 = connection segment
        int flags;   // SYN, ACK, FIN, RST, DATA
        String payload = "";
        /** proto 3 = VPN tunnel: the packet carried inside, and the shared key. */
        Packet inner;
        String key = "";

        Packet copy() {
            Packet p = new Packet();
            p.src = src;
            p.dst = dst;
            p.srcPort = srcPort;
            p.dstPort = dstPort;
            p.proto = proto;
            p.flags = flags;
            p.payload = payload;
            p.inner = inner;
            p.key = key;
            return p;
        }
    }

    public static final class Route {
        Iface target;
        Packet packet;
        int ticks;
        String error;
        /** A firewall dropped it without telling anyone. */
        boolean dropped;
    }

    private record Pending(long due, long seq, GlobalPos where, int slot, Packet packet) {}

    private record WanEntry(GlobalPos where, int slot) {}

    private static final PriorityQueue<Pending> QUEUE = new PriorityQueue<>(Comparator.comparingLong(Pending::due).thenComparingLong(Pending::seq));
    private static long seq;
    /** The game tick of the packet being routed (for the firewall log). */
    private static long tickNow;
    private static final Map<Long, WanEntry> WAN = new HashMap<>();
    /** Hostnames of uplink interfaces, across the whole server. */
    private static final Map<String, Long> DNS = new HashMap<>();
    /** Access point blocks and sockets with a port that joined a Wi-Fi network (loaded ones). */
    private static final Set<GlobalPos> APS = new HashSet<>();
    private static final Set<GlobalPos> WIFI_HOSTS = new HashSet<>();

    private NetworkManager() {}

    // ------------------------------------------------------------------ lookups

    public static PlugSocketBlockEntity beOf(ServerLevel level, BlockPos pos) {
        if (!level.isLoaded(pos)) return null;
        return level.getBlockEntity(pos) instanceof PlugSocketBlockEntity b ? b : null;
    }

    private static PlugSocketBlockEntity be(Iface i) {
        return beOf(i.level(), i.pos());
    }

    private static boolean usable(Iface i) {
        PlugSocketBlockEntity b = be(i);
        return b != null && i.slot() >= 0 && i.slot() < b.slotCount() && b.isRj45(i.slot());
    }

    /** Traffic counters of a port (getStats). */
    private static void count(Iface i, Packet p, boolean tx) {
        PlugSocketBlockEntity b = be(i);
        if (b == null || i.slot() >= NetConfig.MAX) return;
        NetConfig c = b.net();
        int len = 28 + (p.payload == null ? 0 : p.payload.length());
        if (tx) {
            c.txPackets[i.slot()]++;
            c.txBytes[i.slot()] += len;
        } else {
            c.rxPackets[i.slot()]++;
            c.rxBytes[i.slot()] += len;
        }
    }

    /** Every port of the segment that is set to sniff hears the packet. */
    private static void sniff(List<Iface> dom, Packet p) {
        for (Iface d : dom) {
            PlugSocketBlockEntity b = be(d);
            if (b == null || d.slot() >= NetConfig.MAX || !b.net().sniff[d.slot()]) continue;
            for (NetListener l : b.netListeners()) {
                l.sniff(d.slot() + 1, NetConfig.format(p.src), NetConfig.format(p.dst), protoName(p), p.srcPort, p.dstPort, p.payload);
            }
        }
    }

    /** A packet passes through this port: its light blinks. */
    private static void mark(Iface i) {
        PlugSocketBlockEntity b = be(i);
        if (b != null) b.markActivity(i.slot());
    }

    /**
     * Lights up every port on the way from one port to another inside a segment (a switch shows which ports are busy)
     * and returns that path, from the first port to the last (empty when there is none).
     */
    private static List<Iface> markPath(Iface from, Iface to) {
        if (from.equals(to)) {
            mark(from);
            return List.of(from);
        }
        Map<Iface, Iface> parent = new HashMap<>();
        ArrayDeque<Iface> todo = new ArrayDeque<>();
        parent.put(from, from);
        todo.add(from);
        while (!todo.isEmpty() && parent.size() < 256) {
            Iface i = todo.poll();
            if (!usable(i)) continue;
            if (i.equals(to)) break;
            for (Iface n : neighbors(i)) {
                if (!parent.containsKey(n)) {
                    parent.put(n, i);
                    todo.add(n);
                }
            }
        }
        if (!parent.containsKey(to)) return List.of();
        List<Iface> path = new ArrayList<>();
        Iface i = to;
        for (int guard = 0; guard < 300; guard++) {
            mark(i);
            path.add(0, i);
            if (i.equals(from)) break;
            i = parent.get(i);
        }
        return path;
    }

    /**
     * What the cables and the quality-of-service settings on the way cost a packet: extra delay in ticks, or -1 when a
     * transmit queue is so long that the packet is lost. Every port the packet leaves through can have a cap (its cable's
     * packets-per-second and the port's own QoS limit, the smaller counts); packets over the cap wait their turn.
     */
    private static int charge(List<Iface> path) {
        if (path.size() < 2) return 0;
        double now = path.get(0).level().getServer().getTickCount();
        int extra = 0;
        for (int k = 0; k + 1 < path.size(); k++) {
            Iface a = path.get(k);
            PlugSocketBlockEntity b = be(a);
            if (b == null || a.slot() >= NetConfig.MAX) continue;
            NetConfig c = b.net();
            int rate = c.qosRate[a.slot()];
            int delay = c.qosDelay[a.slot()];
            CableTier tier = b.cordTier(a.slot());
            if (tier != null && path.get(k + 1).equals(peer(a))) {
                delay += tier.delayTicks;
                if (tier.packetsPerSecond > 0 && (rate <= 0 || tier.packetsPerSecond < rate)) rate = tier.packetsPerSecond;
            }
            extra += delay;
            if (rate > 0) {
                double start = Math.max(now, c.busyUntil[a.slot()]);
                double wait = start - now;
                if (wait > MAX_QUEUE_TICKS) return -1;
                c.busyUntil[a.slot()] = start + 20.0 / rate;
                extra += (int) wait;   // sub-tick waits add up through busyUntil, they are not rounded up each time
            }
        }
        return extra;
    }

    // ------------------------------------------------------------------ Wi-Fi

    /** A network name in range of a port. */
    public record WifiNet(String ssid, boolean secured, int signal, int distance) {}

    private static double distance(BlockPos a, BlockPos b) {
        return Math.sqrt(a.distSqr(b));
    }

    private static int signal(double dist, int range) {
        return Math.max(1, (int) Math.round(100.0 * (1.0 - dist / Math.max(1, range))));
    }

    /**
     * The access point this port is connected to by radio. A port stays on the access point it has as long as that one is in range,
     * and moves to the best one only when that is stronger by the port's roaming margin (15 signal points unless set with
     * setRoaming): no flapping between two access points that are about as far away, and a smooth hand-off as you walk.
     */
    public static Iface wifiApOf(Iface client) {
        PlugSocketBlockEntity b = be(client);
        if (b == null || b.isAccessPointBlock() || client.slot() >= NetConfig.MAX) return null;
        NetConfig c = b.net();
        String ssid = c.wifiSsid(client.slot());
        if (ssid.isEmpty()) return null;
        MinecraftServer server = client.level().getServer();
        BlockPos best = null, current = null;
        int bestSig = 0, currentSig = 0;
        double bestDist = Double.MAX_VALUE;
        for (GlobalPos gp : APS) {
            ServerLevel lvl = server.getLevel(gp.dimension());
            if (lvl != client.level()) continue;
            PlugSocketBlockEntity ab = beOf(lvl, gp.pos());
            if (ab == null || !ab.isAccessPointBlock()) continue;
            NetConfig ac = ab.net();
            String key = c.wifiKey(client.slot());
            boolean main = ssid.equals(ac.apSsid) && key.equals(ac.apKey);
            boolean guest = !ac.apGuestSsid.isEmpty() && ssid.equals(ac.apGuestSsid) && key.equals(ac.apGuestKey);
            if (!main && !guest) continue;
            double d = distance(gp.pos(), client.pos());
            if (d > ac.apRange) continue;
            int sig = signal(d, ac.apRange);
            if (sig > bestSig || (sig == bestSig && d < bestDist)) { bestDist = d; best = gp.pos(); bestSig = sig; }
            if (gp.pos().equals(c.roamAp[client.slot()])) { current = gp.pos(); currentSig = sig; }
        }
        BlockPos pick = best;
        if (current != null && best != null && !current.equals(best) && bestSig - currentSig < c.roamMargin(client.slot())) pick = current;
        if (pick == null) {
            c.roamAp[client.slot()] = null;
            return null;
        }
        BlockPos before = c.roamAp[client.slot()];
        if (before != null && !before.equals(pick)) c.roams[client.slot()]++;
        c.roamAp[client.slot()] = pick;
        return new Iface(client.level(), pick, 0);
    }

    /** Is this port on the guest network of the access point it is connected to? */
    public static boolean isGuest(Iface client) {
        PlugSocketBlockEntity b = be(client);
        if (b == null || b.isAccessPointBlock() || client.slot() >= NetConfig.MAX) return false;
        String ssid = b.net().wifiSsid(client.slot());
        if (ssid.isEmpty()) return false;
        Iface ap = wifiApOf(client);
        if (ap == null) return false;
        PlugSocketBlockEntity ab = be(ap);
        return ab != null && ssid.equals(ab.net().apGuestSsid) && !ssid.equals(ab.net().apSsid);
    }

    /** Guest clients can only talk to routers: no other guests, no LAN hosts. */
    private static boolean isolated(Iface a, Iface b) {
        PlugSocketBlockEntity ab = be(a);
        PlugSocketBlockEntity bb = be(b);
        if (ab == null || bb == null) return false;
        if (isGuest(a) && !bb.net().routing) return true;
        return isGuest(b) && !ab.net().routing;
    }

    /** The access point a repeater takes its connection from: the nearest other one with that name and password in range. */
    public static Iface upstreamOf(Iface ap) {
        PlugSocketBlockEntity b = be(ap);
        if (b == null || !b.isAccessPointBlock() || b.net().apUpstream.isEmpty()) return null;
        NetConfig c = b.net();
        MinecraftServer server = ap.level().getServer();
        Iface best = null;
        double bestDist = Double.MAX_VALUE;
        for (GlobalPos gp : APS) {
            ServerLevel lvl = server.getLevel(gp.dimension());
            if (lvl != ap.level() || gp.pos().equals(ap.pos())) continue;
            PlugSocketBlockEntity ub = beOf(lvl, gp.pos());
            if (ub == null || !ub.isAccessPointBlock()) continue;
            NetConfig uc = ub.net();
            if (!c.apUpstream.equals(uc.apSsid) || !c.apUpKey.equals(uc.apKey)) continue;
            double d = distance(gp.pos(), ap.pos());
            if (d <= uc.apRange && d < bestDist) {
                bestDist = d;
                best = new Iface(lvl, gp.pos(), 0);
            }
        }
        return best;
    }

    /** Repeaters that take their connection from this access point. */
    public static List<Iface> repeatersOf(Iface ap) {
        List<Iface> out = new ArrayList<>();
        MinecraftServer server = ap.level().getServer();
        for (GlobalPos gp : APS) {
            ServerLevel lvl = server.getLevel(gp.dimension());
            if (lvl != ap.level() || gp.pos().equals(ap.pos())) continue;
            Iface r = new Iface(lvl, gp.pos(), 0);
            if (ap.equals(upstreamOf(r))) out.add(r);
        }
        return out;
    }

    /** Every port that is connected to this access point by radio. */
    public static List<Iface> wifiClientsOf(Iface ap) {
        List<Iface> out = new ArrayList<>();
        MinecraftServer server = ap.level().getServer();
        for (GlobalPos gp : WIFI_HOSTS) {
            ServerLevel lvl = server.getLevel(gp.dimension());
            if (lvl != ap.level() || gp.pos().equals(ap.pos())) continue;
            PlugSocketBlockEntity cb = beOf(lvl, gp.pos());
            if (cb == null) continue;
            for (int s = 0; s < cb.slotCount() && s < NetConfig.MAX; s++) {
                if (!cb.isRj45(s) || cb.net().wifiSsid(s).isEmpty()) continue;
                Iface ci = new Iface(lvl, gp.pos(), s);
                if (ap.equals(wifiApOf(ci))) out.add(ci);
            }
        }
        return out;
    }

    public static int wifiClientCount(Iface ap) {
        return wifiClientsOf(ap).size();
    }

    /** Networks a port can hear (strongest access point of each name). */
    public static List<WifiNet> wifiScan(Iface me) {
        return wifiScanAt(me.level(), me.pos());
    }

    /** Networks that can be heard at a position (also used by the Wi-Fi analyzer item). */
    public static List<WifiNet> wifiScanAt(ServerLevel level, BlockPos at) {
        Map<String, WifiNet> best = new java.util.LinkedHashMap<>();
        MinecraftServer server = level.getServer();
        for (GlobalPos gp : APS) {
            ServerLevel lvl = server.getLevel(gp.dimension());
            if (lvl != level) continue;
            PlugSocketBlockEntity ab = beOf(lvl, gp.pos());
            if (ab == null || !ab.isAccessPointBlock()) continue;
            NetConfig ac = ab.net();
            double d = distance(gp.pos(), at);
            if (d > ac.apRange) continue;
            int sig = signal(d, ac.apRange);
            if (!ac.apSsid.isEmpty()) offer(best, new WifiNet(ac.apSsid, !ac.apKey.isEmpty(), sig, (int) Math.round(d)));
            if (!ac.apGuestSsid.isEmpty()) offer(best, new WifiNet(ac.apGuestSsid, !ac.apGuestKey.isEmpty(), sig, (int) Math.round(d)));
        }
        return new ArrayList<>(best.values());
    }

    private static void offer(Map<String, WifiNet> best, WifiNet n) {
        WifiNet old = best.get(n.ssid());
        if (old == null || old.signal() < n.signal()) best.put(n.ssid(), n);
    }

    /** Joins a network by radio. Null on success, otherwise why not. */
    public static String joinWifi(Iface me, String ssid, String key) {
        if (!usable(me)) return "not a network port";
        PlugSocketBlockEntity b = be(me);
        if (b.isAccessPointBlock()) return "an access point cannot join a network";
        if (me.slot() >= NetConfig.MAX) return "not a network port";
        String name = ssid.trim();
        if (name.isEmpty()) return "bad network name";
        boolean heard = false;
        boolean match = false;
        MinecraftServer server = me.level().getServer();
        for (GlobalPos gp : APS) {
            ServerLevel lvl = server.getLevel(gp.dimension());
            if (lvl != me.level()) continue;
            PlugSocketBlockEntity ab = beOf(lvl, gp.pos());
            if (ab == null || !ab.isAccessPointBlock()) continue;
            NetConfig ac = ab.net();
            boolean isMain = name.equals(ac.apSsid);
            boolean isGuestName = !ac.apGuestSsid.isEmpty() && name.equals(ac.apGuestSsid);
            if (!isMain && !isGuestName) continue;
            if (distance(gp.pos(), me.pos()) > ac.apRange) continue;
            heard = true;
            if ((isMain && key.equals(ac.apKey)) || (isGuestName && key.equals(ac.apGuestKey))) match = true;
        }
        if (!heard) return "network not found in range";
        if (!match) return "wrong password";
        NetConfig c = b.net();
        c.wifiSsid[me.slot()] = name;
        c.wifiKey[me.slot()] = key;
        WIFI_HOSTS.add(GlobalPos.of(me.level().dimension(), me.pos()));
        b.netChanged();
        return null;
    }

    public static void leaveWifi(Iface me) {
        PlugSocketBlockEntity b = be(me);
        if (b == null || me.slot() >= NetConfig.MAX) return;
        b.net().wifiSsid[me.slot()] = null;
        b.net().wifiKey[me.slot()] = null;
        b.netChanged();
    }

    /** {ssid, signal 1-100, distance} of the access point a port is connected to, or null. */
    public static WifiNet wifiLink(Iface me) {
        Iface ap = wifiApOf(me);
        if (ap == null) return null;
        PlugSocketBlockEntity ab = be(ap);
        double d = distance(ap.pos(), me.pos());
        String ssid = be(me).net().wifiSsid(me.slot());
        return new WifiNet(ssid, true, signal(d, ab.net().apRange), (int) Math.round(d));
    }

    public static String mac(Iface i) {
        int h = Objects.hash(i.level().dimension().location().toString(), i.pos().asLong(), i.slot());
        return String.format("02:52:50:%02x:%02x:%02x", (h >> 16) & 255, (h >> 8) & 255, h & 255);
    }

    /** The interface at the other end of the cord in this slot, if there is one. */
    public static Iface peer(Iface i) {
        PlugSocketBlockEntity b = be(i);
        if (b == null) return null;
        int[] p = b.cordPeer(i.slot());
        return p == null ? null : new Iface(i.level(), new BlockPos(p[0], p[1], p[2]), p[3]);
    }

    private static List<Iface> neighbors(Iface i) {
        List<Iface> out = new ArrayList<>();
        PlugSocketBlockEntity b = be(i);
        if (b == null) return out;
        Iface peer = peer(i);
        if (peer != null) out.add(peer);
        NetConfig nc = b.net();
        if (nc.bridge || b.isSwitchBlock()) {
            for (int s = 0; s < b.slotCount(); s++) {
                if (s != i.slot() && b.isRj45(s) && sameVlan(nc, s, i.slot())) out.add(new Iface(i.level(), i.pos(), s));
            }
        } else if (b.isRouterBlock() && i.slot() != PlugSocketBlockEntity.ROUTER_WAN) {
            for (int s = 0; s < PlugSocketBlockEntity.ROUTER_WAN; s++) {   // the LAN ports are one segment (per VLAN)
                if (s != i.slot() && sameVlan(nc, s, i.slot())) out.add(new Iface(i.level(), i.pos(), s));
            }
        }
        if (b.isAccessPointBlock()) {
            out.addAll(wifiClientsOf(i));   // the access point bridges its cable and the radio
            Iface up = upstreamOf(i);       // a repeater is also bridged to the access point it listens to
            if (up != null) out.add(up);
            out.addAll(repeatersOf(i));
        } else if (i.slot() < NetConfig.MAX && !b.net().wifiSsid(i.slot()).isEmpty()) {
            Iface ap = wifiApOf(i);
            if (ap != null) out.add(ap);
        }
        return out;
    }

    private static boolean sameVlan(NetConfig c, int a, int b) {
        return a < NetConfig.MAX && b < NetConfig.MAX && c.vlan[a] == c.vlan[b];
    }

    /** Every interface that shares a segment with this one (itself included). */
    public static List<Iface> domain(Iface start) {
        List<Iface> out = new ArrayList<>();
        Set<Iface> seen = new HashSet<>();
        ArrayDeque<Iface> todo = new ArrayDeque<>();
        todo.add(start);
        seen.add(start);
        while (!todo.isEmpty() && out.size() < 256) {
            Iface i = todo.poll();
            if (!usable(i)) continue;
            out.add(i);
            for (Iface n : neighbors(i)) if (seen.add(n)) todo.add(n);
        }
        return out;
    }

    private static Iface findByIp(List<Iface> domain, long ip) {
        for (Iface i : domain) {
            PlugSocketBlockEntity b = be(i);
            if (b != null && NetConfig.parse(b.net().ip(i.slot())) == ip) return i;
        }
        return null;
    }

    // ------------------------------------------------------------------ routing

    private static Route fail(String why) {
        Route r = new Route();
        r.error = why;
        return r;
    }

    private static String protoName(Packet p) {
        return p.proto == 1 ? "tcp" : p.proto == 2 ? "icmp" : p.proto == 3 ? "tunnel" : "udp";
    }

    /** Checks the firewall of this socket: null when the packet may pass, otherwise the route that stops it. */
    private static Route firewall(NetConfig c, Packet p, String dir) {
        if (c.rules.isEmpty() && c.fwPolicy.equals("allow")) return null;
        String verdict = c.fwPolicy;
        int ruleNo = 0;   // 0 = no rule matched, the default policy decided
        int idx = 0;
        for (NetConfig.FwRule r : c.rules) {
            idx++;
            if (!r.dir().equals("any") && !r.dir().equals(dir)) continue;
            if (!r.proto().equals("any") && !r.proto().equals(protoName(p))) continue;
            if (!NetConfig.inSpec(r.src(), p.src) || !NetConfig.inSpec(r.dst(), p.dst)) continue;
            if (r.port() != 0 && (p.proto == 2 || p.dstPort != r.port())) continue;
            verdict = r.action();
            ruleNo = idx;
            break;
        }
        if (verdict.equals("allow")) return null;
        c.fwBlocked++;
        c.logBlocked(new NetConfig.FwLogEntry(tickNow, verdict, dir, protoName(p), NetConfig.format(p.src),
                NetConfig.format(p.dst), p.proto == 2 ? 0 : p.dstPort, ruleNo));
        if (verdict.equals("drop")) {
            Route r = new Route();
            r.dropped = true;
            return r;
        }
        return fail("blocked by a firewall");
    }

    /** A transmit queue is full: the packet is lost without a word, like on a flooded line. */
    private static Route congested() {
        Route r = new Route();
        r.dropped = true;
        return r;
    }

    private static Route ok(Iface target, Packet p, int ticks) {
        Route r = new Route();
        r.target = target;
        r.packet = p;
        r.ticks = ticks;
        return r;
    }

    /** The packet leaves through this interface. */
    private static Route out(Iface at, Packet p, int ttl, int ticks) {
        if (ttl <= 0) return fail("time to live exceeded");
        PlugSocketBlockEntity b = be(at);
        if (b == null) return fail("interface offline");
        tickNow = at.level().getServer().getTickCount();
        NetConfig c = b.net();
        mark(at);
        count(at, p, true);
        if (c.uplink[at.slot()]) return wan(at, p, ttl, ticks);
        long mine = NetConfig.parse(c.ip(at.slot()));
        if (mine < 0) return fail("interface has no address");
        List<Iface> dom = domain(at);
        if (NetConfig.sameSubnet(mine, p.dst, c.prefix[at.slot()])) {
            Iface t = findByIp(dom, p.dst);
            if (t == null) return fail("host unreachable");
            if (isolated(at, t)) return fail("blocked by client isolation (guest network)");
            int cost = charge(markPath(at, t));
            sniff(dom, p);
            if (cost < 0) return congested();
            return ok(t, p, ticks + cost);
        }
        long gw = NetConfig.parse(c.gateway(at.slot()));
        if (gw < 0) return fail("no route to host");
        Iface g = findByIp(dom, gw);
        if (g == null) return fail("gateway unreachable");
        if (isolated(at, g)) return fail("blocked by client isolation (guest network)");
        int cost = charge(markPath(at, g));
        sniff(dom, p);
        if (cost < 0) return congested();
        return forward(g, p, ttl - 1, ticks + 1 + cost);
    }

    /** A packet arrives at a router's interface to be passed on. */
    private static Route forward(Iface in, Packet p, int ttl, int ticks) {
        PlugSocketBlockEntity b = be(in);
        if (b == null) return fail("gateway offline");
        NetConfig c = b.net();
        if (!c.routing) return fail("gateway is not a router");
        mark(in);
        count(in, p, false);
        Route stop;
        // 1. a network this router is attached to
        for (int s = 0; s < b.slotCount(); s++) {
            if (s == in.slot() || !b.isRj45(s) || c.uplink[s]) continue;
            long ipS = NetConfig.parse(c.ip(s));
            if (ipS >= 0 && NetConfig.sameSubnet(ipS, p.dst, c.prefix[s])) {
                if ((stop = firewall(c, p, "any")) != null) return stop;
                return out(new Iface(in.level(), in.pos(), s), p, ttl, ticks);
            }
        }
        // 1b. a VPN tunnel to another router's network
        for (String[] tun : c.tunnels.values()) {
            if (!NetConfig.inSpec(tun[1], p.dst)) continue;
            for (int s = 0; s < b.slotCount(); s++) {
                if (!b.isRj45(s) || !c.uplink[s]) continue;
                long wanIp = NetConfig.parse(c.ip(s));
                if (wanIp < 0) break;
                if ((stop = firewall(c, p, "any")) != null) return stop;
                Packet outer = new Packet();
                outer.src = wanIp;
                outer.dst = NetConfig.parse(tun[0]);
                outer.proto = 3;
                outer.inner = p.copy();
                outer.key = tun[2];
                return out(new Iface(in.level(), in.pos(), s), outer, ttl, ticks);
            }
            return fail("tunnel is down (no uplink)");
        }
        // 2. the internet, through the uplink (with NAT)
        for (int s = 0; s < b.slotCount(); s++) {
            if (!b.isRj45(s) || !c.uplink[s]) continue;
            if ((stop = firewall(c, p, "out")) != null) return stop;
            return out(new Iface(in.level(), in.pos(), s), natOut(c, s, p), ttl, ticks);
        }
        // 3. another router
        for (int s = 0; s < b.slotCount(); s++) {
            if (s == in.slot() || !b.isRj45(s) || c.gateway(s).isEmpty()) continue;
            if ((stop = firewall(c, p, "any")) != null) return stop;
            return out(new Iface(in.level(), in.pos(), s), p, ttl, ticks);
        }
        return fail("no route");
    }

    private static Packet natOut(NetConfig c, int uplinkSlot, Packet p) {
        String key = NetConfig.format(p.src) + ":" + p.srcPort;
        Integer port = c.natOut.get(key);
        if (port == null) {
            for (Map.Entry<Integer, String> f : c.forwards.entrySet()) {   // a forwarded service answers from its public port
                if (f.getValue().equals(key)) {
                    port = f.getKey();
                    break;
                }
            }
        }
        if (port == null) {
            port = c.nextNatPort++;
            if (c.nextNatPort > 65535) c.nextNatPort = 49152;
            c.natOut.put(key, port);
            c.natIn.put(port, key);
        }
        Packet q = p.copy();
        q.src = NetConfig.parse(c.ip(uplinkSlot));
        q.srcPort = port;
        return q;
    }

    private static Route wan(Iface at, Packet p, int ttl, int ticks) {
        if (peer(at) == null) return fail("the line is down (no cable on the uplink)");
        WanEntry e = WAN.get(p.dst);
        if (e == null) return fail("destination unreachable on the internet");
        ServerLevel lvl = at.level().getServer().getLevel(e.where().dimension());
        if (lvl == null) return fail("destination unreachable on the internet");
        Iface t = new Iface(lvl, e.where().pos(), e.slot());
        PlugSocketBlockEntity tb = be(t);
        if (tb == null || !tb.net().uplink[e.slot()] || peer(t) == null) return fail("destination unreachable on the internet");
        int delay;
        if (lvl == at.level()) {
            double dx = t.pos().getX() - at.pos().getX();
            double dz = t.pos().getZ() - at.pos().getZ();
            delay = 1 + (int) Math.min(10, Math.sqrt(dx * dx + dz * dz) / 512);
        } else {
            delay = 6;
        }
        return inbound(t, p, ttl - 1, ticks + delay);
    }

    /** A packet comes in through an uplink interface. */
    private static Route inbound(Iface t, Packet p, int ttl, int ticks) {
        PlugSocketBlockEntity b = be(t);
        if (b == null) return fail("destination offline");
        NetConfig c = b.net();
        mark(t);
        count(t, p, false);
        Route stop;
        if (p.proto == 3) return tunnelIn(t, b, p, ttl, ticks);
        if (c.routing) {
            String priv = c.natIn.get(p.dstPort);
            boolean established = priv != null;   // an answer to something a host behind the router sent: always let in
            if (priv == null) priv = c.forwards.get(p.dstPort);   // port forwarding
            if (priv != null) {
                int colon = priv.lastIndexOf(':');
                long privIp = NetConfig.parse(priv.substring(0, colon));
                int privPort = Integer.parseInt(priv.substring(colon + 1));
                Packet q = p.copy();
                q.dst = privIp;
                q.dstPort = privPort;
                if (!established && (stop = firewall(c, q, "in")) != null) return stop;
                for (int s = 0; s < b.slotCount(); s++) {
                    if (s == t.slot() || !b.isRj45(s) || c.uplink[s]) continue;
                    long ipS = NetConfig.parse(c.ip(s));
                    if (ipS >= 0 && NetConfig.sameSubnet(ipS, privIp, c.prefix[s])) {
                        return out(new Iface(t.level(), t.pos(), s), q, ttl, ticks);
                    }
                }
                return fail("nothing behind the router answers");
            }
        }
        if ((stop = firewall(c, p, "in")) != null) return stop;
        return ok(t, p, ticks);
    }

    /** The other end of a VPN tunnel sent us a packet: check who and the key, then let it into the LAN. */
    private static Route tunnelIn(Iface t, PlugSocketBlockEntity b, Packet p, int ttl, int ticks) {
        NetConfig c = b.net();
        if (!c.routing || p.inner == null) return fail("not a tunnel endpoint");
        for (String[] tun : c.tunnels.values()) {
            if (NetConfig.parse(tun[0]) != p.src || !tun[2].equals(p.key) || !NetConfig.inSpec(tun[1], p.inner.src)) continue;
            Packet q = p.inner.copy();
            Route stop = firewall(c, q, "any");
            if (stop != null) return stop;
            for (int s = 0; s < b.slotCount(); s++) {
                if (!b.isRj45(s) || c.uplink[s]) continue;
                long ipS = NetConfig.parse(c.ip(s));
                if (ipS >= 0 && NetConfig.sameSubnet(ipS, q.dst, c.prefix[s])) {
                    return out(new Iface(t.level(), t.pos(), s), q, ttl, ticks);
                }
            }
            return fail("nothing behind the router answers");
        }
        return fail("tunnel refused (unknown peer or wrong key)");
    }

    // ------------------------------------------------------------------ what the peripheral calls

    /** Sends a datagram. Returns null when it was handed over, otherwise why not. */
    public static String send(Iface src, String dstIp, int srcPort, int dstPort, String payload) {
        if (!usable(src)) return "not a network port";
        long dst = NetConfig.parse(dstIp);
        if (dst < 0) return "bad address";
        if (payload.length() > MTU) return "packet too large (more than " + MTU + " characters)";
        if (srcPort < 0 || srcPort > 65535 || dstPort < 0 || dstPort > 65535) return "bad port";
        PlugSocketBlockEntity b = be(src);
        long mine = NetConfig.parse(b.net().ip(src.slot()));
        if (mine < 0) return "interface has no address";
        Packet p = new Packet();
        p.src = mine;
        p.dst = dst;
        p.srcPort = srcPort;
        p.dstPort = dstPort;
        p.payload = payload;
        return dispatch(src, p);
    }

    private static String dispatch(Iface src, Packet p) {
        Route r = out(src, p, TTL, 0);
        if (r.error != null) return r.error;
        schedule(r);
        return null;
    }

    private static void schedule(Route r) {
        if (r.dropped) return;   // a firewall dropped it: nobody hears about it
        if (r.ticks <= 0) {
            deliver(r.target, r.packet);
        } else {
            QUEUE.add(new Pending(r.target.level().getServer().getTickCount() + r.ticks, ++seq,
                    GlobalPos.of(r.target.level().dimension(), r.target.pos()), r.target.slot(), r.packet));
        }
    }

    /** Round trip time in milliseconds, or a negative number and the reason in error[0]. */
    public static int ping(Iface src, String dstIp, String[] error) {
        if (!usable(src)) {
            error[0] = "not a network port";
            return -1;
        }
        long dst = NetConfig.parse(dstIp);
        if (dst < 0) {
            error[0] = "bad address";
            return -1;
        }
        PlugSocketBlockEntity b = be(src);
        long mine = NetConfig.parse(b.net().ip(src.slot()));
        if (mine < 0) {
            error[0] = "interface has no address";
            return -1;
        }
        Packet p = new Packet();
        p.src = mine;
        p.dst = dst;
        p.proto = 2;   // ICMP echo
        Route r = out(src, p, TTL, 0);
        if (r.error != null) {
            error[0] = r.error;
            return -1;
        }
        if (r.dropped) {
            error[0] = "request timed out";
            return -1;
        }
        return 1 + r.ticks * 100;   // one tick is 50 ms each way
    }

    /** Every host port in the segment (the ports of a Network Switch are not hosts). */
    public static List<Iface> scan(Iface src) {
        List<Iface> out = new ArrayList<>();
        for (Iface i : domain(src)) {
            PlugSocketBlockEntity b = be(i);
            if (b == null || b.isSwitchBlock() || b.isAccessPointBlock()) continue;
            if (b.isRouterBlock() && i.slot() > 0 && i.slot() != PlugSocketBlockEntity.ROUTER_WAN) continue;   // one entry per router
            out.add(i);
        }
        return out;
    }

    /**
     * DHCP: takes an address from a DHCP server in the same segment. A reserved address (by MAC) wins, then the address
     * the port had before, then the first free one in the server's range. Returns null on success, otherwise why not.
     */
    public static String autoConfigure(Iface me) {
        if (!usable(me)) return "not a network port";
        PlugSocketBlockEntity b = be(me);
        List<Iface> dom = domain(me);
        String myMac = mac(me);
        for (Iface d : dom) {
            if (d.equals(me)) continue;
            PlugSocketBlockEntity db = be(d);
            if (db == null || d.slot() >= NetConfig.MAX) continue;
            NetConfig dc = db.net();
            int ds = d.slot();
            long dip = NetConfig.parse(dc.ip(ds));
            int pre = dc.prefix[ds];
            if (!dc.dhcp[ds] || dip < 0 || pre < 8 || pre > 30) continue;
            long mask = (0xFFFFFFFFL << (32 - pre)) & 0xFFFFFFFFL;
            long net = dip & mask;
            long size = 1L << (32 - pre);
            long first = dc.dhcpFirst[ds] > 0 ? dc.dhcpFirst[ds] : 2;
            long last = dc.dhcpLast[ds] > 0 ? Math.min(dc.dhcpLast[ds], size - 2) : size - 2;
            Set<Long> used = new HashSet<>();      // addresses of other ports
            Set<String> present = new HashSet<>(); // ports that are in this segment right now
            for (Iface o : dom) {
                present.add(mac(o));
                if (o.equals(me)) continue;
                PlugSocketBlockEntity ob = be(o);
                if (ob != null) used.add(NetConfig.parse(ob.net().ip(o.slot())));
            }
            used.add(dip);
            Set<Long> reservedForOthers = new HashSet<>();
            for (Map.Entry<String, String> e : dc.reservations.entrySet()) {
                if (!e.getKey().equals(myMac)) reservedForOthers.add(NetConfig.parse(e.getValue()));
            }
            long mine = -1;
            long resv = NetConfig.parse(dc.reservations.get(myMac));
            if (resv >= 0 && NetConfig.sameSubnet(resv, dip, pre) && !used.contains(resv)) mine = resv;
            if (mine < 0) {
                long lease = NetConfig.parse(dc.leases.get(myMac));
                if (lease >= 0 && NetConfig.sameSubnet(lease, dip, pre) && !used.contains(lease)
                        && !reservedForOthers.contains(lease) && lease - net >= 1 && lease - net <= size - 2) {
                    mine = lease;
                }
            }
            if (mine < 0) {
                Set<Long> taken = new HashSet<>(used);
                taken.addAll(reservedForOthers);
                for (Map.Entry<String, String> e : dc.leases.entrySet()) {   // the lease of a port that is gone can be reused
                    if (!e.getKey().equals(myMac) && present.contains(e.getKey())) taken.add(NetConfig.parse(e.getValue()));
                }
                for (long off = first; off <= last; off++) {
                    if (!taken.contains(net + off)) {
                        mine = net + off;
                        break;
                    }
                }
            }
            if (mine < 0) return "the DHCP address pool is full";
            String text = NetConfig.format(mine);
            dc.leases.entrySet().removeIf(e -> e.getValue().equals(text) && !e.getKey().equals(myMac));
            dc.leases.remove(myMac);
            dc.leases.put(myMac, text);   // newest last
            while (dc.leases.size() > 128) dc.leases.remove(dc.leases.keySet().iterator().next());
            NetConfig c = b.net();
            c.ip[me.slot()] = text;
            c.prefix[me.slot()] = pre;
            c.gateway[me.slot()] = dc.routing ? NetConfig.format(dip) : "";
            b.netChanged();
            db.netChanged();
            return null;
        }
        return "no DHCP server found";
    }

    /** Turns a port into an uplink (a modem) or back. Returns null on success, otherwise why not. */
    public static String setUplink(Iface me, boolean on) {
        if (!usable(me)) return "not a network port";
        PlugSocketBlockEntity b = be(me);
        NetConfig c = b.net();
        int s = me.slot();
        if (on) {
            if (peer(me) == null) return "no cable on this port";
            if (!c.uplink[s]) {
                long ip = assignPublicIp(me, PublicRange.byIndex(c.uplinkRange[s]));
                c.ip[s] = NetConfig.format(ip);
                c.prefix[s] = 32;
                c.gateway[s] = "";
                c.uplink[s] = true;
                if (!c.hostname(s).isEmpty()) DNS.putIfAbsent(c.hostname(s), ip);
            }
        } else if (c.uplink[s]) {
            long old = NetConfig.parse(c.ip(s));
            WAN.remove(old);
            DNS.values().removeIf(v -> v == old);
            c.uplink[s] = false;
            c.ip[s] = "";
            c.prefix[s] = 0;
        }
        b.netChanged();
        return null;
    }

    private static long assignPublicIp(Iface i, PublicRange range) {
        int h = (int) (Math.abs((long) Objects.hash(i.level().dimension().location().toString(), i.pos().asLong(), i.slot())) % range.size);
        long ip = range.base;
        for (long n = 0; n < range.size; n++) {
            ip = range.base + ((h + n) % range.size);
            if (!WAN.containsKey(ip)) break;
        }
        WAN.put(ip, new WanEntry(GlobalPos.of(i.level().dimension(), i.pos()), i.slot()));
        return ip;
    }

    // ------------------------------------------------------------------ raw frames

    /** A raw Ethernet frame to one port of the segment, or to all of them (ff:ff:ff:ff:ff:ff). Null on success. */
    public static String sendFrame(Iface src, String dstMac, int etherType, String payload) {
        if (!usable(src)) return "not a network port";
        if (payload.length() > MTU) return "frame too large (more than " + MTU + " characters)";
        if (etherType < 0 || etherType > 65535) return "bad ether type";
        String dm = dstMac.trim().toLowerCase(Locale.ROOT);
        boolean broadcast = dm.equals("ff:ff:ff:ff:ff:ff");
        String sm = mac(src);
        mark(src);
        int n = 0;
        for (Iface i : domain(src)) {
            if (i.equals(src)) continue;
            PlugSocketBlockEntity b = be(i);
            if (b == null || b.isSwitchBlock() || b.isAccessPointBlock()) continue;
            if (isolated(src, i)) continue;
            if (broadcast || mac(i).equals(dm)) {
                markPath(src, i);
                for (NetListener l : b.netListeners()) l.frame(i.slot() + 1, sm, dm, etherType, payload);
                n++;
            }
        }
        return n == 0 && !broadcast ? "no such station in this segment" : null;
    }

    // ------------------------------------------------------------------ connections (TCP-like)

    private static final int SYN = 1, ACK = 2, FIN = 4, RST = 8, DATA = 16;

    private static final class Conn {
        final Iface local;
        final int localPort;
        final long remoteIp;
        final int remotePort;
        final int id;
        boolean established;

        Conn(Iface local, int localPort, long remoteIp, int remotePort, int id) {
            this.local = local;
            this.localPort = localPort;
            this.remoteIp = remoteIp;
            this.remotePort = remotePort;
            this.id = id;
        }
    }

    private static final Map<String, Conn> CONNS = new HashMap<>();
    private static final Set<String> LISTEN = new HashSet<>();
    private static int nextConnId = 1;
    private static int nextEphemeral = 49152;

    private static String ikey(Iface i) {
        return i.level().dimension().location() + "|" + i.pos().asLong() + "|" + i.slot();
    }

    private static String ckey(Iface i, int localPort, long remoteIp, int remotePort) {
        return ikey(i) + "|" + localPort + "|" + remoteIp + "|" + remotePort;
    }

    private static Conn conn(Iface me, int id) {
        for (Conn c : CONNS.values()) if (c.id == id && c.local.equals(me)) return c;
        return null;
    }

    private static void notifyTcp(Iface t, String event, int id, Object... args) {
        PlugSocketBlockEntity b = be(t);
        if (b == null) return;
        for (NetListener l : b.netListeners()) l.tcp(t.slot() + 1, event, id, args);
    }

    private static Packet segment(Iface from, long dst, int srcPort, int dstPort, int flags, String payload) {
        PlugSocketBlockEntity b = be(from);
        Packet p = new Packet();
        p.proto = 1;
        p.flags = flags;
        p.src = b == null ? 0 : NetConfig.parse(b.net().ip(from.slot()));
        p.dst = dst;
        p.srcPort = srcPort;
        p.dstPort = dstPort;
        p.payload = payload;
        return p;
    }

    public static String listen(Iface me, int port, boolean on) {
        if (!usable(me)) return "not a network port";
        if (port < 1 || port > 65535) return "bad port";
        if (on) LISTEN.add(ikey(me) + "|" + port);
        else LISTEN.remove(ikey(me) + "|" + port);
        return null;
    }

    /** Opens a connection: returns its id, or -1 and why not in error[0]. "connected" arrives as an event. */
    public static int connect(Iface me, String dstIp, int dstPort, String[] error) {
        if (!usable(me)) {
            error[0] = "not a network port";
            return -1;
        }
        long dst = NetConfig.parse(dstIp);
        if (dst < 0 || dstPort < 1 || dstPort > 65535) {
            error[0] = "bad address or port";
            return -1;
        }
        PlugSocketBlockEntity b = be(me);
        if (NetConfig.parse(b.net().ip(me.slot())) < 0) {
            error[0] = "interface has no address";
            return -1;
        }
        int local = nextEphemeral++;
        if (nextEphemeral > 65535) nextEphemeral = 49152;
        Packet syn = segment(me, dst, local, dstPort, SYN, "");
        Route r = out(me, syn, TTL, 0);
        if (r.error != null) {
            error[0] = r.error;
            return -1;
        }
        Conn c = new Conn(me, local, dst, dstPort, nextConnId++);
        CONNS.put(ckey(me, local, dst, dstPort), c);
        schedule(r);
        return c.id;
    }

    /** Sends data on an open connection (at most 1500 characters at a time). Null on success. */
    public static String tcpSend(Iface me, int id, String data) {
        Conn c = conn(me, id);
        if (c == null) return "no such connection";
        if (!c.established) return "connection is not open yet";
        if (data.length() > MTU) return "segment too large (more than " + MTU + " characters)";
        String err = dispatch(me, segment(me, c.remoteIp, c.localPort, c.remotePort, DATA, data));
        if (err != null) {
            CONNS.remove(ckey(me, c.localPort, c.remoteIp, c.remotePort));
            notifyTcp(me, "closed", id, "timeout");
        }
        return err;
    }

    public static String tcpClose(Iface me, int id) {
        Conn c = conn(me, id);
        if (c == null) return "no such connection";
        CONNS.remove(ckey(me, c.localPort, c.remoteIp, c.remotePort));
        dispatch(me, segment(me, c.remoteIp, c.localPort, c.remotePort, FIN, ""));
        return null;
    }

    private static void reply(Iface from, Packet orig, int flags) {
        dispatch(from, segment(from, orig.src, orig.dstPort, orig.srcPort, flags, ""));
    }

    private static void tcpIn(Iface t, Packet p) {
        if ((p.flags & SYN) != 0 && (p.flags & ACK) == 0) {
            if (!LISTEN.contains(ikey(t) + "|" + p.dstPort)) {
                reply(t, p, RST);   // connection refused
                return;
            }
            Conn c = new Conn(t, p.dstPort, p.src, p.srcPort, nextConnId++);
            c.established = true;
            CONNS.put(ckey(t, p.dstPort, p.src, p.srcPort), c);
            notifyTcp(t, "accepted", c.id, NetConfig.format(p.src), p.srcPort, p.dstPort);
            reply(t, p, SYN | ACK);
            return;
        }
        String key = ckey(t, p.dstPort, p.src, p.srcPort);
        Conn c = CONNS.get(key);
        if (c == null) {
            if ((p.flags & RST) == 0) reply(t, p, RST);
            return;
        }
        if ((p.flags & RST) != 0) {
            CONNS.remove(key);
            notifyTcp(t, "closed", c.id, c.established ? "connection reset" : "connection refused");
        } else if ((p.flags & SYN) != 0) {   // SYN + ACK
            c.established = true;
            notifyTcp(t, "connected", c.id, NetConfig.format(c.remoteIp), c.remotePort);
        } else if ((p.flags & FIN) != 0) {
            CONNS.remove(key);
            notifyTcp(t, "closed", c.id, "closed by the other side");
        } else if ((p.flags & DATA) != 0 && c.established) {
            notifyTcp(t, "data", c.id, p.payload);
        }
    }

    // ------------------------------------------------------------------ names

    /** Gives a port a hostname. On an uplink it is registered for the whole server. Null on success. */
    public static String setHostname(Iface me, String name) {
        if (!usable(me)) return "not a network port";
        String n = name.trim().toLowerCase(Locale.ROOT);
        if (!n.isEmpty() && !n.matches("[a-z0-9]([a-z0-9.-]{0,60}[a-z0-9])?")) return "bad name (letters, digits, dots and dashes)";
        PlugSocketBlockEntity b = be(me);
        NetConfig c = b.net();
        int s = me.slot();
        long ip = NetConfig.parse(c.ip(s));
        if (c.uplink[s] && !n.isEmpty() && DNS.containsKey(n) && DNS.get(n) != ip) return "name already taken";
        if (!c.hostname(s).isEmpty()) DNS.remove(c.hostname(s), ip);
        c.hostname[s] = n;
        if (c.uplink[s] && !n.isEmpty()) DNS.put(n, ip);
        b.netChanged();
        return null;
    }

    /** An address for a name: a port with that hostname in the segment, or an uplink with that name anywhere. */
    public static String resolve(Iface me, String name, String[] error) {
        String n = name.trim().toLowerCase(Locale.ROOT);
        for (Iface i : domain(me)) {
            PlugSocketBlockEntity b = be(i);
            if (b != null && n.equals(b.net().hostname(i.slot())) && !b.net().ip(i.slot()).isEmpty()) return b.net().ip(i.slot());
        }
        for (Iface i : domain(me)) {   // local DNS records of a router (or any socket) in the segment
            PlugSocketBlockEntity b = be(i);
            String rec = b == null ? null : b.net().dnsRecords.get(n);
            if (rec != null) return rec;
        }
        Long ip = DNS.get(n);
        if (ip != null && WAN.containsKey(ip)) return NetConfig.format(ip);
        error[0] = "name not found";
        return null;
    }

    /** An address or a name to an address. */
    public static String address(Iface me, String hostOrIp, String[] error) {
        if (NetConfig.parse(hostOrIp) >= 0) return hostOrIp.trim();
        return resolve(me, hostOrIp, error);
    }

    // ------------------------------------------------------------------ bookkeeping

    /** A socket with uplinks has loaded: it is on the internet again. */
    public static void register(PlugSocketBlockEntity be) {
        if (!(be.getLevel() instanceof ServerLevel level)) return;
        NetConfig c = be.net();
        GlobalPos here = GlobalPos.of(level.dimension(), be.getBlockPos());
        if (be.isAccessPointBlock()) APS.add(here);
        for (int s = 0; s < be.slotCount() && s < NetConfig.MAX; s++) {
            if (!c.wifiSsid(s).isEmpty()) WIFI_HOSTS.add(here);
        }
        for (int s = 0; s < be.slotCount(); s++) {
            long ip = NetConfig.parse(c.ip(s));
            if (c.uplink[s] && ip >= 0) {
                WAN.put(ip, new WanEntry(GlobalPos.of(level.dimension(), be.getBlockPos()), s));
                if (!c.hostname(s).isEmpty()) DNS.putIfAbsent(c.hostname(s), ip);
            }
        }
    }

    /** A socket is gone (broken or its chunk unloaded): its uplinks are off the internet. */
    public static void unregister(PlugSocketBlockEntity be) {
        if (!(be.getLevel() instanceof ServerLevel level)) return;
        GlobalPos here = GlobalPos.of(level.dimension(), be.getBlockPos());
        APS.remove(here);
        WIFI_HOSTS.remove(here);
        WAN.values().removeIf(e -> e.where().equals(here));
        DNS.values().removeIf(ip -> !WAN.containsKey(ip));
        CONNS.values().removeIf(c -> c.local.level() == level && c.local.pos().equals(be.getBlockPos()));
        String prefix = level.dimension().location() + "|" + be.getBlockPos().asLong() + "|";
        LISTEN.removeIf(k -> k.startsWith(prefix));
    }

    private static void deliver(Iface t, Packet p) {
        PlugSocketBlockEntity b = be(t);
        if (b == null) return;
        mark(t);
        count(t, p, false);
        if (p.proto == 1) {
            tcpIn(t, p);
            return;
        }
        for (NetListener l : b.netListeners()) {
            l.packet(t.slot() + 1, NetConfig.format(p.src), p.srcPort, p.dstPort, p.payload);
        }
    }

    /** Drops uplinks whose socket was broken (the block entity can't tell us itself, see PlugSocketBlockEntity). */
    private static void sweepBroken(MinecraftServer server) {
        WAN.values().removeIf(e -> {
            ServerLevel lvl = server.getLevel(e.where().dimension());
            if (lvl == null || !lvl.isLoaded(e.where().pos())) return false;
            return !(lvl.getBlockEntity(e.where().pos()) instanceof PlugSocketBlockEntity b) || b.isRemoved();
        });
        DNS.values().removeIf(ip -> !WAN.containsKey(ip));
        APS.removeIf(gp -> gone(server, gp));
        WIFI_HOSTS.removeIf(gp -> gone(server, gp));
    }

    /** Is the socket at this position loaded and no longer there? */
    private static boolean gone(MinecraftServer server, GlobalPos gp) {
        ServerLevel lvl = server.getLevel(gp.dimension());
        if (lvl == null || !lvl.isLoaded(gp.pos())) return false;
        return !(lvl.getBlockEntity(gp.pos()) instanceof PlugSocketBlockEntity b) || b.isRemoved();
    }

    @SubscribeEvent
    public static void onServerTick(ServerTickEvent.Post event) {
        MinecraftServer server = event.getServer();
        long now = server.getTickCount();
        tickNow = now;
        if (now % 40 == 0) sweepBroken(server);
        Pending p;
        while ((p = QUEUE.peek()) != null && p.due() <= now) {
            QUEUE.poll();
            ServerLevel level = server.getLevel(p.where().dimension());
            if (level == null) continue;
            deliver(new Iface(level, p.where().pos(), p.slot()), p.packet());
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        QUEUE.clear();
        WAN.clear();
        DNS.clear();
        APS.clear();
        WIFI_HOSTS.clear();
        CONNS.clear();
        LISTEN.clear();
    }
}
