package com.realplugs.ponder;

import net.createmod.ponder.api.scene.SceneBuilder;
import net.createmod.ponder.api.scene.SceneBuildingUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;

/**
 * Ponder scenes. Airport schematic (5 x 5 x 10): a pillar at x=3, z=5 with a Universal Power Strip at y=1 and a USB
 * Charging Hub at y=2 on each of its four faces. House schematic (4 x 4 x 4): one Wall Outlet at (1, 1, 1) facing east.
 */
public final class RealPlugsScenes {
    private RealPlugsScenes() {}

    /** Power strips, hubs and panels. */
    public static void chargingIsland(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("charging_island", "Power strips and USB hubs");
        scene.configureBasePlate(0, 0, 10);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos strip = util.grid().at(2, 1, 5);
        BlockPos hub = util.grid().at(2, 2, 5);

        scene.overlay().showText(90)
                .text("Power strips, hubs and panels can be mounted on any wall, floor or ceiling")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(90)
                .text("A Universal Power Strip has four slots: US, EU, UK and USB-A")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(90)
                .text("A USB Charging Hub has two USB-A slots and two USB-C slots")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(hub, Direction.WEST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(110)
                .text("Power comes in through the two small connectors on the sides: red is hot and blue is neutral. Connect them with Power Grid wires")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.NORTH))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(110)
                .text("Right-click a slot with a plug of the same connector. A slot only passes power while something is plugged into it")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(120);

        scene.effects().indicateSuccess(strip);
        scene.idle(20);
    }

    /** Wall outlets. */
    public static void wallOutlet(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("wall_outlet", "Wall outlets");
        scene.configureBasePlate(0, 0, 4);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos outlet = util.grid().at(1, 1, 1);

        scene.overlay().showText(80)
                .text("Wall outlets sit flat against a wall. This one is a US outlet with two slots")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(90);

        scene.overlay().showText(100)
                .text("Wire power into the small red (hot) and blue (neutral) connectors on its sides")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.NORTH))
                .placeNearTarget();
        scene.idle(110);

        scene.overlay().showText(100)
                .text("Hold a plug of the matching connector and right-click a slot. A plug that does not fit is refused")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(110);

        scene.overlay().showText(90)
                .text("EU, UK, AU and DC barrel outlets work the same way, each with its own connector")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(100);

        scene.effects().indicateSuccess(outlet);
        scene.idle(20);
    }

    /** Plugs and adapters. */
    public static void plugsAndAdapters(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("plugs_and_adapters", "Plugs and adapters");
        scene.configureBasePlate(0, 0, 4);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos outlet = util.grid().at(1, 1, 1);

        scene.overlay().showText(110)
                .text("Plugs come in many connectors: US, EU, UK, AU, USB-A, USB-C, Micro-USB, Lightning, HDMI, DisplayPort, Ethernet and DC barrel")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(110)
                .text("An adapter plugs into a slot and has its own slots for a different connector, so an EU device can use a US outlet")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(90)
                .text("Multi-taps turn one slot into several")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(100);

        scene.overlay().showText(100)
                .text("Right-click a slot with an empty hand to take its plug or adapter back out")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(outlet, Direction.EAST))
                .placeNearTarget();
        scene.idle(110);
    }

    /** Plug cords. */
    public static void cords(SceneBuilder scene, SceneBuildingUtil util) {
        scene.title("plug_cords", "Plug cords");
        scene.configureBasePlate(0, 0, 10);
        scene.showBasePlate();
        scene.rotateCameraY(90);
        scene.idle(5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);

        BlockPos strip = util.grid().at(2, 1, 5);
        BlockPos hub = util.grid().at(2, 2, 5);

        scene.overlay().showText(110)
                .text("A plug cord is a Power Grid cord with a plug on each end. Some have the same plug on both ends, others change connector, like US to USB-A")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(110)
                .text("Right-click a free slot with the cord, then a second slot to finish the lead. Each end only fits slots of its own connector")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(hub, Direction.WEST))
                .placeNearTarget();
        scene.idle(120);

        scene.overlay().showText(100)
                .text("A slot holding a cord passes power like a plugged-in plug, so the cord carries that one slot")
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(strip, Direction.WEST))
                .placeNearTarget();
        scene.idle(110);
    }

    // ------------------------------------------------------------------ networking (network_showcase schematic, 11 x 4 x 7)
    // router (1,1,3), switch (4,1,3), Wi-Fi access point (7,1,3), computers at (4,1,1), (1,1,5) and (9,1,5)

    private static void networkIntro(SceneBuilder scene, SceneBuildingUtil util, String id, String title) {
        scene.title(id, title);
        scene.configureBasePlate(0, 0, 11);
        scene.showBasePlate();
        scene.idle(5);
    }

    private static void reveal(SceneBuilder scene, SceneBuildingUtil util, int x, int z) {
        scene.world().showSection(util.select().position(x, 1, z), Direction.DOWN);
        scene.idle(10);
    }

    private static void say(SceneBuilder scene, SceneBuildingUtil util, BlockPos at, Direction face, int ticks, String text) {
        scene.overlay().showText(ticks)
                .text(text)
                .attachKeyFrame()
                .pointAt(util.vector().blockSurface(at, face))
                .placeNearTarget();
        scene.idle(ticks + 10);
    }

    /** How to build a home network. */
    public static void homeNetwork(SceneBuilder scene, SceneBuildingUtil util) {
        networkIntro(scene, util, "home_network", "Building a home network");
        BlockPos router = util.grid().at(1, 1, 3);
        BlockPos sw = util.grid().at(4, 1, 3);
        BlockPos ap = util.grid().at(7, 1, 3);
        BlockPos pc = util.grid().at(4, 1, 1);

        reveal(scene, util, 1, 3);
        say(scene, util, router, Direction.SOUTH, 100, "The Network Router has three LAN ports and one WAN port. Plug a cable into the WAN port and the router gets a public address from the provider");
        say(scene, util, router, Direction.SOUTH, 100, "It hands out private addresses to everything on its LAN (DHCP), translates them for the internet (NAT) and has a firewall");

        reveal(scene, util, 4, 3);
        say(scene, util, sw, Direction.SOUTH, 100, "A Network Switch gives you more ports. Cable one of its ports to a LAN port of the router; its lights show which ports are busy");

        reveal(scene, util, 4, 1);
        reveal(scene, util, 1, 5);
        say(scene, util, pc, Direction.SOUTH, 100, "Computers get an RJ45 socket and a cable to the switch. They ask the router for an address with autoConfigure and can then reach each other and the internet");

        reveal(scene, util, 7, 3);
        say(scene, util, ap, Direction.SOUTH, 100, "A Wi-Fi Access Point, cabled to the switch, lets laptops and pocket computers join by radio: set a name and a password");

        reveal(scene, util, 9, 5);
        say(scene, util, util.grid().at(9, 1, 5), Direction.SOUTH, 100, "A computer in range joins with joinWifi, or you set it up with the Network Configurator, no program needed");

        scene.effects().indicateSuccess(router);
        scene.idle(10);
        scene.effects().indicateSuccess(sw);
        scene.idle(10);
        scene.effects().indicateSuccess(ap);
        scene.idle(20);
    }

    /** Cat5, Cat6 and fibre. */
    public static void cableTypes(SceneBuilder scene, SceneBuildingUtil util) {
        networkIntro(scene, util, "cable_types", "Cat5, Cat6 and fibre cables");
        BlockPos router = util.grid().at(1, 1, 3);
        BlockPos sw = util.grid().at(4, 1, 3);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);
        say(scene, util, router, Direction.EAST, 100, "Every network cable has a speed class. Right-click one port, then the other, to connect them. The plain Ethernet cord has no limits");
        say(scene, util, router, Direction.EAST, 100, "Cat5 is the cheapest: 2 ticks of delay on every hop and 40 packets per second, up to 12 blocks long");
        say(scene, util, sw, Direction.WEST, 100, "Cat6 adds only 1 tick, carries 200 packets per second and reaches 24 blocks");
        say(scene, util, sw, Direction.WEST, 100, "Fibre has no added delay, no packet limit and reaches 64 blocks: use it between buildings");
        say(scene, util, sw, Direction.NORTH, 110, "Packets above a cable's limit wait in a queue, in order. A queue that would hold a packet for over 5 seconds drops it. setQos lets you limit a port further so one busy computer cannot flood the LAN");
        scene.effects().indicateSuccess(sw);
        scene.idle(20);
    }

    /** Wi-Fi roaming. */
    public static void wifiRoaming(SceneBuilder scene, SceneBuildingUtil util) {
        networkIntro(scene, util, "wifi_roaming", "Wi-Fi range and roaming");
        BlockPos ap = util.grid().at(7, 1, 3);
        BlockPos laptop = util.grid().at(9, 1, 5);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);
        say(scene, util, ap, Direction.SOUTH, 100, "An access point reaches as far as its range setting (4 to 64 blocks). The Wi-Fi Analyzer shows the signal where you stand");
        say(scene, util, laptop, Direction.SOUTH, 100, "With several access points of the same name and password, a laptop stays on the one it has while it is in range");
        say(scene, util, laptop, Direction.SOUTH, 110, "It only moves when another one is clearly stronger: 15 signal points by default. setRoaming changes that margin, 0 always takes the strongest");
        say(scene, util, ap, Direction.SOUTH, 100, "A repeater, an access point with an upstream name, extends the network to places the first one cannot reach");
        scene.effects().indicateSuccess(laptop);
        scene.idle(20);
    }

    /** The Network Configurator. */
    public static void configurator(SceneBuilder scene, SceneBuildingUtil util) {
        networkIntro(scene, util, "configurator", "The Network Configurator");
        BlockPos router = util.grid().at(1, 1, 3);
        BlockPos ap = util.grid().at(7, 1, 3);
        scene.world().showSection(util.select().layersFrom(1), Direction.DOWN);
        scene.idle(15);
        say(scene, util, router, Direction.SOUTH, 100, "Right-click a router, switch, access point or computer socket with the Network Configurator to open its settings, no computer needed");
        say(scene, util, router, Direction.SOUTH, 110, "Pages for the firewall and DHCP range, and one page per port: address, gateway, DHCP, VLAN, hostname, limits and Wi-Fi");
        say(scene, util, ap, Direction.SOUTH, 100, "An access point has a Wi-Fi page for its name, password, range and guest network");
        say(scene, util, router, Direction.SOUTH, 100, "Press Apply to save. The same checks apply as from a program, and a message tells you if a value was refused");
        scene.effects().indicateSuccess(router);
        scene.idle(20);
    }
}
