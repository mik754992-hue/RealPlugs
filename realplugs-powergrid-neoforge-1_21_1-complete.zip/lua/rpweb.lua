-- rpweb 2: websites on a Real Plugs network, from CC: Tweaked computers.
--
--   rpweb init                                   make a starter site in /www
--   rpweb serve [slot] [name] [--list hub]       serve /www (port 80); name = the address people type;
--                                                --list = announce the site to a directory (search engine)
--   rpweb directory [slot] [name]                run a directory / search engine site
--   rpweb browse [address]                       tabbed text browser
--
-- Pages: HTML (h1-h3 p br hr ul ol li a b i font span pre center blockquote table img form input textarea select),
-- plain .txt, images (.nfp), and .lua pages that run on the server and can answer forms.
-- Put it on a computer with:  edit rpweb   (paste this file, Ctrl, Save, Exit).  Other programs can  require("rpweb").

local M = {}

local CHUNK = 1400          -- the network carries at most 1500 characters per segment
local MAX_PAGE = 60000      -- biggest page the server sends / the browser takes
local ROOT = "www"
local DIR_PORT = 8053       -- directory announcements (datagrams)

-- ------------------------------------------------------------------ small helpers

local function trim(s) return (tostring(s or ""):gsub("^%s+", ""):gsub("%s+$", "")) end

function M.escape(s)
  return (tostring(s):gsub("&", "&amp;"):gsub("<", "&lt;"):gsub(">", "&gt;"):gsub('"', "&quot;"))
end

function M.urlencode(s)
  return (tostring(s):gsub("[^%w%-_%.~]", function(c) return string.format("%%%02X", c:byte()) end))
end

function M.urldecode(s)
  s = tostring(s):gsub("+", " ")
  return (s:gsub("%%(%x%x)", function(h) return string.char(tonumber(h, 16)) end))
end

function M.parseQuery(s)
  local t = {}
  for pair in tostring(s or ""):gmatch("[^&]+") do
    local k, v = pair:match("^([^=]*)=?(.*)$")
    if k and k ~= "" then t[M.urldecode(k)] = M.urldecode(v) end
  end
  return t
end

function M.encodeQuery(t)
  local keys = {}
  for k in pairs(t) do keys[#keys + 1] = k end
  table.sort(keys)
  local out = {}
  for _, k in ipairs(keys) do out[#out + 1] = M.urlencode(k) .. "=" .. M.urlencode(t[k]) end
  return table.concat(out, "&")
end

-- ------------------------------------------------------------------ addresses

function M.parseUrl(url)
  url = trim(url)
  local scheme = url:match("^(%a+)://")
  if scheme then
    if scheme:lower() ~= "http" then return nil, "only http:// addresses work here" end
    url = url:gsub("^%a+://", "")
  end
  local hostport, path = url:match("^([^/]+)(/.*)$")
  if not hostport then
    hostport, path = url:match("^([^/?]+)(%?.*)$")
    if hostport then path = "/" .. path else hostport, path = url, "/" end
  end
  local host, port = hostport:match("^(.-):(%d+)$")
  if not host then host, port = hostport, "80" end
  if host == "" then return nil, "no address" end
  return { host = host:lower(), port = tonumber(port), path = path }
end

function M.formatUrl(u)
  return "http://" .. u.host .. (u.port ~= 80 and (":" .. u.port) or "") .. u.path
end

local function normalize(path)
  local q = ""
  local qi = path:find("?", 1, true)
  if qi then q = path:sub(qi); path = path:sub(1, qi - 1) end
  local out = {}
  for part in path:gmatch("[^/]+") do
    if part == ".." then out[#out] = nil elseif part ~= "." then out[#out + 1] = part end
  end
  local r = "/" .. table.concat(out, "/")
  if path:sub(-1) == "/" and r ~= "/" then r = r .. "/" end
  return r .. q
end

-- a link found on page `base` (a parsed address) -> full address text
function M.resolve(base, href)
  href = trim(href)
  if href:match("^%a+://") or href:match("^about:") then return href end
  local hostpart = base.host .. (base.port ~= 80 and (":" .. base.port) or "")
  if href:sub(1, 1) == "?" then return "http://" .. hostpart .. (base.path:match("^[^?]*")) .. href end
  if href:sub(1, 1) == "/" then return "http://" .. hostpart .. normalize(href) end
  local dir = base.path:match("^([^?]*/)") or "/"
  return "http://" .. hostpart .. normalize(dir .. href)
end

-- ------------------------------------------------------------------ the protocol (a small HTTP/1.0)

function M.buildRequest(host, path, method, body, cookie)
  method = method or "GET"
  local s = method .. " " .. path .. " HTTP/1.0\r\nHost: " .. host .. "\r\nUser-Agent: rpweb/2\r\n"
  if cookie and cookie ~= "" then s = s .. "Cookie: " .. cookie .. "\r\n" end
  if body then s = s .. "Content-Type: application/x-www-form-urlencoded\r\nContent-Length: " .. #body .. "\r\n" end
  return s .. "\r\n" .. (body or "")
end

local function parseHeaders(head)
  local headers = {}
  for k, v in head:gmatch("\r?\n([^:\r\n]+):%s*([^\r\n]*)") do
    k = k:lower()
    if k == "set-cookie" and headers[k] then headers[k] = headers[k] .. "\n" .. v else headers[k] = v end
  end
  return headers
end

function M.parseResponse(raw)
  local s, e = raw:find("\r\n\r\n", 1, true)
  if not s then return nil end
  local head, body = raw:sub(1, s - 1), raw:sub(e + 1)
  local status, reason = head:match("^HTTP/%d%.%d (%d+) ?([^\r\n]*)")
  if not status then return nil end
  return { status = tonumber(status), reason = reason, headers = parseHeaders(head), body = body }
end

function M.responseComplete(raw)
  local r = M.parseResponse(raw)
  if not r then return false end
  local len = tonumber(r.headers["content-length"])
  return len ~= nil and #r.body >= len
end

-- a request from raw text: the request table, nil while more must arrive, false when it is not HTTP
function M.parseRequest(raw)
  local s, e = raw:find("\r\n\r\n", 1, true)
  if not s then s, e = raw:find("\n\n", 1, true) end
  if not s then return nil end
  local head, body = raw:sub(1, s - 1), raw:sub(e + 1)
  local method, target = head:match("^(%u+) (%S+)")
  if not method then return false end
  local headers = parseHeaders(head)
  local len = tonumber(headers["content-length"]) or 0
  if #body < len then return nil end
  body = body:sub(1, len)
  local path, qs = target:match("^([^?#]*)%??([^#]*)")
  local req = { method = method, target = target, path = M.urldecode((path:gsub("%+", "%%2B"))), query = M.parseQuery(qs),
                headers = headers, body = body, form = {} }
  if method == "POST" then req.form = M.parseQuery(body) end
  req.cookies = M.parseCookies(headers["cookie"])
  return req
end

-- ------------------------------------------------------------------ cookies
-- "a=1; b=2" -> { a = "1", b = "2" } (values are url-encoded)
function M.parseCookies(header)
  local t = {}
  for k, v in tostring(header or ""):gmatch("([^=;%s]+)=([^;]*)") do t[k] = M.urldecode(v) end
  return t
end

-- One Set-Cookie line (without the line break). days = how long it lives (nil = until the browser closes, 0 = delete).
function M.setCookieLine(name, value, days)
  local s = "Set-Cookie: " .. M.urlencode(tostring(name)) .. "=" .. M.urlencode(tostring(value)) .. "; Path=/"
  if days then s = s .. "; Max-Age=" .. math.floor(days * 86400) end
  return s
end

-- The browser's cookie jar: jar[host][name] = value. `header` = every Set-Cookie header of a response, joined by newlines.
function M.storeCookies(jar, host, header)
  if not header then return end
  for line in (header .. "\n"):gmatch("([^\n]*)\n") do
    local name, value = line:match("^%s*([^=;%s]+)=([^;]*)")
    if name then
      local gone = line:find("[Mm]ax%-[Aa]ge=0") or line:find("[Mm]ax%-[Aa]ge=%-")
      jar[host] = jar[host] or {}
      local n = 0
      for _ in pairs(jar[host]) do n = n + 1 end
      if gone then jar[host][M.urldecode(name)] = nil
      elseif n < 20 or jar[host][M.urldecode(name)] then jar[host][M.urldecode(name)] = M.urldecode(value) end
    end
  end
end

function M.cookieHeader(jar, host)
  local c = jar and jar[host]
  if not c then return nil end
  local parts = {}
  for k, v in pairs(c) do parts[#parts + 1] = M.urlencode(k) .. "=" .. M.urlencode(v) end
  table.sort(parts)
  return #parts > 0 and table.concat(parts, "; ") or nil
end

-- ------------------------------------------------------------------ colours (colour names and #rrggbb, as in CSS)
local CC_RGB = {
  white = { 240, 240, 240 }, orange = { 242, 178, 51 }, magenta = { 229, 127, 216 }, lightBlue = { 153, 178, 242 },
  yellow = { 222, 222, 108 }, lime = { 127, 204, 25 }, pink = { 242, 178, 204 }, gray = { 76, 76, 76 },
  lightGray = { 153, 153, 153 }, cyan = { 76, 153, 178 }, purple = { 178, 102, 229 }, blue = { 51, 102, 204 },
  brown = { 127, 102, 76 }, green = { 87, 166, 78 }, red = { 204, 76, 76 }, black = { 17, 17, 17 },
}
local CSS_NAME = { grey = "gray", lightgrey = "lightGray", lightgray = "lightGray", lightblue = "lightBlue", aqua = "cyan",
                   fuchsia = "magenta", violet = "purple", navy = "blue", maroon = "red", olive = "green", teal = "cyan",
                   silver = "lightGray", gold = "yellow" }

-- a colour name or #rgb / #rrggbb -> the nearest ComputerCraft colour name, or nil
function M.cssColor(v)
  if not v then return nil end
  v = tostring(v):gsub("^%s+", ""):gsub("%s+$", "")
  local low = v:lower()
  if CC_RGB[v] then return v end
  for name in pairs(CC_RGB) do if name:lower() == low then return name end end
  if CSS_NAME[low] then return CSS_NAME[low] end
  local hex = low:match("^#(%x%x%x%x%x%x)$")
  if not hex then
    local r, g, b = low:match("^#(%x)(%x)(%x)$")
    if r then hex = r .. r .. g .. g .. b .. b end
  end
  if not hex then return nil end
  local R, G, B = tonumber(hex:sub(1, 2), 16), tonumber(hex:sub(3, 4), 16), tonumber(hex:sub(5, 6), 16)
  local best, bestD
  for name, c in pairs(CC_RGB) do
    local d = (c[1] - R) ^ 2 + (c[2] - G) ^ 2 + (c[3] - B) ^ 2
    if not bestD or d < bestD or (d == bestD and name < best) then best, bestD = name, d end
  end
  return best
end

-- the value of one property in a style="a: b; c: d" attribute
function M.styleValue(style, prop)
  if not style then return nil end
  for k, v in style:gmatch("([%w%-]+)%s*:%s*([^;]+)") do
    if k:lower() == prop then return (v:gsub("%s+$", "")) end
  end
end

local MIME = { html = "text/html", htm = "text/html", txt = "text/plain", md = "text/plain", nfp = "image/nfp", lua = "text/plain" }

local function response(code, reason, mime, body, extra)
  return "HTTP/1.0 " .. code .. " " .. reason .. "\r\nContent-Type: " .. mime ..
         "\r\nContent-Length: " .. #body .. "\r\nServer: rpweb/2\r\n" .. (extra or "") .. "\r\n" .. body
end

-- ------------------------------------------------------------------ server side: pages that run (.lua)

-- A tiny password hash for page logins. It keeps passwords out of the data files in plain sight; it is a game, not a bank.
function M.hash(s)
  local a, b = 5381, 52711
  s = "rp:" .. tostring(s)
  for i = 1, #s do
    local c = s:byte(i)
    a = (a * 33 + c) % 4294967291
    b = (b * 31 + c * (i % 7 + 1)) % 4294967279
  end
  return string.format("%08x%08x", a, b)
end

M.PAGE_SECONDS = 2       -- a page that runs longer than this is stopped (500 page)
M.PAGE_HOOKS = 4000      -- ... or after this many hook calls of 10000 VM instructions, where the VM has a hook
local TIMEOUT = "page took too long"

-- Runs fn(...) with a time limit. Where the VM allows debug.sethook (tight loops included) the limit is enforced every
-- 10000 instructions; without it the limit is checked by the page functions (echo, data_*, ...) and ComputerCraft's own
-- "too long without yielding" watchdog stops a loop that never calls anything.
local function guarded(fn, check)
  local co = coroutine.create(fn)
  if debug and debug.sethook then
    local hooks = 0
    pcall(debug.sethook, co, function()
      hooks = hooks + 1
      if hooks > M.PAGE_HOOKS then error(TIMEOUT, 0) end
      check()
    end, "", 10000)
  end
  local ok, a, b, c = coroutine.resume(co)
  return ok, a, b, c
end

-- Runs a page. `api` = { load(name), save(name, table) } for the page's small database. Returns {status=, mime=, body=, location=, cookies=}.
function M.runPage(text, file, req, api)
  local out, outLen = {}, 0
  local redirectTo
  local cookiesOut = {}
  local deadline = os.clock() + M.PAGE_SECONDS
  local function check() if os.clock() > deadline then error(TIMEOUT, 0) end end
  local session, sessionId, allSessions
  local env = {
    request = req,
    string = string, table = table, math = math, tostring = tostring, tonumber = tonumber, pairs = pairs, ipairs = ipairs,
    type = type, select = select, pcall = pcall, error = error, next = next, assert = assert,
    os = { time = os.time, date = os.date, clock = os.clock },
    escape = M.escape, html = M.escape, urlencode = M.urlencode,
    echo = function(...)
      check()
      local parts = {}
      for i = 1, select("#", ...) do parts[#parts + 1] = tostring((select(i, ...))) end
      local piece = table.concat(parts)
      outLen = outLen + #piece
      if outLen > MAX_PAGE then error("page too large", 0) end
      out[#out + 1] = piece
    end,
    redirect = function(url) redirectTo = tostring(url) end,
    data_load = function(name) check(); return api and api.load(tostring(name)) end,
    data_save = function(name, t) check(); if api then return api.save(tostring(name), t) end end,
    -- cookies: cookie("name") reads one the browser sent, setcookie("name", "value", days) sends one (days = 0 deletes)
    cookie = function(name) return req and req.cookies and req.cookies[tostring(name)] end,
    setcookie = function(name, value, days)
      if #cookiesOut < 8 then cookiesOut[#cookiesOut + 1] = M.setCookieLine(name, value, days) end
    end,
    -- logins: users_add("name", "password") -> true or nil, why;  users_check("name", "password") -> true/false
    users_add = function(name, pw)
      check()
      name, pw = tostring(name or ""), tostring(pw or "")
      if not name:match("^[%w_%-]+$") or #name > 16 then return nil, "names are 1 to 16 letters, digits, _ or -" end
      if #pw < 3 then return nil, "the password is too short" end
      local users = (api and api.load("_users")) or {}
      if users[name:lower()] then return nil, "that name is taken" end
      users[name:lower()] = M.hash(pw)
      if api then api.save("_users", users) end
      return true
    end,
    users_check = function(name, pw)
      check()
      local users = (api and api.load("_users")) or {}
      local h = users[tostring(name or ""):lower()]
      return h ~= nil and h == M.hash(tostring(pw or ""))
    end,
    -- session(): a table that is kept for this browser (by a cookie). Put the logged-in name in it: session().user = "dan"
    session = function()
      if session then return session end
      local sessions = (api and api.load("_sessions")) or {}
      local id = req and req.cookies and req.cookies.rpsid
      if type(id) ~= "string" or not id:match("^%x+$") or not sessions[id] then
        id = ""
        for _ = 1, 16 do id = id .. string.format("%x", math.random(0, 15)) end
        sessions[id] = { t = os.time and os.time() or 0, data = {} }
        local n, oldest, oldestT = 0, nil, nil
        for k, v in pairs(sessions) do
          n = n + 1
          if k ~= id and (not oldestT or (v.t or 0) < oldestT) then oldest, oldestT = k, v.t or 0 end
        end
        if n > 200 and oldest then sessions[oldest] = nil end
        cookiesOut[#cookiesOut + 1] = M.setCookieLine("rpsid", id)
      end
      sessionId, allSessions = id, sessions
      session = sessions[id].data
      return session
    end,
  }
  local function pass(ok, err, ...)   -- a page cannot swallow the time limit
    if not ok and tostring(err):find(TIMEOUT, 1, true) then error(err, 0) end
    return ok, err, ...
  end
  env.pcall = function(f, ...) return pass(pcall(f, ...)) end
  if textutils then env.textutils = { serialise = textutils.serialise, unserialise = textutils.unserialise, urlEncode = textutils.urlEncode } end
  local fn, err = load(text, "@" .. file, "t", env)
  if not fn then return { status = 500, mime = "text/html", body = "<h1>500</h1><p>" .. M.escape(err) .. "</p>" } end
  local ok, a, b, c = guarded(fn, check)
  if session and api and allSessions then api.save("_sessions", allSessions) end   -- keep what the page put in the session
  if not ok then
    local msg = tostring(a)
    if msg:find(TIMEOUT, 1, true) then
      return { status = 500, mime = "text/html", body = "<h1>500</h1><p>" .. M.escape(file) .. " ran for more than " .. M.PAGE_SECONDS .. " seconds and was stopped.</p>" }
    end
    return { status = 500, mime = "text/html", body = "<h1>500</h1><p>Error in " .. M.escape(file) .. ": " .. M.escape(msg) .. "</p>" }
  end
  if redirectTo then return { status = 302, mime = "text/html", body = "", location = redirectTo, cookies = cookiesOut } end
  if type(a) == "table" then
    if a.redirect then return { status = 302, mime = "text/html", body = "", location = tostring(a.redirect), cookies = cookiesOut } end
    return { status = a.status or 200, mime = a.mime or "text/html", body = tostring(a.body or table.concat(out)), cookies = cookiesOut }
  end
  local body = a ~= nil and tostring(a) or table.concat(out)
  return { status = tonumber(b) or 200, mime = type(c) == "string" and c or "text/html", body = body, cookies = cookiesOut }
end

local REASON = { [200] = "OK", [301] = "Moved", [302] = "Found", [400] = "Bad Request", [404] = "Not Found",
                 [405] = "Method Not Allowed", [413] = "Too Large", [500] = "Server Error" }

local function respond(r)
  local extra = r.location and ("Location: " .. r.location .. "\r\n") or ""
  for _, line in ipairs(r.cookies or {}) do extra = extra .. line .. "\r\n" end
  return response(r.status, REASON[r.status] or "OK", r.mime or "text/html", r.body or "", extra)
end
M.respond = respond

-- ctx: read(path) -> text or nil, isDir(path) -> bool, vars = {hits=, time=, host=}, api = page database,
--      route(req) -> {status=, mime=, body=} or nil (built-in pages, tried first)
function M.handle(request, ctx)
  local req = type(request) == "table" and request or M.parseRequest(request)
  if not req then return response(400, "Bad Request", "text/plain", "bad request") end
  if req.method ~= "GET" and req.method ~= "HEAD" and req.method ~= "POST" then
    return response(405, "Method Not Allowed", "text/plain", "GET and POST only")
  end
  local path = req.path
  if path:sub(1, 1) ~= "/" or path:find("..", 1, true) or path:find("%z") or path:find("\\", 1, true) then
    return response(400, "Bad Request", "text/plain", "bad path")
  end
  if ctx.route then
    local r = ctx.route(req)
    if r then return respond(r) end
  end
  local file = ROOT .. path
  if path:sub(-1) == "/" then file = file .. "index.html"
  elseif ctx.isDir(file) then return "HTTP/1.0 301 Moved\r\nLocation: " .. path .. "/\r\nContent-Length: 0\r\n\r\n" end
  local luaFile = file:match("%.lua$") and file or nil
  local text = ctx.read(file)
  if not text and not luaFile then   -- /page also finds /page.lua
    luaFile = file .. ".lua"
    text = ctx.read(luaFile)
    if text then file = luaFile end
  elseif text and luaFile then file = luaFile end
  if not text then
    local nf = ctx.read(ROOT .. "/404.html")
      or "<h1>404</h1><p>No page called " .. M.escape(path) .. " here.</p><p><a href=\"/\">Home</a></p>"
    return response(404, "Not Found", "text/html", nf)
  end
  if file:match("%.lua$") then
    req.host = ctx.vars.host
    return respond(M.runPage(text, file, req, ctx.api))
  end
  local ext = file:match("%.(%w+)$")
  local mime = MIME[ext and ext:lower() or ""] or "text/plain"
  if mime == "text/html" or ext == "txt" then   -- {{hits}}, {{time}}, {{host}} work in pages
    text = text:gsub("{{(%w+)}}", function(k) local v = ctx.vars[k]; return v ~= nil and tostring(v) or nil end)
  end
  if #text > MAX_PAGE then return response(413, "Too Large", "text/plain", "page too large") end
  return response(200, "OK", mime, req.method == "HEAD" and "" or text)
end

-- ------------------------------------------------------------------ directory (search engine for named sites)

-- registry: name -> { title=, desc=, seen= }
function M.directoryRoute(registry)
  local function page(body)
    return { status = 200, mime = "text/html", body = "<html><head><title>Directory</title></head><body>" .. body .. "</body></html>" }
  end
  local function form(q)
    return '<form action="/search" method="get"><input name="q" value="' .. M.escape(q or "") ..
           '" size="24"> <input type="submit" value="Search"></form>'
  end
  local function names()
    local list = {}
    for n in pairs(registry) do list[#list + 1] = n end
    table.sort(list)
    return list
  end
  local function entry(n, e)
    return '<p><a href="http://' .. M.escape(n) .. '/">' .. M.escape(e.title ~= "" and e.title or n) .. "</a> (" ..
           M.escape(n) .. ")<br>" .. M.escape(e.desc or "") .. "</p>"
  end
  return function(req)
    if req.path == "/" then
      local out = { "<h1>Site directory</h1>", form(""), "<h2>All sites</h2>" }
      local list = names()
      for _, n in ipairs(list) do out[#out + 1] = entry(n, registry[n]) end
      if #list == 0 then out[#out + 1] = "<p>No sites have announced themselves yet.</p>" end
      out[#out + 1] = "<hr><p>Add your site: <b>rpweb serve 1 yourname --list this-directory</b></p>"
      return page(table.concat(out))
    elseif req.path == "/search" then
      local q = trim(req.query.q or ""):lower()
      local out = { "<h1>Search</h1>", form(q) }
      local hits = 0
      for _, n in ipairs(names()) do
        local e = registry[n]
        local hay = (n .. " " .. (e.title or "") .. " " .. (e.desc or "")):lower()
        local all = q ~= ""
        for word in q:gmatch("%S+") do if not hay:find(word, 1, true) then all = false end end
        if all then hits = hits + 1; out[#out + 1] = entry(n, e) end
      end
      out[#out + 1] = hits == 0 and "<p>Nothing found.</p>" or ("<p>" .. hits .. " result" .. (hits == 1 and "" or "s") .. ".</p>")
      out[#out + 1] = '<p><a href="/">All sites</a></p>'
      return page(table.concat(out))
    end
  end
end

-- the announcement a site sends to a directory: "ANNOUNCE\nname\ntitle\ndescription"
function M.buildAnnounce(name, indexHtml)
  local title = (indexHtml or ""):match("<[Tt][Ii][Tt][Ll][Ee]>(.-)</[Tt][Ii][Tt][Ll][Ee]>") or ""
  local desc = (indexHtml or ""):match('<[Mm][Ee][Tt][Aa]%s+name="description"%s+content="([^"]*)"') or ""
  title = trim(title:gsub("%s+", " ")):sub(1, 60)
  desc = trim(desc:gsub("%s+", " ")):sub(1, 160)
  return "ANNOUNCE\n" .. name .. "\n" .. title .. "\n" .. desc
end

function M.parseAnnounce(payload)
  local name, title, desc = payload:match("^ANNOUNCE\n([^\n]*)\n([^\n]*)\n?([^\n]*)")
  if not name or not name:match("^[%w%.%-_]+$") then return nil end
  return name:lower(), { title = title or "", desc = desc or "" }
end

-- ------------------------------------------------------------------ rendering pages (a small subset of HTML)

local ENT = { lt = "<", gt = ">", amp = "&", quot = '"', nbsp = " ", apos = "'" }
local function entities(s)
  return (s:gsub("&(#?%w+);", function(e)
    if ENT[e] then return ENT[e] end
    local n = e:match("^#(%d+)$")
    if n and tonumber(n) < 256 then return string.char(tonumber(n)) end
  end))
end

local function attr(attrs, name)
  local v = attrs:match("%f[%w]" .. name .. '%s*=%s*"([^"]*)"') or attrs:match("%f[%w]" .. name .. "%s*=%s*'([^']*)'")
         or attrs:match("%f[%w]" .. name .. "%s*=%s*([^%s>]+)")
  return v and entities(v)
end

local NFP = { ["0"] = "white", ["1"] = "orange", ["2"] = "magenta", ["3"] = "lightBlue", ["4"] = "yellow", ["5"] = "lime",
              ["6"] = "pink", ["7"] = "gray", ["8"] = "lightGray", ["9"] = "cyan", a = "purple", b = "blue", c = "brown",
              d = "green", e = "red", f = "black" }

-- an .nfp picture (hex digits, space = see-through) -> rows of segments with a background colour
function M.parseNfp(text, maxW, maxH)
  local rows = {}
  for line in (text .. "\n"):gmatch("([^\n]*)\n") do
    if #rows >= (maxH or 30) then break end
    line = line:gsub("\r", ""):sub(1, maxW or 50)
    local segs, cur, n = {}, nil, 0
    for ch in line:gmatch(".") do
      local c = NFP[ch:lower()]
      if cur and cur.bg == c then cur.t = cur.t .. " " else cur = { t = " ", fg = "white", bg = c }; segs[#segs + 1] = cur end
    end
    rows[#rows + 1] = { segs = segs }
  end
  while #rows > 0 and #rows[#rows].segs == 0 do rows[#rows] = nil end
  return rows
end

-- returns { lines = { {segs = { {t=, fg=, bg=, link=, input=, submit=} }}, ... }, links = { href, ... }, title =,
--           forms = { {method=, action=} }, inputs = { {form=, type=, name=, value=, size=, checked=, options=} }, images = { src, ... } }
-- assets: optional table src -> .nfp text for <img> tags
function M.render(html, width, base, assets)
  local lines, links, title, forms, inputs, images = {}, {}, nil, {}, {}, {}
  local cur, curLen, indent = {}, 0, 0
  local fgStack, fg = {}, "white"
  local linkId, inPre, skip, inTitle = nil, false, nil, false
  local listStack, titleBuf = {}, {}
  local formId, area, select_ = nil, nil, nil
  local bg, align, fx = nil, nil, {}   -- background colour, text alignment and the styled tags that set them
  local STYLED = { div = true, p = true, span = true, font = true, td = true, th = true, center = true,
                   h1 = true, h2 = true, h3 = true, table = true, tr = true }

  local function flush()
    if (align == "center" or align == "right") and curLen < width and #cur > 0 and not inPre then
      local pad = align == "center" and math.floor((width - curLen) / 2) or (width - curLen)
      if pad > 0 then table.insert(cur, 1, { t = string.rep(" ", pad), fg = "white", bg = bg }) end
    end
    lines[#lines + 1] = { segs = cur }
    cur, curLen = {}, 0
  end
  local function newline() if curLen > 0 or #cur > 0 then flush() end end
  local function blank()
    newline()
    if #lines > 0 and #lines[#lines].segs > 0 then lines[#lines + 1] = { segs = {} } end
  end
  local function put(text, color, link, extra)
    if text == "" then return end
    if curLen == 0 and indent > 0 then cur[#cur + 1] = { t = string.rep(" ", indent), fg = "white" }; curLen = indent end
    local seg = { t = text, fg = color, link = link, bg = bg }
    if extra then for k, v in pairs(extra) do seg[k] = v end end
    cur[#cur + 1] = seg
    curLen = curLen + #text
  end
  local function words(text)
    if inPre then
      local first = true
      for piece in (text .. "\n"):gmatch("([^\n]*)\n") do
        if not first then newline() end
        first = false
        put(piece, fg, linkId)
      end
      return
    end
    text = entities(text):gsub("%s+", " ")
    for lead, w in text:gmatch("( ?)([^ ]+)") do
      local need = #w + ((curLen > indent and lead ~= "") and 1 or 0)
      if curLen > indent and curLen + need > width then newline() end
      if curLen > indent and lead ~= "" then put(" ", fg, linkId) end
      while #w > width - indent do   -- a word longer than a line
        put(w:sub(1, width - indent - curLen), fg, linkId)
        newline()
        w = w:sub(width - indent + 1)
      end
      put(w, fg, linkId)
    end
    if text:sub(-1) == " " and curLen > indent then put(" ", fg, linkId) end
  end
  local function addInput(t)
    inputs[#inputs + 1] = t
    t.form = formId
    return #inputs
  end
  local function widget(tp, attrs)
    local id
    if tp == "hidden" then addInput({ type = "hidden", name = attr(attrs, "name") or "", value = attr(attrs, "value") or "" }); return end
    if tp == "submit" or tp == "button" then
      local label = attr(attrs, "value") or "Submit"
      id = addInput({ type = "submit", name = attr(attrs, "name") or "", value = label })
      local txt = "[ " .. label .. " ]"
      if curLen > indent and curLen + #txt > width then newline() end
      put(txt, "lime", nil, { submit = id })
    elseif tp == "checkbox" then
      id = addInput({ type = "checkbox", name = attr(attrs, "name") or "", value = attr(attrs, "value") or "on", checked = attrs:find("%f[%w]checked") ~= nil })
      if curLen > indent and curLen + 3 > width then newline() end
      put("[ ]", "lime", nil, { input = id })
    else
      local size = tonumber(attr(attrs, "size")) or 16
      size = math.max(4, math.min(size, width - indent - 4))
      id = addInput({ type = tp == "password" and "password" or "text", name = attr(attrs, "name") or "", value = attr(attrs, "value") or "", size = size })
      if curLen > indent and curLen + size + 2 > width then newline() end
      put(string.rep(" ", size + 2), "yellow", nil, { input = id })
    end
  end

  html = html:gsub("<!%-%-.-%-%->", "")
  local pos = 1
  while pos <= #html do
    local s, e, closing, tag, attrs = html:find("<(/?)(%w+)([^>]*)>", pos)
    local text = html:sub(pos, (s or #html + 1) - 1)
    if text ~= "" and not skip then
      if inTitle then titleBuf[#titleBuf + 1] = text
      elseif area then area.value = area.value .. entities(text)
      elseif select_ then -- option text is read at the <option> tag
      else words(text) end
    end
    if not s then break end
    pos = e + 1
    tag = tag:lower()
    local close = closing == "/"
    local pf, pb, pa = fg, bg, align   -- before this tag changes anything (see the styled tags below)
    if skip then
      if close and tag == skip then skip = nil end
    elseif tag == "script" or tag == "style" then
      if not close then skip = tag end
    elseif tag == "title" then
      inTitle = not close
      if close then title = entities(table.concat(titleBuf)):gsub("%s+", " ") end
    elseif tag == "h1" or tag == "h2" or tag == "h3" then
      blank()
      if close then fg = table.remove(fgStack) or "white" else
        fgStack[#fgStack + 1] = fg
        fg = tag == "h1" and "yellow" or tag == "h2" and "orange" or "lightBlue"
      end
    elseif tag == "p" or tag == "div" or tag == "table" or tag == "center" or tag == "ul" or tag == "ol" or tag == "blockquote" then
      blank()
      if tag == "ul" or tag == "ol" then
        if close then table.remove(listStack); indent = math.max(0, indent - 2)
        else listStack[#listStack + 1] = { n = 0, ordered = tag == "ol" }; indent = indent + 2 end
      elseif tag == "blockquote" then indent = close and math.max(0, indent - 4) or indent + 4 end
    elseif tag == "br" or tag == "tr" then newline()
    elseif tag == "td" or tag == "th" then if not close then put("  ", fg) end
    elseif tag == "hr" then blank(); put(string.rep("-", width), "gray"); newline()
    elseif tag == "li" and not close then
      newline()
      local l = listStack[#listStack]
      local mark = "* "
      if l then l.n = l.n + 1; if l.ordered then mark = l.n .. ". " end end
      indent = indent - 2
      put(mark, "lime")
      indent = indent + 2
    elseif tag == "pre" then blank(); inPre = not close
    elseif tag == "b" or tag == "strong" or tag == "i" or tag == "em" or tag == "u" then
      if close then fg = table.remove(fgStack) or "white" else fgStack[#fgStack + 1] = fg; fg = "white" end
    elseif tag == "font" or tag == "span" then
      if close then fg = table.remove(fgStack) or "white" else
        fgStack[#fgStack + 1] = fg
        fg = attr(attrs, "color") or fg
      end
    elseif tag == "a" then
      if close then
        if linkId then put("[" .. linkId .. "]", "gray") end
        linkId = nil
        fg = table.remove(fgStack) or "white"
      else
        local href = attr(attrs, "href")
        if href then
          links[#links + 1] = base and M.resolve(base, href) or href
          linkId = #links
        end
        fgStack[#fgStack + 1] = fg
        if href then fg = "lightBlue" end
      end
    elseif tag == "img" then
      local src = attr(attrs, "src")
      local full = src and (base and M.resolve(base, src) or src)
      if full and full:lower():match("%.nfp$") and #images < 6 then
        local seen = false
        for _, i in ipairs(images) do if i == full then seen = true end end
        if not seen then images[#images + 1] = full end
      end
      if full and assets and assets[full] then
        blank()
        for _, row in ipairs(M.parseNfp(assets[full], width - indent, 40)) do
          if indent > 0 then table.insert(row.segs, 1, { t = string.rep(" ", indent), fg = "white" }) end
          lines[#lines + 1] = row
        end
        lines[#lines + 1] = { segs = {} }
      else
        put("[image: " .. (attr(attrs, "alt") or src or "?") .. "]", "gray")
      end
    elseif tag == "form" then
      blank()
      if close then formId = nil else
        forms[#forms + 1] = { method = (attr(attrs, "method") or "get"):lower(), action = attr(attrs, "action") or "" }
        formId = #forms
      end
    elseif tag == "input" and not close then
      widget((attr(attrs, "type") or "text"):lower(), attrs)
    elseif tag == "textarea" then
      if close then
        if area then
          local id = addInput({ type = "text", name = area.name, value = area.value:gsub("\r?\n", " "), size = area.size })
          if curLen > indent and curLen + area.size + 2 > width then newline() end
          put(string.rep(" ", area.size + 2), "yellow", nil, { input = id })
          area = nil
        end
      else
        area = { name = attr(attrs, "name") or "", value = "", size = math.max(4, math.min(tonumber(attr(attrs, "cols")) or 24, width - indent - 4)) }
      end
    elseif tag == "select" then
      if close then
        if select_ then
          local id = addInput({ type = "select", name = select_.name, options = select_.options, value = select_.value or (select_.options[1] and select_.options[1][1]) or "" })
          local w = 4
          for _, o in ipairs(select_.options) do w = math.max(w, #o[2] + 2) end
          w = math.min(w, width - indent - 2)
          if curLen > indent and curLen + w > width then newline() end
          put(string.rep(" ", w), "yellow", nil, { input = id })
          inputs[id].size = w - 2
          select_ = nil
        end
      else select_ = { name = attr(attrs, "name") or "", options = {} } end
    elseif tag == "button" and not close then   -- <button name=".." value="..">Label</button> submits the form
      local cs, ce = html:find("</[Bb][Uu][Tt][Tt][Oo][Nn]>", pos)
      local inner = cs and html:sub(pos, cs - 1) or ""
      if ce then pos = ce + 1 end
      local label = trim(entities((inner:gsub("<[^>]*>", ""))))
      if label == "" then label = attr(attrs, "value") or "Submit" end
      local id = addInput({ type = "submit", name = attr(attrs, "name") or "", value = attr(attrs, "value") or label })
      local txt = "[ " .. label .. " ]"
      if curLen > indent and curLen + #txt > width then newline() end
      put(txt, "lime", nil, { submit = id })
    elseif tag == "option" and select_ and not close then
      local label = html:match("^([^<]*)", pos) or ""
      local value = attr(attrs, "value") or trim(label)
      select_.options[#select_.options + 1] = { value, trim(entities(label)) }
      if attrs:find("%f[%w]selected") then select_.value = value end
    end
    -- CSS-like colours and layout: color, bgcolor / background, align / text-align (attributes or style="...") on a few tags
    if STYLED[tag] and not skip then
      if close then
        while fx[#fx] and fx[#fx].tag == "p" and tag ~= "p" do   -- a <p> that was never closed
          local t = table.remove(fx); fg, bg, align = t.fg, t.bg, t.align
        end
        local top = fx[#fx]
        if top and top.tag == tag then
          fx[#fx] = nil
          if tag ~= "font" and tag ~= "span" then fg = top.fg end
          bg, align = top.bg, top.align
        end
      else
        if tag == "p" and fx[#fx] and fx[#fx].tag == "p" then
          local t = table.remove(fx); fg, bg, align = t.fg, t.bg, t.align
        end
        local style = attr(attrs, "style")
        local color = M.cssColor(attr(attrs, "color") or M.styleValue(style, "color"))
        local back = M.cssColor(attr(attrs, "bgcolor") or M.styleValue(style, "background-color") or M.styleValue(style, "background"))
        local al = attr(attrs, "align") or M.styleValue(style, "text-align") or (tag == "center" and "center") or nil
        al = al and al:lower() or nil
        if al ~= "center" and al ~= "right" then al = nil end
        if (color or back or al) and #fx < 30 then
          fx[#fx + 1] = { tag = tag, fg = pf, bg = pb, align = pa }
          if color then fg = color end
          if back then bg = back end
          if al then align = al end
        end
      end
    end
  end
  newline()
  while #lines > 0 and #lines[#lines].segs == 0 do lines[#lines] = nil end
  return { lines = lines, links = links, title = title, forms = forms, inputs = inputs, images = images }
end

function M.renderText(text, width)
  local lines = {}
  for line in (text .. "\n"):gmatch("([^\n]*)\n") do
    line = line:gsub("\r", ""):gsub("\t", "  ")
    repeat
      lines[#lines + 1] = { segs = { { t = line:sub(1, width), fg = "white" } } }
      line = line:sub(width + 1)
    until line == ""
  end
  return { lines = lines, links = {}, title = nil, forms = {}, inputs = {}, images = {} }
end

-- the text an input shows (same length as its placeholder)
function M.inputText(input, value, len)
  local v = value
  if input.type == "checkbox" then return (v and v ~= "") and "[x]" or "[ ]" end
  if input.type == "select" then
    for _, o in ipairs(input.options) do if o[1] == v then v = o[2] end end
  end
  v = tostring(v or "")
  if input.type == "password" then v = string.rep("*", #v) end
  local inner = len - 2
  if #v > inner then v = v:sub(#v - inner + 1) end   -- show the end while typing
  return "[" .. v .. string.rep("_", inner - #v) .. "]"
end

-- the form fields to send for a form (+ the submit button that was used)
function M.formValues(page, vals, formId, submitId)
  local out = {}
  for id, input in ipairs(page.inputs) do
    if input.form == formId and input.name ~= "" then
      if input.type == "hidden" then out[input.name] = input.value
      elseif input.type == "checkbox" then if vals[id] ~= nil and vals[id] ~= "" then out[input.name] = input.value end
      elseif input.type == "submit" then if id == submitId then out[input.name] = input.value end
      else out[input.name] = vals[id] ~= nil and vals[id] or input.value end
    end
  end
  return out
end

-- ------------------------------------------------------------------ small formats used by other rpweb tools

-- "word word" lines of a bookmark file: url <TAB> title
function M.parseBookmarks(text)
  local out = {}
  for line in (text or ""):gmatch("[^\n]+") do
    local url, t = line:match("^([^\t]+)\t?(.*)$")
    if url then out[#out + 1] = { url = url, title = t ~= "" and t or url } end
  end
  return out
end

function M.bookmarksHtml(list)
  local out = { "<html><head><title>Bookmarks</title></head><body><h1>Bookmarks</h1>" }
  if #list == 0 then out[#out + 1] = "<p>No bookmarks yet. Press D on a page to add it.</p>" end
  out[#out + 1] = "<ul>"
  for _, b in ipairs(list) do out[#out + 1] = '<li><a href="' .. M.escape(b.url) .. '">' .. M.escape(b.title) .. "</a>" end
  out[#out + 1] = "</ul></body></html>"
  return table.concat(out, "\n")
end

M.HOME = [[<html><head><title>rpweb</title></head><body>
<h1>rpweb browser</h1>
<p>Type an address with <b>G</b> (a name like <font color="lime">mysite</font> or an address like 192.168.1.5),
or a link number.</p>
<h2>Keys</h2>
<ul><li>Arrows, PgUp, PgDn, mouse wheel: scroll</li><li>G go, B back, R reload, Q quit</li>
<li>T new tab, W close tab, [ and ] (or Tab) switch tabs</li><li>D bookmark this page, M bookmarks</li>
<li>/ find in page, N next match</li><li>Click links, [ ] boxes and fields</li></ul>
<p><a href="about:bookmarks">Bookmarks</a></p></body></html>]]

-- ------------------------------------------------------------------ everything below needs ComputerCraft

if RPWEB_TEST then return M end

local function findNic()
  local nic = peripheral.find("realplugs_socket")
  if not nic then error("no Real Plugs socket next to this computer", 0) end
  return nic, peripheral.getName(nic)
end

local function pcallClose(nic, slot, id) pcall(nic.tcpClose, slot, id) end

-- gets a page: returns response table, or nil + reason. opts = { method=, body= }
M.jar = {}        -- the browser's cookies for this session: jar[host][name] = value
M.resolver = nil  -- optional function(name) -> address, tried when the network does not know a name (see rpddns)

function M.fetch(nic, slot, url, opts, hops)
  opts = opts or {}
  hops = hops or 0
  local jar = opts.jar or M.jar
  local u, err = M.parseUrl(url)
  if not u then return nil, err end
  local side = peripheral.getName(nic)
  local id, cerr = nic.connect(slot, u.host, u.port)
  if not id and M.resolver and not u.host:match("^%d+%.%d+%.%d+%.%d+$") then
    local ip = M.resolver(u.host)
    if ip then id, cerr = nic.connect(slot, ip, u.port) end
  end
  if not id then return nil, cerr or "cannot connect" end
  local timer = os.startTimer(10)
  local buf = ""
  while true do
    local ev = { os.pullEvent() }
    if ev[1] == "timer" and ev[2] == timer then
      pcallClose(nic, slot, id)
      return nil, "timed out"
    elseif ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot and ev[5] == id then
      if ev[4] == "connected" then
        local req = M.buildRequest(u.host, u.path, opts.method, opts.body, M.cookieHeader(jar, u.host))
        for i = 1, #req, CHUNK do
          local ok, why = nic.tcpSend(slot, id, req:sub(i, i + CHUNK - 1))
          if ok == false then return nil, why end
        end
      elseif ev[4] == "data" then
        buf = buf .. ev[6]
        if #buf > MAX_PAGE + 2000 then pcallClose(nic, slot, id); return nil, "page too large" end
        if M.responseComplete(buf) then break end
      elseif ev[4] == "closed" then
        if buf == "" then return nil, "connection " .. tostring(ev[6] or "closed") end
        break
      end
    end
  end
  os.cancelTimer(timer)
  pcallClose(nic, slot, id)
  local r = M.parseResponse(buf)
  if not r then return nil, "not a web server" end
  r.url = M.formatUrl(u)
  M.storeCookies(jar, u.host, r.headers["set-cookie"])
  local loc = r.headers["location"]
  if (r.status == 301 or r.status == 302) and loc and hops < 4 then
    return M.fetch(nic, slot, M.resolve(u, loc), { jar = jar }, hops + 1)
  end
  return r
end

-- ------------------------------------------------------------------ server

local function readFile(path)
  if not fs.exists(path) or fs.isDir(path) then return nil end
  local f = fs.open(path, "rb"); if not f then return nil end
  local t = f.readAll(); f.close(); return t
end

-- opts: slot, name, route(req), udpPort, onPacket(payload, srcIp), list (directory to announce to), quiet
function M.run(opts)
  local slot = opts.slot or 1
  local nic, side = findNic()
  local ok, why = nic.listen(slot, 80)
  if ok == false then error("cannot listen: " .. tostring(why), 0) end
  if opts.name then
    local ok2, why2 = nic.setHostname(slot, opts.name)
    if ok2 == false then print("name not set: " .. tostring(why2)) end
  end
  local ifs = nic.getInterfaces()[slot]
  local host = opts.name or (ifs and ifs.ip) or "?"
  fs.makeDir("data")
  local ctx = {
    read = readFile,
    isDir = function(path) return fs.exists(path) and fs.isDir(path) end,
    vars = { hits = 0, host = host },
    route = opts.route,
    api = {
      load = function(name)
        if not name:match("^[%w_%-]+$") then return nil end
        local t = readFile("data/" .. name .. ".db")
        return t and textutils.unserialise(t) or nil
      end,
      save = function(name, t)
        if not name:match("^[%w_%-]+$") then return false end
        local f = fs.open("data/" .. name .. ".db", "w"); f.write(textutils.serialise(t)); f.close()
        return true
      end,
    },
  }
  local buffers = {}
  local announceTimer
  local function announce()
    if not opts.list then return end
    local msg = M.buildAnnounce(host, readFile(ROOT .. "/index.html") or "")
    pcall(nic.send, slot, opts.list, DIR_PORT, DIR_PORT, msg)
  end
  if opts.list then announce(); announceTimer = os.startTimer(300) end
  if opts.udpPort then pcall(nic.listen, slot, opts.udpPort) end
  term.clear(); term.setCursorPos(1, 1)
  print("rpweb server on slot " .. slot .. ": http://" .. host .. "/")
  print((opts.title or ("pages are in /" .. ROOT)) .. "  (Ctrl+T stops)")
  while true do
    local ev = { os.pullEventRaw() }
    if ev[1] == "terminate" then
      pcall(nic.unlisten, slot, 80)
      print("stopped"); return
    elseif ev[1] == "timer" and ev[2] == announceTimer then
      announce(); announceTimer = os.startTimer(300)
    elseif ev[1] == "realplugs_packet" and ev[2] == side and ev[3] == slot then
      if opts.onPacket and ev[6] == (opts.udpPort or -1) then opts.onPacket(ev[7], ev[4]) end
    elseif ev[1] == "realplugs_tcp" and ev[2] == side and ev[3] == slot then
      local kind, id = ev[4], ev[5]
      if kind == "accepted" then
        buffers[id] = { ip = ev[6], data = "" }
      elseif kind == "data" and buffers[id] then
        local b = buffers[id]
        b.data = b.data .. ev[6]
        local req, bad = M.parseRequest(b.data)
        if req or bad == false or #b.data > 20000 then
          ctx.vars.hits = ctx.vars.hits + 1
          ctx.vars.time = textutils.formatTime(os.time(), true)
          if req then req.ip = b.ip end
          local out = req and M.handle(req, ctx) or response(bad == false and 400 or 413, "Bad Request", "text/plain", "bad request")
          print(b.ip .. "  " .. (b.data:match("^(%u+ %S+)") or "?") .. "  " .. (out:match("^HTTP/%d%.%d (%d+)") or "?"))
          for i = 1, #out, CHUNK do
            local sent = nic.tcpSend(slot, id, out:sub(i, i + CHUNK - 1))
            if sent == false then break end
          end
          pcallClose(nic, slot, id)
          buffers[id] = nil
        end
      elseif kind == "closed" then
        buffers[id] = nil
      end
    end
  end
end

-- ------------------------------------------------------------------ browser

local BOOKMARKS = ".rpweb_bookmarks"

local function browse(slot, start)
  local nic = findNic()
  local w, h = term.getSize()
  local tabs, cur = {}, 1
  local findText

  local function newTab() return { page = nil, vals = {}, scroll = 0, history = {}, current = nil, status = "G = go, T = new tab, Q = quit" } end
  tabs[1] = newTab()

  local function color(name) return colors[name] or colors.white end
  local function body() return h - 3 end

  local function bookmarks() return M.parseBookmarks(readFile(BOOKMARKS) or "") end

  local function draw()
    local tab = tabs[cur]
    term.setBackgroundColor(colors.black); term.clear()
    -- tab bar
    term.setCursorPos(1, 1); term.setBackgroundColor(colors.gray); term.clearLine()
    local x = 1
    for i, t in ipairs(tabs) do
      local label = " " .. i .. ":" .. ((t.page and t.page.title) or t.current or "new"):sub(1, 10) .. " "
      term.setCursorPos(x, 1)
      term.setBackgroundColor(i == cur and colors.black or colors.gray)
      term.setTextColor(i == cur and colors.yellow or colors.lightGray)
      term.write(label)
      x = x + #label
    end
    -- address bar
    term.setCursorPos(1, 2); term.setBackgroundColor(colors.lightGray); term.setTextColor(colors.black); term.clearLine()
    term.write(" " .. (tab.current or "(no page)"):sub(1, w - 2))
    term.setBackgroundColor(colors.black)
    local page = tab.page
    if page then
      for row = 1, body() do
        local line = page.lines[tab.scroll + row]
        if not line then break end
        term.setCursorPos(1, row + 2)
        for _, seg in ipairs(line.segs) do
          local text = seg.t
          if seg.input then text = M.inputText(page.inputs[seg.input], tab.vals[seg.input] ~= nil and tab.vals[seg.input] or page.inputs[seg.input].value, #seg.t) end
          term.setBackgroundColor(seg.bg and color(seg.bg) or colors.black)
          term.setTextColor(color(seg.fg))
          term.write(text)
        end
        term.setBackgroundColor(colors.black)
      end
    end
    term.setCursorPos(1, h); term.setBackgroundColor(colors.gray); term.setTextColor(colors.white); term.clearLine()
    term.write((tab.status or ""):sub(1, w))
    term.setBackgroundColor(colors.black)
  end

  local function layout(tab)
    local width = w
    if tab.mime and tab.mime:find("html", 1, true) then
      tab.page = M.render(tab.raw, width, tab.base, tab.assets)
    else
      tab.page = M.renderText(tab.raw or "", width)
    end
  end

  local function showHtml(tab, url, html, status)
    tab.raw, tab.mime, tab.base, tab.assets = html, "text/html", M.parseUrl(url) or { host = "", port = 80, path = "/" }, {}
    tab.current = url
    tab.vals = {}
    tab.scroll = 0
    layout(tab)
    tab.status = status or (#tab.page.links .. " links")
  end

  local function load(tab, url, push, opts)
    url = trim(url)
    if url == "about:bookmarks" or url == "about:home" then
      if push and tab.current then tab.history[#tab.history + 1] = tab.current end
      showHtml(tab, url, url == "about:home" and M.HOME or M.bookmarksHtml(bookmarks()), url)
      tab.base = { host = "about", port = 80, path = "/" }
      return
    end
    tab.status = "Loading " .. url .. " ..."
    local old = tab.current
    tab.current = url
    draw()
    local r, err = M.fetch(nic, slot, url, opts)
    if not r then
      tab.current = old
      tab.status = "Error: " .. tostring(err)
      return
    end
    if push and old then tab.history[#tab.history + 1] = old end
    local mime = r.headers["content-type"] or "text/plain"
    tab.raw, tab.mime, tab.base, tab.assets = r.body, mime, M.parseUrl(r.url), {}
    tab.current = r.url
    tab.vals = {}
    tab.scroll = 0
    layout(tab)
    for _, src in ipairs(tab.page.images or {}) do   -- pictures: fetch them, then lay the page out again
      tab.status = "Loading picture " .. src
      draw()
      local img = M.fetch(nic, slot, src)
      if img and img.status == 200 then tab.assets[src] = img.body end
    end
    if next(tab.assets) then layout(tab) end
    tab.status = r.status .. " " .. r.reason .. (tab.page.title and ("  -  " .. tab.page.title) or "") .. "  (" .. #tab.page.links .. " links)"
  end

  local function go(tab, text)
    text = trim(text)
    if text == "" then return end
    if text:match("^%d+$") then
      local href = tab.page and tab.page.links[tonumber(text)]
      if href then load(tab, href, true) else tab.status = "No link " .. text end
    else
      load(tab, text, true)
    end
  end

  local function prompt(label, initial)
    term.setCursorPos(1, h); term.setBackgroundColor(colors.black); term.setTextColor(colors.white); term.clearLine()
    term.write(label)
    return read(nil, nil, nil, initial)
  end

  local function submit(tab, formId, submitId)
    local page = tab.page
    local form = page.forms[formId]
    if not form then return end
    local values = M.formValues(page, tab.vals, formId, submitId)
    local action = form.action ~= "" and form.action or tab.current
    local target = M.resolve(tab.base, action)
    if form.method == "post" then
      load(tab, target, true, { method = "POST", body = M.encodeQuery(values) })
    else
      target = target:gsub("%?.*$", "")
      load(tab, target .. "?" .. M.encodeQuery(values), true)
    end
  end

  local function activate(tab, seg)
    local page = tab.page
    if seg.link then go(tab, tostring(seg.link)); return end
    if seg.submit then submit(tab, page.inputs[seg.submit].form or 0, seg.submit); return end
    if seg.input then
      local input = page.inputs[seg.input]
      local val = tab.vals[seg.input]; if val == nil then val = input.value end
      if input.type == "checkbox" then
        tab.vals[seg.input] = (val ~= nil and val ~= "") and "" or "on"
        if input.checked and tab.vals[seg.input] == nil then tab.vals[seg.input] = "" end
      elseif input.type == "select" then
        local nextOpt = input.options[1]
        for i, o in ipairs(input.options) do if o[1] == val then nextOpt = input.options[i % #input.options + 1] end end
        if nextOpt then tab.vals[seg.input] = nextOpt[1] end
      else
        local text = prompt((input.name ~= "" and input.name or "text") .. ": ", input.type == "password" and "" or tostring(val or ""))
        tab.vals[seg.input] = text
        -- Enter in a text field submits a form that has a search/submit button
        if text ~= "" and input.form then
          for sid, inp in ipairs(page.inputs) do
            if inp.type == "submit" and inp.form == input.form then submit(tab, input.form, sid); return end
          end
        end
      end
    end
  end

  local function find(tab, from)
    if not findText or not tab.page then return end
    local needle = findText:lower()
    local n = #tab.page.lines
    for i = 0, n - 1 do
      local idx = (from + i - 1) % n + 1
      local t = {}
      for _, s in ipairs(tab.page.lines[idx].segs) do t[#t + 1] = s.t end
      if table.concat(t):lower():find(needle, 1, true) then
        tab.scroll = math.max(0, math.min(idx - 1, math.max(0, n - body())))
        tab.status = "Found at line " .. idx .. "   (N = next)"
        return idx
      end
    end
    tab.status = "Not found: " .. findText
  end

  load(tabs[1], (start and start ~= "") and start or "about:home", false)
  local lastFound = 0
  while true do
    draw()
    local tab = tabs[cur]
    local ev = { os.pullEvent() }
    local maxScroll = tab.page and math.max(0, #tab.page.lines - body()) or 0
    if ev[1] == "key" then
      local k = ev[2]
      if k == keys.q then break
      elseif k == keys.up then tab.scroll = math.max(0, tab.scroll - 1)
      elseif k == keys.down then tab.scroll = math.min(maxScroll, tab.scroll + 1)
      elseif k == keys.pageUp then tab.scroll = math.max(0, tab.scroll - (body() - 1))
      elseif k == keys.pageDown or k == keys.space then tab.scroll = math.min(maxScroll, tab.scroll + (body() - 1))
      elseif k == keys.home then tab.scroll = 0
      elseif k == keys["end"] then tab.scroll = maxScroll
      elseif k == keys.b or k == keys.backspace then
        local back = table.remove(tab.history)
        if back then load(tab, back, false) else tab.status = "Nothing to go back to" end
      elseif k == keys.r and tab.current then load(tab, tab.current, false)
      elseif k == keys.g then go(tab, prompt("Go: ", ""))
      elseif k == keys.t then
        tabs[#tabs + 1] = newTab(); cur = #tabs
        local a = prompt("New tab: ", "")
        if trim(a) == "" then load(tabs[cur], "about:home", false) else go(tabs[cur], a) end
      elseif k == keys.w then
        if #tabs > 1 then table.remove(tabs, cur); cur = math.min(cur, #tabs) else tab.status = "That is the last tab" end
      elseif k == keys.rightBracket or k == keys.tab then cur = cur % #tabs + 1
      elseif k == keys.leftBracket then cur = (cur - 2) % #tabs + 1
      elseif k == keys.d and tab.current and not tab.current:match("^about:") then
        local list = bookmarks()
        local exists = false
        for _, b in ipairs(list) do if b.url == tab.current then exists = true end end
        if not exists then
          local f = fs.open(BOOKMARKS, "a"); f.write(tab.current .. "\t" .. ((tab.page and tab.page.title) or tab.current) .. "\n"); f.close()
          tab.status = "Bookmarked"
        else tab.status = "Already bookmarked" end
      elseif k == keys.m then load(tab, "about:bookmarks", true)
      elseif k == keys.slash then
        local t = prompt("Find: ", "")
        if trim(t) ~= "" then findText = t; lastFound = find(tab, tab.scroll + 2) or 0 end
      elseif k == keys.n then lastFound = find(tab, lastFound + 1) or lastFound end
    elseif ev[1] == "mouse_scroll" then
      tab.scroll = math.max(0, math.min(maxScroll, tab.scroll + ev[2] * 2))
    elseif ev[1] == "mouse_click" then
      local cx, cy = ev[3], ev[4]
      if cy == 1 then
        local x = 1
        for i, t in ipairs(tabs) do
          local len = #(" " .. i .. ":" .. ((t.page and t.page.title) or t.current or "new"):sub(1, 10) .. " ")
          if cx >= x and cx < x + len then cur = i end
          x = x + len
        end
      elseif cy >= 3 and tab.page then
        local line = tab.page.lines[tab.scroll + cy - 2]
        if line then
          local x = 1
          for _, seg in ipairs(line.segs) do
            if cx >= x and cx < x + #seg.t and (seg.link or seg.input or seg.submit) then activate(tab, seg); break end
            x = x + #seg.t
          end
        end
      end
    elseif ev[1] == "term_resize" then
      w, h = term.getSize()
      for _, t in ipairs(tabs) do if t.raw then layout(t) end end
    end
  end
  term.setBackgroundColor(colors.black); term.setTextColor(colors.white); term.clear(); term.setCursorPos(1, 1)
end

-- ------------------------------------------------------------------ starter site

local function init()
  fs.makeDir(ROOT)
  local function write(path, text)
    if fs.exists(path) then print("kept " .. path); return end
    local f = fs.open(path, "w"); f.write(text); f.close(); print("made " .. path)
  end
  write(ROOT .. "/index.html", [[<html><head><title>My first website</title>
<meta name="description" content="A site made with rpweb"></head>
<body>
<h1>Welcome to {{host}}</h1>
<p>This page is served by a computer in my base. You are visitor number {{hits}}.
It is {{time}} on the server.</p>
<h2>Pages</h2>
<ul>
<li><a href="about.html">About this site</a></li>
<li><a href="guestbook">Guestbook</a> (a page that runs on the server)</li>
<li><a href="notes.txt">A plain text file</a></li>
</ul>
<hr>
<p>Change this page with <b>edit www/index.html</b>.</p>
</body></html>
]])
  write(ROOT .. "/about.html", [[<html><head><title>About</title></head>
<body>
<h1>About</h1>
<p>Everything here is plain HTML in the <b>www</b> folder: headings, paragraphs, lists,
<font color="lime">coloured text</font>, rules, forms and links to other pages
(<a href="/">home</a>).</p>
<p>Tags the browser understands: h1 h2 h3 p br hr ul ol li a b i font(color) pre center blockquote table
img(alt, .nfp pictures) form input textarea select.
Pages can contain {{hits}} (visitors), {{time}} and {{host}}. A file ending in .lua is a program that
runs on the server: see guestbook.lua.</p>
</body></html>
]])
  write(ROOT .. "/guestbook.lua", [[-- A page that runs on the server. `request` has method, path, query, form, ip.
-- data_load(name) / data_save(name, table) keep a small database in /data. Return the page as text.
local book = data_load("guestbook") or {}
if request.method == "POST" and request.form.msg and request.form.msg ~= "" then
  table.insert(book, 1, { who = request.form.who ~= "" and request.form.who or "anonymous",
                          msg = request.form.msg:sub(1, 200), ip = request.ip })
  while #book > 30 do table.remove(book) end
  data_save("guestbook", book)
  return { redirect = "/guestbook" }          -- after a POST, show the page again
end
echo("<html><head><title>Guestbook</title></head><body><h1>Guestbook</h1>")
echo('<form action="/guestbook" method="post">')
echo('Name <input name="who" size="12"><br>Message <input name="msg" size="30"> ')
echo('<input type="submit" value="Sign"></form><hr>')
for _, e in ipairs(book) do
  echo("<p><b>", escape(e.who), "</b> (", escape(e.ip or "?"), "): ", escape(e.msg), "</p>")
end
if #book == 0 then echo("<p>Nobody has signed yet.</p>") end
echo('<p><a href="/">Home</a></p></body></html>')
]])
  write(ROOT .. "/notes.txt", "A plain text page.\nNo tags here, just lines.\n")
  write(ROOT .. "/404.html", "<h1>404</h1><p>That page does not exist.</p><p><a href=\"/\">Home</a></p>\n")
end

-- ------------------------------------------------------------------ command line

local function parseArgs(args)
  local slot, name, list
  local i = 2
  while args[i] do
    if args[i] == "--list" then list = args[i + 1]; i = i + 1
    elseif tonumber(args[i]) and not slot then slot = tonumber(args[i])
    elseif not name then name = args[i] end
    i = i + 1
  end
  return slot or 1, name, list
end

local function directory(slot, name)
  local registry = {}
  local f = readFile("directory.db")
  if f then registry = textutils.unserialise(f) or {} end
  M.run({
    slot = slot, name = name, route = M.directoryRoute(registry), udpPort = DIR_PORT,
    title = "directory: sites announce themselves with  rpweb serve 1 name --list " .. (name or "this-address"),
    onPacket = function(payload)
      local n, e = M.parseAnnounce(payload)
      if n then
        e.seen = os.epoch and os.epoch("utc") or 0
        registry[n] = e
        local out = fs.open("directory.db", "w"); out.write(textutils.serialise(registry)); out.close()
        print("listed " .. n)
      end
    end,
  })
end

local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if running == "rpweb" or running == "rpweb.lua" then
  local args = { ... }
  -- a file ".rpweb_ddns" with the address of a dynamic DNS server (rpddns serve) lets the browser find names the network does not know
  local ddnsHost = readFile(".rpweb_ddns")
  if ddnsHost and ddnsHost:match("%S") then
    ddnsHost = ddnsHost:match("^%s*(%S+)")
    M.resolver = function(name)
      local okMod, ddns = pcall(require, "rpddns")
      if not okMod then return nil end
      local nic = findNic()
      return ddns.lookup(nic, 1, ddnsHost, name)
    end
  end
  local cmd = args[1]
  if cmd == "init" then init()
  elseif cmd == "serve" then local s, n, l = parseArgs(args); M.run({ slot = s, name = n, list = l })
  elseif cmd == "directory" then local s, n = parseArgs(args); directory(s, n)
  elseif cmd == "browse" then browse(1, args[2])
  else print("rpweb init | serve [slot] [name] [--list hub] | directory [slot] [name] | browse [address]") end
end

return M
