package dan200.computercraft.api.pocket;

import net.minecraft.network.chat.Component;
import net.minecraft.world.item.ItemStack;

/** COMPILE-TIME STUB of CC: Tweaked 1.113's AbstractPocketUpgrade. Excluded from the released jar. */
public abstract class AbstractPocketUpgrade implements IPocketUpgrade {
    private final Component adjective;
    private final ItemStack stack;

    protected AbstractPocketUpgrade(Component adjective, ItemStack stack) {
        this.adjective = adjective;
        this.stack = stack;
    }

    @Override
    public final Component getAdjective() {
        return adjective;
    }

    @Override
    public final ItemStack getCraftingItem() {
        return stack;
    }
}
