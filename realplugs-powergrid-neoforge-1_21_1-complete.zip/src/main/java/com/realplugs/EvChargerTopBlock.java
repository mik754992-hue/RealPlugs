package com.realplugs;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.DirectionProperty;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.joml.Vector3f;

/**
 * The upper half of a two-block-high EV charger: the screen and the button panel. It has no block entity and no
 * drops of its own. Everything (credit, owner, fee ...) lives in the charger below it, which places this block when
 * it is placed and breaks together with it.
 */
public class EvChargerTopBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.HORIZONTAL_FACING;

    /** Buttons, left to right and top to bottom as seen from the front. Zones are in viewer units (see zoneOf). */
    public static final int BTN_MINUS = 0, BTN_PLUS = 1, BTN_MODE = 2, BTN_STOP = 3, SCREEN = 4, NONE = -1;

    private static final VoxelShape[] SHAPES = new VoxelShape[4];

    static {
        VoxelShape north = Block.box(2.5, 0, 7.4, 13.5, 16, 16);
        for (int i = 0; i < 4; i++) SHAPES[i] = rotate(north, i);
    }

    public EvChargerTopBlock(Properties props) {
        super(props);
        registerDefaultState(stateDefinition.any().setValue(FACING, Direction.NORTH));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(FACING);
    }

    /** Turns a north-facing shape clockwise (seen from above) by the given number of quarter turns. */
    private static VoxelShape rotate(VoxelShape s, int quarterTurns) {
        VoxelShape out = Shapes.empty();
        for (AABB b : s.toAabbs()) {
            double x0 = b.minX, z0 = b.minZ, x1 = b.maxX, z1 = b.maxZ;
            for (int i = 0; i < quarterTurns; i++) {
                double nx0 = 1 - z1, nx1 = 1 - z0, nz0 = x0, nz1 = x1;
                x0 = nx0; x1 = nx1; z0 = nz0; z1 = nz1;
            }
            out = Shapes.or(out, Shapes.create(x0, b.minY, z0, x1, b.maxY, z1));
        }
        return out;
    }

    private static int turns(Direction d) {
        return switch (d) {
            case EAST -> 1;
            case SOUTH -> 2;
            case WEST -> 3;
            default -> 0;
        };
    }

    @Override
    protected VoxelShape getShape(BlockState state, net.minecraft.world.level.BlockGetter level, BlockPos pos,
                                  net.minecraft.world.phys.shapes.CollisionContext ctx) {
        return SHAPES[turns(state.getValue(FACING))];
    }

    /** The two halves live and die together. */
    @Override
    protected BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                     BlockPos pos, BlockPos neighborPos) {
        if (dir == Direction.DOWN && !(neighbor.getBlock() instanceof EvChargerBlock)) {
            return Blocks.AIR.defaultBlockState();
        }
        return super.updateShape(state, dir, neighbor, level, pos, neighborPos);
    }

    /** Creative mode: breaking the top must not also drop the charger. */
    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && player.isCreative()) {
            BlockPos below = pos.below();
            if (level.getBlockState(below).getBlock() instanceof EvChargerBlock) {
                level.setBlock(below, Blocks.AIR.defaultBlockState(), 35);   // 35: no drops, no neighbour shape update
            }
        }
        return super.playerWillDestroy(level, pos, state, player);
    }

    @Override
    public ItemStack getCloneItemStack(LevelReader level, BlockPos pos, BlockState state) {
        BlockState below = level.getBlockState(pos.below());
        return below.getBlock() instanceof EvChargerBlock c ? new ItemStack(c) : ItemStack.EMPTY;
    }

    /**
     * Which part of the front panel a hit is on. x runs from the viewer's LEFT edge of the block (0) to the right (16),
     * y is the height inside this block. Layout (matches the texture made by scripts/gen_ev_charger_assets.py):
     * screen x 4..12, y 7.5..13.5; buttons: minus x 4..6.5, plus x 7..9.5, mode x 10..12 (all y 4..7); STOP x 4..12, y 0.5..3.5.
     */
    public static int zoneOf(Vector3f v) {
        float x = v.x, y = v.y;
        if (x >= 4 && x <= 12 && y >= 7.5f && y <= 13.5f) return SCREEN;
        if (y >= 4 && y <= 7) {
            if (x >= 4 && x <= 6.5f) return BTN_MINUS;
            if (x >= 7 && x <= 9.5f) return BTN_PLUS;
            if (x >= 10 && x <= 12) return BTN_MODE;
        }
        if (x >= 4 && x <= 12 && y >= 0.5f && y <= 3.5f) return BTN_STOP;
        return NONE;
    }

    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
                                              Player player, net.minecraft.world.InteractionHand hand, BlockHitResult hit) {
        return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
    }

    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        BlockPos low = pos.below();
        if (!(level.getBlockState(low).getBlock() instanceof EvChargerBlock charger)
                || hit.getDirection() != state.getValue(FACING)) {
            return InteractionResult.PASS;
        }
        int zone = zoneOf(EvChargerBlock.viewerPoint(state.getValue(FACING), pos, hit.getLocation()));
        if (zone == NONE) return InteractionResult.PASS;
        if (!level.isClientSide) charger.pressPanel(level, low, player, zone);
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
