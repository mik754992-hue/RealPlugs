package com.realplugs.cc;

import com.realplugs.RealPlugsMod;
import dan200.computercraft.api.pocket.IPocketUpgrade;
import dan200.computercraft.api.upgrades.UpgradeType;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

/** The CC: Tweaked upgrade type behind the "realplugs:port" pocket upgrades (only loaded when CC is installed). */
public final class ModPocketUpgrades {
    public static final DeferredRegister<UpgradeType<? extends IPocketUpgrade>> TYPES =
            DeferredRegister.create(IPocketUpgrade.typeRegistry(), RealPlugsMod.MODID);

    public static final DeferredHolder<UpgradeType<? extends IPocketUpgrade>, UpgradeType<PortPocketUpgrade>> PORT =
            TYPES.register("port", () -> UpgradeType.create(PortPocketUpgrade.CODEC));

    private ModPocketUpgrades() {}
}
