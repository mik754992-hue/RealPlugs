package net.minecraft.server.level;
public record Dim(String name){ public Dim location(){return this;} @Override public String toString(){return name;} }
