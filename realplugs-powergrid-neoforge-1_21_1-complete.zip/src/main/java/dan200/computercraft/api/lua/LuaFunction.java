package dan200.computercraft.api.lua;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * COMPILE-TIME STUB of CC: Tweaked's annotation, so Real Plugs builds without a CC dependency.
 * It is excluded from the released jar (see build.gradle); the real class comes from CC: Tweaked at runtime.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface LuaFunction {
    String[] value() default {};
    boolean unsafe() default false;
    boolean mainThread() default false;
}
