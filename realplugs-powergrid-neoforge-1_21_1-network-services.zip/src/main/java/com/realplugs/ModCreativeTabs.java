package com.realplugs;

import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomModelData;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModCreativeTabs {
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, RealPlugsMod.MODID);

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MAIN = TABS.register("main", () ->
            CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.realplugs"))
                    .icon(() -> new ItemStack(ModItems.PLUG.get()))
                    .displayItems((params, out) -> {
                        ModItems.SOCKET_ITEMS.values().forEach(h -> out.accept(h.get()));
                        out.accept(ModItems.WIFI_ANALYZER.get());
                        out.accept(ModItems.CAT5_CABLE.get());
                        out.accept(ModItems.CAT6_CABLE.get());
                        out.accept(ModItems.FIBRE_CABLE.get());
                        // index 0 is the unfinished placeholder model, so the tab starts at 1
                        for (int i = 1; i < PlugTypes.PLUGS.length; i++) out.accept(variant(ModItems.PLUG.get(), i));
                        for (int i = 1; i < PlugTypes.ADAPTERS.length; i++) out.accept(variant(ModItems.ADAPTER.get(), i));
                        for (int i = 1; i < PlugTypes.PLUGS.length; i++) out.accept(variant(ModItems.PORT.get(), i));
                        for (int i = 1; i < ExtensionTypes.ALL.length; i++) out.accept(variant(ModItems.EXTENSION_CABLE.get(), i));
                        for (int i = 1; i < CordTypes.ALL.length; i++) out.accept(variant(ModItems.PLUG_CORD.get(), i));
                    })
                    .build());

    private static ItemStack variant(Item item, int type) {
        ItemStack s = new ItemStack(item);
        if (type > 0) s.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(type));
        return s;
    }
}
