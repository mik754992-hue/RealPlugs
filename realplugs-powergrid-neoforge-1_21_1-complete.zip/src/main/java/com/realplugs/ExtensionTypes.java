package com.realplugs;

/**
 * The extension cables, indexed by custom_model_data (1 and up; 0 is a placeholder copy of the US one).
 * One end is a plug of {@code plug} that goes into a slot of that connector. The other end is a power-strip-like block
 * ({@code endBlock}) you place on a surface; it has several slots of its own.
 */
public final class ExtensionTypes {
    public record Def(String name, PlugTypes.Standard plug, String endBlock) {}

    public static final Def[] ALL = {
        new Def("us", PlugTypes.Standard.US_POWER, "ext_us"),
        new Def("us", PlugTypes.Standard.US_POWER, "ext_us"),
        new Def("eu", PlugTypes.Standard.EU_POWER, "ext_eu"),
        new Def("uk", PlugTypes.Standard.UK_POWER, "ext_uk"),
        new Def("au", PlugTypes.Standard.AU_POWER, "ext_au"),
        new Def("usb_a", PlugTypes.Standard.USB_A, "ext_usb"),
        new Def("usb_c", PlugTypes.Standard.USB_C, "ext_usb"),
        new Def("hdmi", PlugTypes.Standard.HDMI, "ext_av"),
        new Def("ethernet", PlugTypes.Standard.RJ45, "ext_av")
    };

    public static Def get(int type) {
        return ALL[type >= 0 && type < ALL.length ? type : 0];
    }

    private ExtensionTypes() {}
}
