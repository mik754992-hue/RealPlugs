package com.realplugs;

import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;

import java.util.List;

/**
 * A socket you stick onto a CC: Tweaked block (computer, monitor, disk drive, printer, modem...) at an exact spot.
 * The variant (custom_model_data) uses the plug numbering: port 3 is the US power socket, port 2 is USB-C, and so on.
 * See PortPlaceHandler for placing it and PortEntity for what it does.
 */
public class PortItem extends Item {
    public PortItem(Properties props) {
        super(props);
    }

    public static PlugTypes.Standard standardOf(ItemStack stack) {
        return PlugTypes.plug(PlugItem.typeOf(stack)).plugs();
    }

    @Override
    public String getDescriptionId(ItemStack stack) {
        int i = PlugItem.typeOf(stack);
        String base = getDescriptionId();
        return i > 0 && i < PlugTypes.PLUGS.length ? base + "." + PlugTypes.PLUGS[i].name() : base;
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, List<Component> tips, TooltipFlag flag) {
        tips.add(Component.translatable("tooltip.realplugs.port_takes", Component.translatable(standardOf(stack).langKey()))
                .withStyle(ChatFormatting.GRAY));
        tips.add(Component.translatable("tooltip.realplugs.port_place").withStyle(ChatFormatting.DARK_GRAY));
    }
}
