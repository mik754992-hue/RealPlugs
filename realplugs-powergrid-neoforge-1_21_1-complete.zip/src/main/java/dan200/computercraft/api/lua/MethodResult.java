package dan200.computercraft.api.lua;

/** COMPILE-TIME STUB of CC: Tweaked's MethodResult. Excluded from the released jar. */
public final class MethodResult {
    private MethodResult() {}

    public static MethodResult of() {
        throw new UnsupportedOperationException("stub");
    }

    public static MethodResult of(Object value) {
        throw new UnsupportedOperationException("stub");
    }

    public static MethodResult of(Object... values) {
        throw new UnsupportedOperationException("stub");
    }
}
