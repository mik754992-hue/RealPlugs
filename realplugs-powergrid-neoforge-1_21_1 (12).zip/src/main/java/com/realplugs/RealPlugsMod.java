package com.realplugs;

import com.realplugs.cc.CCCompat;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModList;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

@Mod(RealPlugsMod.MODID)
public class RealPlugsMod {
    public static final String MODID = "realplugs";

    public RealPlugsMod(IEventBus modBus) {
        ModComponents.COMPONENTS.register(modBus);
        ModBlocks.BLOCKS.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModBlockEntities.BLOCK_ENTITIES.register(modBus);
        ModEntities.ENTITIES.register(modBus);
        ModCreativeTabs.TABS.register(modBus);

        // our handler goes first so plug cords get the slot/standard checks on our outlets
        modBus.addListener((FMLCommonSetupEvent e) ->
                e.enqueueWork(() -> CordItem.PLACEMENT_HANDLERS.add(0, new PlugCordHandler())));

        // CC: Tweaked is optional: only touch its classes when it is installed
        if (ModList.get().isLoaded("computercraft")) {
            CCCompat.init(modBus);
        }
    }
}
