#!/usr/bin/env python3
"""Sanity-check that Java registries, models, blockstates, loot tables, recipes and lang entries agree.

Run from the repo root:  python3 scripts/validate_assets.py
Exits non-zero (and prints every problem) if something is missing, so CI catches typos before a game launch does.
"""
import json
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RES = ROOT / "src/main/resources"
JAVA = ROOT / "src/main/java/com/realplugs"
NS = "realplugs"
errors = []


def err(msg):
    errors.append(msg)


def load(path):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        err(f"{path.relative_to(ROOT)}: invalid JSON ({e})")
        return None


# 1. every JSON file parses
for p in RES.rglob("*.json"):
    load(p)

lang = load(RES / f"assets/{NS}/lang/en_us.json") or {}

# 2. sockets
socket_ids = re.findall(r'new SocketDef\("([a-z0-9_]+)"', (JAVA / "SocketDefs.java").read_text())
pick = load(RES / "data/minecraft/tags/block/mineable/pickaxe.json") or {"values": []}
ANCHOR = "port_anchor"   # hidden helper behind ports: no item, recipe or loot table
for rel in (f"assets/{NS}/blockstates/{ANCHOR}.json", f"assets/{NS}/models/block/{ANCHOR}.json"):
    if not (RES / rel).exists():
        err(f"port anchor: missing {rel}")
for sid in socket_ids:
    if sid == ANCHOR:
        continue
    if sid.startswith("ext_"):   # extension strip ends: placed by the cable, no item/recipe/loot
        for rel in (f"assets/{NS}/blockstates/{sid}.json",):
            if not (RES / rel).exists():
                err(f"extension end '{sid}': missing {rel}")
        if f"block.{NS}.{sid}" not in lang:
            err(f"extension end '{sid}': missing lang key block.{NS}.{sid}")
        continue
    for rel in (f"assets/{NS}/blockstates/{sid}.json", f"assets/{NS}/models/block/{sid}.json",
                f"assets/{NS}/models/item/{sid}.json", f"data/{NS}/loot_table/blocks/{sid}.json",
                f"data/{NS}/recipe/{sid}.json"):
        if not (RES / rel).exists():
            err(f"socket '{sid}': missing {rel}")
    if f"block.{NS}.{sid}" not in lang:
        err(f"socket '{sid}': missing lang key block.{NS}.{sid}")
    if f"{NS}:{sid}" not in pick["values"]:
        err(f"socket '{sid}': not in the pickaxe tag")

# 3. plugs and adapters (array index == custom_model_data)
types = (JAVA / "PlugTypes.java").read_text()
plugs = re.findall(r'new PlugDef\("([a-z0-9_]+)"', types)
adapters = re.findall(r'new AdapterDef\("([a-z0-9_]+)"', types)
for kind, names in (("plug", plugs), ("adapter", adapters)):
    base = load(RES / f"assets/{NS}/models/item/{kind}.json") or {}
    overrides = {o["predicate"]["custom_model_data"]: o["model"] for o in base.get("overrides", [])}
    for i, name in enumerate(names):
        if i == 0:
            continue  # placeholder uses the base model
        if overrides.get(i) != f"{NS}:item/{kind}_{name}":
            err(f"{kind} #{i} '{name}': override in {kind}.json is {overrides.get(i)!r}")
        if not (RES / f"assets/{NS}/models/item/{kind}_{name}.json").exists():
            err(f"{kind} #{i} '{name}': missing models/item/{kind}_{name}.json")
        if f"item.{NS}.{kind}.{name}" not in lang:
            err(f"{kind} #{i} '{name}': missing lang key item.{NS}.{kind}.{name}")
        if not (RES / f"data/{NS}/recipe/{kind}_{name}.json").exists():
            err(f"{kind} #{i} '{name}': no crafting recipe (data/{NS}/recipe/{kind}_{name}.json)")
    for i in overrides:
        if i >= len(names):
            err(f"{kind}.json has an override for #{i} but PlugTypes.java only defines {len(names)}")

# 3b. plug cords: indices 1..len(plugs)-1 mirror the plugs, the rest are the multi-standard cords in CordTypes.java
cord = load(RES / f"assets/{NS}/models/item/plug_cord.json") or {}
co = {o["predicate"]["custom_model_data"]: o["model"] for o in cord.get("overrides", [])}
multi = re.findall(r'new CordDef\("([a-z0-9_]+)", [A-Za-z]+, [A-Za-z]+\)\);', (JAVA / "CordTypes.java").read_text())
cord_names = plugs + multi
for i, name in enumerate(cord_names):
    if i == 0:
        continue
    want = f"{NS}:item/plug_{name}" if i < len(plugs) else f"{NS}:item/plug_cord_{name}"
    if co.get(i) != want:
        err(f"plug_cord #{i} '{name}': override is {co.get(i)!r}, expected {want}")
    if i >= len(plugs) and not (RES / f"assets/{NS}/models/item/plug_cord_{name}.json").exists():
        err(f"plug_cord '{name}': missing model plug_cord_{name}.json")
    if f"item.{NS}.plug_cord.{name}" not in lang:
        err(f"plug_cord '{name}': missing lang key item.{NS}.plug_cord.{name}")
    if not (RES / f"data/{NS}/recipe/plug_cord_{name}.json").exists():
        err(f"plug_cord '{name}': no recipe")
if not (RES / f"data/{NS}/powergrid/wire_types/plug_cord.json").exists():
    err("missing data/realplugs/powergrid/wire_types/plug_cord.json (Power Grid will not treat the item as a cord)")

# 3c. ports (socket items for CC: Tweaked blocks): one model, a plugged model, a lang key and a recipe per plug
port = load(RES / f"assets/{NS}/models/item/port.json") or {}
po = {o["predicate"]["custom_model_data"]: o["model"] for o in port.get("overrides", [])}
for i, name in enumerate(plugs):
    if i == 0:
        continue
    for idx, suffix in ((i, ""), (100 + i, "_plugged")):
        if po.get(idx) != f"{NS}:item/port_{name}{suffix}":
            err(f"port #{idx} '{name}': override is {po.get(idx)!r}")
        if not (RES / f"assets/{NS}/models/item/port_{name}{suffix}.json").exists():
            err(f"port '{name}': missing model port_{name}{suffix}.json")
    if f"item.{NS}.port.{name}" not in lang:
        err(f"port '{name}': missing lang key item.{NS}.port.{name}")
    if not (RES / f"data/{NS}/recipe/port_{name}.json").exists():
        err(f"port '{name}': no recipe")

# 3d. pocket computer port upgrades (CC: Tweaked datapack entries)
for i, name in enumerate(plugs):
    if i == 0:
        continue
    f = RES / f"data/{NS}/computercraft/pocket_upgrade/port_{name}.json"
    if not f.exists():
        err(f"pocket upgrade for port '{name}': missing {f.relative_to(ROOT)}")
    else:
        d = load(f) or {}
        if d.get("type") != f"{NS}:port" or d.get("port") != name:
            err(f"{f.relative_to(ROOT)}: expected type {NS}:port and port {name}")
    if f"upgrade.{NS}.port.{name}" not in lang:
        err(f"pocket upgrade '{name}': missing lang key upgrade.{NS}.port.{name}")

# 3e. Ponder schematics used by RealPlugsPonderPlugin
plugin = (JAVA / "ponder/RealPlugsPonderPlugin.java").read_text()
for sch in set(re.findall(r'"([a-z_]+_showcase)"', plugin)):
    if not (RES / f"assets/{NS}/ponder/{sch}.nbt").exists():
        err(f"ponder: schematic assets/{NS}/ponder/{sch}.nbt is missing")

# 3f. extension cables
ext_names = re.findall(r'new Def\("([a-z0-9_]+)"', (JAVA / "ExtensionTypes.java").read_text())[1:]
for i, name in enumerate(ext_names, 1):
    if f"item.{NS}.extension_cable.{name}" not in lang:
        err(f"extension cable '{name}': missing lang key")
    if not (RES / f"data/{NS}/recipe/extension_cable_{name}.json").exists():
        err(f"extension cable '{name}': no recipe")
if not (RES / f"data/{NS}/powergrid/wire_types/extension_cable.json").exists():
    err("missing data/realplugs/powergrid/wire_types/extension_cable.json")

# 4. connector standards need a lang name
for key in re.findall(r'\("([a-z0-9_]+)", (?:true|false)\)', types):
    if f"standard.{NS}.{key}" not in lang:
        err(f"standard '{key}': missing lang key standard.{NS}.{key}")

# 5. models only reference textures that exist
for p in (RES / f"assets/{NS}/models").rglob("*.json"):
    data = load(p) or {}
    for tex in (data.get("textures") or {}).values():
        if isinstance(tex, str) and tex.startswith(f"{NS}:"):
            if not (RES / f"assets/{NS}/textures/{tex.split(':', 1)[1]}.png").exists():
                err(f"{p.relative_to(ROOT)}: texture {tex} not found")

if errors:
    print(f"{len(errors)} problem(s):")
    for e in errors:
        print(" -", e)
    sys.exit(1)
print(f"OK: {len(socket_ids)} sockets, {len(plugs) - 1} plugs, {len(adapters) - 1} adapters checked.")
