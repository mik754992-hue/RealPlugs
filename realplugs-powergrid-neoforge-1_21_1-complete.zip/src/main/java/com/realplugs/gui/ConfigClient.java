package com.realplugs.gui;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;

/** Client only. Opens the screen, or replaces it by a fresh one with the same page when the server sends an update. */
final class ConfigClient {
    private ConfigClient() {}

    static void open(BlockPos pos, CompoundTag view, String message) {
        Minecraft mc = Minecraft.getInstance();
        int page = 0;
        if (mc.screen instanceof ConfigScreen old && old.pos().equals(pos)) page = old.page();
        mc.setScreen(new ConfigScreen(pos, view, message, page));
    }
}
