package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;

/**
 * Sneak + right-click a CC: Tweaked computer with a plug/adapter to stick it on at the exact
 * spot you clicked (snapped to the 1/16 pixel grid). Not sneaking still opens the computer UI.
 * Works without a compile-time dependency on CC: Tweaked (matches the block by registry name).
 */
@EventBusSubscriber(modid = RealPlugsMod.MODID)
public class ComputerPlugHandler {
    @SubscribeEvent
    public static void onRightClick(PlayerInteractEvent.RightClickBlock event) {
        Player player = event.getEntity();
        ItemStack held = event.getItemStack();
        if (!(held.getItem() instanceof PlugItem) || !player.isShiftKeyDown()) return;

        Level level = event.getLevel();
        BlockState state = level.getBlockState(event.getPos());
        ResourceLocation key = BuiltInRegistries.BLOCK.getKey(state.getBlock());
        if (!key.getNamespace().equals("computercraft") || !key.getPath().contains("computer")) return;

        event.setCanceled(true);
        event.setCancellationResult(InteractionResult.sidedSuccess(level.isClientSide));
        if (level.isClientSide) return;

        Vec3 hit = event.getHitVec().getLocation();
        hit = new Vec3(Math.round(hit.x * 16) / 16.0, Math.round(hit.y * 16) / 16.0, Math.round(hit.z * 16) / 16.0);
        level.addFreshEntity(PlugEntity.create(level, event.getPos(), event.getFace(), hit,
                PlugItem.takeOne(held, player)));
    }
}
