package com.realplugs;

import net.minecraft.client.Minecraft;
import net.minecraft.world.entity.player.Player;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

/** Client-only helper (only ever called when the level is a client level). */
final class PortClient {
    private PortClient() {}

    /** Is the local player holding a cord? Then ports step aside so the cord can be aimed at the port's anchor. */
    static boolean holdsCord() {
        Player p = Minecraft.getInstance().player;
        return p != null && (p.getMainHandItem().getItem() instanceof CordItem || p.getOffhandItem().getItem() instanceof CordItem);
    }
}
