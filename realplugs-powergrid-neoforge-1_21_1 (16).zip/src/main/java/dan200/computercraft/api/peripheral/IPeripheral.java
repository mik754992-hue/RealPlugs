package dan200.computercraft.api.peripheral;

/** COMPILE-TIME STUB of CC: Tweaked's IPeripheral (only the abstract methods). Excluded from the released jar. */
public interface IPeripheral {
    String getType();

    boolean equals(IPeripheral other);
}
