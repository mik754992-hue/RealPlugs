package com.realplugs.gui;

import com.realplugs.PlugSocketBlockEntity;
import com.realplugs.RealPlugsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.neoforged.neoforge.network.PacketDistributor;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.handling.IPayloadContext;

/**
 * The two packets of the configurator screen. The server decides what the screen shows (a list of pages with fields) and what a
 * field means; the screen is only a form. Server to client: {@link OpenPayload} (the form, plus a message). Client to server:
 * {@link ApplyPayload} (the fields that were changed, id -> text).
 */
public final class ConfigPayloads {
    private ConfigPayloads() {}

    public record OpenPayload(BlockPos pos, CompoundTag view, String message) implements CustomPacketPayload {
        public static final Type<OpenPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(RealPlugsMod.MODID, "config_open"));
        public static final StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, OpenPayload> CODEC = StreamCodec.composite(
                BlockPos.STREAM_CODEC, OpenPayload::pos,
                ByteBufCodecs.COMPOUND_TAG, OpenPayload::view,
                ByteBufCodecs.STRING_UTF8, OpenPayload::message,
                OpenPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public record ApplyPayload(BlockPos pos, CompoundTag changes) implements CustomPacketPayload {
        public static final Type<ApplyPayload> TYPE = new Type<>(ResourceLocation.fromNamespaceAndPath(RealPlugsMod.MODID, "config_apply"));
        public static final StreamCodec<net.minecraft.network.RegistryFriendlyByteBuf, ApplyPayload> CODEC = StreamCodec.composite(
                BlockPos.STREAM_CODEC, ApplyPayload::pos,
                ByteBufCodecs.COMPOUND_TAG, ApplyPayload::changes,
                ApplyPayload::new);

        @Override
        public Type<? extends CustomPacketPayload> type() {
            return TYPE;
        }
    }

    public static void register(RegisterPayloadHandlersEvent event) {
        var registrar = event.registrar("1");
        registrar.playToClient(OpenPayload.TYPE, OpenPayload.CODEC, ConfigPayloads::onOpen);
        registrar.playToServer(ApplyPayload.TYPE, ApplyPayload.CODEC, ConfigPayloads::onApply);
    }

    // client side: the real work is in ConfigClient so that this class never touches client-only classes
    private static void onOpen(OpenPayload p, IPayloadContext ctx) {
        ConfigClient.open(p.pos(), p.view(), p.message());
    }

    // server side
    private static void onApply(ApplyPayload p, IPayloadContext ctx) {
        if (!(ctx.player() instanceof ServerPlayer player)) return;
        BlockEntity be = player.level().getBlockEntity(p.pos());
        if (!(be instanceof PlugSocketBlockEntity socket)) return;
        if (player.distanceToSqr(p.pos().getX() + 0.5, p.pos().getY() + 0.5, p.pos().getZ() + 0.5) > 100) return;   // 10 blocks
        if (!ConfiguratorHolding.holds(player)) return;
        ConfigBridge.Backend backend = ConfigBridge.backend;
        if (backend == null) return;
        String msg = backend.apply(socket, p.changes());
        open(player, socket, msg);
    }

    /** Sends the form of a socket to a player (opens the screen, or refreshes it when it is open). */
    public static void open(ServerPlayer player, PlugSocketBlockEntity be, String message) {
        ConfigBridge.Backend backend = ConfigBridge.backend;
        if (backend == null) {
            player.displayClientMessage(net.minecraft.network.chat.Component.literal(
                    "The Network Configurator needs CC: Tweaked to be installed."), false);
            return;
        }
        PacketDistributor.sendToPlayer(player, new OpenPayload(be.getBlockPos(), backend.view(be), message == null ? "" : message));
    }
}
