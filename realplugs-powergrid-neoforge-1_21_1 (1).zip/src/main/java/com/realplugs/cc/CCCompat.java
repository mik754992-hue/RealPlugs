package com.realplugs.cc;

import com.realplugs.ModBlockEntities;
import dan200.computercraft.api.peripheral.PeripheralCapability;
import net.neoforged.neoforge.capabilities.RegisterCapabilitiesEvent;

/** Only ever touched when CC: Tweaked is loaded (see RealPlugsMod), so the CC classes it references always exist. */
public final class CCCompat {
    private CCCompat() {}

    public static void registerCapabilities(RegisterCapabilitiesEvent event) {
        event.registerBlockEntity(PeripheralCapability.get(), ModBlockEntities.SOCKET.get(),
                (be, side) -> new SocketPeripheral(be));
    }
}
