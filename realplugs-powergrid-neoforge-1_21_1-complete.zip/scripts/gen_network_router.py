#!/usr/bin/env python3
"""Generates the Network Router block (3 LAN ports + 1 WAN port) from the av_panel model.
Run from the repo root: python3 scripts/gen_network_router.py. Idempotent. Needs gen_network_switch.py next to it."""
import copy
import json
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from gen_network_switch import A, D, RES, ROOT, box, faces, lenses, shifted  # noqa: E402

ID = "network_router"
WHITE = [1, 1, 3, 3]
GRAPHITE = [9, 1, 11, 3]
GREEN = [1, 9, 3, 11]
AMBER = [9, 9, 11, 11]


def main():
    src = json.loads((A / "models/block/av_panel.json").read_text())
    els = src["elements"]
    out = []
    plate = copy.deepcopy(els[0])
    plate["faces"] = faces(WHITE)
    out.append(plate)
    out.extend(copy.deepcopy(e) for e in els[1:9])            # port frames
    out.extend(copy.deepcopy(e) for e in els[9:15])           # RJ45 jacks of slots 0 and 1
    out.extend(shifted(e, -4) for e in els[12:15])             # slot 2
    out.extend(shifted(e, -8) for e in els[12:15])             # slot 3 (WAN)
    out.extend(copy.deepcopy(e) for e in els[19:21])           # side terminals
    for xc in (14, 10, 6, 2):                                  # link + activity light per port (the last is the WAN)
        out.extend(lenses(xc))
    out.append(box([0.4, 2.4, 11.9], [3.6, 3.4, 12.0], AMBER))     # WAN marking under the last port
    out.append(box([4.4, 2.4, 11.9], [15.6, 3.2, 12.0], GRAPHITE)) # LAN label strip
    for x in (1.0, 14.2):                                      # two antennas
        out.append(box([x, 14.0, 13.0], [x + 0.8, 16.0, 13.8], GRAPHITE))
    model = {"parent": "minecraft:block/block", "textures": src["textures"], "elements": out}
    (A / f"models/block/{ID}.json").write_text(json.dumps(model, indent=1) + "\n")

    state = json.loads((A / "blockstates/av_panel.json").read_text())
    (A / f"blockstates/{ID}.json").write_text(
        json.dumps(state, indent=1).replace("realplugs:block/av_panel", f"realplugs:block/{ID}") + "\n")
    (A / f"models/item/{ID}.json").write_text(json.dumps({"parent": f"realplugs:block/{ID}"}, indent=1) + "\n")
    loot = (D / "loot_table/blocks/power_strip.json").read_text().replace("realplugs:power_strip", f"realplugs:{ID}")
    (D / f"loot_table/blocks/{ID}.json").write_text(loot)
    recipe = {"type": "minecraft:crafting_shapeless", "category": "redstone",
              "ingredients": [{"item": "realplugs:network_switch"}, {"item": "minecraft:redstone"}, {"item": "minecraft:gold_ingot"}],
              "result": {"id": f"realplugs:{ID}", "count": 1}}
    (D / f"recipe/{ID}.json").write_text(json.dumps(recipe, indent=1) + "\n")

    lang_path = A / "lang/en_us.json"
    lang = json.loads(lang_path.read_text())
    lang[f"block.realplugs.{ID}"] = "Network Router"
    lang_path.write_text(json.dumps(lang, indent=1, ensure_ascii=False) + "\n")

    tag_path = RES / "data/minecraft/tags/block/mineable/pickaxe.json"
    tag = json.loads(tag_path.read_text())
    if f"realplugs:{ID}" not in tag["values"]:
        tag["values"].append(f"realplugs:{ID}")
    tag_path.write_text(json.dumps(tag, indent=1) + "\n")

    defs = ROOT / "src/main/java/com/realplugs/SocketDefs.java"
    s = defs.read_text()
    if f'"{ID}"' not in s:
        line = ('        new SocketDef("%s", 0, 16, 2, 14, 4, new PlugTypes.Standard[]{PlugTypes.Standard.RJ45, PlugTypes.Standard.RJ45, '
                'PlugTypes.Standard.RJ45, PlugTypes.Standard.RJ45})\n' % ID)
        s = re.sub(r'(new SocketDef\("network_switch"[^\n]*\))\n', lambda m: m.group(1) + ",\n" + line, s, count=1)
        defs.write_text(s)
    print("ok")


if __name__ == "__main__":
    main()
