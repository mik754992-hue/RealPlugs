package com.realplugs.cc;

import com.realplugs.PlugItem;
import com.realplugs.PlugTypes;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.api.pocket.IPocketAccess;
import net.minecraft.world.item.ItemStack;

import java.util.LinkedHashMap;
import java.util.Map;

/** What a pocket computer sees on its "back": the port's connector and whatever is plugged into it. */
public class PortPeripheral implements IPeripheral {
    private final IPocketAccess access;
    private final PortPocketUpgrade upgrade;

    public PortPeripheral(IPocketAccess access, PortPocketUpgrade upgrade) {
        this.access = access;
        this.upgrade = upgrade;
    }

    @Override
    public String getType() {
        return "realplugs_port";
    }

    @Override
    public boolean equals(IPeripheral other) {
        return other instanceof PortPeripheral p && p.access == access;
    }

    @Override
    public int hashCode() {
        return System.identityHashCode(access);
    }

    /** Connector standard of this port, e.g. "usb_c". */
    @LuaFunction(mainThread = true)
    public final String getStandard() {
        return upgrade.standard().key;
    }

    @LuaFunction(mainThread = true)
    public final boolean isPlugged() {
        return !upgrade.readPlug(access).isEmpty();
    }

    /** {name, standard} of the plugged-in plug, or nil when the port is empty. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getPlug() {
        ItemStack s = upgrade.readPlug(access);
        if (s.isEmpty() || !(s.getItem() instanceof PlugItem)) return null;
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", PlugTypes.PLUGS[PlugItem.typeOf(s)].name());
        PlugTypes.Standard std = PlugItem.plugStandard(s);
        m.put("standard", std == null ? "unknown" : std.key);
        return m;
    }
}
