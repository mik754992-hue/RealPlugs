# libs/

`powergrid-mc1_21_1-0_6_2.jar` is **Create: Power Grid 0.6.2** by patryk3211, Da-Negy, rvndm and casvara,
licensed under **Apache-2.0** (https://github.com/patryk3211/PowerGrid). It is only used as a `compileOnly`
dependency so the build is reproducible; it is **not** bundled into the Real Plugs jar.

To update it, replace the jar and change the file name in `build.gradle` and the version range in `gradle.properties`.
