# Real Plugs test lab (datapack)

Copy this folder into `<world>/datapacks/` (or zip it), run `/reload`, stand on flat ground and run:

    /function realplugs_lab:build

You get a platform with a router, a switch, a Wi-Fi access point and two CC: Tweaked computers, plus Cat5, Cat6 and fibre
cables and a Wi-Fi analyzer. `/function realplugs_lab:clear` removes it again.

A datapack cannot place cords (they are entities), so the cabling is yours to do. That is the point of a lab: plug the
router's uplink side to the internet, a LAN port to the switch, the switch to the computers and try the three cable types.

Then:

1. On the server computer, put the programs from the mod's `lua/` folder on it (or use `rpinstall`), run `rplab` once, then
   `rpweb serve 1 lab`. A home page, a guest book with logins and a mail server (`rpmail serve 1 lab`) are ready.
2. On the client computer run `rpweb browse lab`.
3. Plug the access point to the switch, run `rpadmin` on a computer to change names, DHCP, firewall and QoS.
