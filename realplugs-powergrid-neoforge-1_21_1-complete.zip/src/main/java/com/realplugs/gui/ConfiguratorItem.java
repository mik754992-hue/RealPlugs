package com.realplugs.gui;

import com.realplugs.PlugSocketBlockEntity;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;

/** Right-click a router, switch, access point or any network socket: opens its settings screen. */
public class ConfiguratorItem extends Item {
    public ConfiguratorItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockEntity be = level.getBlockEntity(ctx.getClickedPos());
        if (!(be instanceof PlugSocketBlockEntity socket)) return InteractionResult.PASS;
        if (!level.isClientSide && ctx.getPlayer() instanceof ServerPlayer player) {
            ConfigPayloads.open(player, socket, "");
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
