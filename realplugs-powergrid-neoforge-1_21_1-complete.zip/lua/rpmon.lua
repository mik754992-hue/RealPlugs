-- rpmon: network monitor.
--   rpmon [monitor]            live traffic of every port (packets/s and a bar), refreshed every second
--   rpmon blocked [clear]      the firewall log: the last packets the firewall stopped, who sent them and which rule did it
--   rpmon sniff <slot> [file]  switch a port to sniffing and print every packet of its segment (optionally into a file)
-- With a monitor name (or "right", "top", ...) the table is drawn on that monitor.

local M = {}

-- one firewall log entry as a line: "drop in tcp 10.0.0.5 -> 10.0.0.9:80 (rule 2)"
function M.fmtBlocked(e)
  local port = (e.port or 0) > 0 and (":" .. e.port) or ""
  local rule = (e.rule or 0) > 0 and ("rule " .. e.rule) or "default policy"
  return string.format("%s %s %s %s -> %s%s (%s)", e.action, e.direction, e.protocol, e.src, e.dst, port, rule)
end

function M.fmtBytes(n)
  n = n or 0
  if n >= 1048576 then return string.format("%.1fM", n / 1048576) end
  if n >= 1024 then return string.format("%.1fk", n / 1024) end
  return tostring(math.floor(n)) .. "B"
end

function M.bar(value, max, width)
  if max <= 0 then max = 1 end
  local n = math.min(width, math.floor(width * value / max + 0.5))
  return string.rep("#", n) .. string.rep(".", width - n)
end

-- one line for a sniffed packet: realplugs_sniff args (srcIp, dstIp, protocol, srcPort, dstPort, payload)
function M.fmtSniff(srcIp, dstIp, protocol, srcPort, dstPort, payload)
  local ports = (protocol == "udp" or protocol == "tcp") and (":" .. tostring(srcPort) .. ">" .. tostring(dstPort)) or ""
  local text = tostring(payload or ""):gsub("[%c]", "."):sub(1, 40)
  return string.format("%-15s > %-15s %-6s%s %s", srcIp, dstIp, protocol, ports, text)
end

-- per-second rates from two stat tables
function M.rates(prev, now, seconds)
  seconds = seconds > 0 and seconds or 1
  return { rx = ((now.rxPackets or 0) - (prev.rxPackets or 0)) / seconds, tx = ((now.txPackets or 0) - (prev.txPackets or 0)) / seconds }
end

if RPWEB_TEST then return M end

local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if not (running == "rpmon" or running == "rpmon.lua") then return M end

local args = { ... }
local nic = peripheral.find("realplugs_socket")
if not nic then error("no Real Plugs socket next to this computer", 0) end
local side = peripheral.getName(nic)

if args[1] == "blocked" then
  local slot = tonumber(args[2]) or 1
  if args[2] == "clear" then nic.clearFirewallLog(); print("log cleared"); return end
  local log = nic.getFirewallLog()
  if #log == 0 then print("the firewall has stopped nothing (or has no rules)") end
  for _, e in ipairs(log) do print(M.fmtBlocked(e)) end
  print(#log .. " entries, " .. nic.getFirewallBlocked() .. " packets stopped in total")
  return
end

if args[1] == "sniff" then
  local slot = tonumber(args[2]) or 1
  local file = args[3] and fs.open(args[3], "a")
  nic.setSniffer(slot, true)
  print("sniffing slot " .. slot .. " (Ctrl+T stops)")
  local ok, err = pcall(function()
    while true do
      local ev = { os.pullEvent("realplugs_sniff") }
      if ev[2] == side and ev[3] == slot then
        local line = M.fmtSniff(ev[4], ev[5], ev[6], ev[7], ev[8], ev[9])
        print(line)
        if file then file.writeLine(line); file.flush() end
      end
    end
  end)
  nic.setSniffer(slot, false)
  if file then file.close() end
  return
end

local out = term
if args[1] then
  local mon = peripheral.wrap(args[1])
  if not mon then error("no monitor called " .. args[1], 0) end
  mon.setTextScale(0.5)
  out = mon
end
local prev, last = {}, os.clock()
while true do
  local now = os.clock()
  local w, h = out.getSize()
  out.setBackgroundColor(colors.black); out.clear(); out.setCursorPos(1, 1)
  out.setTextColor(colors.yellow); out.write("port  address         rx/s  tx/s  total")
  local ifs = nic.getInterfaces() or {}
  local rates, peak = {}, 1
  for i = 1, #ifs do
    local st = nic.getStats(i)
    rates[i] = M.rates(prev[i] or st, st, now - last)
    prev[i] = st
    peak = math.max(peak, rates[i].rx, rates[i].tx)
  end
  for i, f in ipairs(ifs) do
    local st = prev[i]
    out.setCursorPos(1, 1 + i * 2); out.setTextColor(colors.white)
    out.write(string.format("%-5d %-15s %-5.1f %-5.1f %s", i, f.ip or "-", rates[i].rx, rates[i].tx, M.fmtBytes((st.rxBytes or 0) + (st.txBytes or 0))))
    out.setCursorPos(1, 2 + i * 2)
    out.setTextColor(colors.lime); out.write("rx " .. M.bar(rates[i].rx, peak, math.max(4, math.min(24, w - 14))))
    out.setTextColor(colors.orange); out.write(" tx " .. M.bar(rates[i].tx, peak, math.max(4, math.min(24, w - 14))))
  end
  out.setCursorPos(1, math.min(h, 3 + #ifs * 2)); out.setTextColor(colors.lightGray)
  out.write("firewall stopped: " .. tostring(nic.getFirewallBlocked()))
  last = now
  sleep(1)
end
