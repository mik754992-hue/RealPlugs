package com.realplugs;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;

/** Same placement as PlugEntityRenderer, so the port models line up with the plug models. */
public class PortEntityRenderer extends EntityRenderer<PortEntity> {
    public PortEntityRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
    }

    @Override
    public void render(PortEntity e, float yaw, float partial, PoseStack ps, MultiBufferSource buf, int light) {
        ItemStack stack = e.getRenderStack();
        if (stack.isEmpty()) return;

        Direction f = e.getFace();
        ps.pushPose();
        if (f.getAxis().isHorizontal()) {
            ps.mulPose(Axis.YP.rotationDegrees(-f.toYRot()));
        } else {
            ps.mulPose(Axis.XP.rotationDegrees(f == Direction.UP ? -90f : 90f));
        }
        ps.scale(0.35f, 0.35f, 0.35f);
        Minecraft.getInstance().getItemRenderer().renderStatic(stack, ItemDisplayContext.FIXED, light, 0, ps, buf,
                e.level(), e.getId());
        ps.popPose();
    }

    @Override
    public ResourceLocation getTextureLocation(PortEntity e) {
        return ResourceLocation.withDefaultNamespace("textures/misc/white.png");
    }
}
