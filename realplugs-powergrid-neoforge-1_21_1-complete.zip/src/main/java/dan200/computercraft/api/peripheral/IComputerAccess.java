package dan200.computercraft.api.peripheral;

/** COMPILE-TIME STUB of CC: Tweaked's IComputerAccess. Excluded from the released jar. */
public interface IComputerAccess {
    String getAttachmentName();

    void queueEvent(String event, Object... arguments);
}
