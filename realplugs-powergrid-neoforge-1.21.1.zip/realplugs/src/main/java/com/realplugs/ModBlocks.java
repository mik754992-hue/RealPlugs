package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(BuiltInRegistries.BLOCK, RealPlugsMod.MODID);

    private static BlockBehaviour.Properties props() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.COLOR_LIGHT_GRAY)
                .strength(0.5f)
                .sound(SoundType.METAL)
                .noOcclusion();
    }

    // slots, xMin, xMax, yMin, yMax, depth   (1/16 block units, authored facing NORTH, back at the south edge)
    public static final DeferredHolder<Block, PlugSocketBlock> OUTLET =
            BLOCKS.register("outlet", () -> new PlugSocketBlock(props(), 2, 2, 14, 1, 15, 3));

    public static final DeferredHolder<Block, PlugSocketBlock> POWER_STRIP =
            BLOCKS.register("power_strip", () -> new PlugSocketBlock(props(), 4, 0, 16, 2, 14, 4));
}
