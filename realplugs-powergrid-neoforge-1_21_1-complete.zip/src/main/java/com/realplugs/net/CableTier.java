package com.realplugs.net;

/**
 * The network cable types. A cord of a tier adds a delay to every hop it carries and caps how many packets per second
 * can leave through each of its ends (packets over the cap wait in a queue; a queue that is too long drops them).
 * The plain Ethernet cord from older versions has no tier: no delay, no cap.
 * The maximum length of each cable is in data/realplugs/powergrid/wire_types/<id>_cable.json.
 */
public enum CableTier {
    CAT5("cat5", "Cat5", 2, 40, "100 Mbit/s"),
    CAT6("cat6", "Cat6", 1, 200, "1 Gbit/s"),
    FIBRE("fibre", "Fibre", 0, 0, "10 Gbit/s");

    public final String id;
    public final String label;
    /** Ticks added to every hop over this cable (one tick = 50 ms one way). */
    public final int delayTicks;
    /** Packets per second that can leave through one end; 0 = no cap. */
    public final int packetsPerSecond;
    /** For display only. */
    public final String speed;

    CableTier(String id, String label, int delayTicks, int packetsPerSecond, String speed) {
        this.id = id;
        this.label = label;
        this.delayTicks = delayTicks;
        this.packetsPerSecond = packetsPerSecond;
        this.speed = speed;
    }

    public static CableTier byId(String id) {
        for (CableTier t : values()) if (t.id.equals(id)) return t;
        return null;
    }
}
