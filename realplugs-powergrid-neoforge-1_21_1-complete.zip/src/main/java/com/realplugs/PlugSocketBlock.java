package com.realplugs;

import com.simibubi.create.foundation.block.IBE;
import com.mojang.math.Axis;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.Containers;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.ItemInteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;
import org.patryk3211.powergrid.electricity.base.DirectionalElectricBlock;
import org.patryk3211.powergrid.electricity.base.IDecoratedTerminal;
import org.patryk3211.powergrid.electricity.base.ITerminalPlacement;
import org.patryk3211.powergrid.electricity.base.TerminalBoundingBox;
import org.patryk3211.powergrid.electricity.wire.powercord.AutoCordEndpoint;
import org.patryk3211.powergrid.electricity.wire.powercord.IAcceptCord;

import java.util.ArrayList;
import java.util.List;

/**
 * A wall plate with N plug slots, wired into Create: Power Grid. Every slot has its own connector standard
 * (see SocketDef) and only accepts plugs/adapters whose plug side matches it.
 * Authored facing NORTH (front faces north, back is at the south edge); FACING is the front direction.
 * Terminals (1/16 block units, north frame): a small hot connector on the left side and a neutral one on the
 * right side of the plate, and one tap stud per slot. See PlugSocketBlockEntity for the circuit.
 *
 * Implementing IAcceptCord lets Power Grid's cords plug into the plate. Instead of one big cord box over the whole
 * plate, every slot gets its own box (cordTerminal) and its own cord end (getEndpoint): slot i's tap terminal
 * (2 + i) plus the neutral bus. Clicking a single terminal still wires one conductor.
 */
public class PlugSocketBlock extends DirectionalElectricBlock implements IBE<PlugSocketBlockEntity>, IAcceptCord {
    private static final double STUD = 1.5;   // how far studs/bars stick out of the plate front

    public final SocketDef def;
    public final int slots;
    private final int xMin, xMax, yMin, yMax, depth;

    public PlugSocketBlock(Properties props, SocketDef def) {
        super(props);
        this.def = def;
        this.slots = def.slots().length;
        this.xMin = def.xMin();
        this.xMax = def.xMax();
        this.yMin = def.yMin();
        this.yMax = def.yMax();
        this.depth = def.depth();

        double zf = 16 - depth;     // front face of the plate
        double zs = zf - STUD;      // front of the studs
        double sw = (xMax - xMin) / (double) slots;

        List<TerminalBoundingBox> terminals = new ArrayList<>();
        VoxelShape shape = Block.box(xMin, yMin, zf, xMax, yMax, 16);

        // 0: hot bus, 1: neutral bus. Small connectors on the two SIDES of the plate (hot on the viewer's left,
        // neutral on the right) instead of big bars across the front.
        double ym = (yMin + yMax) / 2.0;
        double padR = Math.max(Math.min(1.5, 16 - xMax), 0.0);
        double padL = Math.max(Math.min(1.5, xMin), 0.0);
        double z0 = zf + 0.2;
        double z1 = 16 - 0.2;
        terminals.add(new TerminalBoundingBox(IDecoratedTerminal.CONNECTOR,
                xMax - 1.5, ym - 1.5, z0, xMax + padR, ym + 1.5, z1).withColor(IDecoratedTerminal.RED));
        terminals.add(new TerminalBoundingBox(IDecoratedTerminal.CONNECTOR,
                xMin - padL, ym - 1.5, z0, xMin + 1.5, ym + 1.5, z1).withColor(IDecoratedTerminal.BLUE));
        shape = Shapes.or(shape,
                Block.box(xMax - 1.5, ym - 1.5, z0, xMax + padR, ym + 1.5, z1),
                Block.box(xMin - padL, ym - 1.5, z0, xMin + 1.5, ym + 1.5, z1));

        // 2 + i: tap stud of slot i (slot 0 is on the viewer's left = +x in the north frame)
        for (int i = 0; i < slots; i++) {
            double cx = xMax - (i + 0.5) * sw;
            terminals.add(new TerminalBoundingBox(IDecoratedTerminal.OUTPUT,
                    cx - 1.25, yMin + 2.5, zs, cx + 1.25, yMin + 4, zf).withColor(IDecoratedTerminal.RED));
            shape = Shapes.or(shape, Block.box(cx - 1.25, yMin + 2.5, zs, cx + 1.25, yMin + 4, zf));
        }

        // Power Grid's 3-argument overload reuses the north-authored shape for UP, so floor and ceiling blocks got
        // the wrong hitbox. Give it the properly rotated shape for UP (it derives DOWN from that).
        setTerminalCollection(directionalNorthTerminals(this, terminals.toArray(new TerminalBoundingBox[0]), shape,
                northToUp(shape)));
    }

    /** Rotates a north-facing shape to face up: the front (north) goes to the top, the plate's up goes south. */
    private static VoxelShape northToUp(VoxelShape s) {
        VoxelShape out = Shapes.empty();
        for (AABB b : s.toAabbs()) {
            out = Shapes.or(out, Shapes.create(b.minX, 1 - b.maxZ, b.minY, b.maxX, 1 - b.minZ, b.maxY));
        }
        return out;
    }

    // ---- geometry helpers for the renderer (north frame, block-centered, in blocks) ----
    public double slotCenterX(int i) {
        double sw = (xMax - xMin) / (double) slots;
        return (xMax - (i + 0.5) * sw) / 16.0 - 0.5;
    }
    public double plugCenterY() { return (((yMin + 4.5) + (yMax - 2.5)) / 2.0) / 16.0 - 0.5; }
    public double frontLocalZ() { return (16.0 - depth) / 16.0 - 0.5; }
    public float plugScale() {
        double sw = (xMax - xMin) / (double) slots;
        double regionH = (yMax - 2.5) - (yMin + 4.5);
        return (float) Math.min(0.4, Math.min(sw / 16.0 * 1.1, regionH / 16.0));
    }

    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        // the back of the plate sits against the face you clicked
        return defaultBlockState().setValue(FACING, ctx.getClickedFace());
    }

    @Override
    public Class<PlugSocketBlockEntity> getBlockEntityClass() {
        return PlugSocketBlockEntity.class;
    }

    @Override
    public BlockEntityType<? extends PlugSocketBlockEntity> getBlockEntityType() {
        return ModBlockEntities.SOCKET.get();
    }

    /** Which slot (counted from the viewer's left) did the player click? */
    private int slotAt(BlockState state, BlockPos pos, Vec3 hit) {
        Direction f = state.getValue(FACING);
        Direction right = f.getAxis().isHorizontal() ? f.getCounterClockWise() : Direction.WEST;
        Vec3 rel = hit.subtract(pos.getX(), pos.getY(), pos.getZ());
        double c = right.getAxis() == Direction.Axis.X ? rel.x : rel.z;
        double u = right.getAxisDirection() == Direction.AxisDirection.POSITIVE ? c : 1.0 - c;
        double t = (u * 16.0 - xMin) / (xMax - xMin);
        return Mth.clamp((int) Math.floor(t * slots), 0, slots - 1);
    }

    /** This block with the given front direction. */
    public BlockState withFront(Direction f) {
        return defaultBlockState().setValue(FACING, f);
    }

    /** Slot under a world-space hit position (0-based, from the viewer's left). Used by the cord handler. */
    public int slotAtHit(BlockState state, BlockPos pos, Vec3 hit) {
        return slotAt(state, pos, hit);
    }

    // ---- cords: one box and one cord end per slot ----

    /** The hover/placement box for a cord: this slot's column of the plate, not the whole block. */
    @Override
    public ITerminalPlacement cordTerminal(BlockState state, Level level, BlockHitResult hit) {
        BlockPos pos = hit.getBlockPos();
        ITerminalPlacement stud = terminal(state, 2 + slotAt(state, pos, hit.getLocation()));
        if (!(stud instanceof TerminalBoundingBox tb)) return IAcceptCord.super.cordTerminal(state, level, hit);

        AABB s = tb.getOutline();
        VoxelShape plateShape = state.getShape(level, pos);
        AABB plate = plateShape.isEmpty() ? new AABB(0, 0, 0, 1, 1, 1) : plateShape.bounds();
        Direction f = state.getValue(FACING);
        // the axis the slots are spread along, whatever way the plate faces
        Direction.Axis along = f.getAxis().isHorizontal() ? f.getCounterClockWise().getAxis() : Direction.Axis.X;
        double halfWidth = (xMax - xMin) / (double) slots / 16.0 / 2.0;

        double[] lo = new double[3];
        double[] hi = new double[3];
        for (Direction.Axis ax : Direction.Axis.values()) {
            int i = ax.ordinal();
            if (ax == along) {
                double c = (ax.choose(s.minX, s.minY, s.minZ) + ax.choose(s.maxX, s.maxY, s.maxZ)) / 2.0;
                lo[i] = c - halfWidth;
                hi[i] = c + halfWidth;
            } else {
                lo[i] = ax.choose(plate.minX, plate.minY, plate.minZ);
                hi[i] = ax.choose(plate.maxX, plate.maxY, plate.maxZ);
            }
        }
        return new TerminalBoundingBox(IDecoratedTerminal.CORD, new AABB(lo[0], lo[1], lo[2], hi[0], hi[1], hi[2]));
    }

    /** A cord end plugged into the clicked slot: that slot's tap and the neutral bus, at the slot's exact spot. */
    @Override
    public AutoCordEndpoint getEndpoint(UseOnContext ctx) {
        BlockPos pos = ctx.getClickedPos();
        BlockState state = ctx.getLevel().getBlockState(pos);
        int slot = slotAt(state, pos, ctx.getClickLocation());
        return new AutoCordEndpoint(pos, 2 + slot, 1, slotWorldPos(state, pos, slot), state.getValue(FACING));
    }

    /** We draw the plug ourselves (see PlugSocketRenderer), so Power Grid must not draw its own on our slots. */
    @Override
    public boolean renderPlug() {
        return false;
    }

    /** World position of the front of a slot, using the same rotation the renderer applies. */
    public Vec3 slotWorldPos(BlockState state, BlockPos pos, int slot) {
        Direction f = state.getValue(FACING);
        org.joml.Quaternionf q = f.getAxis().isHorizontal()
                ? Axis.YP.rotationDegrees(-(f.toYRot() + 180f))
                : Axis.XP.rotationDegrees(f == Direction.UP ? 90f : -90f);
        Vector3f v = new Vector3f((float) slotCenterX(slot), (float) plugCenterY(), (float) frontLocalZ());
        q.transform(v);
        return new Vec3(pos.getX() + 0.5 + v.x, pos.getY() + 0.5 + v.y, pos.getZ() + 0.5 + v.z);
    }

    private static ItemInteractionResult noFit(Level level, Player player, PlugTypes.Standard needs) {
        if (!level.isClientSide) {
            player.displayClientMessage(Component.translatable("message.realplugs.no_fit",
                    Component.translatable(needs.langKey())), true);
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Holding a plug/adapter: it has to match the slot's standard (or the adapter that is already there). */
    @Override
    protected ItemInteractionResult useItemOn(ItemStack held, BlockState state, Level level, BlockPos pos,
                                              Player player, InteractionHand hand, BlockHitResult hit) {
        // a pocket computer with a port: ask it to tether to this slot (the port upgrade does the linking next tick)
        if (!(this instanceof PortAnchorBlock) && PocketTether.isPocketComputer(held) && PocketTether.hasPortUpgrade(held)) {
            if (!level.isClientSide) {
                PocketTether.request(player.getUUID(),
                        new PocketTether.Request(level.dimension(), pos, slotAt(state, pos, hit.getLocation()), level.getGameTime()));
            }
            return ItemInteractionResult.sidedSuccess(level.isClientSide);
        }

        if (!(held.getItem() instanceof PlugItem)
                || !(level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be)) {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }

        int slot = slotAt(state, pos, hit.getLocation());
        PlugTypes.Standard needs = def.slots()[slot];
        ItemStack target = be.plugs().get(slot);

        if (target.isEmpty()) {
            if (be.hasCord(slot)) {
                if (!level.isClientSide) player.displayClientMessage(Component.translatable("message.realplugs.cord_slot_taken"), true);
                return ItemInteractionResult.sidedSuccess(level.isClientSide);
            }
            if (PlugItem.plugStandard(held) != needs) return noFit(level, player, needs);
            if (!level.isClientSide) be.setPlug(slot, PlugItem.takeOne(held, player));
        } else if (target.getItem() instanceof PlugItem ti && ti.adapter) {
            if (!PlugItem.canInsert(target, held)) {
                return noFit(level, player, PlugTypes.adapter(PlugItem.typeOf(target)).accepts());
            }
            if (!level.isClientSide) {
                PlugItem.addInner(target, PlugItem.takeOne(held, player));
                be.plugsChanged();
            }
        } else {
            return ItemInteractionResult.PASS_TO_DEFAULT_BLOCK_INTERACTION;
        }
        return ItemInteractionResult.sidedSuccess(level.isClientSide);
    }

    /** Empty hand: pull the last plug out of the adapter first, then the plug/adapter itself. Everything else is Power Grid's. */
    @Override
    protected InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
        if (player.getMainHandItem().isEmpty() && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
            int slot = slotAt(state, pos, hit.getLocation());
            ItemStack target = be.plugs().get(slot);
            if (!target.isEmpty()) {
                if (!level.isClientSide) {
                    ItemStack in = PlugItem.popInner(target);
                    if (!in.isEmpty()) {
                        be.plugsChanged();
                        PlugItem.give(player, in);
                    } else {
                        ItemStack out = target.copy();
                        be.setPlug(slot, ItemStack.EMPTY);
                        PlugItem.give(player, out);
                    }
                }
                return InteractionResult.sidedSuccess(level.isClientSide);
            }
        }
        return super.useWithoutItem(state, level, pos, player, hit);
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moving) {
        if (!state.is(newState.getBlock()) && level.getBlockEntity(pos) instanceof PlugSocketBlockEntity be) {
            for (ItemStack s : be.plugs()) {
                if (!s.isEmpty()) Containers.dropItemStack(level, pos.getX(), pos.getY(), pos.getZ(), s);
            }
        }
        super.onRemove(state, level, pos, newState, moving);
    }
}
