-- rpadmin: manage a Real Plugs router (or any socket) from a web page.
--   rpadmin <password> [slot] [name]
-- Run it on a computer next to the router. Then open  http://<name or address>/  with rpweb browse from any
-- computer on the LAN and type the password. Everything the router's Lua API can do for DHCP, DNS, port forwards, the
-- firewall, tunnels and Wi-Fi is on that page.  Needs rpweb.lua on this computer.

local web = require("rpweb")
local M = {}
local e = web.escape

local function row(...)
  local out = { "<tr>" }
  for _, c in ipairs({ ... }) do out[#out + 1] = "<td>" .. tostring(c) .. " </td>" end
  out[#out + 1] = "</tr>"
  return table.concat(out)
end

local function link(key, label, extra)
  return '<a href="/?key=' .. web.urlencode(key) .. (extra or "") .. '">' .. label .. "</a>"
end

local function field(name, size, value)
  return '<input name="' .. name .. '" size="' .. (size or 10) .. '" value="' .. e(value or "") .. '"> '
end

-- the form of one action: hidden key + act, fields, button
local function form(key, act, fields, button)
  return '<form action="/" method="get"><input type="hidden" name="key" value="' .. e(key) .. '">' ..
         '<input type="hidden" name="act" value="' .. act .. '">' .. fields .. '<input type="submit" value="' .. button .. '"></form>'
end

-- nic: the socket peripheral. Returns a route(req) function for rpweb.
function M.makeRoute(nic, password, lanSlot)
  lanSlot = lanSlot or 1
  local function perform(q)
    local act = q.act
    local function ok(r, why) if r == false or r == nil then return "Failed: " .. tostring(why) end return "Done." end
    if act == "dns_add" then return ok(nic.addDnsRecord(q.name or "", q.ip or ""))
    elseif act == "dns_del" then nic.removeDnsRecord(q.name or ""); return "Removed."
    elseif act == "resv_add" then return ok(nic.reserveAddress(lanSlot, q.mac or "", q.ip or ""))
    elseif act == "resv_del" then nic.removeReservation(q.mac or ""); return "Removed."
    elseif act == "leases_clear" then nic.clearDhcpLeases(); return "Leases cleared."
    elseif act == "range" then return ok(nic.setDhcpRange(lanSlot, q.first or "", q.last or ""))
    elseif act == "pf_add" then return ok(nic.addPortForward(tonumber(q.pub) or 0, q.ip or "", tonumber(q.port) or 0))
    elseif act == "pf_del" then nic.removePortForward(tonumber(q.pub) or 0); return "Removed."
    elseif act == "fw_add" then return ok(nic.addFirewallRule(q.action or "", q.dir or "any", q.proto or "any", q.src or "any", q.dst or "any", tonumber(q.port) or 0))
    elseif act == "fw_del" then return ok(nic.removeFirewallRule(tonumber(q.n) or 0))
    elseif act == "fw_policy" then return ok(nic.setFirewallPolicy(q.policy or ""))
    elseif act == "tun_add" then return ok(nic.addTunnel(q.name or "", q.peer or "", q.net or "", q.tkey or ""))
    elseif act == "tun_del" then nic.removeTunnel(q.name or ""); return "Removed."
    elseif act == "ap_set" then
      if (q.pass or "") == "" then return ok(nic.setAccessPoint(q.ssid or "")) end
      return ok(nic.setAccessPoint(q.ssid or "", q.pass))
    elseif act == "guest_set" then
      if (q.ssid or "") == "" then nic.clearGuestNetwork(); return "Guest network off." end
      if (q.pass or "") == "" then return ok(nic.setGuestNetwork(q.ssid)) end
      return ok(nic.setGuestNetwork(q.ssid, q.pass))
    elseif act == "dhcp" then return ok(nic.setDhcp(lanSlot, q.on == "on"))
    end
    return nil
  end

  local function page(key, msg)
    local o = { "<html><head><title>Router admin</title></head><body><h1>Router admin</h1>" }
    if msg and msg ~= "" then o[#o + 1] = '<p><font color="yellow">' .. e(msg) .. "</font></p>" end
    o[#o + 1] = "<p>" .. link(key, "Refresh") .. "</p>"

    o[#o + 1] = "<h2>Ports</h2><table>" .. row("port", "address", "network", "link", "rx pkts", "tx pkts")
    local ifs = nic.getInterfaces() or {}
    for i, f in ipairs(ifs) do
      local st = nic.getStats(i) or {}
      o[#o + 1] = row(i, e(f.ip or ""), e(tostring(f.prefix or "")), f.linkUp and "up" or "-", st.rxPackets or 0, st.txPackets or 0)
    end
    o[#o + 1] = "</table>"

    local d = nic.getDhcp(lanSlot) or {}
    o[#o + 1] = "<h2>DHCP (port " .. lanSlot .. ")</h2><p>" .. (d.enabled and "on" or "off") ..
      (d.first and (", range " .. e(d.first) .. " - " .. e(d.last)) or "") .. "</p>"
    o[#o + 1] = form(key, "dhcp", '<input type="checkbox" name="on" value="on"' .. (d.enabled and " checked" or "") .. "> enabled ", "Set")
    o[#o + 1] = form(key, "range", "First " .. field("first", 14, d.first) .. "Last " .. field("last", 14, d.last), "Set range")
    o[#o + 1] = "<h3>Leases and reservations</h3><table>" .. row("mac", "address", "kind", "")
    for _, l in ipairs(nic.getDhcpLeases() or {}) do
      o[#o + 1] = row(e(l.mac), e(l.ip), l.reserved and "reserved" or "lease",
        l.reserved and link(key, "remove", "&act=resv_del&mac=" .. web.urlencode(l.mac)) or "")
    end
    o[#o + 1] = "</table>" .. form(key, "resv_add", "MAC " .. field("mac", 18) .. "Address " .. field("ip", 14), "Reserve") ..
      "<p>" .. link(key, "Forget all leases", "&act=leases_clear") .. "</p>"

    o[#o + 1] = "<h2>DNS records</h2><table>"
    for _, r in ipairs(nic.getDnsRecords() or {}) do
      o[#o + 1] = row(e(r.name), e(r.ip), link(key, "remove", "&act=dns_del&name=" .. web.urlencode(r.name)))
    end
    o[#o + 1] = "</table>" .. form(key, "dns_add", "Name " .. field("name", 14) .. "Address " .. field("ip", 14), "Add")

    o[#o + 1] = "<h2>Port forwards</h2><table>"
    for _, f in ipairs(nic.getPortForwards() or {}) do
      o[#o + 1] = row(f.publicPort or f.port or "?", e(f.ip or ""), f.port or "", link(key, "remove", "&act=pf_del&pub=" .. tostring(f.publicPort or "")))
    end
    o[#o + 1] = "</table>" .. form(key, "pf_add", "Public port " .. field("pub", 6) .. "To " .. field("ip", 14) .. "port " .. field("port", 6), "Forward")

    o[#o + 1] = "<h2>Firewall</h2><p>Policy: <b>" .. e(nic.getFirewallPolicy() or "?") .. "</b>, stopped " ..
      tostring(nic.getFirewallBlocked() or 0) .. " packets</p>"
    o[#o + 1] = "<p>" .. link(key, "allow", "&act=fw_policy&policy=allow") .. " | " .. link(key, "reject", "&act=fw_policy&policy=reject") ..
      " | " .. link(key, "drop", "&act=fw_policy&policy=drop") .. "</p><table>" .. row("#", "action", "dir", "proto", "from", "to", "port", "")
    for _, r in ipairs(nic.getFirewallRules() or {}) do
      o[#o + 1] = row(r.position, r.action, r.direction, r.protocol, e(r.src), e(r.dst), r.port, link(key, "remove", "&act=fw_del&n=" .. r.position))
    end
    o[#o + 1] = "</table>" .. form(key, "fw_add", "Action " .. field("action", 6, "reject") .. "Dir " .. field("dir", 4, "in") ..
      "Proto " .. field("proto", 4, "tcp") .. "From " .. field("src", 12, "any") .. "To " .. field("dst", 12, "any") .. "Port " .. field("port", 5, "0"), "Add rule")

    o[#o + 1] = "<h2>VPN tunnels</h2><table>"
    for _, t in ipairs(nic.getTunnels() or {}) do
      o[#o + 1] = row(e(t.name), e(t.peer), e(t.network), link(key, "remove", "&act=tun_del&name=" .. web.urlencode(t.name)))
    end
    o[#o + 1] = "</table>" .. form(key, "tun_add", "Name " .. field("name", 8) .. "Other router " .. field("peer", 14) ..
      "Its network " .. field("net", 16, "192.168.2.0/24") .. "Key " .. field("tkey", 10), "Add tunnel")

    if nic.isAccessPoint() then
      local ap = nic.getAccessPoint() or {}
      o[#o + 1] = "<h2>Wi-Fi</h2><p>Network <b>" .. e(ap.ssid or "") .. "</b>" .. (ap.secured and " (password)" or " (open)") ..
        ", range " .. tostring(ap.range) .. ", " .. tostring(ap.clients) .. " clients" ..
        (ap.guestSsid and (", guest network <b>" .. e(ap.guestSsid) .. "</b>") or "") .. "</p>"
      o[#o + 1] = form(key, "ap_set", "Name " .. field("ssid", 14, ap.ssid) .. "Password " .. field("pass", 14), "Set network")
      o[#o + 1] = form(key, "guest_set", "Guest name " .. field("ssid", 14, ap.guestSsid) .. "Password " .. field("pass", 14), "Set guest network")
      o[#o + 1] = "<table>" .. row("mac", "address", "signal")
      for _, c in ipairs(nic.getWifiClients() or {}) do o[#o + 1] = row(e(c.mac), e(c.ip), c.signal) end
      o[#o + 1] = "</table>"
    end
    o[#o + 1] = "</body></html>"
    return table.concat(o, "\n")
  end

  return function(req)
    if req.path ~= "/" then return nil end
    local key = req.query.key or ""
    if key ~= password then
      return { status = 200, mime = "text/html", body = "<html><head><title>Router admin</title></head><body><h1>Router admin</h1>" ..
        '<form action="/" method="get">Password <input type="password" name="key" size="16"> <input type="submit" value="Log in"></form>' ..
        (key ~= "" and '<p><font color="red">Wrong password.</font></p>' or "") .. "</body></html>" }
    end
    if req.query.act then
      local msg = perform(req.query)
      if msg then return { status = 302, mime = "text/html", body = "", location = "/?key=" .. web.urlencode(key) .. "&msg=" .. web.urlencode(msg) } end
    end
    return { status = 200, mime = "text/html", body = page(key, req.query.msg) }
  end
end

if RPWEB_TEST then return M end

local running = shell and shell.getRunningProgram and fs.getName(shell.getRunningProgram()) or ""
if running == "rpadmin" or running == "rpadmin.lua" then
  local args = { ... }
  local pass = args[1]
  if not pass then print("rpadmin <password> [slot] [name]"); return end
  local slot, name = tonumber(args[2]) or 1, args[3]
  if args[2] and not tonumber(args[2]) then name = args[2]; slot = 1 end
  local nic = peripheral.find("realplugs_socket")
  if not nic then error("no Real Plugs socket next to this computer", 0) end
  web.run({ slot = slot, name = name, route = M.makeRoute(nic, pass, slot), title = "router admin page (password required)" })
end

return M
