#!/bin/sh
# Runs the Lua tests (they test the parts of the rpweb programs that do not need ComputerCraft).
# Needs a Lua 5.3+ interpreter: lua, lua5.4 or texlua (TeX Live). Run from the repo root:  sh tests/lua/run.sh
LUA=$(command -v lua5.4 || command -v lua5.3 || command -v lua || command -v texlua) || { echo "no Lua interpreter found"; exit 1; }
status=0
for t in tests/lua/rpweb2.lua tests/lua/tools.lua tests/lua/tools2.lua tests/lua/services.lua; do
  echo "== $t"; "$LUA" "$t" | grep -v '^  ok' || true
  "$LUA" "$t" >/dev/null || status=1
done
exit $status
