package net.neoforged.fml.common; public @interface EventBusSubscriber { String modid(); }
