package com.realplugs.cc;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.realplugs.ModItems;
import com.realplugs.PlugItem;
import com.realplugs.PlugSocketBlock;
import com.realplugs.PlugSocketBlockEntity;
import com.realplugs.PlugTypes;
import com.realplugs.PocketTether;
import com.realplugs.PortAnchorBlock;
import com.realplugs.PortItem;
import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.api.pocket.AbstractPocketUpgrade;
import dan200.computercraft.api.pocket.IPocketAccess;
import dan200.computercraft.api.upgrades.UpgradeType;
import net.minecraft.core.BlockPos;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import org.patryk3211.powergrid.electricity.wire.powercord.CordItem;

/**
 * A Real Plugs port as a pocket computer upgrade. Craft it onto a pocket computer, or run pocket.equipBack() with
 * the port item in your inventory. The data files are data/realplugs/computercraft/pocket_upgrade/port_*.json.
 *
 * The port can hold a plain plug (right-click the pocket computer with the plug in the other hand), or be
 * tethered to an outlet slot of the same connector (right-click the slot with the pocket computer). A tether acts like
 * a cord: the slot shows a plug and a rope is drawn to your hand, but it is not a Power Grid cord. It snaps when you
 * walk too far away. Both live in the upgrade data and are readable from Lua as the "back" peripheral.
 */
public class PortPocketUpgrade extends AbstractPocketUpgrade {
    public static final MapCodec<PortPocketUpgrade> CODEC = Codec.STRING.fieldOf("port").flatXmap(
            name -> {
                for (int i = 1; i < PlugTypes.PLUGS.length; i++) {
                    if (PlugTypes.PLUGS[i].name().equals(name)) return DataResult.success(new PortPocketUpgrade(i));
                }
                return DataResult.error(() -> "Unknown Real Plugs port: " + name);
            },
            up -> DataResult.success(PlugTypes.PLUGS[up.index].name()));

    private static final String PLUG_KEY = "Plug";
    private static final String LINK_KEY = "Link";

    /** Where a port is tethered to. */
    public record Link(ResourceKey<Level> dim, BlockPos pos, int slot) {}

    private final int index;

    public PortPocketUpgrade(int index) {
        super(Component.translatable("upgrade.realplugs.port." + PlugTypes.PLUGS[index].name()), portStack(index));
        this.index = index;
    }

    private static ItemStack portStack(int index) {
        ItemStack s = new ItemStack(ModItems.PORT.get());
        s.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(index));
        return s;
    }

    public PlugTypes.Standard standard() {
        return PlugTypes.PLUGS[index].plugs();
    }

    public String portName() {
        return PlugTypes.PLUGS[index].name();
    }

    @Override
    public UpgradeType<? extends dan200.computercraft.api.pocket.IPocketUpgrade> getType() {
        return ModPocketUpgrades.PORT.get();
    }

    /** Only the port of this exact standard (the item alone would match every port). */
    @Override
    public boolean isItemSuitable(ItemStack stack) {
        return stack.getItem() instanceof PortItem && PlugItem.typeOf(stack) == index;
    }

    @Override
    public IPeripheral createPeripheral(IPocketAccess access) {
        return new PortPeripheral(access, this);
    }

    // ---- the upgrade data: {Plug: <plug stack>, Link: {Dim, X, Y, Z, Slot}} ----

    private static CompoundTag readTag(IPocketAccess access) {
        var data = access.getUpgradeData().get(DataComponents.CUSTOM_DATA);
        return data == null || data.isEmpty() ? new CompoundTag() : data.get().copyTag();
    }

    private static void writeTag(IPocketAccess access, CompoundTag tag) {
        access.setUpgradeData(DataComponentPatch.builder().set(DataComponents.CUSTOM_DATA, CustomData.of(tag)).build());
    }

    public ItemStack readPlug(IPocketAccess access) {
        CompoundTag tag = readTag(access);
        if (!tag.contains(PLUG_KEY)) return ItemStack.EMPTY;
        return ItemStack.parseOptional(access.getLevel().registryAccess(), tag.getCompound(PLUG_KEY));
    }

    private void writePlug(IPocketAccess access, ItemStack plug) {
        CompoundTag tag = readTag(access);
        if (plug.isEmpty()) tag.remove(PLUG_KEY);
        else tag.put(PLUG_KEY, plug.save(access.getLevel().registryAccess()));
        writeTag(access, tag);
    }

    public Link readLink(IPocketAccess access) {
        return linkOf(readTag(access));
    }

    private static Link linkOf(CompoundTag tag) {
        if (!tag.contains(LINK_KEY)) return null;
        CompoundTag l = tag.getCompound(LINK_KEY);
        ResourceLocation dim = ResourceLocation.tryParse(l.getString("Dim"));
        if (dim == null) return null;
        return new Link(ResourceKey.create(Registries.DIMENSION, dim), new BlockPos(l.getInt("X"), l.getInt("Y"), l.getInt("Z")), l.getInt("Slot"));
    }

    // ---- right-click: plug in / unplug / untether ----

    @Override
    public boolean onRightClick(Level level, IPocketAccess access, IPeripheral peripheral) {
        if (!(access.getEntity() instanceof Player player)) return false;
        ItemStack held = player.getOffhandItem().getItem() instanceof PlugItem ? player.getOffhandItem()
                : player.getMainHandItem().getItem() instanceof PlugItem ? player.getMainHandItem() : ItemStack.EMPTY;
        ItemStack current = readPlug(access);
        Link link = readLink(access);

        // a cord in the other hand: say why it can't work, instead of silently opening the screen
        if (held.isEmpty() && (player.getMainHandItem().getItem() instanceof CordItem
                || player.getOffhandItem().getItem() instanceof CordItem)) {
            if (!level.isClientSide) {
                player.displayClientMessage(Component.translatable("message.realplugs.pocket_no_cords"), true);
            }
            return true;
        }

        if (!held.isEmpty() && held.getItem() instanceof PlugItem pi) {
            if (!level.isClientSide) {
                if (!current.isEmpty() || link != null) {
                    player.displayClientMessage(Component.translatable("message.realplugs.port_taken"), true);
                } else if (pi.adapter || PlugItem.plugStandard(held) != standard()) {
                    player.displayClientMessage(Component.translatable("message.realplugs.no_fit",
                            Component.translatable(standard().langKey())), true);
                } else {
                    writePlug(access, PlugItem.takeOne(held, player));
                    player.displayClientMessage(Component.translatable("message.realplugs.pocket_plugged"), true);
                }
            }
            return true;
        }

        if (player.isShiftKeyDown()) {
            if (link != null) {                       // sneak + right-click while tethered: untether
                if (!level.isClientSide) {
                    releaseLink(player, link);
                    CompoundTag tag = readTag(access);
                    tag.remove(LINK_KEY);
                    writeTag(access, tag);
                    player.displayClientMessage(Component.translatable("message.realplugs.tether_unlinked"), true);
                }
                return true;
            }
            if (!current.isEmpty()) {                 // ...or unplug
                if (!level.isClientSide) {
                    PlugItem.give(player, current);
                    writePlug(access, ItemStack.EMPTY);
                    player.displayClientMessage(Component.translatable("message.realplugs.pocket_unplugged"), true);
                }
                return true;
            }
        }
        return false;
    }

    // ---- tether: runs every tick the pocket computer is in a player's inventory ----

    @Override
    public void update(IPocketAccess access, IPeripheral peripheral) {
        if (!(access.getEntity() instanceof ServerPlayer player)) return;
        long now = access.getLevel().getGameTime();

        PocketTether.Request req = PocketTether.take(player.getUUID(), now);
        if (req != null) {
            tryLink(access, player, req, now);
        } else if (player.tickCount % 10 == 0) {
            maintain(access, player, now);
        }
    }

    private void tryLink(IPocketAccess access, ServerPlayer player, PocketTether.Request req, long now) {
        ServerLevel target = player.server.getLevel(req.dim());
        if (target == null || !(target.getBlockEntity(req.pos()) instanceof PlugSocketBlockEntity be)
                || !(be.getBlockState().getBlock() instanceof PlugSocketBlock block) || block instanceof PortAnchorBlock) return;
        int slot = req.slot();
        if (slot < 0 || slot >= block.def.slots().length) return;

        Link old = readLink(access);
        if (old != null && old.dim().equals(req.dim()) && old.pos().equals(req.pos()) && old.slot() == slot) {
            // clicking the slot you are tethered to again lets go
            be.releaseTether(slot, player.getUUID());
            CompoundTag tag = readTag(access);
            tag.remove(LINK_KEY);
            writeTag(access, tag);
            player.displayClientMessage(Component.translatable("message.realplugs.tether_unlinked"), true);
            return;
        }
        if (block.def.slots()[slot] != standard()) {
            player.displayClientMessage(Component.translatable("message.realplugs.cord_wrong_slot",
                    Component.translatable(standard().langKey()), Component.translatable(standard().langKey()),
                    Component.translatable(block.def.slots()[slot].langKey())), true);
            return;
        }
        if (!readPlug(access).isEmpty()) {
            player.displayClientMessage(Component.translatable("message.realplugs.port_taken"), true);
            return;
        }
        boolean mine = player.getUUID().equals(be.tetherOwner(slot));
        if (!be.plugs().get(slot).isEmpty() || (!mine && be.hasCord(slot))) {
            player.displayClientMessage(Component.translatable("message.realplugs.cord_slot_taken"), true);
            return;
        }
        if (player.level() != target || player.distanceToSqr(Vec3.atCenterOf(req.pos())) > PocketTether.RANGE * PocketTether.RANGE) {
            player.displayClientMessage(Component.translatable("message.realplugs.tether_too_far"), true);
            return;
        }

        if (old != null) releaseLink(player, old);   // moving the tether to another slot
        CompoundTag tag = readTag(access);
        CompoundTag l = new CompoundTag();
        l.putString("Dim", req.dim().location().toString());
        l.putInt("X", req.pos().getX());
        l.putInt("Y", req.pos().getY());
        l.putInt("Z", req.pos().getZ());
        l.putInt("Slot", slot);
        tag.put(LINK_KEY, l);
        writeTag(access, tag);
        be.renewTether(slot, player.getUUID(), now + 30);
        player.displayClientMessage(Component.translatable("message.realplugs.tether_linked"), true);
    }

    /** Keeps a valid tether alive, or snaps it. */
    private void maintain(IPocketAccess access, ServerPlayer player, long now) {
        Link link = readLink(access);
        if (link == null) return;
        ServerLevel target = player.server.getLevel(link.dim());
        PlugSocketBlockEntity be = target != null && target.getBlockEntity(link.pos()) instanceof PlugSocketBlockEntity b ? b : null;
        boolean ok = be != null && player.level() == target
                && be.getBlockState().getBlock() instanceof PlugSocketBlock block && link.slot() < block.def.slots().length
                && be.plugs().get(link.slot()).isEmpty() && !be.hasPgCord(link.slot())
                && player.distanceToSqr(Vec3.atCenterOf(link.pos())) <= PocketTether.RANGE * PocketTether.RANGE;
        if (ok) {
            be.renewTether(link.slot(), player.getUUID(), now + 30);
        } else {
            releaseLink(player, link);
            CompoundTag tag = readTag(access);
            tag.remove(LINK_KEY);
            writeTag(access, tag);
            player.displayClientMessage(Component.translatable("message.realplugs.tether_snapped"), true);
        }
    }

    private static void releaseLink(Player player, Link link) {
        if (player instanceof ServerPlayer sp && sp.server.getLevel(link.dim()) != null
                && sp.server.getLevel(link.dim()).getBlockEntity(link.pos()) instanceof PlugSocketBlockEntity be) {
            be.releaseTether(link.slot(), player.getUUID());
        }
    }
}
