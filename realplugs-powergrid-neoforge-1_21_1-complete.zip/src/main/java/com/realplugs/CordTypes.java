package com.realplugs;

import java.util.ArrayList;
import java.util.List;

/**
 * The plug cord variants, indexed by custom_model_data.
 * 0..11 mirror the plug list (the same plug on both ends); 12 and up have a different connector on each end,
 * for example a US plug on one end and USB-A on the other.
 */
public final class CordTypes {
    public record CordDef(String name, PlugTypes.Standard a, PlugTypes.Standard b) {}

    public static final CordDef[] ALL = build();

    private static CordDef[] build() {
        List<CordDef> l = new ArrayList<>();
        for (PlugTypes.PlugDef p : PlugTypes.PLUGS) l.add(new CordDef(p.name(), p.plugs(), p.plugs()));
        PlugTypes.Standard us = PlugTypes.Standard.US_POWER, eu = PlugTypes.Standard.EU_POWER,
                uk = PlugTypes.Standard.UK_POWER, au = PlugTypes.Standard.AU_POWER,
                usbA = PlugTypes.Standard.USB_A, usbC = PlugTypes.Standard.USB_C,
                micro = PlugTypes.Standard.MICRO_USB, hdmi = PlugTypes.Standard.HDMI,
                dp = PlugTypes.Standard.DISPLAYPORT, barrel = PlugTypes.Standard.BARREL,
                lightning = PlugTypes.Standard.LIGHTNING, vga = PlugTypes.Standard.VGA, aux = PlugTypes.Standard.AUX,
                rca = PlugTypes.Standard.RCA, xlr = PlugTypes.Standard.XLR, usbB = PlugTypes.Standard.USB_B;
        l.add(new CordDef("us_usb_a", us, usbA));
        l.add(new CordDef("us_usb_c", us, usbC));
        l.add(new CordDef("us_micro_usb", us, micro));
        l.add(new CordDef("eu_usb_a", eu, usbA));
        l.add(new CordDef("eu_usb_c", eu, usbC));
        l.add(new CordDef("uk_usb_a", uk, usbA));
        l.add(new CordDef("uk_usb_c", uk, usbC));
        l.add(new CordDef("au_usb_a", au, usbA));
        l.add(new CordDef("au_usb_c", au, usbC));
        l.add(new CordDef("us_barrel", us, barrel));
        l.add(new CordDef("eu_barrel", eu, barrel));
        l.add(new CordDef("hdmi_displayport", hdmi, dp));
        l.add(new CordDef("hdmi_usb_c", hdmi, usbC));
        l.add(new CordDef("usb_a_usb_c", usbA, usbC));
        l.add(new CordDef("usb_a_micro_usb", usbA, micro));
        l.add(new CordDef("us_lightning", us, lightning));
        l.add(new CordDef("usb_a_lightning", usbA, lightning));
        l.add(new CordDef("usb_c_lightning", usbC, lightning));
        l.add(new CordDef("vga_hdmi", vga, hdmi));
        l.add(new CordDef("vga_displayport", vga, dp));
        l.add(new CordDef("aux_rca", aux, rca));
        l.add(new CordDef("xlr_aux", xlr, aux));
        l.add(new CordDef("usb_a_usb_b", usbA, usbB));
        l.add(new CordDef("usb_c_usb_b", usbC, usbB));
        return l.toArray(new CordDef[0]);
    }

    public static CordDef get(int type) {
        return ALL[type >= 0 && type < ALL.length ? type : 0];
    }

    private CordTypes() {}
}
