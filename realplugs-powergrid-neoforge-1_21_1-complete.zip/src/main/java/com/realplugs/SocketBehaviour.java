package com.realplugs;

import org.patryk3211.powergrid.electricity.base.ElectricBehaviour;
import org.patryk3211.powergrid.electricity.wire.BaseWireEntity;
import org.patryk3211.powergrid.electricity.wire.BlockWireEndpoint;

/**
 * Power Grid's electric behaviour, plus a callback when a wire or cord is attached or removed,
 * so a slot's contact can close while a plug cord sits in it.
 */
public class SocketBehaviour extends ElectricBehaviour {
    private final PlugSocketBlockEntity socket;

    public SocketBehaviour(PlugSocketBlockEntity be) {
        super(be);
        this.socket = be;
    }

    @Override
    public void addConnection(BlockWireEndpoint endpoint, BaseWireEntity wire) {
        super.addConnection(endpoint, wire);
        socket.cordsChanged();
    }

    @Override
    public void removeConnection(BlockWireEndpoint endpoint, BaseWireEntity wire) {
        super.removeConnection(endpoint, wire);
        socket.cordsChanged();
    }
}
