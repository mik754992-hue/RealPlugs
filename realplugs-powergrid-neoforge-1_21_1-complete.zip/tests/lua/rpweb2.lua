RPWEB_TEST = true
local M = dofile("lua/rpweb.lua")
local fails = 0
local function eq(a,b,w) if a~=b then print("FAIL "..w..": got "..tostring(a).." expected "..tostring(b)); fails=fails+1 else print("  ok  "..w) end end
-- addresses
local u = M.parseUrl("http://Home.Site:8080/a/b.html?x=1"); eq(u.host,"home.site","host"); eq(u.port,8080,"port"); eq(u.path,"/a/b.html?x=1","path+query")
eq(M.parseUrl("files").path,"/","bare name"); eq(M.parseUrl("site?q=1").path,"/?q=1","bare name with query")
eq(select(2,M.parseUrl("https://x")),"only http:// addresses work here","https refused")
eq(M.resolve(M.parseUrl("http://s/a/b.html"),"c.html"),"http://s/a/c.html","relative")
eq(M.resolve(M.parseUrl("http://s/a/b.html"),"../x.html?q=2"),"http://s/x.html?q=2","dotdot + query kept")
eq(M.resolve(M.parseUrl("http://s/a/b.html?x=1"),"?y=2"),"http://s/a/b.html?y=2","query only")
eq(M.resolve(M.parseUrl("http://s/a/b.html"),"/z"),"http://s/z","absolute path")
-- queries
local q = M.parseQuery("a=1&b=x%20y+z&c=&d"); eq(q.a,"1","q a"); eq(q.b,"x y z","q b"); eq(q.c,"","q c")
eq(M.encodeQuery({b="x y",a="1&2"}),"a=1%262&b=x%20y","encode sorted")
-- request parsing
local raw = "POST /g?x=1 HTTP/1.0\r\nHost: h\r\nContent-Length: 11\r\n\r\nwho=a&msg=b"
eq(M.parseRequest(raw:sub(1,#raw-3)),nil,"body incomplete")
local r = M.parseRequest(raw); eq(r.method,"POST","method"); eq(r.path,"/g","path"); eq(r.query.x,"1","query"); eq(r.form.who,"a","form who"); eq(r.form.msg,"b","form msg")
eq(M.parseRequest("junk\r\n\r\n"),false,"not http"); eq(M.parseRequest("GET / HTTP/1.0\r\nHost"),nil,"headers incomplete")
eq(M.parseRequest("GET /a+b HTTP/1.0\r\n\r\n").path,"/a+b","plus kept in path")
local br = M.buildRequest("h","/p","POST","a=1"); eq(M.parseRequest(br).form.a,"1","built POST round trip")
-- server: files, templates, lua pages
local files = { ["www/index.html"]="<h1>Hi {{host}}</h1><p>visit {{hits}}</p>", ["www/notes.txt"]="plain {{hits}}", ["www/sub/index.html"]="sub",
  ["www/echo.lua"]='echo("<p>", escape(request.query.name or "nobody"), "</p>") return nil',
  ["www/book.lua"]='local b = data_load("b") or {} if request.method=="POST" then b[#b+1]=request.form.m data_save("b",b) return {redirect="/book"} end return "<p>"..#b.." entries</p>"',
  ["www/boom.lua"]='error("oops")', ["www/syn.lua"]='this is not lua', ["www/p.nfp"]="0f\nf0" }
local db = {}
local ctx = { read=function(p) return files[p] end, isDir=function(p) return p=="www/sub" end, vars={hits=7,host="home.site"},
  api={ load=function(n) return db[n] end, save=function(n,t) db[n]=t return true end } }
local function get(path) return M.parseResponse(M.handle("GET "..path.." HTTP/1.0\r\n\r\n",ctx)) end
local x = get("/"); eq(x.status,200,"index"); eq(x.body,"<h1>Hi home.site</h1><p>visit 7</p>","template"); eq(x.headers["content-type"],"text/html","mime")
eq(get("/notes.txt").body,"plain 7","txt template"); eq(get("/nope").status,404,"404"); eq(get("/../s").status,400,"dotdot"); eq(get("/%2e%2e/x").status,400,"escaped dotdot")
eq(get("/sub").status,301,"dir redirect"); eq(get("/sub/").body,"sub","dir index"); eq(get("/p.nfp").headers["content-type"],"image/nfp","nfp mime")
eq(get("/echo?name=<b>").body,"<p>&lt;b&gt;</p>","lua page via /echo, escaped"); eq(get("/echo.lua").body,"<p>nobody</p>","lua page by file name")
eq(get("/boom").status,500,"error page 500"); eq(get("/syn").status,500,"syntax error 500")
local pr = M.parseResponse(M.handle("POST /book HTTP/1.0\r\nContent-Length: 3\r\n\r\nm=x",ctx))
eq(pr.status,302,"POST redirect"); eq(pr.headers["location"],"/book","location"); eq(#db.b,1,"page saved data"); eq(get("/book").body,"<p>1 entries</p>","page reads data")
eq(M.parseResponse(M.handle("DELETE / HTTP/1.0\r\n\r\n",ctx)).status,405,"DELETE refused")
-- sandbox
files["www/evil.lua"]='return tostring(io)..tostring(fs)..tostring(os.execute)..tostring(load)..tostring(require)'
eq(get("/evil").body,"nilnilnilnilnil","sandbox: no io/fs/os.execute/load/require")
-- directory
local reg = {}
local n,e = M.parseAnnounce(M.buildAnnounce("Mine.Site","<html><head><title> My  Shop </title><meta name=\"description\" content=\"Sells bricks\"></head>"))
eq(n,"mine.site","announce name"); eq(e.title,"My Shop","announce title"); eq(e.desc,"Sells bricks","announce desc"); reg[n]=e
reg["farm"]={title="Farm",desc="eggs and wheat"}
eq(M.parseAnnounce("ANNOUNCE\nbad name\nx\ny"),nil,"bad names refused"); eq(M.parseAnnounce("hello"),nil,"not an announcement")
local dctx = { read=function() return nil end, isDir=function() return false end, vars={}, route=M.directoryRoute(reg) }
local d = M.parseResponse(M.handle("GET / HTTP/1.0\r\n\r\n",dctx)).body
eq(d:find("mine.site",1,true)~=nil and d:find("Farm",1,true)~=nil,true,"directory lists all")
local s1 = M.parseResponse(M.handle("GET /search?q=brick HTTP/1.0\r\n\r\n",dctx)).body
eq(s1:find("My Shop",1,true)~=nil and s1:find("Farm",1,true)==nil,true,"search finds by description")
local s2 = M.parseResponse(M.handle("GET /search?q=eggs+wheat HTTP/1.0\r\n\r\n",dctx)).body
eq(s2:find("Farm",1,true)~=nil,true,"search needs all words")
eq(M.parseResponse(M.handle("GET /search?q=zzz HTTP/1.0\r\n\r\n",dctx)).body:find("Nothing found",1,true)~=nil,true,"no results")
-- render: forms, inputs, images
local page = [[<html><head><title>F</title></head><body><h1>Form</h1>
<form action="/guestbook" method="post"><input type="hidden" name="h" value="1">
Name <input name="who" size="8" value="Bob"> <input type="password" name="pw">
<input type="checkbox" name="agree" value="yes"> agree
<select name="color"><option value="r">Red</option><option value="g" selected>Green</option></select>
<textarea name="t" cols="10">hello
there</textarea>
<input type="submit" name="go" value="Send"></form>
<img src="p.nfp" alt="pic"><img src="x.png" alt="skip"></body></html>]]
local out = M.render(page, 30, M.parseUrl("http://s/a/f.html"))
eq(#out.forms,1,"one form"); eq(out.forms[1].method,"post","form method"); eq(out.forms[1].action,"/guestbook","form action")
local names = {} for id,i in ipairs(out.inputs) do names[#names+1]=i.type..":"..i.name end
eq(table.concat(names,","),"hidden:h,text:who,password:pw,checkbox:agree,select:color,text:t,submit:go","inputs in order")
eq(out.inputs[5].value,"g","select keeps selected option"); eq(out.inputs[6].value,"hello there","textarea text")
eq(#out.images,1,"one .nfp image found"); eq(out.images[1],"http://s/a/p.nfp","image url resolved")
local vals = { [2]="Alice", [4]="on" }
local fv = M.formValues(out, vals, 1, 7)
eq(fv.h,"1","hidden sent"); eq(fv.who,"Alice","typed value sent"); eq(fv.pw,"","untouched password empty"); eq(fv.agree,"yes","checked box sent"); eq(fv.color,"g","select default sent"); eq(fv.go,"Send","clicked submit sent")
eq(M.formValues(out, {}, 1, nil).agree,nil,"unchecked box not sent"); eq(M.formValues(out, {}, 1, nil).go,nil,"submit not sent when not clicked")
eq(M.inputText(out.inputs[2],"Bob",10),"[Bob_____]","text field"); eq(M.inputText(out.inputs[3],"abc",10),"[***_____]","password stars")
eq(M.inputText(out.inputs[4],"on",3),"[x]","checkbox on"); eq(M.inputText(out.inputs[4],"",3),"[ ]","checkbox off"); eq(M.inputText(out.inputs[5],"g",9),"[Green__]","select label")
eq(M.inputText(out.inputs[2],"abcdefghijklmnop",10),"[ijklmnop]","long text shows the end")
for i,l in ipairs(out.lines) do local n=0 local n=0 for _,sg in ipairs(l.segs) do n=n+#sg.t end if n>30 then print("FAIL line too wide "..i.." "..n); fails=fails+1 end end
local withImg = M.render(page, 30, M.parseUrl("http://s/a/f.html"), { ["http://s/a/p.nfp"]="0f\nf0" })
local pics=0 for _,l in ipairs(withImg.lines) do for _,sg in ipairs(l.segs) do if sg.bg then pics=pics+1 end end end
eq(pics,4,"picture drawn as 4 coloured cells")
local nfp = M.parseNfp("00ff\n  e1\n",10,10); eq(#nfp,2,"nfp rows"); eq(nfp[1].segs[1].t,"  ","nfp run merged"); eq(nfp[1].segs[1].bg,"white","nfp white"); eq(nfp[1].segs[2].bg,"black","nfp black"); eq(nfp[2].segs[2].bg,"red","nfp: transparent run then red")
-- bookmarks
local bl = M.parseBookmarks("http://a/\tSite A\nhttp://b/\n"); eq(#bl,2,"two bookmarks"); eq(bl[2].title,"http://b/","title falls back"); eq(M.bookmarksHtml(bl):find('href="http://a/"',1,true)~=nil,true,"bookmark page links")
local hr = M.render(M.HOME, 40, {host="about",port=80,path="/"}); eq(hr.title,"rpweb","home page title"); eq(hr.links[1],"about:bookmarks","home links to bookmarks")
print(fails==0 and "ALL OK" or (fails.." FAILED"))
os.exit(fails==0 and 0 or 1)
