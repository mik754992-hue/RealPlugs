package com.realplugs;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(BuiltInRegistries.ITEM, RealPlugsMod.MODID);

    public static final DeferredHolder<Item, PlugItem> PLUG =
            ITEMS.register("plug", () -> new PlugItem(new Item.Properties(), false));
    public static final DeferredHolder<Item, PlugItem> ADAPTER =
            ITEMS.register("adapter", () -> new PlugItem(new Item.Properties(), true));

    public static final DeferredHolder<Item, BlockItem> OUTLET =
            ITEMS.register("outlet", () -> new BlockItem(ModBlocks.OUTLET.get(), new Item.Properties()));
    public static final DeferredHolder<Item, BlockItem> POWER_STRIP =
            ITEMS.register("power_strip", () -> new BlockItem(ModBlocks.POWER_STRIP.get(), new Item.Properties()));
}
