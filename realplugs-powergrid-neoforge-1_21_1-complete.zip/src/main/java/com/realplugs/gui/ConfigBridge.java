package com.realplugs.gui;

import com.realplugs.PlugSocketBlockEntity;
import net.minecraft.nbt.CompoundTag;

/** Connects the configurator to the code that knows the settings. Set by CCCompat when CC: Tweaked is loaded. */
public final class ConfigBridge {
    private ConfigBridge() {}

    public interface Backend {
        /** The form: {title, info: [string], pages: [{title, fields: [{id, label, value, type (text|bool|choice), choices}]}]}. */
        CompoundTag view(PlugSocketBlockEntity be);

        /** Applies changed fields (id -> text); returns a message for the player. */
        String apply(PlugSocketBlockEntity be, CompoundTag changes);
    }

    public static volatile Backend backend;
}
