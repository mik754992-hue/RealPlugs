package dan200.computercraft.api.pocket;

import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.api.upgrades.UpgradeBase;
import dan200.computercraft.api.upgrades.UpgradeType;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** COMPILE-TIME STUB of CC: Tweaked 1.113's IPocketUpgrade. Excluded from the released jar. */
public interface IPocketUpgrade extends UpgradeBase {
    static ResourceKey<Registry<UpgradeType<? extends IPocketUpgrade>>> typeRegistry() {
        throw new UnsupportedOperationException("stub: the real class comes from CC: Tweaked");
    }

    @Override
    UpgradeType<? extends IPocketUpgrade> getType();

    IPeripheral createPeripheral(IPocketAccess access);

    default void update(IPocketAccess access, IPeripheral peripheral) {
    }

    default boolean onRightClick(Level level, IPocketAccess access, IPeripheral peripheral) {
        return false;
    }
}
