package com.realplugs.cc;

import com.realplugs.PlugItem;
import com.realplugs.PlugSocketBlock;
import com.realplugs.PlugSocketBlockEntity;
import com.realplugs.PlugTypes;
import com.realplugs.net.NetConfig;
import com.realplugs.net.NetListener;
import com.realplugs.net.NetworkManager;
import dan200.computercraft.api.lua.LuaException;
import dan200.computercraft.api.lua.LuaFunction;
import dan200.computercraft.api.lua.MethodResult;
import dan200.computercraft.api.peripheral.IComputerAccess;
import dan200.computercraft.api.peripheral.IPeripheral;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.item.ItemStack;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * Read-only CC: Tweaked peripheral for every outlet / power strip.
 * Slot numbers are 1-based in Lua, counted from the viewer's left like the in-world slots.
 * Everything runs on the main thread because it reads block entity state.
 */
public class SocketPeripheral implements IPeripheral {
    private final PlugSocketBlockEntity be;

    public SocketPeripheral(PlugSocketBlockEntity be) {
        this.be = be;
    }

    @Override
    public String getType() {
        return "realplugs_socket";
    }

    @Override
    public boolean equals(IPeripheral other) {
        return other instanceof SocketPeripheral p && p.be == be;
    }

    @Override
    public int hashCode() {
        return System.identityHashCode(be);
    }

    @LuaFunction(mainThread = true)
    public final String getSocketId() {
        return BuiltInRegistries.BLOCK.getKey(be.getBlockState().getBlock()).getPath();
    }

    @LuaFunction(mainThread = true)
    public final int getSlotCount() {
        return be.plugs().size();
    }

    /** Connector standard of a slot, e.g. "us_power", "usb_c". nil when the slot does not exist. */
    @LuaFunction(mainThread = true)
    public final String getSlotStandard(int slot) {
        if (!valid(slot) || !(be.getBlockState().getBlock() instanceof PlugSocketBlock b)) return null;
        return b.def.slots()[slot - 1].key;
    }

    @LuaFunction(mainThread = true)
    public final boolean isPlugged(int slot) {
        return valid(slot) && !be.plugs().get(slot - 1).isEmpty();
    }

    @LuaFunction(mainThread = true)
    public final int getPluggedCount() {
        int n = 0;
        for (ItemStack s : be.plugs()) if (!s.isEmpty()) n++;
        return n;
    }

    /** What sits in a slot: {name, standard, adapter, inner = {...}} or nil when it is empty. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getPlug(int slot) {
        if (!valid(slot)) return null;
        return describe(be.plugs().get(slot - 1));
    }

    /** One entry per slot: {slot, standard, plugged, plug?}. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getSlots() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (int i = 1; i <= be.plugs().size(); i++) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("slot", i);
            m.put("standard", getSlotStandard(i));
            Map<String, Object> plug = describe(be.plugs().get(i - 1));
            m.put("plugged", plug != null);
            if (plug != null) m.put("plug", plug);
            out.add(m);
        }
        return out;
    }

    private boolean valid(int slot) {
        return slot >= 1 && slot <= be.plugs().size();
    }

    private static Map<String, Object> describe(ItemStack s) {
        if (s.isEmpty() || !(s.getItem() instanceof PlugItem pi)) return null;
        int type = PlugItem.typeOf(s);
        Map<String, Object> m = new LinkedHashMap<>();
        PlugTypes.Standard std = PlugItem.plugStandard(s);
        m.put("name", pi.adapter ? PlugTypes.adapter(type).name() : PlugTypes.plug(type).name());
        m.put("standard", std == null ? "unknown" : std.key);
        m.put("adapter", pi.adapter);
        if (pi.adapter) {
            m.put("accepts", PlugTypes.adapter(type).accepts().key);
            List<Map<String, Object>> inner = new ArrayList<>();
            for (ItemStack in : PlugItem.inners(s)) {
                Map<String, Object> d = describe(in);
                if (d != null) inner.add(d);
            }
            m.put("inner", inner);
        }
        return m;
    }

    // ------------------------------------------------------------------ networking (see NetworkManager)

    @Override
    public void attach(IComputerAccess computer) {
        be.addNetListener(computer, new NetListener() {
            @Override
            public void packet(int slot, String srcIp, int srcPort, int dstPort, String payload) {
                computer.queueEvent("realplugs_packet", computer.getAttachmentName(), slot, srcIp, srcPort, dstPort, payload);
            }

            @Override
            public void frame(int slot, String srcMac, String dstMac, int etherType, String payload) {
                computer.queueEvent("realplugs_frame", computer.getAttachmentName(), slot, srcMac, dstMac, etherType, payload);
            }

            @Override
            public void tcp(int slot, String event, int id, Object... args) {
                Object[] all = new Object[4 + args.length];
                all[0] = computer.getAttachmentName();
                all[1] = slot;
                all[2] = event;
                all[3] = id;
                System.arraycopy(args, 0, all, 4, args.length);
                computer.queueEvent("realplugs_tcp", all);
            }
        });
    }

    @Override
    public void detach(IComputerAccess computer) {
        be.removeNetListener(computer);
    }

    private NetworkManager.Iface iface(int slot) throws LuaException {
        if (!(be.getLevel() instanceof ServerLevel level)) throw new LuaException("not available here");
        if (slot < 1 || slot > be.slotCount() || !be.isRj45(slot - 1)) throw new LuaException("slot " + slot + " is not a network port");
        return new NetworkManager.Iface(level, be.getBlockPos(), slot - 1);
    }

    private static MethodResult fail(String why) {
        return MethodResult.of(new Object[]{null, why});
    }

    /** One entry per RJ45 port: {slot, mac, ip, prefix, gateway, uplink, dhcp, linkUp, peerMac?}. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getInterfaces() throws LuaException {
        List<Map<String, Object>> out = new ArrayList<>();
        for (int s = 1; s <= be.slotCount(); s++) {
            if (!be.isRj45(s - 1)) continue;
            NetworkManager.Iface i = iface(s);
            NetConfig c = be.net();
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("slot", s);
            m.put("mac", NetworkManager.mac(i));
            m.put("ip", c.ip(s - 1));
            m.put("prefix", c.prefix[s - 1]);
            m.put("gateway", c.gateway(s - 1));
            m.put("uplink", c.uplink[s - 1]);
            m.put("dhcp", c.dhcp[s - 1]);
            m.put("hostname", c.hostname(s - 1));
            NetworkManager.Iface peer = NetworkManager.peer(i);
            m.put("linkUp", peer != null);
            if (peer != null) m.put("peerMac", NetworkManager.mac(peer));
            out.add(m);
        }
        return out;
    }

    @LuaFunction(mainThread = true)
    public final String getMac(int slot) throws LuaException {
        return NetworkManager.mac(iface(slot));
    }

    /** Is there an ethernet cord with two ends in this port? */
    @LuaFunction(mainThread = true)
    public final boolean isLinkUp(int slot) throws LuaException {
        return NetworkManager.peer(iface(slot)) != null;
    }

    /** MAC address of the port at the other end of the cord, or nil. */
    @LuaFunction(mainThread = true)
    public final String getPeerMac(int slot) throws LuaException {
        NetworkManager.Iface peer = NetworkManager.peer(iface(slot));
        return peer == null ? null : NetworkManager.mac(peer);
    }

    /** The ports that share settings with this one: the LAN ports of a router block are one interface. */
    private int[] group(int slot) {
        if (be.isRouterBlock() && slot - 1 != PlugSocketBlockEntity.ROUTER_WAN) return new int[]{0, 1, 2};
        return new int[]{slot - 1};
    }

    /** Sets the address of a port by hand. prefix is the network size (24 means 255.255.255.0). On a router the LAN ports share it. */
    @LuaFunction(mainThread = true)
    public final MethodResult setAddress(int slot, String ip, int prefix, Optional<String> gateway) throws LuaException {
        iface(slot);
        NetConfig c = be.net();
        if (c.uplink[slot - 1] || (be.isRouterBlock() && slot - 1 == PlugSocketBlockEntity.ROUTER_WAN)) {
            return fail("this port is the WAN: its address comes from the ISP");
        }
        if (NetConfig.parse(ip) < 0) return fail("bad address");
        if (prefix < 1 || prefix > 32) return fail("prefix must be 1 to 32");
        String gw = gateway.orElse("");
        if (!gw.isEmpty() && NetConfig.parse(gw) < 0) return fail("bad gateway");
        for (int s : group(slot)) {
            c.ip[s] = ip.trim();
            c.prefix[s] = prefix;
            c.gateway[s] = gw.trim();
        }
        be.netChanged();
        return MethodResult.of(true);
    }

    /** Forget the address of a port. */
    @LuaFunction(mainThread = true)
    public final void clearAddress(int slot) throws LuaException {
        iface(slot);
        NetConfig c = be.net();
        if (c.uplink[slot - 1] || be.isRouterBlock()) return;   // a router keeps its LAN address
        c.ip[slot - 1] = "";
        c.prefix[slot - 1] = 0;
        c.gateway[slot - 1] = "";
        be.netChanged();
    }

    /** Router mode: pass packets between the ports of this socket and out through its uplink (with NAT). */
    @LuaFunction(mainThread = true)
    public final void setRouting(boolean on) {
        if (be.isRouterBlock()) return;   // a Network Router always routes
        be.net().routing = on;
        be.netChanged();
    }

    @LuaFunction(mainThread = true)
    public final boolean isRouting() {
        return be.net().routing || be.isRouterBlock();
    }

    /** Is this socket a Network Router block (ports 1-3 LAN, port 4 WAN)? */
    @LuaFunction(mainThread = true)
    public final boolean isRouter() {
        return be.isRouterBlock();
    }

    /** Switch mode: all ports of this socket form one network segment. */
    @LuaFunction(mainThread = true)
    public final void setBridge(boolean on) {
        if (be.isSwitchBlock()) return;   // a Network Switch is always bridged
        be.net().bridge = on;
        be.netChanged();
    }

    @LuaFunction(mainThread = true)
    public final boolean isBridge() {
        return be.net().bridge || be.isSwitchBlock();
    }

    /** DHCP server: hand out addresses of this port's network to other ports in its segment (see autoConfigure). */
    @LuaFunction(mainThread = true)
    public final void setDhcp(int slot, boolean on) throws LuaException {
        iface(slot);
        for (int s : group(slot)) be.net().dhcp[s] = on;
        be.netChanged();
    }

    /** DHCP client: take an address, prefix and gateway from a DHCP server in the segment. Returns the address, or nil and why not. */
    @LuaFunction(mainThread = true)
    public final MethodResult autoConfigure(int slot) throws LuaException {
        String err = NetworkManager.autoConfigure(iface(slot));
        return err == null ? MethodResult.of(be.net().ip(slot - 1)) : fail(err);
    }

    /** Modem: connect a cabled port to the internet. The ISP gives it a public address. Returns true and the address, or false and why not. */
    @LuaFunction(mainThread = true)
    public final MethodResult setUplink(int slot, boolean on) throws LuaException {
        if (be.isRouterBlock() && slot - 1 != PlugSocketBlockEntity.ROUTER_WAN) {
            return MethodResult.of(false, "only the WAN port (port 4) can be an uplink");
        }
        String err = NetworkManager.setUplink(iface(slot), on);
        return err == null ? MethodResult.of(true, be.net().ip(slot - 1)) : MethodResult.of(false, err);
    }

    /** Sends a datagram (at most 1500 characters) to an address or a hostname. It arrives as a "realplugs_packet" event. */
    @LuaFunction(mainThread = true)
    public final MethodResult send(int slot, String host, int dstPort, int srcPort, String payload) throws LuaException {
        NetworkManager.Iface me = iface(slot);
        String[] error = new String[1];
        String ip = NetworkManager.address(me, host, error);
        if (ip == null) return MethodResult.of(false, error[0]);
        String err = NetworkManager.send(me, ip, srcPort, dstPort, payload);
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    /** Round trip time in milliseconds to an address or hostname, or nil and why it cannot be reached. */
    @LuaFunction(mainThread = true)
    public final MethodResult ping(int slot, String host) throws LuaException {
        NetworkManager.Iface me = iface(slot);
        String[] error = new String[1];
        String ip = NetworkManager.address(me, host, error);
        if (ip == null) return fail(error[0]);
        int rtt = NetworkManager.ping(me, ip, error);
        return rtt < 0 ? fail(error[0]) : MethodResult.of(rtt);
    }

    /** A raw Ethernet frame to one port of the segment, or ff:ff:ff:ff:ff:ff for all. Arrives as "realplugs_frame". */
    @LuaFunction(mainThread = true)
    public final MethodResult sendFrame(int slot, String dstMac, int etherType, String payload) throws LuaException {
        String err = NetworkManager.sendFrame(iface(slot), dstMac, etherType, payload);
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    /** Accept connections on a port. The event "realplugs_tcp" says "accepted" with a connection id. */
    @LuaFunction(mainThread = true)
    public final MethodResult listen(int slot, int port) throws LuaException {
        String err = NetworkManager.listen(iface(slot), port, true);
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    @LuaFunction(mainThread = true)
    public final MethodResult unlisten(int slot, int port) throws LuaException {
        String err = NetworkManager.listen(iface(slot), port, false);
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    /** Opens a connection to an address or hostname. Returns the connection id; "connected" (or "closed") follows as an event. */
    @LuaFunction(mainThread = true)
    public final MethodResult connect(int slot, String host, int port) throws LuaException {
        NetworkManager.Iface me = iface(slot);
        String[] error = new String[1];
        String ip = NetworkManager.address(me, host, error);
        if (ip == null) return fail(error[0]);
        int id = NetworkManager.connect(me, ip, port, error);
        return id < 0 ? fail(error[0]) : MethodResult.of(id);
    }

    /** Sends data on a connection (at most 1500 characters at a time). */
    @LuaFunction(mainThread = true)
    public final MethodResult tcpSend(int slot, int id, String data) throws LuaException {
        String err = NetworkManager.tcpSend(iface(slot), id, data);
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    @LuaFunction(mainThread = true)
    public final MethodResult tcpClose(int slot, int id) throws LuaException {
        String err = NetworkManager.tcpClose(iface(slot), id);
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    /** Gives the port a hostname. On an uplink the name is known to the whole server. */
    @LuaFunction(mainThread = true)
    public final MethodResult setHostname(int slot, String name) throws LuaException {
        String err = NetworkManager.setHostname(iface(slot), name);
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    @LuaFunction(mainThread = true)
    public final String getHostname(int slot) throws LuaException {
        iface(slot);
        return be.net().hostname(slot - 1);
    }

    /** The address behind a hostname (a port in this segment, or an uplink anywhere). */
    @LuaFunction(mainThread = true)
    public final MethodResult resolve(int slot, String name) throws LuaException {
        String[] error = new String[1];
        String ip = NetworkManager.resolve(iface(slot), name, error);
        return ip == null ? fail(error[0]) : MethodResult.of(ip);
    }

    /** Router: send unsolicited traffic that arrives at the public port to a host behind the router (like a home router's port forwarding). */
    @LuaFunction(mainThread = true)
    public final MethodResult addPortForward(int publicPort, String ip, int port) {
        if (!be.net().routing && !be.isRouterBlock()) return MethodResult.of(false, "this socket is not a router");
        long target = NetConfig.parse(ip);
        if (target < 0) return MethodResult.of(false, "bad address");
        if (publicPort < 1 || publicPort > 65535 || port < 1 || port > 65535) return MethodResult.of(false, "bad port");
        be.net().forwards.put(publicPort, NetConfig.format(target) + ":" + port);
        be.netChanged();
        return MethodResult.of(true);
    }

    @LuaFunction(mainThread = true)
    public final void removePortForward(int publicPort) {
        be.net().forwards.remove(publicPort);
        be.netChanged();
    }

    /** {publicPort, ip, port} for every forward. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getPortForwards() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map.Entry<Integer, String> e : be.net().forwards.entrySet()) {
            int colon = e.getValue().lastIndexOf(':');
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("publicPort", e.getKey());
            m.put("ip", e.getValue().substring(0, colon));
            m.put("port", Integer.parseInt(e.getValue().substring(colon + 1)));
            out.add(m);
        }
        return out;
    }

    /** Every port in this port's network segment: {mac, ip, self}. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> scan(int slot) throws LuaException {
        NetworkManager.Iface me = iface(slot);
        List<Map<String, Object>> out = new ArrayList<>();
        for (NetworkManager.Iface i : NetworkManager.scan(me)) {
            PlugSocketBlockEntity b = NetworkManager.beOf(i.level(), i.pos());
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("mac", NetworkManager.mac(i));
            m.put("ip", b == null ? "" : b.net().ip(i.slot()));
            m.put("self", i.equals(me));
            out.add(m);
        }
        return out;
    }

    // ------------------------------------------------------------------ DHCP server: range, reservations, leases

    private static final java.util.regex.Pattern MAC = java.util.regex.Pattern.compile("([0-9a-f]{2}:){5}[0-9a-f]{2}");

    private static String cleanMac(String mac) {
        String m = mac == null ? "" : mac.trim().toLowerCase(java.util.Locale.ROOT);
        return MAC.matcher(m).matches() ? m : null;
    }

    /** Limits the addresses a DHCP server hands out (both inside this port's network, first <= last). The default is everything but .1 and the last one. */
    @LuaFunction(mainThread = true)
    public final MethodResult setDhcpRange(int slot, String first, String last) throws LuaException {
        iface(slot);
        NetConfig c = be.net();
        long ip = NetConfig.parse(c.ip(slot - 1));
        int pre = c.prefix[slot - 1];
        if (ip < 0 || pre < 8 || pre > 30) return fail("give this port an address first (network size 8 to 30)");
        long a = NetConfig.parse(first);
        long z = NetConfig.parse(last);
        if (a < 0 || z < 0) return fail("bad address");
        if (!NetConfig.sameSubnet(ip, a, pre) || !NetConfig.sameSubnet(ip, z, pre)) return fail("the range must be inside this port's network");
        long net = ip & ((0xFFFFFFFFL << (32 - pre)) & 0xFFFFFFFFL);
        long size = 1L << (32 - pre);
        long lo = a - net;
        long hi = z - net;
        if (lo < 1 || hi > size - 2 || lo > hi) return fail("bad range");
        for (int s : group(slot)) {
            c.dhcpFirst[s] = (int) lo;
            c.dhcpLast[s] = (int) hi;
        }
        be.netChanged();
        return MethodResult.of(true);
    }

    /** {enabled, first, last} of the DHCP server on this port. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getDhcp(int slot) throws LuaException {
        iface(slot);
        NetConfig c = be.net();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("enabled", c.dhcp[slot - 1]);
        long ip = NetConfig.parse(c.ip(slot - 1));
        int pre = c.prefix[slot - 1];
        if (ip >= 0 && pre >= 8 && pre <= 30) {
            long net = ip & ((0xFFFFFFFFL << (32 - pre)) & 0xFFFFFFFFL);
            long size = 1L << (32 - pre);
            long lo = c.dhcpFirst[slot - 1] > 0 ? c.dhcpFirst[slot - 1] : 2;
            long hi = c.dhcpLast[slot - 1] > 0 ? Math.min(c.dhcpLast[slot - 1], size - 2) : size - 2;
            m.put("first", NetConfig.format(net + lo));
            m.put("last", NetConfig.format(net + hi));
        }
        return m;
    }

    /** Always give this MAC address the same address (it must be inside this port's network). */
    @LuaFunction(mainThread = true)
    public final MethodResult reserveAddress(int slot, String mac, String ip) throws LuaException {
        iface(slot);
        NetConfig c = be.net();
        String m = cleanMac(mac);
        if (m == null) return fail("bad MAC address (like 02:52:50:aa:bb:cc)");
        long want = NetConfig.parse(ip);
        long mine = NetConfig.parse(c.ip(slot - 1));
        int pre = c.prefix[slot - 1];
        if (want < 0) return fail("bad address");
        if (mine < 0 || pre < 8 || pre > 30) return fail("give this port an address first (network size 8 to 30)");
        if (!NetConfig.sameSubnet(mine, want, pre) || want == mine) return fail("the address must be inside this port's network (and not the server's own)");
        for (Map.Entry<String, String> e : c.reservations.entrySet()) {
            if (!e.getKey().equals(m) && NetConfig.parse(e.getValue()) == want) return fail("that address is reserved for another port");
        }
        c.reservations.put(m, NetConfig.format(want));
        be.netChanged();
        return MethodResult.of(true);
    }

    @LuaFunction(mainThread = true)
    public final void removeReservation(String mac) {
        String m = cleanMac(mac);
        if (m != null && be.net().reservations.remove(m) != null) be.netChanged();
    }

    /** {mac, ip, reserved} for every address this DHCP server remembers or reserves. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getDhcpLeases() {
        NetConfig c = be.net();
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map.Entry<String, String> e : c.reservations.entrySet()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("mac", e.getKey());
            m.put("ip", e.getValue());
            m.put("reserved", true);
            out.add(m);
        }
        for (Map.Entry<String, String> e : c.leases.entrySet()) {
            if (c.reservations.containsKey(e.getKey())) continue;
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("mac", e.getKey());
            m.put("ip", e.getValue());
            m.put("reserved", false);
            out.add(m);
        }
        return out;
    }

    /** Forget every lease (reservations stay). */
    @LuaFunction(mainThread = true)
    public final void clearDhcpLeases() {
        be.net().leases.clear();
        be.netChanged();
    }

    // ------------------------------------------------------------------ local DNS records

    /** A name that every port in this port's segment can resolve to an address (a router acts as the DNS server of its LAN). */
    @LuaFunction(mainThread = true)
    public final MethodResult addDnsRecord(String name, String ip) {
        String n = name == null ? "" : name.trim().toLowerCase(java.util.Locale.ROOT);
        if (!n.matches("[a-z0-9]([a-z0-9.-]{0,60}[a-z0-9])?")) return MethodResult.of(false, "bad name (letters, digits, dots and dashes)");
        long a = NetConfig.parse(ip);
        if (a < 0) return MethodResult.of(false, "bad address");
        if (be.net().dnsRecords.size() >= 64 && !be.net().dnsRecords.containsKey(n)) return MethodResult.of(false, "too many records (64)");
        be.net().dnsRecords.put(n, NetConfig.format(a));
        be.netChanged();
        return MethodResult.of(true);
    }

    @LuaFunction(mainThread = true)
    public final void removeDnsRecord(String name) {
        String n = name == null ? "" : name.trim().toLowerCase(java.util.Locale.ROOT);
        if (be.net().dnsRecords.remove(n) != null) be.netChanged();
    }

    /** {name, ip} for every local DNS record on this socket. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getDnsRecords() {
        List<Map<String, Object>> out = new ArrayList<>();
        for (Map.Entry<String, String> e : be.net().dnsRecords.entrySet()) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("name", e.getKey());
            m.put("ip", e.getValue());
            out.add(m);
        }
        return out;
    }

    // ------------------------------------------------------------------ firewall

    private static final List<String> FW_ACTIONS = List.of("allow", "reject", "drop");
    private static final List<String> FW_DIRS = List.of("any", "in", "out");
    private static final List<String> FW_PROTOS = List.of("any", "udp", "tcp", "icmp");

    private String fwProblem(String action, String dir, String proto, String src, String dst, int port) {
        if (!FW_ACTIONS.contains(action)) return "action must be allow, reject or drop";
        if (!FW_DIRS.contains(dir)) return "direction must be any, in (from the internet) or out (to the internet)";
        if (!FW_PROTOS.contains(proto)) return "protocol must be any, udp, tcp or icmp";
        if (!NetConfig.validSpec(src) || !NetConfig.validSpec(dst)) return "source and destination are \"any\", an address or a network like 192.168.1.0/24";
        if (port < 0 || port > 65535) return "bad port (0 means any)";
        if (port != 0 && proto.equals("icmp")) return "icmp has no ports";
        if (be.net().rules.size() >= 64) return "too many rules (64)";
        return null;
    }

    private static String lower(String s) {
        return s == null ? "" : s.trim().toLowerCase(java.util.Locale.ROOT);
    }

    /**
     * Adds a firewall rule at the end of the list. Rules are checked in order, the first match decides.
     * action: allow, reject (the sender is told) or drop (silence). direction: any, in (arrives on the uplink) or out (leaves through it).
     * protocol: any, udp, tcp or icmp (ping). src and dst: "any", an address or "a.b.c.d/n". port: destination port, 0 = any.
     * The destination of an "in" rule is the host behind the router (after port forwarding); answers to what a LAN host sent are always let in.
     */
    @LuaFunction(mainThread = true)
    public final MethodResult addFirewallRule(String action, String direction, String protocol, String src, String dst, int port) {
        String a = lower(action), d = lower(direction), p = lower(protocol), s = lower(src), t = lower(dst);
        String err = fwProblem(a, d, p, s, t, port);
        if (err != null) return MethodResult.of(false, err);
        be.net().rules.add(new NetConfig.FwRule(a, d, p, s, t, port));
        be.netChanged();
        return MethodResult.of(true, be.net().rules.size());
    }

    /** Like addFirewallRule, but puts the rule at a position (1 = first). */
    @LuaFunction(mainThread = true)
    public final MethodResult insertFirewallRule(int position, String action, String direction, String protocol, String src, String dst, int port) {
        String a = lower(action), d = lower(direction), p = lower(protocol), s = lower(src), t = lower(dst);
        String err = fwProblem(a, d, p, s, t, port);
        if (err != null) return MethodResult.of(false, err);
        int at = Math.max(1, Math.min(position, be.net().rules.size() + 1)) - 1;
        be.net().rules.add(at, new NetConfig.FwRule(a, d, p, s, t, port));
        be.netChanged();
        return MethodResult.of(true, at + 1);
    }

    @LuaFunction(mainThread = true)
    public final MethodResult removeFirewallRule(int position) {
        if (position < 1 || position > be.net().rules.size()) return MethodResult.of(false, "no such rule");
        be.net().rules.remove(position - 1);
        be.netChanged();
        return MethodResult.of(true);
    }

    @LuaFunction(mainThread = true)
    public final void clearFirewall() {
        be.net().rules.clear();
        be.net().fwPolicy = "allow";
        be.netChanged();
    }

    /** What happens to a packet that no rule matches: allow (the default), reject or drop. */
    @LuaFunction(mainThread = true)
    public final MethodResult setFirewallPolicy(String policy) {
        String p = lower(policy);
        if (!FW_ACTIONS.contains(p)) return MethodResult.of(false, "policy must be allow, reject or drop");
        be.net().fwPolicy = p;
        be.netChanged();
        return MethodResult.of(true);
    }

    @LuaFunction(mainThread = true)
    public final String getFirewallPolicy() {
        return be.net().fwPolicy;
    }

    /** {position, action, direction, protocol, src, dst, port} for every rule, in the order they are checked. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getFirewallRules() {
        List<Map<String, Object>> out = new ArrayList<>();
        int n = 1;
        for (NetConfig.FwRule r : be.net().rules) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("position", n++);
            m.put("action", r.action());
            m.put("direction", r.dir());
            m.put("protocol", r.proto());
            m.put("src", r.src());
            m.put("dst", r.dst());
            m.put("port", r.port());
            out.add(m);
        }
        return out;
    }

    /** How many packets the firewall of this socket stopped since the world was loaded. */
    @LuaFunction(mainThread = true)
    public final int getFirewallBlocked() {
        return be.net().fwBlocked;
    }

    // ------------------------------------------------------------------ Wi-Fi

    /** Is this socket a Wi-Fi Access Point block? */
    @LuaFunction(mainThread = true)
    public final boolean isAccessPoint() {
        return be.isAccessPointBlock();
    }

    private static String ssidProblem(String ssid) {
        if (ssid == null || ssid.trim().isEmpty() || ssid.length() > 32) return "the network name needs 1 to 32 characters";
        for (char ch : ssid.toCharArray()) if (ch < 32 || ch == 127) return "bad character in the network name";
        return null;
    }

    private static String keyProblem(String key) {
        if (key.isEmpty()) return null;
        if (key.length() < 8 || key.length() > 63) return "a password needs 8 to 63 characters (or none, for an open network)";
        for (char ch : key.toCharArray()) if (ch < 32 || ch == 127) return "bad character in the password";
        return null;
    }

    /** Access point: sets the network name and password (leave the password out for an open network). */
    @LuaFunction(mainThread = true)
    public final MethodResult setAccessPoint(String ssid, Optional<String> password) {
        if (!be.isAccessPointBlock()) return MethodResult.of(false, "this socket is not an access point");
        String err = ssidProblem(ssid);
        String key = password.orElse("");
        if (err == null) err = keyProblem(key);
        if (err != null) return MethodResult.of(false, err);
        be.net().apSsid = ssid.trim();
        be.net().apKey = key;
        be.netChanged();
        return MethodResult.of(true);
    }

    /** Access point: how far the radio reaches, in blocks (4 to 64). */
    @LuaFunction(mainThread = true)
    public final MethodResult setWifiRange(int blocks) {
        if (!be.isAccessPointBlock()) return MethodResult.of(false, "this socket is not an access point");
        if (blocks < 4 || blocks > 64) return MethodResult.of(false, "range must be 4 to 64 blocks");
        be.net().apRange = blocks;
        be.netChanged();
        return MethodResult.of(true);
    }

    /** Access point: {ssid, secured, range, clients}. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getAccessPoint() throws LuaException {
        if (!be.isAccessPointBlock()) return null;
        NetConfig c = be.net();
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ssid", c.apSsid);
        m.put("secured", !c.apKey.isEmpty());
        m.put("range", c.apRange);
        m.put("clients", getWifiClients().size());
        return m;
    }

    /** Access point: {mac, ip, signal} of every port connected to it by radio. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> getWifiClients() throws LuaException {
        List<Map<String, Object>> out = new ArrayList<>();
        if (!be.isAccessPointBlock()) return out;
        NetworkManager.Iface ap = iface(1);
        for (NetworkManager.Iface ci : NetworkManager.wifiClientsOf(ap)) {
            PlugSocketBlockEntity cb = NetworkManager.beOf(ci.level(), ci.pos());
            NetworkManager.WifiNet link = NetworkManager.wifiLink(ci);
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("mac", NetworkManager.mac(ci));
            m.put("ip", cb == null ? "" : cb.net().ip(ci.slot()));
            m.put("signal", link == null ? 0 : link.signal());
            out.add(m);
        }
        return out;
    }

    /** The networks this port can hear: {ssid, secured, signal (1-100), distance}. */
    @LuaFunction(mainThread = true)
    public final List<Map<String, Object>> scanWifi(int slot) throws LuaException {
        List<Map<String, Object>> out = new ArrayList<>();
        for (NetworkManager.WifiNet n : NetworkManager.wifiScan(iface(slot))) {
            Map<String, Object> m = new LinkedHashMap<>();
            m.put("ssid", n.ssid());
            m.put("secured", n.secured());
            m.put("signal", n.signal());
            m.put("distance", n.distance());
            out.add(m);
        }
        return out;
    }

    /** Joins a Wi-Fi network by radio (no cable needed). The port stays joined: it reconnects whenever the access point is in range again. */
    @LuaFunction(mainThread = true)
    public final MethodResult joinWifi(int slot, String ssid, Optional<String> password) throws LuaException {
        String err = NetworkManager.joinWifi(iface(slot), ssid == null ? "" : ssid, password.orElse(""));
        return err == null ? MethodResult.of(true) : MethodResult.of(false, err);
    }

    @LuaFunction(mainThread = true)
    public final void leaveWifi(int slot) throws LuaException {
        NetworkManager.leaveWifi(iface(slot));
    }

    /** {ssid, connected, signal, distance} for the network this port joined, or nil when it did not join one. */
    @LuaFunction(mainThread = true)
    public final Map<String, Object> getWifi(int slot) throws LuaException {
        NetworkManager.Iface me = iface(slot);
        String ssid = be.net().wifiSsid(slot - 1);
        if (ssid.isEmpty()) return null;
        NetworkManager.WifiNet link = NetworkManager.wifiLink(me);
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("ssid", ssid);
        m.put("connected", link != null);
        m.put("signal", link == null ? 0 : link.signal());
        m.put("distance", link == null ? 0 : link.distance());
        return m;
    }
}
