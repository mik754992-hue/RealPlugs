package dan200.computercraft.api.lua;

/** COMPILE-TIME STUB of CC: Tweaked's LuaException. Excluded from the released jar. */
public class LuaException extends Exception {
    public LuaException(String message) {
        super(message);
    }
}
