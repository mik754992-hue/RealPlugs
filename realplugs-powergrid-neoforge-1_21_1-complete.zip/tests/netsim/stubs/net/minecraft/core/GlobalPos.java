package net.minecraft.core;
import net.minecraft.server.level.Dim;
public record GlobalPos(Dim dimension, BlockPos pos){ public static GlobalPos of(Dim d, BlockPos p){return new GlobalPos(d,p);} }
