package com.realplugs.cc;

import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.realplugs.ModItems;
import com.realplugs.PlugItem;
import com.realplugs.PlugTypes;
import com.realplugs.PortItem;
import dan200.computercraft.api.peripheral.IPeripheral;
import dan200.computercraft.api.pocket.AbstractPocketUpgrade;
import dan200.computercraft.api.pocket.IPocketAccess;
import dan200.computercraft.api.upgrades.UpgradeType;
import net.minecraft.core.component.DataComponentPatch;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.CustomModelData;
import net.minecraft.world.level.Level;

/**
 * A Real Plugs port as a pocket computer upgrade. Craft it onto a pocket computer, or run pocket.equipBack() with
 * the port item in your inventory. The data files are data/realplugs/computercraft/pocket_upgrade/port_*.json.
 * A plain plug of the port's standard can be plugged in (right-click the pocket computer holding the plug in the
 * other hand) and read from Lua as the "back" peripheral.
 */
public class PortPocketUpgrade extends AbstractPocketUpgrade {
    public static final MapCodec<PortPocketUpgrade> CODEC = Codec.STRING.fieldOf("port").flatXmap(
            name -> {
                for (int i = 1; i < PlugTypes.PLUGS.length; i++) {
                    if (PlugTypes.PLUGS[i].name().equals(name)) return DataResult.success(new PortPocketUpgrade(i));
                }
                return DataResult.error(() -> "Unknown Real Plugs port: " + name);
            },
            up -> DataResult.success(PlugTypes.PLUGS[up.index].name()));

    private static final String PLUG_KEY = "Plug";

    private final int index;

    public PortPocketUpgrade(int index) {
        super(Component.translatable("upgrade.realplugs.port." + PlugTypes.PLUGS[index].name()), portStack(index));
        this.index = index;
    }

    private static ItemStack portStack(int index) {
        ItemStack s = new ItemStack(ModItems.PORT.get());
        s.set(DataComponents.CUSTOM_MODEL_DATA, new CustomModelData(index));
        return s;
    }

    public PlugTypes.Standard standard() {
        return PlugTypes.PLUGS[index].plugs();
    }

    public String portName() {
        return PlugTypes.PLUGS[index].name();
    }

    @Override
    public UpgradeType<? extends dan200.computercraft.api.pocket.IPocketUpgrade> getType() {
        return ModPocketUpgrades.PORT.get();
    }

    /** Only the port of this exact standard (the item alone would match every port). */
    @Override
    public boolean isItemSuitable(ItemStack stack) {
        return stack.getItem() instanceof PortItem && PlugItem.typeOf(stack) == index;
    }

    @Override
    public IPeripheral createPeripheral(IPocketAccess access) {
        return new PortPeripheral(access, this);
    }

    // ---- the plugged-in plug lives in the upgrade data ----

    @Override
    public boolean onRightClick(Level level, IPocketAccess access, IPeripheral peripheral) {
        if (!(access.getEntity() instanceof Player player)) return false;
        ItemStack held = player.getOffhandItem().getItem() instanceof PlugItem ? player.getOffhandItem()
                : player.getMainHandItem().getItem() instanceof PlugItem ? player.getMainHandItem() : ItemStack.EMPTY;
        ItemStack current = readPlug(access);

        if (!held.isEmpty() && held.getItem() instanceof PlugItem pi) {
            if (!level.isClientSide) {
                if (!current.isEmpty()) {
                    player.displayClientMessage(Component.translatable("message.realplugs.port_taken"), true);
                } else if (pi.adapter || PlugItem.plugStandard(held) != standard()) {
                    player.displayClientMessage(Component.translatable("message.realplugs.no_fit",
                            Component.translatable(standard().langKey())), true);
                } else {
                    writePlug(access, PlugItem.takeOne(held, player));
                }
            }
            return true;
        }
        if (!current.isEmpty() && player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                PlugItem.give(player, current);
                writePlug(access, ItemStack.EMPTY);
            }
            return true;
        }
        return false;
    }

    public ItemStack readPlug(IPocketAccess access) {
        var data = access.getUpgradeData().get(DataComponents.CUSTOM_DATA);
        if (data == null || data.isEmpty()) return ItemStack.EMPTY;
        CompoundTag tag = data.get().copyTag();
        if (!tag.contains(PLUG_KEY)) return ItemStack.EMPTY;
        return ItemStack.parseOptional(access.getLevel().registryAccess(), tag.getCompound(PLUG_KEY));
    }

    private void writePlug(IPocketAccess access, ItemStack plug) {
        CompoundTag tag = new CompoundTag();
        if (!plug.isEmpty()) tag.put(PLUG_KEY, plug.save(access.getLevel().registryAccess()));
        access.setUpgradeData(DataComponentPatch.builder().set(DataComponents.CUSTOM_DATA, CustomData.of(tag)).build());
    }
}
