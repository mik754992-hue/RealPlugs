package com.realplugs.net;

import net.minecraft.nbt.CompoundTag;

import java.util.HashMap;
import java.util.Map;

/**
 * Network settings of one socket: one set per slot (each RJ45 slot is its own interface), plus the router and bridge
 * switches that apply to the whole socket. Saved with the block entity.
 */
public final class NetConfig {
    public static final int MAX = 8;

    public final String[] ip = new String[MAX];
    public final int[] prefix = new int[MAX];
    public final String[] gateway = new String[MAX];
    public final boolean[] uplink = new boolean[MAX];
    public final boolean[] dhcp = new boolean[MAX];
    public final String[] hostname = new String[MAX];
    /** Forward packets between this socket's interfaces (a router). */
    public boolean routing;
    /** All RJ45 slots of this socket form one segment (a switch). */
    public boolean bridge;
    /** The Network Router block has had its factory settings applied. */
    public boolean configured;
    /** Port forwarding of a router: public port -> "ip:port" of a private host. */
    public final Map<Integer, String> forwards = new HashMap<>();

    /** NAT table of a router, not saved: private "ip:port" -> public port, and back. */
    public final Map<String, Integer> natOut = new HashMap<>();
    public final Map<Integer, String> natIn = new HashMap<>();
    public int nextNatPort = 49152;

    public String ip(int slot) {
        return ip[slot] == null ? "" : ip[slot];
    }

    public String hostname(int slot) {
        return hostname[slot] == null ? "" : hostname[slot];
    }

    public String gateway(int slot) {
        return gateway[slot] == null ? "" : gateway[slot];
    }

    public boolean isEmpty() {
        if (routing || bridge || configured || !forwards.isEmpty()) return false;
        for (int i = 0; i < MAX; i++) {
            if (!ip(i).isEmpty() || !gateway(i).isEmpty() || uplink[i] || dhcp[i] || !hostname(i).isEmpty()) return false;
        }
        return true;
    }

    public CompoundTag save() {
        CompoundTag t = new CompoundTag();
        t.putBoolean("Routing", routing);
        t.putBoolean("Bridge", bridge);
        t.putBoolean("Configured", configured);
        CompoundTag fwd = new CompoundTag();
        for (Map.Entry<Integer, String> e : forwards.entrySet()) fwd.putString(Integer.toString(e.getKey()), e.getValue());
        t.put("Fwd", fwd);
        for (int i = 0; i < MAX; i++) {
            if (ip(i).isEmpty() && gateway(i).isEmpty() && !uplink[i] && !dhcp[i] && hostname(i).isEmpty()) continue;
            CompoundTag s = new CompoundTag();
            s.putString("Ip", ip(i));
            s.putInt("Prefix", prefix[i]);
            s.putString("Gw", gateway(i));
            s.putBoolean("Uplink", uplink[i]);
            s.putBoolean("Dhcp", dhcp[i]);
            s.putString("Host", hostname(i));
            t.put("S" + i, s);
        }
        return t;
    }

    public void load(CompoundTag t) {
        routing = t.getBoolean("Routing");
        bridge = t.getBoolean("Bridge");
        configured = t.getBoolean("Configured");
        forwards.clear();
        CompoundTag fwd = t.getCompound("Fwd");
        for (String k : fwd.getAllKeys()) {
            try {
                forwards.put(Integer.parseInt(k), fwd.getString(k));
            } catch (NumberFormatException ignored) {
                // a damaged entry is dropped
            }
        }
        for (int i = 0; i < MAX; i++) {
            if (!t.contains("S" + i)) continue;
            CompoundTag s = t.getCompound("S" + i);
            ip[i] = s.getString("Ip");
            prefix[i] = s.getInt("Prefix");
            gateway[i] = s.getString("Gw");
            uplink[i] = s.getBoolean("Uplink");
            dhcp[i] = s.getBoolean("Dhcp");
            hostname[i] = s.getString("Host");
        }
    }

    // ---- IPv4 helpers ----

    /** "a.b.c.d" to a number, or -1. */
    public static long parse(String s) {
        if (s == null || s.isEmpty()) return -1;
        String[] p = s.trim().split("\\.");
        if (p.length != 4) return -1;
        long v = 0;
        for (String x : p) {
            int n;
            try {
                n = Integer.parseInt(x);
            } catch (NumberFormatException e) {
                return -1;
            }
            if (n < 0 || n > 255) return -1;
            v = (v << 8) | n;
        }
        return v;
    }

    public static String format(long v) {
        return ((v >> 24) & 255) + "." + ((v >> 16) & 255) + "." + ((v >> 8) & 255) + "." + (v & 255);
    }

    /** Are both addresses in the same network of this prefix length (1..32)? */
    public static boolean sameSubnet(long a, long b, int prefix) {
        if (prefix < 1 || prefix > 32) return false;
        long mask = prefix == 32 ? 0xFFFFFFFFL : (0xFFFFFFFFL << (32 - prefix)) & 0xFFFFFFFFL;
        return (a & mask) == (b & mask);
    }
}
